var _i = (c) => {
  throw TypeError(c);
};
var js = (c, t, e) => t.has(c) || _i("Cannot " + e);
var dt = (c, t, e) => (js(c, t, "read from private field"), e ? e.call(c) : t.get(c)), Qt = (c, t, e) => t.has(c) ? _i("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(c) : t.set(c, e), Dt = (c, t, e, s) => (js(c, t, "write to private field"), s ? s.call(c, e) : t.set(c, e), e), Zt = (c, t, e) => (js(c, t, "access private method"), e);
var Ui = (c, t, e, s) => ({
  set _(i) {
    Dt(c, t, i, e);
  },
  get _() {
    return dt(c, t, s);
  }
});
var er = {
  /***/
  9306(c, t, e) {
    var s = e(4901), i = e(6823), n = TypeError;
    c.exports = function(r) {
      if (s(r)) return r;
      throw new n(i(r) + " is not a function");
    };
  },
  /***/
  3506(c, t, e) {
    var s = e(3925), i = String, n = TypeError;
    c.exports = function(r) {
      if (s(r)) return r;
      throw new n("Can't set " + i(r) + " as a prototype");
    };
  },
  /***/
  7080(c, t, e) {
    var s = e(4402).has;
    c.exports = function(i) {
      return s(i), i;
    };
  },
  /***/
  3463(c) {
    var t = TypeError;
    c.exports = function(e) {
      if (typeof e == "string") return e;
      throw new t("Argument is not a string");
    };
  },
  /***/
  4328(c, t, e) {
    var s = e(4995), i = new s.WeakMap(), n = s.set, r = s.remove;
    c.exports = function(a) {
      return n(i, a, 1), r(i, a), a;
    };
  },
  /***/
  6557(c, t, e) {
    var s = e(4995).has;
    c.exports = function(i) {
      return s(i), i;
    };
  },
  /***/
  6469(c, t, e) {
    var s = e(8227), i = e(2360), n = e(4913).f, r = s("unscopables"), a = Array.prototype;
    a[r] === void 0 && n(a, r, {
      configurable: !0,
      value: i(null)
    }), c.exports = function(o) {
      a[r][o] = !0;
    };
  },
  /***/
  679(c, t, e) {
    var s = e(1625), i = TypeError;
    c.exports = function(n, r) {
      if (s(r, n)) return n;
      throw new i("Incorrect invocation");
    };
  },
  /***/
  3972(c, t, e) {
    var s = e(34), i = String, n = TypeError;
    c.exports = function(r) {
      if (r === void 0 || s(r)) return r;
      throw new n(i(r) + " is not an object or undefined");
    };
  },
  /***/
  8551(c, t, e) {
    var s = e(34), i = String, n = TypeError;
    c.exports = function(r) {
      if (s(r)) return r;
      throw new n(i(r) + " is not an object");
    };
  },
  /***/
  4154(c, t, e) {
    var s = e(6955), i = TypeError;
    c.exports = function(n) {
      if (s(n) === "Uint8Array") return n;
      throw new i("Argument is not an Uint8Array");
    };
  },
  /***/
  7811(c) {
    c.exports = typeof ArrayBuffer < "u" && typeof DataView < "u";
  },
  /***/
  7394(c, t, e) {
    var s = e(4576), i = e(6706), n = e(2195), r = s.ArrayBuffer, a = s.TypeError;
    c.exports = r && i(r.prototype, "byteLength", "get") || function(o) {
      if (n(o) !== "ArrayBuffer") throw new a("ArrayBuffer expected");
      return o.byteLength;
    };
  },
  /***/
  3238(c, t, e) {
    var s = e(4576), i = e(7811), n = e(7394), r = s.DataView;
    c.exports = function(a) {
      if (!i || n(a) !== 0) return !1;
      try {
        return new r(a), !1;
      } catch {
        return !0;
      }
    };
  },
  /***/
  5169(c, t, e) {
    var s = e(3238), i = TypeError;
    c.exports = function(n) {
      if (s(n)) throw new i("ArrayBuffer is detached");
      return n;
    };
  },
  /***/
  4644(c, t, e) {
    var s = e(7811), i = e(3724), n = e(4576), r = e(4901), a = e(34), o = e(9297), l = e(6955), h = e(6823), d = e(6699), u = e(6840), f = e(2106), p = e(1625), g = e(2787), m = e(2967), v = e(8227), y = e(3392), b = e(1181), w = b.enforce, A = b.get, S = n.Int8Array, E = S && S.prototype, T = n.Uint8ClampedArray, x = T && T.prototype, P = S && g(S), C = E && g(E), I = Object.prototype, R = n.TypeError, D = v("toStringTag"), _ = y("TYPED_ARRAY_TAG"), M = "TypedArrayConstructor", k = s && !!m && l(n.opera) !== "Opera", $ = !1, U, tt, vt, Y = {
      Int8Array: 1,
      Uint8Array: 1,
      Uint8ClampedArray: 1,
      Int16Array: 2,
      Uint16Array: 2,
      Int32Array: 4,
      Uint32Array: 4,
      Float32Array: 4,
      Float64Array: 8
    }, J = {
      BigInt64Array: 8,
      BigUint64Array: 8
    }, rt = function(Q) {
      if (!a(Q)) return !1;
      var ot = l(Q);
      return ot === "DataView" || o(Y, ot) || o(J, ot);
    }, Rt = function(G) {
      var Q = g(G);
      if (a(Q)) {
        var ot = A(Q);
        return ot && o(ot, M) ? ot[M] : Rt(Q);
      }
    }, F = function(G) {
      if (!a(G)) return !1;
      var Q = l(G);
      return o(Y, Q) || o(J, Q);
    }, O = function(G) {
      if (F(G)) return G;
      throw new R("Target is not a typed array");
    }, L = function(G) {
      if (r(G) && (!m || p(P, G))) return G;
      throw new R(h(G) + " is not a typed array constructor");
    }, W = function(G, Q, ot, xt) {
      if (i) {
        if (ot) for (var Tt in Y) {
          var yt = n[Tt];
          if (yt && o(yt.prototype, G)) try {
            delete yt.prototype[G];
          } catch {
            try {
              yt.prototype[G] = Q;
            } catch {
            }
          }
        }
        (!C[G] || ot) && u(C, G, ot ? Q : k && E[G] || Q, xt);
      }
    }, it = function(G, Q, ot) {
      var xt, Tt;
      if (i) {
        if (m) {
          if (ot) {
            for (xt in Y)
              if (Tt = n[xt], Tt && o(Tt, G)) try {
                delete Tt[G];
              } catch {
              }
          }
          if (!P[G] || ot)
            try {
              return u(P, G, ot ? Q : k && P[G] || Q);
            } catch {
            }
          else return;
        }
        for (xt in Y)
          Tt = n[xt], Tt && (!Tt[G] || ot) && u(Tt, G, Q);
      }
    };
    for (U in Y)
      tt = n[U], vt = tt && tt.prototype, vt ? w(vt)[M] = tt : k = !1;
    for (U in J)
      tt = n[U], vt = tt && tt.prototype, vt && (w(vt)[M] = tt);
    if ((!k || !r(P) || P === Function.prototype) && (P = function() {
      throw new R("Incorrect invocation");
    }, k))
      for (U in Y)
        n[U] && m(n[U], P);
    if ((!k || !C || C === I) && (C = P.prototype, k))
      for (U in Y)
        n[U] && m(n[U].prototype, C);
    if (k && g(x) !== C && m(x, C), i && !o(C, D)) {
      $ = !0, f(C, D, {
        configurable: !0,
        get: function() {
          return a(this) ? this[_] : void 0;
        }
      });
      for (U in Y) n[U] && d(n[U].prototype, _, U);
    }
    c.exports = {
      NATIVE_ARRAY_BUFFER_VIEWS: k,
      TYPED_ARRAY_TAG: $ && _,
      aTypedArray: O,
      aTypedArrayConstructor: L,
      exportTypedArrayMethod: W,
      exportTypedArrayStaticMethod: it,
      getTypedArrayConstructor: Rt,
      isView: rt,
      isTypedArray: F,
      TypedArray: P,
      TypedArrayPrototype: C
    };
  },
  /***/
  5370(c, t, e) {
    var s = e(6198);
    c.exports = function(i, n, r) {
      for (var a = 0, o = arguments.length > 2 ? r : s(n), l = new i(o); o > a; ) l[a] = n[a++];
      return l;
    };
  },
  /***/
  9617(c, t, e) {
    var s = e(5397), i = e(5610), n = e(6198), r = function(a) {
      return function(o, l, h) {
        var d = s(o), u = n(d);
        if (u === 0) return !a && -1;
        var f = i(h, u), p;
        if (a && l !== l) {
          for (; u > f; )
            if (p = d[f++], p !== p) return !0;
        } else for (; u > f; f++)
          if ((a || f in d) && d[f] === l) return a || f || 0;
        return !a && -1;
      };
    };
    c.exports = {
      // `Array.prototype.includes` method
      // https://tc39.es/ecma262/#sec-array.prototype.includes
      includes: r(!0),
      // `Array.prototype.indexOf` method
      // https://tc39.es/ecma262/#sec-array.prototype.indexof
      indexOf: r(!1)
    };
  },
  /***/
  4527(c, t, e) {
    var s = e(3724), i = e(4376), n = TypeError, r = Object.getOwnPropertyDescriptor, a = s && !(function() {
      if (this !== void 0) return !0;
      try {
        Object.defineProperty([], "length", { writable: !1 }).length = 1;
      } catch (o) {
        return o instanceof TypeError;
      }
    })();
    c.exports = a ? function(o, l) {
      if (i(o) && !r(o, "length").writable)
        throw new n("Cannot set read only .length");
      return o.length = l;
    } : function(o, l) {
      return o.length = l;
    };
  },
  /***/
  7680(c, t, e) {
    var s = e(9504);
    c.exports = s([].slice);
  },
  /***/
  2804(c) {
    var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", e = t + "+/", s = t + "-_", i = function(n) {
      for (var r = {}, a = 0; a < 64; a++) r[n.charAt(a)] = a;
      return r;
    };
    c.exports = {
      i2c: e,
      c2i: i(e),
      i2cUrl: s,
      c2iUrl: i(s)
    };
  },
  /***/
  6319(c, t, e) {
    var s = e(8551), i = e(9539);
    c.exports = function(n, r, a, o) {
      try {
        return o ? r(s(a)[0], a[1]) : r(a);
      } catch (l) {
        i(n, "throw", l);
      }
    };
  },
  /***/
  2195(c, t, e) {
    var s = e(9504), i = s({}.toString), n = s("".slice);
    c.exports = function(r) {
      return n(i(r), 8, -1);
    };
  },
  /***/
  6955(c, t, e) {
    var s = e(2140), i = e(4901), n = e(2195), r = e(8227), a = r("toStringTag"), o = Object, l = n(/* @__PURE__ */ (function() {
      return arguments;
    })()) === "Arguments", h = function(d, u) {
      try {
        return d[u];
      } catch {
      }
    };
    c.exports = s ? n : function(d) {
      var u, f, p;
      return d === void 0 ? "Undefined" : d === null ? "Null" : typeof (f = h(u = o(d), a)) == "string" ? f : l ? n(u) : (p = n(u)) === "Object" && i(u.callee) ? "Arguments" : p;
    };
  },
  /***/
  7740(c, t, e) {
    var s = e(9297), i = e(5031), n = e(7347), r = e(4913);
    c.exports = function(a, o, l) {
      for (var h = i(o), d = r.f, u = n.f, f = 0; f < h.length; f++) {
        var p = h[f];
        !s(a, p) && !(l && s(l, p)) && d(a, p, u(o, p));
      }
    };
  },
  /***/
  2211(c, t, e) {
    var s = e(9039);
    c.exports = !s(function() {
      function i() {
      }
      return i.prototype.constructor = null, Object.getPrototypeOf(new i()) !== i.prototype;
    });
  },
  /***/
  2529(c) {
    c.exports = function(t, e) {
      return { value: t, done: e };
    };
  },
  /***/
  6699(c, t, e) {
    var s = e(3724), i = e(4913), n = e(6980);
    c.exports = s ? function(r, a, o) {
      return i.f(r, a, n(1, o));
    } : function(r, a, o) {
      return r[a] = o, r;
    };
  },
  /***/
  6980(c) {
    c.exports = function(t, e) {
      return {
        enumerable: !(t & 1),
        configurable: !(t & 2),
        writable: !(t & 4),
        value: e
      };
    };
  },
  /***/
  4659(c, t, e) {
    var s = e(3724), i = e(4913), n = e(6980);
    c.exports = function(r, a, o) {
      s ? i.f(r, a, n(0, o)) : r[a] = o;
    };
  },
  /***/
  2106(c, t, e) {
    var s = e(283), i = e(4913);
    c.exports = function(n, r, a) {
      return a.get && s(a.get, r, { getter: !0 }), a.set && s(a.set, r, { setter: !0 }), i.f(n, r, a);
    };
  },
  /***/
  6840(c, t, e) {
    var s = e(4901), i = e(4913), n = e(283), r = e(9433);
    c.exports = function(a, o, l, h) {
      h || (h = {});
      var d = h.enumerable, u = h.name !== void 0 ? h.name : o;
      if (s(l) && n(l, u, h), h.global)
        d ? a[o] = l : r(o, l);
      else {
        try {
          h.unsafe ? a[o] && (d = !0) : delete a[o];
        } catch {
        }
        d ? a[o] = l : i.f(a, o, {
          value: l,
          enumerable: !1,
          configurable: !h.nonConfigurable,
          writable: !h.nonWritable
        });
      }
      return a;
    };
  },
  /***/
  6279(c, t, e) {
    var s = e(6840);
    c.exports = function(i, n, r) {
      for (var a in n) s(i, a, n[a], r);
      return i;
    };
  },
  /***/
  9433(c, t, e) {
    var s = e(4576), i = Object.defineProperty;
    c.exports = function(n, r) {
      try {
        i(s, n, { value: r, configurable: !0, writable: !0 });
      } catch {
        s[n] = r;
      }
      return r;
    };
  },
  /***/
  3724(c, t, e) {
    var s = e(9039);
    c.exports = !s(function() {
      return Object.defineProperty({}, 1, { get: function() {
        return 7;
      } })[1] !== 7;
    });
  },
  /***/
  4055(c, t, e) {
    var s = e(4576), i = e(34), n = s.document, r = i(n) && i(n.createElement);
    c.exports = function(a) {
      return r ? n.createElement(a) : {};
    };
  },
  /***/
  6837(c) {
    var t = TypeError, e = 9007199254740991;
    c.exports = function(s) {
      if (s > e) throw new t("Maximum allowed index exceeded");
      return s;
    };
  },
  /***/
  5002(c) {
    c.exports = {
      IndexSizeError: { s: "INDEX_SIZE_ERR", c: 1, m: 1 },
      DOMStringSizeError: { s: "DOMSTRING_SIZE_ERR", c: 2, m: 0 },
      HierarchyRequestError: { s: "HIERARCHY_REQUEST_ERR", c: 3, m: 1 },
      WrongDocumentError: { s: "WRONG_DOCUMENT_ERR", c: 4, m: 1 },
      InvalidCharacterError: { s: "INVALID_CHARACTER_ERR", c: 5, m: 1 },
      NoDataAllowedError: { s: "NO_DATA_ALLOWED_ERR", c: 6, m: 0 },
      NoModificationAllowedError: { s: "NO_MODIFICATION_ALLOWED_ERR", c: 7, m: 1 },
      NotFoundError: { s: "NOT_FOUND_ERR", c: 8, m: 1 },
      NotSupportedError: { s: "NOT_SUPPORTED_ERR", c: 9, m: 1 },
      InUseAttributeError: { s: "INUSE_ATTRIBUTE_ERR", c: 10, m: 1 },
      InvalidStateError: { s: "INVALID_STATE_ERR", c: 11, m: 1 },
      SyntaxError: { s: "SYNTAX_ERR", c: 12, m: 1 },
      InvalidModificationError: { s: "INVALID_MODIFICATION_ERR", c: 13, m: 1 },
      NamespaceError: { s: "NAMESPACE_ERR", c: 14, m: 1 },
      InvalidAccessError: { s: "INVALID_ACCESS_ERR", c: 15, m: 1 },
      ValidationError: { s: "VALIDATION_ERR", c: 16, m: 0 },
      TypeMismatchError: { s: "TYPE_MISMATCH_ERR", c: 17, m: 1 },
      SecurityError: { s: "SECURITY_ERR", c: 18, m: 1 },
      NetworkError: { s: "NETWORK_ERR", c: 19, m: 1 },
      AbortError: { s: "ABORT_ERR", c: 20, m: 1 },
      URLMismatchError: { s: "URL_MISMATCH_ERR", c: 21, m: 1 },
      QuotaExceededError: { s: "QUOTA_EXCEEDED_ERR", c: 22, m: 1 },
      TimeoutError: { s: "TIMEOUT_ERR", c: 23, m: 1 },
      InvalidNodeTypeError: { s: "INVALID_NODE_TYPE_ERR", c: 24, m: 1 },
      DataCloneError: { s: "DATA_CLONE_ERR", c: 25, m: 1 }
    };
  },
  /***/
  8727(c) {
    c.exports = [
      "constructor",
      "hasOwnProperty",
      "isPrototypeOf",
      "propertyIsEnumerable",
      "toLocaleString",
      "toString",
      "valueOf"
    ];
  },
  /***/
  2839(c, t, e) {
    var s = e(4576), i = s.navigator, n = i && i.userAgent;
    c.exports = n ? String(n) : "";
  },
  /***/
  9519(c, t, e) {
    var s = e(4576), i = e(2839), n = s.process, r = s.Deno, a = n && n.versions || r && r.version, o = a && a.v8, l, h;
    o && (l = o.split("."), h = l[0] > 0 && l[0] < 4 ? 1 : +(l[0] + l[1])), !h && i && (l = i.match(/Edge\/(\d+)/), (!l || l[1] >= 74) && (l = i.match(/Chrome\/(\d+)/), l && (h = +l[1]))), c.exports = h;
  },
  /***/
  6193(c, t, e) {
    var s = e(9504), i = Error, n = s("".replace), r = (function(l) {
      return String(new i(l).stack);
    })("zxcasd"), a = /\n\s*at [^:]*:[^\n]*/, o = a.test(r);
    c.exports = function(l, h) {
      if (o && typeof l == "string" && !i.prepareStackTrace)
        for (; h--; ) l = n(l, a, "");
      return l;
    };
  },
  /***/
  6518(c, t, e) {
    var s = e(4576), i = e(7347).f, n = e(6699), r = e(6840), a = e(9433), o = e(7740), l = e(2796);
    c.exports = function(h, d) {
      var u = h.target, f = h.global, p = h.stat, g, m, v, y, b, w;
      if (f ? m = s : p ? m = s[u] || a(u, {}) : m = s[u] && s[u].prototype, m) for (v in d) {
        if (b = d[v], h.dontCallGetSet ? (w = i(m, v), y = w && w.value) : y = m[v], g = l(f ? v : u + (p ? "." : "#") + v, h.forced), !g && y !== void 0) {
          if (typeof b == typeof y) continue;
          o(b, y);
        }
        (h.sham || y && y.sham) && n(b, "sham", !0), r(m, v, b, h);
      }
    };
  },
  /***/
  9039(c) {
    c.exports = function(t) {
      try {
        return !!t();
      } catch {
        return !0;
      }
    };
  },
  /***/
  8745(c, t, e) {
    var s = e(616), i = Function.prototype, n = i.apply, r = i.call;
    c.exports = typeof Reflect == "object" && Reflect.apply || (s ? r.bind(n) : function() {
      return r.apply(n, arguments);
    });
  },
  /***/
  6080(c, t, e) {
    var s = e(7476), i = e(9306), n = e(616), r = s(s.bind);
    c.exports = function(a, o) {
      return i(a), o === void 0 ? a : n ? r(a, o) : function() {
        return a.apply(o, arguments);
      };
    };
  },
  /***/
  616(c, t, e) {
    var s = e(9039);
    c.exports = !s(function() {
      var i = (function() {
      }).bind();
      return typeof i != "function" || i.hasOwnProperty("prototype");
    });
  },
  /***/
  9565(c, t, e) {
    var s = e(616), i = Function.prototype.call;
    c.exports = s ? i.bind(i) : function() {
      return i.apply(i, arguments);
    };
  },
  /***/
  350(c, t, e) {
    var s = e(3724), i = e(9297), n = Function.prototype, r = s && Object.getOwnPropertyDescriptor, a = i(n, "name"), o = a && (function() {
    }).name === "something", l = a && (!s || s && r(n, "name").configurable);
    c.exports = {
      EXISTS: a,
      PROPER: o,
      CONFIGURABLE: l
    };
  },
  /***/
  6706(c, t, e) {
    var s = e(9504), i = e(9306);
    c.exports = function(n, r, a) {
      try {
        return s(i(Object.getOwnPropertyDescriptor(n, r)[a]));
      } catch {
      }
    };
  },
  /***/
  7476(c, t, e) {
    var s = e(2195), i = e(9504);
    c.exports = function(n) {
      if (s(n) === "Function") return i(n);
    };
  },
  /***/
  9504(c, t, e) {
    var s = e(616), i = Function.prototype, n = i.call, r = s && i.bind.bind(n, n);
    c.exports = s ? r : function(a) {
      return function() {
        return n.apply(a, arguments);
      };
    };
  },
  /***/
  944(c) {
    var t = TypeError;
    c.exports = function(e) {
      var s = e && e.alphabet;
      if (s === void 0 || s === "base64" || s === "base64url") return s || "base64";
      throw new t("Incorrect `alphabet` option");
    };
  },
  /***/
  7751(c, t, e) {
    var s = e(4576), i = e(4901), n = function(r) {
      return i(r) ? r : void 0;
    };
    c.exports = function(r, a) {
      return arguments.length < 2 ? n(s[r]) : s[r] && s[r][a];
    };
  },
  /***/
  1767(c) {
    c.exports = function(t) {
      return {
        iterator: t,
        next: t.next,
        done: !1
      };
    };
  },
  /***/
  8646(c, t, e) {
    var s = e(9565), i = e(8551), n = e(1767), r = e(3085);
    c.exports = function(a, o) {
      (!o || typeof a != "string") && i(a);
      var l = r(a);
      return n(i(l !== void 0 ? s(l, a) : a));
    };
  },
  /***/
  8563(c, t, e) {
    var s = e(9565), i = e(4901), n = e(8551), r = e(6823), a = e(3085), o = TypeError;
    c.exports = function(l, h) {
      var d = arguments.length < 2 ? a(l) : h;
      if (i(d)) return n(s(d, l));
      throw new o(r(l) + " is not iterable");
    };
  },
  /***/
  3085(c, t, e) {
    var s = e(2195), i = e(4117), n = e(5966), r = e(8227), a = r("iterator"), o = Array.prototype;
    c.exports = function(l) {
      if (!i(l)) return n(l, a) || n(l, "@@iterator") || (s(l) === "Arguments" ? o[a] : void 0);
    };
  },
  /***/
  5966(c, t, e) {
    var s = e(9306), i = e(4117);
    c.exports = function(n, r) {
      var a = n[r];
      return i(a) ? void 0 : s(a);
    };
  },
  /***/
  3789(c, t, e) {
    var s = e(9306), i = e(8551), n = e(9565), r = e(1291), a = e(1767), o = "Invalid size", l = RangeError, h = TypeError, d = Math.max, u = function(f, p) {
      this.set = f, this.size = d(p, 0), this.has = s(f.has), this.keys = s(f.keys);
    };
    u.prototype = {
      getIterator: function() {
        return a(i(n(this.keys, this.set)));
      },
      includes: function(f) {
        return n(this.has, this.set, f);
      }
    }, c.exports = function(f) {
      i(f);
      var p = +f.size;
      if (p !== p) throw new h(o);
      var g = r(p);
      if (g < 0) throw new l(o);
      return new u(f, g);
    };
  },
  /***/
  4576(c) {
    var t = function(e) {
      return e && e.Math === Math && e;
    };
    c.exports = // eslint-disable-next-line es/no-global-this -- safe
    t(typeof globalThis == "object" && globalThis) || t(typeof window == "object" && window) || // eslint-disable-next-line no-restricted-globals -- safe
    t(typeof self == "object" && self) || t(typeof global == "object" && global) || t(typeof this == "object" && this) || // eslint-disable-next-line no-new-func -- fallback
    /* @__PURE__ */ (function() {
      return this;
    })() || Function("return this")();
  },
  /***/
  9297(c, t, e) {
    var s = e(9504), i = e(8981), n = s({}.hasOwnProperty);
    c.exports = Object.hasOwn || function(a, o) {
      return n(i(a), o);
    };
  },
  /***/
  421(c) {
    c.exports = {};
  },
  /***/
  397(c, t, e) {
    var s = e(7751);
    c.exports = s("document", "documentElement");
  },
  /***/
  5917(c, t, e) {
    var s = e(3724), i = e(9039), n = e(4055);
    c.exports = !s && !i(function() {
      return Object.defineProperty(n("div"), "a", {
        get: function() {
          return 7;
        }
      }).a !== 7;
    });
  },
  /***/
  7055(c, t, e) {
    var s = e(9504), i = e(9039), n = e(2195), r = Object, a = s("".split);
    c.exports = i(function() {
      return !r("z").propertyIsEnumerable(0);
    }) ? function(o) {
      return n(o) === "String" ? a(o, "") : r(o);
    } : r;
  },
  /***/
  3167(c, t, e) {
    var s = e(4901), i = e(34), n = e(2967);
    c.exports = function(r, a, o) {
      var l, h;
      return (
        // it can work only with native `setPrototypeOf`
        n && // we haven't completely correct pre-ES6 way for getting `new.target`, so use this
        s(l = a.constructor) && l !== o && i(h = l.prototype) && h !== o.prototype && n(r, h), r
      );
    };
  },
  /***/
  3706(c, t, e) {
    var s = e(9504), i = e(4901), n = e(7629), r = s(Function.toString);
    i(n.inspectSource) || (n.inspectSource = function(a) {
      return r(a);
    }), c.exports = n.inspectSource;
  },
  /***/
  1181(c, t, e) {
    var s = e(8622), i = e(4576), n = e(34), r = e(6699), a = e(9297), o = e(7629), l = e(6119), h = e(421), d = "Object already initialized", u = i.TypeError, f = i.WeakMap, p, g, m, v = function(A) {
      return m(A) ? g(A) : p(A, {});
    }, y = function(A) {
      return function(S) {
        var E;
        if (!n(S) || (E = g(S)).type !== A)
          throw new u("Incompatible receiver, " + A + " required");
        return E;
      };
    };
    if (s || o.state) {
      var b = o.state || (o.state = new f());
      b.get = b.get, b.has = b.has, b.set = b.set, p = function(A, S) {
        if (b.has(A)) throw new u(d);
        return S.facade = A, b.set(A, S), S;
      }, g = function(A) {
        return b.get(A) || {};
      }, m = function(A) {
        return b.has(A);
      };
    } else {
      var w = l("state");
      h[w] = !0, p = function(A, S) {
        if (a(A, w)) throw new u(d);
        return S.facade = A, r(A, w, S), S;
      }, g = function(A) {
        return a(A, w) ? A[w] : {};
      }, m = function(A) {
        return a(A, w);
      };
    }
    c.exports = {
      set: p,
      get: g,
      has: m,
      enforce: v,
      getterFor: y
    };
  },
  /***/
  4209(c, t, e) {
    var s = e(8227), i = e(6269), n = s("iterator"), r = Array.prototype;
    c.exports = function(a) {
      return a !== void 0 && (i.Array === a || r[n] === a);
    };
  },
  /***/
  4376(c, t, e) {
    var s = e(2195);
    c.exports = Array.isArray || function(n) {
      return s(n) === "Array";
    };
  },
  /***/
  1108(c, t, e) {
    var s = e(6955);
    c.exports = function(i) {
      var n = s(i);
      return n === "BigInt64Array" || n === "BigUint64Array";
    };
  },
  /***/
  4901(c) {
    var t = typeof document == "object" && document.all;
    c.exports = typeof t > "u" && t !== void 0 ? function(e) {
      return typeof e == "function" || e === t;
    } : function(e) {
      return typeof e == "function";
    };
  },
  /***/
  2796(c, t, e) {
    var s = e(9039), i = e(4901), n = /#|\.prototype\./, r = function(d, u) {
      var f = o[a(d)];
      return f === h ? !0 : f === l ? !1 : i(u) ? s(u) : !!u;
    }, a = r.normalize = function(d) {
      return String(d).replace(n, ".").toLowerCase();
    }, o = r.data = {}, l = r.NATIVE = "N", h = r.POLYFILL = "P";
    c.exports = r;
  },
  /***/
  4117(c) {
    c.exports = function(t) {
      return t == null;
    };
  },
  /***/
  34(c, t, e) {
    var s = e(4901);
    c.exports = function(i) {
      return typeof i == "object" ? i !== null : s(i);
    };
  },
  /***/
  3925(c, t, e) {
    var s = e(34);
    c.exports = function(i) {
      return s(i) || i === null;
    };
  },
  /***/
  6395(c) {
    c.exports = !1;
  },
  /***/
  5810(c, t, e) {
    var s = e(34), i = e(1181).get;
    c.exports = function(r) {
      if (!s(r)) return !1;
      var a = i(r);
      return !!a && a.type === "RawJSON";
    };
  },
  /***/
  757(c, t, e) {
    var s = e(7751), i = e(4901), n = e(1625), r = e(7040), a = Object;
    c.exports = r ? function(o) {
      return typeof o == "symbol";
    } : function(o) {
      var l = s("Symbol");
      return i(l) && n(l.prototype, a(o));
    };
  },
  /***/
  507(c, t, e) {
    var s = e(9565);
    c.exports = function(i, n, r) {
      for (var a = r ? i : i.iterator, o = i.next, l, h; !(l = s(o, a)).done; )
        if (h = n(l.value), h !== void 0) return h;
    };
  },
  /***/
  2652(c, t, e) {
    var s = e(6080), i = e(9565), n = e(8551), r = e(6823), a = e(4209), o = e(6198), l = e(1625), h = e(8563), d = e(3085), u = e(9539), f = TypeError, p = function(m, v) {
      this.stopped = m, this.result = v;
    }, g = p.prototype;
    c.exports = function(m, v, y) {
      var b = y && y.that, w = !!(y && y.AS_ENTRIES), A = !!(y && y.IS_RECORD), S = !!(y && y.IS_ITERATOR), E = !!(y && y.INTERRUPTED), T = s(v, b), x, P, C, I, R, D, _, M = function(U) {
        var tt = x;
        return x = void 0, tt && u(tt, "normal"), new p(!0, U);
      }, k = function(U) {
        return w ? (n(U), E ? T(U[0], U[1], M) : T(U[0], U[1])) : E ? T(U, M) : T(U);
      };
      if (A)
        x = m.iterator;
      else if (S)
        x = m;
      else {
        if (P = d(m), !P) throw new f(r(m) + " is not iterable");
        if (a(P)) {
          for (C = 0, I = o(m); I > C; C++)
            if (R = k(m[C]), R && l(g, R)) return R;
          return new p(!1);
        }
        x = h(m, P);
      }
      for (D = A ? m.next : x.next; !(_ = i(D, x)).done; ) {
        var $ = _.value;
        try {
          R = k($);
        } catch (U) {
          if (x) u(x, "throw", U);
          else throw U;
        }
        if (typeof R == "object" && R && l(g, R)) return R;
      }
      return new p(!1);
    };
  },
  /***/
  6859(c) {
    c.exports = function(t) {
      t.iterator = t.next = t.nextHandler = t.mapper = t.predicate = t.inner = t.iterables = t.iters = t.openIters = t.padding = t.finishResults = t.buffer = null;
    };
  },
  /***/
  1385(c, t, e) {
    var s = e(9539);
    c.exports = function(i, n, r) {
      for (var a = i.length - 1; a >= 0; a--)
        if (i[a] !== void 0)
          try {
            r = s(i[a].iterator, n, r);
          } catch (o) {
            n = "throw", r = o;
          }
      if (n === "throw") throw r;
      return r;
    };
  },
  /***/
  9539(c, t, e) {
    var s = e(9565), i = e(8551), n = e(5966);
    c.exports = function(r, a, o) {
      var l, h;
      i(r);
      try {
        if (l = n(r, "return"), !l) {
          if (a === "throw") throw o;
          return o;
        }
        l = s(l, r);
      } catch (d) {
        h = !0, l = d;
      }
      if (a === "throw") throw o;
      if (h) throw l;
      return i(l), o;
    };
  },
  /***/
  9462(c, t, e) {
    var s = e(9565), i = e(2360), n = e(6699), r = e(6279), a = e(8227), o = e(1181), l = e(5966), h = e(7657).IteratorPrototype, d = e(2529), u = e(9539), f = e(1385), p = e(6859), g = a("toStringTag"), m = "IteratorHelper", v = "WrapForValidIterator", y = "normal", b = "throw", w = o.set, A = function(T) {
      var x = o.getterFor(T ? v : m);
      return r(i(h), {
        next: function() {
          var C = x(this);
          if (T) return C.nextHandler();
          if (C.done) return d(void 0, !0);
          try {
            var I = C.nextHandler();
            return C.done && p(C), C.returnHandlerResult ? I : d(I, C.done);
          } catch (R) {
            throw C.done = !0, p(C), R;
          }
        },
        return: function() {
          var P = x(this), C = P.iterator, I = P.inner, R = P.openIters, D = P.done;
          if (P.done = !0, T) {
            var _ = l(C, "return");
            return _ ? s(_, C) : d(void 0, !0);
          }
          if (p(P), D) return d(void 0, !0);
          if (I) try {
            u(I.iterator, y);
          } catch (M) {
            return u(C, b, M);
          }
          if (R) try {
            f(R, y);
          } catch (M) {
            if (C) return u(C, b, M);
            throw M;
          }
          return C && u(C, y), d(void 0, !0);
        }
      });
    }, S = A(!0), E = A(!1);
    n(E, g, "Iterator Helper"), c.exports = function(T, x, P) {
      var C = function(R, D) {
        D ? (D.iterator = R.iterator, D.next = R.next) : D = R, D.type = x ? v : m, D.returnHandlerResult = !!P, D.nextHandler = T, D.counter = 0, D.done = !1, w(this, D);
      };
      return C.prototype = x ? S : E, C;
    };
  },
  /***/
  684(c) {
    c.exports = function(t, e) {
      var s = typeof Iterator == "function" && Iterator.prototype[t];
      if (s) try {
        s.call({ next: null }, e).next();
      } catch {
        return !0;
      }
    };
  },
  /***/
  4549(c, t, e) {
    var s = e(4576);
    c.exports = function(i, n) {
      var r = s.Iterator, a = r && r.prototype, o = a && a[i], l = !1;
      if (o) try {
        o.call({
          next: function() {
            return { done: !0 };
          },
          return: function() {
            l = !0;
          }
        }, -1);
      } catch (h) {
        h instanceof n || (l = !1);
      }
      if (!l) return o;
    };
  },
  /***/
  7657(c, t, e) {
    var s = e(9039), i = e(4901), n = e(34), r = e(2360), a = e(2787), o = e(6840), l = e(8227), h = e(6395), d = l("iterator"), u = !1, f, p, g;
    [].keys && (g = [].keys(), "next" in g ? (p = a(a(g)), p !== Object.prototype && (f = p)) : u = !0);
    var m = !n(f) || s(function() {
      var v = {};
      return f[d].call(v) !== v;
    });
    m ? f = {} : h && (f = r(f)), i(f[d]) || o(f, d, function() {
      return this;
    }), c.exports = {
      IteratorPrototype: f,
      BUGGY_SAFARI_ITERATORS: u
    };
  },
  /***/
  6269(c) {
    c.exports = Object.create ? /* @__PURE__ */ Object.create(null) : {};
  },
  /***/
  6198(c, t, e) {
    var s = e(8014);
    c.exports = function(i) {
      return s(i.length);
    };
  },
  /***/
  283(c, t, e) {
    var s = e(9504), i = e(9039), n = e(4901), r = e(9297), a = e(3724), o = e(350).CONFIGURABLE, l = e(3706), h = e(1181), d = h.enforce, u = h.get, f = String, p = Object.defineProperty, g = s("".slice), m = s("".replace), v = s([].join), y = a && !i(function() {
      return p(function() {
      }, "length", { value: 8 }).length !== 8;
    }), b = String(String).split("String"), w = c.exports = function(A, S, E) {
      g(f(S), 0, 7) === "Symbol(" && (S = "[" + m(f(S), /^Symbol\(([^)]*)\).*$/, "$1") + "]"), E && E.getter && (S = "get " + S), E && E.setter && (S = "set " + S), (!r(A, "name") || o && A.name !== S) && (a ? p(A, "name", { value: S, configurable: !0 }) : A.name = S), y && E && r(E, "arity") && A.length !== E.arity && p(A, "length", { value: E.arity });
      try {
        E && r(E, "constructor") && E.constructor ? a && p(A, "prototype", { writable: !1 }) : A.prototype && (A.prototype = void 0);
      } catch {
      }
      var T = d(A);
      return r(T, "source") || (T.source = v(b, typeof S == "string" ? S : "")), A;
    };
    Function.prototype.toString = w(function() {
      return n(this) && u(this).source || l(this);
    }, "toString");
  },
  /***/
  2248(c, t, e) {
    var s = e(9504), i = Map.prototype;
    c.exports = {
      // eslint-disable-next-line es/no-map -- safe
      Map,
      set: s(i.set),
      get: s(i.get),
      has: s(i.has),
      remove: s(i.delete),
      proto: i
    };
  },
  /***/
  741(c) {
    var t = Math.ceil, e = Math.floor;
    c.exports = Math.trunc || function(i) {
      var n = +i;
      return (n > 0 ? e : t)(n);
    };
  },
  /***/
  7819(c, t, e) {
    var s = e(9039);
    c.exports = !s(function() {
      var i = "9007199254740993", n = JSON.rawJSON(i);
      return !JSON.isRawJSON(n) || JSON.stringify(n) !== i;
    });
  },
  /***/
  6043(c, t, e) {
    var s = e(9306), i = TypeError, n = function(r) {
      var a, o;
      this.promise = new r(function(l, h) {
        if (a !== void 0 || o !== void 0) throw new i("Bad Promise constructor");
        a = l, o = h;
      }), this.resolve = s(a), this.reject = s(o);
    };
    c.exports.f = function(r) {
      return new n(r);
    };
  },
  /***/
  2603(c, t, e) {
    var s = e(655);
    c.exports = function(i, n) {
      return i === void 0 ? arguments.length < 2 ? "" : n : s(i);
    };
  },
  /***/
  4149(c) {
    var t = RangeError;
    c.exports = function(e) {
      if (e === e) return e;
      throw new t("NaN is not allowed");
    };
  },
  /***/
  2360(c, t, e) {
    var s = e(8551), i = e(6801), n = e(8727), r = e(421), a = e(397), o = e(4055), l = e(6119), h = ">", d = "<", u = "prototype", f = "script", p = l("IE_PROTO"), g = function() {
    }, m = function(A) {
      return d + f + h + A + d + "/" + f + h;
    }, v = function(A) {
      A.write(m("")), A.close();
      var S = A.parentWindow.Object;
      return A = null, S;
    }, y = function() {
      var A = o("iframe"), S = "java" + f + ":", E;
      return A.style.display = "none", a.appendChild(A), A.src = String(S), E = A.contentWindow.document, E.open(), E.write(m("document.F=Object")), E.close(), E.F;
    }, b, w = function() {
      try {
        b = new ActiveXObject("htmlfile");
      } catch {
      }
      w = typeof document < "u" ? document.domain && b ? v(b) : y() : v(b);
      for (var A = n.length; A--; ) delete w[u][n[A]];
      return w();
    };
    r[p] = !0, c.exports = Object.create || function(S, E) {
      var T;
      return S !== null ? (g[u] = s(S), T = new g(), g[u] = null, T[p] = S) : T = w(), E === void 0 ? T : i.f(T, E);
    };
  },
  /***/
  6801(c, t, e) {
    var s = e(3724), i = e(8686), n = e(4913), r = e(8551), a = e(5397), o = e(1072);
    t.f = s && !i ? Object.defineProperties : function(h, d) {
      r(h);
      for (var u = a(d), f = o(d), p = f.length, g = 0, m; p > g; ) n.f(h, m = f[g++], u[m]);
      return h;
    };
  },
  /***/
  4913(c, t, e) {
    var s = e(3724), i = e(5917), n = e(8686), r = e(8551), a = e(6969), o = TypeError, l = Object.defineProperty, h = Object.getOwnPropertyDescriptor, d = "enumerable", u = "configurable", f = "writable";
    t.f = s ? n ? function(g, m, v) {
      if (r(g), m = a(m), r(v), typeof g == "function" && m === "prototype" && "value" in v && f in v && !v[f]) {
        var y = h(g, m);
        y && y[f] && (g[m] = v.value, v = {
          configurable: u in v ? v[u] : y[u],
          enumerable: d in v ? v[d] : y[d],
          writable: !1
        });
      }
      return l(g, m, v);
    } : l : function(g, m, v) {
      if (r(g), m = a(m), r(v), i) try {
        return l(g, m, v);
      } catch {
      }
      if ("get" in v || "set" in v) throw new o("Accessors not supported");
      return "value" in v && (g[m] = v.value), g;
    };
  },
  /***/
  7347(c, t, e) {
    var s = e(3724), i = e(9565), n = e(8773), r = e(6980), a = e(5397), o = e(6969), l = e(9297), h = e(5917), d = Object.getOwnPropertyDescriptor;
    t.f = s ? d : function(f, p) {
      if (f = a(f), p = o(p), h) try {
        return d(f, p);
      } catch {
      }
      if (l(f, p)) return r(!i(n.f, f, p), f[p]);
    };
  },
  /***/
  8480(c, t, e) {
    var s = e(1828), i = e(8727), n = i.concat("length", "prototype");
    t.f = Object.getOwnPropertyNames || function(a) {
      return s(a, n);
    };
  },
  /***/
  3717(c, t) {
    t.f = Object.getOwnPropertySymbols;
  },
  /***/
  2787(c, t, e) {
    var s = e(9297), i = e(4901), n = e(8981), r = e(6119), a = e(2211), o = r("IE_PROTO"), l = Object, h = l.prototype;
    c.exports = a ? l.getPrototypeOf : function(d) {
      var u = n(d);
      if (s(u, o)) return u[o];
      var f = u.constructor;
      return i(f) && u instanceof f ? f.prototype : u instanceof l ? h : null;
    };
  },
  /***/
  1625(c, t, e) {
    var s = e(9504);
    c.exports = s({}.isPrototypeOf);
  },
  /***/
  1828(c, t, e) {
    var s = e(9504), i = e(9297), n = e(5397), r = e(9617).indexOf, a = e(421), o = s([].push);
    c.exports = function(l, h) {
      var d = n(l), u = 0, f = [], p;
      for (p in d) !i(a, p) && i(d, p) && o(f, p);
      for (; h.length > u; ) i(d, p = h[u++]) && (~r(f, p) || o(f, p));
      return f;
    };
  },
  /***/
  1072(c, t, e) {
    var s = e(1828), i = e(8727);
    c.exports = Object.keys || function(r) {
      return s(r, i);
    };
  },
  /***/
  8773(c, t) {
    var e = {}.propertyIsEnumerable, s = Object.getOwnPropertyDescriptor, i = s && !e.call({ 1: 2 }, 1);
    t.f = i ? function(r) {
      var a = s(this, r);
      return !!a && a.enumerable;
    } : e;
  },
  /***/
  2967(c, t, e) {
    var s = e(6706), i = e(34), n = e(7750), r = e(3506);
    c.exports = Object.setPrototypeOf || ("__proto__" in {} ? (function() {
      var a = !1, o = {}, l;
      try {
        l = s(Object.prototype, "__proto__", "set"), l(o, []), a = o instanceof Array;
      } catch {
      }
      return function(d, u) {
        return n(d), r(u), i(d) && (a ? l(d, u) : d.__proto__ = u), d;
      };
    })() : void 0);
  },
  /***/
  4270(c, t, e) {
    var s = e(9565), i = e(4901), n = e(34), r = TypeError;
    c.exports = function(a, o) {
      var l, h;
      if (o === "string" && i(l = a.toString) && !n(h = s(l, a)) || i(l = a.valueOf) && !n(h = s(l, a)) || o !== "string" && i(l = a.toString) && !n(h = s(l, a))) return h;
      throw new r("Can't convert object to primitive value");
    };
  },
  /***/
  5031(c, t, e) {
    var s = e(7751), i = e(9504), n = e(8480), r = e(3717), a = e(8551), o = i([].concat);
    c.exports = s("Reflect", "ownKeys") || function(h) {
      var d = n.f(a(h)), u = r.f;
      return u ? o(d, u(h)) : d;
    };
  },
  /***/
  8235(c, t, e) {
    var s = e(9504), i = e(9297), n = SyntaxError, r = parseInt, a = String.fromCharCode, o = s("".charAt), l = s("".slice), h = s(/./.exec), d = {
      '\\"': '"',
      "\\\\": "\\",
      "\\/": "/",
      "\\b": "\b",
      "\\f": "\f",
      "\\n": `
`,
      "\\r": "\r",
      "\\t": "	"
    }, u = /^[\da-f]{4}$/i, f = /^[\u0000-\u001F]$/;
    c.exports = function(p, g) {
      for (var m = !0, v = ""; g < p.length; ) {
        var y = o(p, g);
        if (y === "\\") {
          var b = l(p, g, g + 2);
          if (i(d, b))
            v += d[b], g += 2;
          else if (b === "\\u") {
            g += 2;
            var w = l(p, g, g + 4);
            if (!h(u, w)) throw new n("Bad Unicode escape at: " + g);
            v += a(r(w, 16)), g += 4;
          } else throw new n('Unknown escape sequence: "' + b + '"');
        } else if (y === '"') {
          m = !1, g++;
          break;
        } else {
          if (h(f, y)) throw new n("Bad control character in string literal at: " + g);
          v += y, g++;
        }
      }
      if (m) throw new n("Unterminated string at: " + g);
      return { value: v, end: g };
    };
  },
  /***/
  1103(c) {
    c.exports = function(t) {
      try {
        return { error: !1, value: t() };
      } catch (e) {
        return { error: !0, value: e };
      }
    };
  },
  /***/
  3438(c, t, e) {
    var s = e(8551), i = e(34), n = e(6043);
    c.exports = function(r, a) {
      if (s(r), i(a) && a.constructor === r) return a;
      var o = n.f(r), l = o.resolve;
      return l(a), o.promise;
    };
  },
  /***/
  7750(c, t, e) {
    var s = e(4117), i = TypeError;
    c.exports = function(n) {
      if (s(n)) throw new i("Can't call method on " + n);
      return n;
    };
  },
  /***/
  9286(c, t, e) {
    var s = e(4402), i = e(8469), n = s.Set, r = s.add;
    c.exports = function(a) {
      var o = new n();
      return i(a, function(l) {
        r(o, l);
      }), o;
    };
  },
  /***/
  3440(c, t, e) {
    var s = e(7080), i = e(4402), n = e(9286), r = e(5170), a = e(3789), o = e(8469), l = e(507), h = i.has, d = i.remove;
    c.exports = function(f) {
      var p = s(this), g = a(f), m = n(p);
      return r(m) <= g.size ? o(m, function(v) {
        g.includes(v) && d(m, v);
      }) : l(g.getIterator(), function(v) {
        h(m, v) && d(m, v);
      }), m;
    };
  },
  /***/
  4402(c, t, e) {
    var s = e(9504), i = Set.prototype;
    c.exports = {
      // eslint-disable-next-line es/no-set -- safe
      Set,
      add: s(i.add),
      has: s(i.has),
      remove: s(i.delete),
      proto: i
    };
  },
  /***/
  8750(c, t, e) {
    var s = e(7080), i = e(4402), n = e(5170), r = e(3789), a = e(8469), o = e(507), l = i.Set, h = i.add, d = i.has;
    c.exports = function(f) {
      var p = s(this), g = r(f), m = new l();
      return n(p) > g.size ? o(g.getIterator(), function(v) {
        d(p, v) && h(m, v);
      }) : a(p, function(v) {
        g.includes(v) && h(m, v);
      }), m;
    };
  },
  /***/
  4449(c, t, e) {
    var s = e(7080), i = e(4402).has, n = e(5170), r = e(3789), a = e(8469), o = e(507), l = e(9539);
    c.exports = function(d) {
      var u = s(this), f = r(d);
      if (n(u) <= f.size) return a(u, function(g) {
        if (f.includes(g)) return !1;
      }, !0) !== !1;
      var p = f.getIterator();
      return o(p, function(g) {
        if (i(u, g)) return l(p.iterator, "normal", !1);
      }) !== !1;
    };
  },
  /***/
  3838(c, t, e) {
    var s = e(7080), i = e(5170), n = e(8469), r = e(3789);
    c.exports = function(o) {
      var l = s(this), h = r(o);
      return i(l) > h.size ? !1 : n(l, function(d) {
        if (!h.includes(d)) return !1;
      }, !0) !== !1;
    };
  },
  /***/
  8527(c, t, e) {
    var s = e(7080), i = e(4402).has, n = e(5170), r = e(3789), a = e(507), o = e(9539);
    c.exports = function(h) {
      var d = s(this), u = r(h);
      if (n(d) < u.size) return !1;
      var f = u.getIterator();
      return a(f, function(p) {
        if (!i(d, p)) return o(f.iterator, "normal", !1);
      }) !== !1;
    };
  },
  /***/
  8469(c, t, e) {
    var s = e(9504), i = e(507), n = e(4402), r = n.Set, a = n.proto, o = s(a.forEach), l = s(a.keys), h = l(new r()).next;
    c.exports = function(d, u, f) {
      return f ? i({ iterator: l(d), next: h }, u) : o(d, u);
    };
  },
  /***/
  4916(c, t, e) {
    var s = e(7751), i = function(r) {
      return {
        size: r,
        has: function() {
          return !1;
        },
        keys: function() {
          return {
            next: function() {
              return { done: !0 };
            }
          };
        }
      };
    }, n = function(r) {
      return {
        size: r,
        has: function() {
          return !0;
        },
        keys: function() {
          throw new Error("e");
        }
      };
    };
    c.exports = function(r, a) {
      var o = s("Set");
      try {
        new o()[r](i(0));
        try {
          return new o()[r](i(-1)), !1;
        } catch {
          if (!a) return !0;
          try {
            return new o()[r](n(-1 / 0)), !1;
          } catch {
            var l = new o([1, 2]);
            return a(l[r](n(1 / 0)));
          }
        }
      } catch {
        return !1;
      }
    };
  },
  /***/
  9835(c) {
    c.exports = function(t) {
      try {
        var e = /* @__PURE__ */ new Set(), s = {
          size: 0,
          has: function() {
            return !0;
          },
          keys: function() {
            return Object.defineProperty({}, "next", {
              get: function() {
                return e.clear(), e.add(4), function() {
                  return { done: !0 };
                };
              }
            });
          }
        }, i = e[t](s);
        return i.size === 1 && i.values().next().value === 4;
      } catch {
        return !1;
      }
    };
  },
  /***/
  5170(c, t, e) {
    var s = e(6706), i = e(4402);
    c.exports = s(i.proto, "size", "get") || function(n) {
      return n.size;
    };
  },
  /***/
  3650(c, t, e) {
    var s = e(7080), i = e(4402), n = e(9286), r = e(3789), a = e(507), o = i.add, l = i.has, h = i.remove;
    c.exports = function(u) {
      var f = s(this), p = r(u).getIterator(), g = n(f);
      return a(p, function(m) {
        l(f, m) ? h(g, m) : o(g, m);
      }), g;
    };
  },
  /***/
  4204(c, t, e) {
    var s = e(7080), i = e(4402).add, n = e(9286), r = e(3789), a = e(507);
    c.exports = function(l) {
      var h = s(this), d = r(l).getIterator(), u = n(h);
      return a(d, function(f) {
        i(u, f);
      }), u;
    };
  },
  /***/
  6119(c, t, e) {
    var s = e(5745), i = e(3392), n = s("keys");
    c.exports = function(r) {
      return n[r] || (n[r] = i(r));
    };
  },
  /***/
  7629(c, t, e) {
    var s = e(6395), i = e(4576), n = e(9433), r = "__core-js_shared__", a = c.exports = i[r] || n(r, {});
    (a.versions || (a.versions = [])).push({
      version: "3.50.0",
      mode: s ? "pure" : "global",
      copyright: "\xA9 2013\u20132025 Denis Pushkarev (zloirock.ru), 2025\u20132026 CoreJS Company (core-js.io). All rights reserved.",
      license: "https://github.com/zloirock/core-js/blob/v3.50.0/LICENSE",
      source: "https://github.com/zloirock/core-js"
    });
  },
  /***/
  5745(c, t, e) {
    var s = e(7629), i = Object.create || Object;
    c.exports = function(n, r) {
      return s[n] || (s[n] = r || i(null));
    };
  },
  /***/
  4495(c, t, e) {
    var s = e(9519), i = e(9039), n = e(4576), r = n.String;
    c.exports = !!Object.getOwnPropertySymbols && !i(function() {
      var a = /* @__PURE__ */ Symbol("symbol detection");
      return !r(a) || !(Object(a) instanceof Symbol) || // Chrome 38-40 symbols are not inherited from DOM collections prototypes to instances
      !Symbol.sham && s && s < 41;
    });
  },
  /***/
  1240(c, t, e) {
    var s = e(9504);
    c.exports = s(1.1.valueOf);
  },
  /***/
  5610(c, t, e) {
    var s = e(1291), i = Math.max, n = Math.min;
    c.exports = function(r, a) {
      var o = s(r);
      return o < 0 ? i(o + a, 0) : n(o, a);
    };
  },
  /***/
  5854(c, t, e) {
    var s = e(2777), i = TypeError;
    c.exports = function(n) {
      var r = s(n, "number");
      if (typeof r == "number") throw new i("Can't convert number to bigint");
      return BigInt(r);
    };
  },
  /***/
  5397(c, t, e) {
    var s = e(7055), i = e(7750);
    c.exports = function(n) {
      return s(i(n));
    };
  },
  /***/
  1291(c, t, e) {
    var s = e(741);
    c.exports = function(i) {
      var n = +i;
      return n !== n || n === 0 ? 0 : s(n);
    };
  },
  /***/
  8014(c, t, e) {
    var s = e(1291), i = Math.min;
    c.exports = function(n) {
      var r = s(n);
      return r > 0 ? i(r, 9007199254740991) : 0;
    };
  },
  /***/
  8981(c, t, e) {
    var s = e(7750), i = Object;
    c.exports = function(n) {
      return i(s(n));
    };
  },
  /***/
  9590(c, t, e) {
    var s = e(1291), i = RangeError;
    c.exports = function(n) {
      var r = s(n);
      if (r < 0) throw new i("The argument can't be less than 0");
      return r;
    };
  },
  /***/
  2777(c, t, e) {
    var s = e(9565), i = e(34), n = e(757), r = e(5966), a = e(4270), o = e(8227), l = TypeError, h = o("toPrimitive");
    c.exports = function(d, u) {
      if (!i(d) || n(d)) return d;
      var f = r(d, h), p;
      if (f) {
        if (u === void 0 && (u = "default"), p = s(f, d, u), !i(p) || n(p)) return p;
        throw new l("Can't convert object to primitive value");
      }
      return u === void 0 && (u = "number"), a(d, u);
    };
  },
  /***/
  6969(c, t, e) {
    var s = e(2777), i = e(757);
    c.exports = function(n) {
      var r = s(n, "string");
      return i(r) ? r : r + "";
    };
  },
  /***/
  2140(c, t, e) {
    var s = e(8227), i = s("toStringTag"), n = {};
    n[i] = "z", c.exports = String(n) === "[object z]";
  },
  /***/
  655(c, t, e) {
    var s = e(6955), i = String;
    c.exports = function(n) {
      if (s(n) === "Symbol") throw new TypeError("Cannot convert a Symbol value to a string");
      return i(n);
    };
  },
  /***/
  6823(c) {
    var t = String;
    c.exports = function(e) {
      try {
        return t(e);
      } catch {
        return "Object";
      }
    };
  },
  /***/
  3392(c, t, e) {
    var s = e(9504), i = 0, n = Math.random(), r = s(1.1.toString);
    c.exports = function(a) {
      return "Symbol(" + (a === void 0 ? "" : a) + ")_" + r(++i + n, 36);
    };
  },
  /***/
  9143(c, t, e) {
    var s = e(4576), i = e(9504), n = e(3972), r = e(3463), a = e(9297), o = e(2804), l = e(944), h = e(5169), d = o.c2i, u = o.c2iUrl, f = s.SyntaxError, p = s.TypeError, g = s.Array, m = i("".charAt), v = Math.floor, y = function(A, S) {
      for (var E = A.length; S < E; S++) {
        var T = m(A, S);
        if (T !== " " && T !== "	" && T !== `
` && T !== "\f" && T !== "\r") break;
      }
      return S;
    }, b = function(A, S, E) {
      var T = A.length;
      T < 4 && (A += T === 2 ? "AA" : "A");
      var x = (S[m(A, 0)] << 18) + (S[m(A, 1)] << 12) + (S[m(A, 2)] << 6) + S[m(A, 3)], P = [
        x >> 16 & 255,
        x >> 8 & 255,
        x & 255
      ];
      if (T === 2) {
        if (E && P[1] !== 0)
          throw new f("Extra bits");
        return [P[0]];
      }
      if (T === 3) {
        if (E && P[2] !== 0)
          throw new f("Extra bits");
        return [P[0], P[1]];
      }
      return P;
    }, w = function(A, S, E) {
      for (var T = S.length, x = 0; x < T; x++)
        A[E + x] = S[x];
      return E + T;
    };
    c.exports = function(A, S, E, T) {
      r(A), n(S);
      var x = l(S) === "base64" ? d : u, P = S ? S.lastChunkHandling : void 0;
      if (P === void 0 && (P = "loose"), P !== "loose" && P !== "strict" && P !== "stop-before-partial")
        throw new p("Incorrect `lastChunkHandling` option");
      E && h(E.buffer);
      var C = A.length, I = E || g(v(C * 3 / 4)), R = 0, D = 0, _ = "", M = 0;
      if (T) for (; ; ) {
        if (M = y(A, M), M === C) {
          if (_.length > 0) {
            if (P === "stop-before-partial")
              break;
            if (P === "loose") {
              if (_.length === 1)
                throw new f("Malformed padding: exactly one additional character");
              R = w(I, b(_, x, !1), R);
            } else
              throw new f("Missing padding");
          }
          D = C;
          break;
        }
        var k = m(A, M);
        if (++M, k === "=") {
          if (_.length < 2)
            throw new f("Padding is too early");
          if (M = y(A, M), _.length === 2) {
            if (M === C) {
              if (P === "stop-before-partial")
                break;
              throw new f("Malformed padding: only one =");
            }
            m(A, M) === "=" && (++M, M = y(A, M));
          }
          if (M < C)
            throw new f("Unexpected character after padding");
          R = w(I, b(_, x, P === "strict"), R), D = C;
          break;
        }
        if (!a(x, k))
          throw new f("Unexpected character");
        var $ = T - R;
        if ($ === 1 && _.length === 2 || $ === 2 && _.length === 3 || (_ += k, _.length === 4 && (R = w(I, b(_, x, !1), R), _ = "", D = M, R === T)))
          break;
      }
      return E || (I.length = R), { bytes: I, read: D, written: R };
    };
  },
  /***/
  2303(c, t, e) {
    var s = e(4576), i = e(9504), n = s.Uint8Array, r = s.SyntaxError, a = Math.min, o = i("".match);
    c.exports = function(l, h) {
      var d = l.length;
      if (d % 2 !== 0) throw new r("String should be an even number of characters");
      for (var u = h ? a(h.length, d / 2) : d / 2, f = h || new n(u), p = o(l, /[\S\s]{2}/g), g = 0; g < u; g++) {
        var m = +("0x" + p[g] + "0");
        if (m !== m)
          throw new r("String should only contain hex characters");
        f[g] = m >> 4;
      }
      return { bytes: f, read: g << 1 };
    };
  },
  /***/
  7416(c, t, e) {
    var s = e(9039), i = e(8227), n = e(3724), r = e(6395), a = i("iterator");
    c.exports = !s(function() {
      var o = new URL("b?a=1&b=2&c=3", "https://a"), l = o.searchParams, h = new URLSearchParams("a=1&a=2&b=3"), d = "";
      return o.pathname = "c%20d", l.forEach(function(u, f) {
        l.delete("b"), d += f + u;
      }), h.delete("a", 2), h.delete("b", void 0), r && (!o.toJSON || !h.has("a", 1) || h.has("a", 2) || !h.has("a", void 0) || h.has("b")) || !l.size && (r || !n) || !l.sort || o.href !== "https://a/c%20d?a=1&c=3" || l.get("c") !== "3" || String(new URLSearchParams("?a=1")) !== "a=1" || !l[a] || new URL("https://a@b").username !== "a" || new URLSearchParams(new URLSearchParams("a=b")).get("a") !== "b" || new URL("https://\u0442\u0435\u0441\u0442").host !== "xn--e1aybc" || new URL("https://a#\u0431").hash !== "#%D0%B1" || d !== "a1c3" || new URL("https://x", void 0).host !== "x";
    });
  },
  /***/
  7040(c, t, e) {
    var s = e(4495);
    c.exports = s && !Symbol.sham && typeof Symbol.iterator == "symbol";
  },
  /***/
  8686(c, t, e) {
    var s = e(3724), i = e(9039);
    c.exports = s && i(function() {
      return Object.defineProperty(function() {
      }, "prototype", {
        value: 42,
        writable: !1
      }).prototype !== 42;
    });
  },
  /***/
  2812(c) {
    var t = TypeError;
    c.exports = function(e, s) {
      if (e < s) throw new t("Not enough arguments");
      return e;
    };
  },
  /***/
  8622(c, t, e) {
    var s = e(4576), i = e(4901), n = s.WeakMap;
    c.exports = i(n) && /native code/.test(String(n));
  },
  /***/
  4995(c, t, e) {
    var s = e(9504), i = WeakMap.prototype;
    c.exports = {
      // eslint-disable-next-line es/no-weak-map -- safe
      WeakMap,
      set: s(i.set),
      get: s(i.get),
      has: s(i.has),
      remove: s(i.delete)
    };
  },
  /***/
  8227(c, t, e) {
    var s = e(4576), i = e(5745), n = e(9297), r = e(3392), a = e(4495), o = e(7040), l = s.Symbol, h = i("wks"), d = o ? l.for || l : l && l.withoutSetter || r;
    c.exports = function(u) {
      return n(h, u) || (h[u] = a && n(l, u) ? l[u] : d("Symbol." + u)), h[u];
    };
  },
  /***/
  4423(c, t, e) {
    var s = e(6518), i = e(9617).includes, n = e(9039), r = e(6469), a = n(function() {
      return !Array(1).includes();
    }), o = n(function() {
      return [, 1].includes(void 0, 1);
    });
    s({ target: "Array", proto: !0, forced: a || o }, {
      includes: function(h) {
        return i(this, h, arguments.length > 1 ? arguments[1] : void 0);
      }
    }), r("includes");
  },
  /***/
  4114(c, t, e) {
    var s = e(6518), i = e(8981), n = e(6198), r = e(4527), a = e(6837), o = e(9039), l = o(function() {
      return [].push.call({ length: 4294967296 }, 1) !== 4294967297;
    }), h = function() {
      try {
        Object.defineProperty([], "length", { writable: !1 }).push();
      } catch (u) {
        return u instanceof TypeError;
      }
    }, d = l || !h();
    s({ target: "Array", proto: !0, arity: 1, forced: d }, {
      // eslint-disable-next-line no-unused-vars -- required for `.length`
      push: function(f) {
        var p = i(this), g = n(p), m = arguments.length;
        a(g + m);
        for (var v = 0; v < m; v++)
          p[g] = arguments[v], g++;
        return r(p, g), g;
      }
    });
  },
  /***/
  8111(c, t, e) {
    var s = e(6518), i = e(4576), n = e(679), r = e(8551), a = e(4901), o = e(2787), l = e(2106), h = e(4659), d = e(9039), u = e(9297), f = e(8227), p = e(7657).IteratorPrototype, g = e(3724), m = e(6395), v = "constructor", y = "Iterator", b = f("toStringTag"), w = TypeError, A = i[y], S = m || !a(A) || A.prototype !== p || !d(function() {
      A({});
    }), E = function() {
      if (n(this, p), o(this) === p) throw new w("Abstract class Iterator not directly constructable");
    }, T = function(x, P) {
      g ? l(p, x, {
        configurable: !0,
        get: function() {
          return P;
        },
        set: function(C) {
          if (r(this), this === p) throw new w("You can't redefine this property");
          u(this, x) ? this[x] = C : h(this, x, C);
        }
      }) : p[x] = P;
    };
    u(p, b) || T(b, y), (S || !u(p, v) || p[v] === Object) && T(v, E), E.prototype = p, s({ global: !0, constructor: !0, forced: S }, {
      Iterator: E
    });
  },
  /***/
  9314(c, t, e) {
    var s = e(6518), i = e(9565), n = e(8551), r = e(1767), a = e(4149), o = e(9590), l = e(9539), h = e(9462), d = e(684), u = e(4549), f = e(6395), p = RangeError, g = 1 / 0, m = !f && !d("drop", 0), v = !f && !m && u("drop", RangeError), y = f || m || v || !(function() {
      try {
        Iterator.prototype.drop.call({
          next: function() {
            return { done: !0 };
          }
        }, 9007199254740992);
      } catch (w) {
        return w instanceof p;
      }
    })(), b = h(function() {
      for (var w = this.iterator, A = this.next, S, E; this.remaining; )
        if (this.remaining--, S = n(i(A, w)), E = this.done = !!S.done, E) return;
      if (S = n(i(A, w)), E = this.done = !!S.done, !E) return S.value;
    });
    s({ target: "Iterator", proto: !0, real: !0, forced: y }, {
      drop: function(A) {
        n(this);
        var S;
        try {
          if (S = o(a(+A)), S > 9007199254740991 && S !== g)
            throw new p("The argument should be a safe integer");
        } catch (E) {
          l(this, "throw", E);
        }
        return v ? i(v, this, S) : new b(r(this), {
          remaining: S
        });
      }
    });
  },
  /***/
  1148(c, t, e) {
    var s = e(6518), i = e(9565), n = e(2652), r = e(9306), a = e(8551), o = e(1767), l = e(9539), h = e(4549), d = h("every", TypeError);
    s({ target: "Iterator", proto: !0, real: !0, forced: d }, {
      every: function(f) {
        a(this);
        try {
          r(f);
        } catch (m) {
          l(this, "throw", m);
        }
        if (d) return i(d, this, f);
        var p = o(this), g = 0;
        return !n(p, function(m, v) {
          if (!f(m, g++)) return v();
        }, { IS_RECORD: !0, INTERRUPTED: !0 }).stopped;
      }
    });
  },
  /***/
  2489(c, t, e) {
    var s = e(6518), i = e(9565), n = e(9306), r = e(8551), a = e(1767), o = e(9462), l = e(6319), h = e(6395), d = e(9539), u = e(684), f = e(4549), p = !h && !u("filter", function() {
    }), g = !h && !p && f("filter", TypeError), m = h || p || g, v = o(function() {
      for (var y = this.iterator, b = this.predicate, w = this.next, A, S, E; ; ) {
        if (A = r(i(w, y)), S = this.done = !!A.done, S) return;
        if (E = A.value, l(y, b, [E, this.counter++], !0)) return E;
      }
    });
    s({ target: "Iterator", proto: !0, real: !0, forced: m }, {
      filter: function(b) {
        r(this);
        try {
          n(b);
        } catch (w) {
          d(this, "throw", w);
        }
        return g ? i(g, this, b) : new v(a(this), {
          predicate: b
        });
      }
    });
  },
  /***/
  116(c, t, e) {
    var s = e(6518), i = e(9565), n = e(2652), r = e(9306), a = e(8551), o = e(1767), l = e(9539), h = e(4549), d = h("find", TypeError);
    s({ target: "Iterator", proto: !0, real: !0, forced: d }, {
      find: function(f) {
        a(this);
        try {
          r(f);
        } catch (m) {
          l(this, "throw", m);
        }
        if (d) return i(d, this, f);
        var p = o(this), g = 0;
        return n(p, function(m, v) {
          if (f(m, g++)) return v(m);
        }, { IS_RECORD: !0, INTERRUPTED: !0 }).result;
      }
    });
  },
  /***/
  531(c, t, e) {
    var s = e(6518), i = e(9565), n = e(9306), r = e(8551), a = e(1767), o = e(8646), l = e(9462), h = e(9539), d = e(9039), u = e(6395), f = e(684), p = e(4549), g = !u && d(function() {
      return [1].values().flatMap(function() {
        return [1];
      }).find(function() {
        return !0;
      }) !== 1;
    }), m = !u && !g && !f("flatMap", function() {
    }), v = !u && !g && !m && p("flatMap", TypeError), y = u || g || m || v, b = l(function() {
      for (var w = this.iterator, A = this.mapper, S, E; ; ) {
        if (E = this.inner) try {
          if (S = r(i(E.next, E.iterator)), !S.done) return S.value;
          this.inner = null;
        } catch (T) {
          h(w, "throw", T);
        }
        if (S = r(i(this.next, w)), this.done = !!S.done) return;
        try {
          this.inner = o(A(S.value, this.counter++), !1);
        } catch (T) {
          h(w, "throw", T);
        }
      }
    });
    s({ target: "Iterator", proto: !0, real: !0, forced: y }, {
      flatMap: function(A) {
        r(this);
        try {
          n(A);
        } catch (S) {
          h(this, "throw", S);
        }
        return v ? i(v, this, A) : new b(a(this), {
          mapper: A,
          inner: null
        });
      }
    });
  },
  /***/
  7588(c, t, e) {
    var s = e(6518), i = e(9565), n = e(2652), r = e(9306), a = e(8551), o = e(1767), l = e(9539), h = e(4549), d = h("forEach", TypeError);
    s({ target: "Iterator", proto: !0, real: !0, forced: d }, {
      forEach: function(f) {
        a(this);
        try {
          r(f);
        } catch (m) {
          l(this, "throw", m);
        }
        if (d) return i(d, this, f);
        var p = o(this), g = 0;
        n(p, function(m) {
          f(m, g++);
        }, { IS_RECORD: !0 });
      }
    });
  },
  /***/
  1701(c, t, e) {
    var s = e(6518), i = e(9565), n = e(9306), r = e(8551), a = e(1767), o = e(9462), l = e(6319), h = e(9539), d = e(684), u = e(4549), f = e(6395), p = !f && !d("map", function() {
    }), g = !f && !p && u("map", TypeError), m = f || p || g, v = o(function() {
      var y = this.iterator, b = r(i(this.next, y)), w = this.done = !!b.done;
      if (!w) return l(y, this.mapper, [b.value, this.counter++], !0);
    });
    s({ target: "Iterator", proto: !0, real: !0, forced: m }, {
      map: function(b) {
        r(this);
        try {
          n(b);
        } catch (w) {
          h(this, "throw", w);
        }
        return g ? i(g, this, b) : new v(a(this), {
          mapper: b
        });
      }
    });
  },
  /***/
  3579(c, t, e) {
    var s = e(6518), i = e(9565), n = e(2652), r = e(9306), a = e(8551), o = e(1767), l = e(9539), h = e(4549), d = h("some", TypeError);
    s({ target: "Iterator", proto: !0, real: !0, forced: d }, {
      some: function(f) {
        a(this);
        try {
          r(f);
        } catch (m) {
          l(this, "throw", m);
        }
        if (d) return i(d, this, f);
        var p = o(this), g = 0;
        return n(p, function(m, v) {
          if (f(m, g++)) return v();
        }, { IS_RECORD: !0, INTERRUPTED: !0 }).stopped;
      }
    });
  },
  /***/
  4972(c, t, e) {
    var s = e(6518), i = e(9565), n = e(8551), r = e(1767), a = e(4149), o = e(9590), l = e(9462), h = e(9539), d = e(684), u = e(4549), f = e(6395), p = RangeError, g = 1 / 0, m = !f && !d("take", 1), v = !f && !m && u("take", RangeError), y = f || m || v || !(function() {
      try {
        Iterator.prototype.take.call({
          next: function() {
            return { done: !0 };
          }
        }, 9007199254740992);
      } catch (w) {
        return w instanceof p;
      }
    })(), b = l(function() {
      var w = this.iterator;
      if (!this.remaining--)
        return this.done = !0, h(w, "normal", void 0);
      var A = n(i(this.next, w)), S = this.done = !!A.done;
      if (!S) return A.value;
    });
    s({ target: "Iterator", proto: !0, real: !0, forced: y }, {
      take: function(A) {
        n(this);
        var S;
        try {
          if (S = o(a(+A)), S > 9007199254740991 && S !== g)
            throw new p("The argument should be a safe integer");
        } catch (E) {
          h(this, "throw", E);
        }
        return v ? i(v, this, S) : new b(r(this), {
          remaining: S
        });
      }
    });
  },
  /***/
  1806(c, t, e) {
    var s = e(6518), i = e(8551), n = e(4659), r = e(2652), a = e(1767);
    s({ target: "Iterator", proto: !0, real: !0 }, {
      toArray: function() {
        var l = [], h = 0;
        return r(a(i(this)), function(d) {
          n(l, h++, d);
        }, { IS_RECORD: !0 }), l;
      }
    });
  },
  /***/
  9112(c, t, e) {
    var s = e(6518), i = e(3724), n = e(4576), r = e(7751), a = e(9504), o = e(9565), l = e(4901), h = e(34), d = e(4376), u = e(9297), f = e(655), p = e(6198), g = e(4659), m = e(9039), v = e(8235), y = e(4495), b = n.JSON, w = n.Number, A = n.SyntaxError, S = b && b.parse, E = r("Object", "keys"), T = Object.getOwnPropertyDescriptor, x = a("".charAt), P = a("".slice), C = a(/./.exec), I = a([].push), R = /^\d$/, D = /^[1-9]$/, _ = /^[\d-]$/, M = /^[\t\n\r ]$/, k = 0, $ = 1, U = function(F, O) {
      F = f(F);
      var L = new J(F, 0), W = L.parse(), it = W.value, G = L.skip(M, W.end);
      if (G < F.length)
        throw new A('Unexpected extra character: "' + x(F, G) + '" after the parsed data at: ' + G);
      return l(O) ? tt({ "": it }, "", O, W) : it;
    }, tt = function(F, O, L, W) {
      var it = F[O], G = W && it === W.value, Q = G && typeof W.source == "string" ? { source: W.source } : {}, ot, xt, Tt, yt, Gt;
      if (h(it)) {
        var Be = d(it), Te = G ? W.nodes : Be ? [] : {};
        if (Be)
          for (ot = Te.length, Tt = p(it), yt = 0; yt < Tt; yt++)
            vt(it, yt, tt(it, "" + yt, L, yt < ot ? Te[yt] : void 0));
        else
          for (xt = E(it), Tt = p(xt), yt = 0; yt < Tt; yt++)
            Gt = xt[yt], vt(it, Gt, tt(it, Gt, L, u(Te, Gt) ? Te[Gt] : void 0));
      }
      return o(L, F, O, it, Q);
    }, vt = function(F, O, L) {
      if (i) {
        var W = T(F, O);
        if (W && !W.configurable) return;
      }
      L === void 0 ? delete F[O] : g(F, O, L);
    }, Y = function(F, O, L, W) {
      this.value = F, this.end = O, this.source = L, this.nodes = W;
    }, J = function(F, O) {
      this.source = F, this.index = O;
    };
    J.prototype = {
      fork: function(F) {
        return new J(this.source, F);
      },
      parse: function() {
        var F = this.source, O = this.skip(M, this.index), L = this.fork(O), W = x(F, O);
        if (C(_, W)) return L.number();
        switch (W) {
          case "{":
            return L.object();
          case "[":
            return L.array();
          case '"':
            return L.string();
          case "t":
            return L.keyword(!0);
          case "f":
            return L.keyword(!1);
          case "n":
            return L.keyword(null);
        }
        throw new A('Unexpected character: "' + W + '" at: ' + O);
      },
      node: function(F, O, L, W, it) {
        return new Y(O, W, F ? null : P(this.source, L, W), it);
      },
      object: function() {
        for (var F = this.source, O = this.index + 1, L = !1, W = {}, it = {}, G = !1; O < F.length; ) {
          if (O = this.until(['"', "}"], O), x(F, O) === "}" && !L) {
            O++, G = !0;
            break;
          }
          var Q = this.fork(O).string(), ot = Q.value;
          O = Q.end, O = this.until([":"], O) + 1, O = this.skip(M, O), Q = this.fork(O).parse(), g(it, ot, Q), g(W, ot, Q.value), O = this.until([",", "}"], Q.end);
          var xt = x(F, O);
          if (xt === ",")
            L = !0, O++;
          else if (xt === "}") {
            O++, G = !0;
            break;
          }
        }
        if (!G) throw new A("Unterminated object at: " + O);
        return this.node($, W, this.index, O, it);
      },
      array: function() {
        for (var F = this.source, O = this.index + 1, L = !1, W = [], it = [], G = !1; O < F.length; ) {
          if (O = this.skip(M, O), x(F, O) === "]" && !L) {
            O++, G = !0;
            break;
          }
          var Q = this.fork(O).parse();
          if (I(it, Q), I(W, Q.value), O = this.until([",", "]"], Q.end), x(F, O) === ",")
            L = !0, O++;
          else if (x(F, O) === "]") {
            O++, G = !0;
            break;
          }
        }
        if (!G) throw new A("Unterminated array at: " + O);
        return this.node($, W, this.index, O, it);
      },
      string: function() {
        var F = this.index, O = v(this.source, this.index + 1);
        return this.node(k, O.value, F, O.end);
      },
      number: function() {
        var F = this.source, O = this.index, L = O;
        if (x(F, L) === "-" && L++, x(F, L) === "0") L++;
        else if (C(D, x(F, L))) L = this.skip(R, L + 1);
        else throw new A("Failed to parse number at: " + L);
        if (x(F, L) === ".") {
          var W = L + 1;
          if (L = this.skip(R, W), W === L) throw new A("Failed to parse number's fraction at: " + L);
        }
        if (x(F, L) === "e" || x(F, L) === "E") {
          L++, (x(F, L) === "+" || x(F, L) === "-") && L++;
          var it = L;
          if (L = this.skip(R, L), it === L) throw new A("Failed to parse number's exponent value at: " + L);
        }
        return this.node(k, w(P(F, O, L)), O, L);
      },
      keyword: function(F) {
        var O = "" + F, L = this.index, W = L + O.length;
        if (P(this.source, L, W) !== O) throw new A("Failed to parse value at: " + L);
        return this.node(k, F, L, W);
      },
      skip: function(F, O) {
        for (var L = this.source; O < L.length && C(F, x(L, O)); O++) ;
        return O;
      },
      until: function(F, O) {
        O = this.skip(M, O);
        for (var L = x(this.source, O), W = 0; W < F.length; W++) if (F[W] === L) return O;
        throw new A('Unexpected character: "' + L + '" at: ' + O);
      }
    };
    var rt = m(function() {
      var F = "9007199254740993", O;
      return S(F, function(L, W, it) {
        O = it.source;
      }), O !== F;
    }), Rt = y && !m(function() {
      return 1 / S("-0 	") !== -1 / 0;
    });
    s({ target: "JSON", stat: !0, forced: rt }, {
      parse: function(O, L) {
        return Rt && !l(L) ? S(O) : U(O, L);
      }
    });
  },
  /***/
  3110(c, t, e) {
    var s = e(6518), i = e(7751), n = e(9565), r = e(9504), a = e(9039), o = e(4376), l = e(4901), h = e(34), d = e(2360), u = e(5810), f = e(757), p = e(2195), g = e(1240), m = e(9617).includes, v = e(9297), y = e(655), b = e(8235), w = e(3392), A = e(4495), S = e(7819), E = String, T = TypeError, x = i("JSON", "stringify"), P = i("BigInt"), C = r("".valueOf), I = r((!0).valueOf), R = P && r(P.prototype.valueOf), D = r(/./.exec), _ = r("".charAt), M = r("".charCodeAt), k = r("".replace), $ = r("".slice), U = r([].push), tt = r([].pop), vt = r(1.1.toString), Y = /[\uD800-\uDFFF]/g, J = /^[\uD800-\uDBFF]$/, rt = /^[\uDC00-\uDFFF]$/, Rt = /^\d+$/, F = w(), O = w(), L = w(), W = F.length, it = O.length, G = !A || a(function() {
      var et = i("Symbol")("stringify detection");
      return x([et]) !== "[null]" || x({ a: et }) !== "{}" || x(Object(et)) !== "{}";
    }), Q = a(function() {
      return x("\uDF06\uD834") !== '"\\udf06\\ud834"' || x("\uDEAD") !== '"\\udead"';
    }), ot = S ? i("JSON", "isRawJSON") : u, xt = G ? function(et, lt, ft) {
      return x(et, function(Pt, It) {
        var wt = n(lt, this, Pt, It);
        if (!f(wt)) return wt;
      }, ft);
    } : x, Tt = function(et, lt, ft) {
      var Pt = _(ft, lt - 1), It = _(ft, lt + 1);
      return D(J, et) && !D(rt, It) || D(rt, et) && !D(J, Pt) ? "\\u" + vt(M(et, 0), 16) : et;
    }, yt = function(et) {
      if (o(et)) {
        for (var lt = et.length, ft = [], Pt = d(null), It = 0; It < lt; It++) {
          var wt = et[It], Vt;
          if (typeof wt == "string") Vt = wt;
          else if (typeof wt == "number" || p(wt) === "Number" || p(wt) === "String") Vt = y(wt);
          else continue;
          v(Pt, Vt) || (Pt[Vt] = !0, U(ft, Vt));
        }
        return ft;
      }
    }, Gt = function(et, lt) {
      try {
        return et(lt), !0;
      } catch {
        return !1;
      }
    }, Be = function(et) {
      var lt = p(et);
      return lt === "Number" && Gt(g, et) || lt === "String" && Gt(C, et) || lt === "Boolean" && Gt(I, et) || !!R && lt === "BigInt" && Gt(R, et);
    }, Te = function(et) {
      if (!h(et) || l(et) || o(et)) return !1;
      try {
        return !Be(et);
      } catch {
        return !0;
      }
    }, Qn = function(et, lt) {
      return {
        toJSON: function() {
          var ft = et[lt];
          if (h(ft) || typeof ft == "bigint") {
            var Pt = ft.toJSON;
            l(Pt) && (ft = n(Pt, ft, lt));
          }
          return ft;
        }
      };
    }, Zn = function(et) {
      for (var lt = 0, ft = et.length; lt < ft; lt++)
        if (D(Rt, et[lt])) return O;
      return "";
    }, qn = function(et, lt, ft) {
      for (var Pt = d(null), It = 0, wt = lt.length; It < wt; It++) {
        var Vt = lt[It];
        Pt[ft + Vt] = Qn(et, Vt);
      }
      return Pt[L] = null, Pt;
    };
    x && s({ target: "JSON", stat: !0, arity: 3, forced: G || Q || !S }, {
      stringify: function(lt, ft, Pt) {
        var It = l(ft) ? ft : void 0, wt = It ? void 0 : yt(ft), Vt = wt && Zn(wt), Di = [], Us = [], ki = [], rs, Hs = !1, Ni = !0, ne = xt(lt, function(He, Jt) {
          if (He = E(He), wt) {
            if (He === L) {
              tt(Us), rs = tt(ki);
              return;
            }
            if (Ni) Ni = !1;
            else if (this !== rs && !o(this) && !m(wt, He)) return;
          } else It && (Jt = n(It, this, He, Jt));
          if (ot(Jt))
            return S ? Jt : (Hs = !0, F + (U(Di, Jt.rawJSON) - 1));
          if (wt && Te(Jt)) {
            if (m(Us, Jt)) throw new T("Converting circular structure to JSON");
            var Bi = qn(Jt, wt, Vt);
            return U(Us, Jt), U(ki, rs), rs = Bi, Vt && (Hs = !0), Bi;
          }
          return Jt;
        }, Pt);
        if (typeof ne != "string" || (Q && (ne = k(ne, Y, Tt)), !Hs)) return ne;
        for (var _e = "", tr = ne.length, Ce = 0; Ce < tr; Ce++) {
          var Fi = _(ne, Ce);
          if (Fi === '"') {
            var Li = b(ne, ++Ce).end - 1, Ue = $(ne, Ce, Li);
            $(Ue, 0, W) === F ? _e += Di[$(Ue, W)] : $(Ue, 0, it) === O ? _e += '"' + $(Ue, it) + '"' : _e += '"' + Ue + '"', Ce = Li;
          } else _e += Fi;
        }
        return _e;
      }
    });
  },
  /***/
  2731(c, t, e) {
    var s = e(6518), i = e(9306), n = e(2248), r = e(6395), a = n.get, o = n.has, l = n.set;
    s({ target: "Map", proto: !0, real: !0, forced: r }, {
      getOrInsertComputed: function(d, u) {
        var f = o(this, d);
        if (i(u), f) return a(this, d);
        d === 0 && 1 / d === -1 / 0 && (d = 0);
        var p = u(d);
        return l(this, d, p), p;
      }
    });
  },
  /***/
  5367(c, t, e) {
    var s = e(6518), i = e(2248), n = e(6395), r = i.get, a = i.has, o = i.set;
    s({ target: "Map", proto: !0, real: !0, forced: n }, {
      getOrInsert: function(h, d) {
        return a(this, h) ? r(this, h) : (o(this, h, d), d);
      }
    });
  },
  /***/
  3068(c, t, e) {
    var s = e(6518), i = e(9504), n = e(2652), r = RangeError, a = TypeError, o = 1 / 0, l = NaN, h = Math.abs, d = Math.pow, u = i([].push), f = d(2, 1023), p = d(2, 53) - 1, g = Number.MAX_VALUE, m = d(2, 971), v = {}, y = {}, b = {}, w = {}, A = {}, S = function(E, T) {
      var x = E + T, P = T - (x - E);
      return { hi: x, lo: P };
    };
    s({ target: "Math", stat: !0 }, {
      // eslint-disable-next-line max-statements -- ok
      sumPrecise: function(T) {
        var x = [], P = 0, C = w;
        switch (n(T, function(F) {
          if (++P > p) throw new r("Maximum allowed index exceeded");
          if (typeof F != "number") throw new a("Value is not a number");
          C !== v && (F !== F ? C = v : F === o ? C = C === y ? v : b : F === -o ? C = C === b ? v : y : (F !== 0 || 1 / F === o) && (C === w || C === A) && (C = A, u(x, F)));
        }), C) {
          case v:
            return l;
          case y:
            return -o;
          case b:
            return o;
          case w:
            return -0;
        }
        for (var I = [], R = 0, D, _, M, k, $, U, tt = 0; tt < x.length; tt++) {
          D = x[tt];
          for (var vt = 0, Y = 0; Y < I.length; Y++) {
            if (_ = I[Y], h(D) < h(_) && (U = D, D = _, _ = U), M = S(D, _), k = M.hi, $ = M.lo, h(k) === o) {
              var J = k === o ? 1 : -1;
              R += J, D = D - J * f - J * f, h(D) < h(_) && (U = D, D = _, _ = U), M = S(D, _), k = M.hi, $ = M.lo;
            }
            $ !== 0 && (I[vt++] = $), D = k;
          }
          I.length = vt, D !== 0 && u(I, D);
        }
        var rt = I.length - 1;
        if (k = 0, $ = 0, R !== 0) {
          var Rt = rt >= 0 ? I[rt] : 0;
          if (rt--, h(R) > 1 || R > 0 && Rt > 0 || R < 0 && Rt < 0)
            return R > 0 ? o : -o;
          if (M = S(R * f, Rt / 2), k = M.hi, $ = M.lo, $ *= 2, h(2 * k) === o)
            return k > 0 ? k === f && $ === -(m / 2) && rt >= 0 && I[rt] < 0 ? g : o : k === -f && $ === m / 2 && rt >= 0 && I[rt] > 0 ? -g : -o;
          $ !== 0 && (I[++rt] = $, $ = 0), k *= 2;
        }
        for (; rt >= 0 && (M = S(k, I[rt--]), k = M.hi, $ = M.lo, $ === 0); )
          ;
        return rt >= 0 && ($ < 0 && I[rt] < 0 || $ > 0 && I[rt] > 0) && (_ = $ * 2, D = k + _, _ === D - k && (k = D)), k;
      }
    });
  },
  /***/
  1689(c, t, e) {
    var s = e(6518), i = e(4576), n = e(8745), r = e(7680), a = e(3438), o = e(6043), l = e(9306), h = e(1103), d = e(9039), u = i.Promise, f = !1, p = !u || !u.try || d(function() {
      var g = u.resolve();
      return u.try(function(m) {
        return f = m === 8, g;
      }, 8) !== g;
    }) || !f;
    s({ target: "Promise", stat: !0, forced: p }, {
      try: function(g) {
        var m = arguments.length > 1 ? r(arguments, 1) : [], v = h(function() {
          return n(l(g), void 0, m);
        });
        if (!v.error) return a(this, v.value);
        var y = o.f(this), b = y.reject;
        return b(v.value), y.promise;
      }
    });
  },
  /***/
  7642(c, t, e) {
    var s = e(6518), i = e(3440), n = e(9039), r = e(4916), a = !r("difference", function(l) {
      return l.size === 0;
    }), o = a || n(function() {
      var l = {
        size: 1,
        has: function() {
          return !0;
        },
        keys: function() {
          var d = 0;
          return {
            next: function() {
              var u = d++ > 1;
              return h.has(1) && h.clear(), { done: u, value: 2 };
            }
          };
        }
      }, h = /* @__PURE__ */ new Set([1, 2, 3, 4]);
      return h.difference(l).size !== 3;
    });
    s({ target: "Set", proto: !0, real: !0, forced: o }, {
      difference: i
    });
  },
  /***/
  8004(c, t, e) {
    var s = e(6518), i = e(9039), n = e(8750), r = e(4916), a = !r("intersection", function(o) {
      return o.size === 2 && o.has(1) && o.has(2);
    }) || i(function() {
      return String(Array.from((/* @__PURE__ */ new Set([1, 2, 3])).intersection(/* @__PURE__ */ new Set([3, 2])))) !== "3,2";
    });
    s({ target: "Set", proto: !0, real: !0, forced: a }, {
      intersection: n
    });
  },
  /***/
  3853(c, t, e) {
    var s = e(6518), i = e(4449), n = e(4916), r = !n("isDisjointFrom", function(a) {
      return !a;
    });
    s({ target: "Set", proto: !0, real: !0, forced: r }, {
      isDisjointFrom: i
    });
  },
  /***/
  5876(c, t, e) {
    var s = e(6518), i = e(3838), n = e(4916), r = !n("isSubsetOf", function(a) {
      return a;
    });
    s({ target: "Set", proto: !0, real: !0, forced: r }, {
      isSubsetOf: i
    });
  },
  /***/
  2475(c, t, e) {
    var s = e(6518), i = e(8527), n = e(4916), r = !n("isSupersetOf", function(a) {
      return !a;
    });
    s({ target: "Set", proto: !0, real: !0, forced: r }, {
      isSupersetOf: i
    });
  },
  /***/
  5024(c, t, e) {
    var s = e(6518), i = e(3650), n = e(9835), r = e(4916), a = !r("symmetricDifference") || !n("symmetricDifference");
    s({ target: "Set", proto: !0, real: !0, forced: a }, {
      symmetricDifference: i
    });
  },
  /***/
  1698(c, t, e) {
    var s = e(6518), i = e(4204), n = e(9835), r = e(4916), a = !r("union") || !n("union");
    s({ target: "Set", proto: !0, real: !0, forced: a }, {
      union: i
    });
  },
  /***/
  9577(c, t, e) {
    var s = e(4644), i = e(1108), n = e(6198), r = e(1291), a = e(5854), o = s.aTypedArray, l = s.getTypedArrayConstructor, h = s.exportTypedArrayMethod, d = RangeError, u = (function() {
      try {
        new Int8Array(1).with(2, { valueOf: function() {
          throw 8;
        } });
      } catch (p) {
        return p === 8;
      }
    })(), f = u && (function() {
      try {
        new Int8Array(1).with(-0.5, 1);
      } catch {
        return !0;
      }
    })();
    h("with", function(p, g) {
      var m = o(this), v = n(m), y = r(p), b = y < 0 ? v + y : y, w = i(m) ? a(g) : +g;
      if (b >= v || b < 0) throw new d("Incorrect index");
      for (var A = new (l(m))(v), S = 0; S < v; S++) A[S] = S === b ? w : m[S];
      return A;
    }, !u || f);
  },
  /***/
  5213(c, t, e) {
    var s = e(6518), i = e(4576), n = e(5370), r = e(9143), a = i.Uint8Array, o = !a || !a.fromBase64 || !(function() {
      try {
        a.fromBase64("a");
        return;
      } catch {
      }
      try {
        a.fromBase64("", null);
      } catch {
        return !0;
      }
    })();
    a && s({ target: "Uint8Array", stat: !0, forced: o }, {
      fromBase64: function(h) {
        var d = r(h, arguments.length > 1 ? arguments[1] : void 0, null, 9007199254740991);
        return n(a, d.bytes);
      }
    });
  },
  /***/
  6632(c, t, e) {
    var s = e(6518), i = e(4576), n = e(9143), r = e(4154), a = i.Uint8Array, o = !a || !a.prototype.setFromBase64 || !(function() {
      var l = new a([255, 255, 255, 255, 255]);
      try {
        l.setFromBase64("", null);
        return;
      } catch {
      }
      try {
        l.setFromBase64("a");
        return;
      } catch {
      }
      try {
        l.setFromBase64("MjYyZg===");
      } catch {
        return l[0] === 50 && l[1] === 54 && l[2] === 50 && l[3] === 255 && l[4] === 255;
      }
    })();
    a && s({ target: "Uint8Array", proto: !0, forced: o }, {
      setFromBase64: function(h) {
        r(this);
        var d = n(h, arguments.length > 1 ? arguments[1] : void 0, this, this.length);
        return { read: d.read, written: d.written };
      }
    });
  },
  /***/
  4226(c, t, e) {
    var s = e(6518), i = e(4576), n = e(3463), r = e(4154), a = e(5169), o = e(2303);
    function l() {
      try {
        var h = new ArrayBuffer(16, { maxByteLength: 1024 });
        new Uint8Array(h).setFromHex("cafed00d");
      } catch {
        return !0;
      }
    }
    i.Uint8Array && s({ target: "Uint8Array", proto: !0, forced: l() }, {
      setFromHex: function(d) {
        r(this), n(d), a(this.buffer);
        var u = o(d, this).read;
        return { read: u, written: u / 2 };
      }
    });
  },
  /***/
  9486(c, t, e) {
    var s = e(6518), i = e(4576), n = e(9504), r = e(3972), a = e(4154), o = e(5169), l = e(2804), h = e(944), d = l.i2c, u = l.i2cUrl, f = Math.floor, p = Math.ceil, g = n("".charAt), m = i.Uint8Array, v = i.Array, y = n([].join), b = !m || !m.prototype.toBase64 || !(function() {
      try {
        var w = new m();
        w.toBase64(null);
      } catch {
        return !0;
      }
    })();
    m && s({ target: "Uint8Array", proto: !0, forced: b }, {
      toBase64: function() {
        var A = a(this), S = arguments.length ? r(arguments[0]) : void 0, E = h(S) === "base64" ? d : u, T = !!S && !!S.omitPadding;
        o(this.buffer);
        for (var x = 0, P = A.length, C = v(T ? f(P / 3) * 4 + (P % 3 ? P % 3 + 1 : 0) : p(P / 3) * 4), I = 0, R, D = function(_) {
          return g(E, R >> 6 * _ & 63);
        }; x + 2 < P; x += 3)
          R = (A[x] << 16) + (A[x + 1] << 8) + A[x + 2], C[I++] = D(3), C[I++] = D(2), C[I++] = D(1), C[I++] = D(0);
        return x + 2 === P ? (R = (A[x] << 16) + (A[x + 1] << 8), C[I++] = D(3), C[I++] = D(2), C[I++] = D(1), T || (C[I++] = "=")) : x + 1 === P && (R = A[x] << 16, C[I++] = D(3), C[I++] = D(2), T || (C[I++] = "=", C[I++] = "=")), y(C, "");
      }
    });
  },
  /***/
  456(c, t, e) {
    var s = e(6518), i = e(4576), n = e(9504), r = e(4154), a = e(5169), o = n(1.1.toString), l = n([].join), h = Array, d = i.Uint8Array, u = !d || !d.prototype.toHex || !(function() {
      try {
        var f = new d([255, 255, 255, 255, 255, 255, 255, 255]);
        return f.toHex() === "ffffffffffffffff";
      } catch {
        return !1;
      }
    })();
    d && s({ target: "Uint8Array", proto: !0, forced: u }, {
      toHex: function() {
        r(this), a(this.buffer);
        for (var p = h(this.length), g = 0, m = this.length; g < m; g++) {
          var v = o(this[g], 16);
          p[g] = v.length === 1 ? "0" + v : v;
        }
        return l(p, "");
      }
    });
  },
  /***/
  9452(c, t, e) {
    var s = e(6518), i = e(9306), n = e(6557), r = e(4328), a = e(4995), o = e(6395), l = a.get, h = a.has, d = a.set, u = o || !(function() {
      try {
        WeakMap.prototype.getOrInsertComputed && (/* @__PURE__ */ new WeakMap()).getOrInsertComputed(1, function() {
          throw 1;
        });
      } catch (f) {
        return f instanceof TypeError;
      }
    })();
    s({ target: "WeakMap", proto: !0, real: !0, forced: u }, {
      getOrInsertComputed: function(p, g) {
        if (o || n(this), r(p), i(g), h(this, p)) return l(this, p);
        var m = g(p);
        return d(this, p, m), m;
      }
    });
  },
  /***/
  8454(c, t, e) {
    var s = e(6518), i = e(4995), n = e(6395), r = i.get, a = i.has, o = i.set;
    s({ target: "WeakMap", proto: !0, real: !0, forced: n }, {
      getOrInsert: function(h, d) {
        return a(this, h) ? r(this, h) : (o(this, h, d), d);
      }
    });
  },
  /***/
  4979(c, t, e) {
    var s = e(6518), i = e(4576), n = e(7751), r = e(6980), a = e(4913).f, o = e(9297), l = e(679), h = e(3167), d = e(2603), u = e(5002), f = e(6193), p = e(3724), g = e(6395), m = "DOMException", v = n("Error"), y = n(m), b = function() {
      l(this, w);
      var M = arguments.length, k = d(M < 1 ? void 0 : arguments[0]), $ = d(M < 2 ? void 0 : arguments[1], "Error"), U = new y(k, $), tt = new v(k);
      return tt.name = m, a(U, "stack", r(1, f(tt.stack, 1))), h(U, this, b), U;
    }, w = b.prototype = y.prototype, A = "stack" in new v(m), S = "stack" in new y(1, 2), E = y && p && Object.getOwnPropertyDescriptor(i, m), T = !!E && !(E.writable && E.configurable), x = A && !T && !S;
    s({ global: !0, constructor: !0, forced: g || x }, {
      // TODO: fix export logic
      DOMException: x ? b : y
    });
    var P = n(m), C = P.prototype;
    if (C.constructor !== P) {
      g || a(C, "constructor", r(1, P));
      for (var I in u) if (o(u, I)) {
        var R = u[I], D = R.s;
        o(P, D) || a(P, D, r(6, R.c));
      }
    }
  },
  /***/
  5781(c, t, e) {
    var s = e(6518), i = e(7751), n = e(2812), r = e(655), a = e(7416), o = i("URL");
    s({ target: "URL", stat: !0, forced: !a }, {
      parse: function(h) {
        var d = n(arguments.length, 1), u = r(h), f = d < 2 || arguments[1] === void 0 ? void 0 : r(arguments[1]);
        try {
          return new o(u, f);
        } catch {
          return null;
        }
      }
    });
  }
  /******/
};
const Hi = {};
function K(c) {
  const t = Hi[c];
  if (t !== void 0)
    return t.exports;
  const e = Hi[c] = {
    /******/
    // no module.id needed
    /******/
    // no module.loaded needed
    /******/
    exports: {}
    /******/
  };
  return er[c].call(e.exports, e, e.exports, K), e.exports;
}
K.d = (c, t) => {
  if (Array.isArray(t))
    for (var e = 0; e < t.length; ) {
      var s = t[e++], i = t[e++];
      K.o(c, s) ? i === 0 && e++ : i === 0 ? Object.defineProperty(c, s, { enumerable: !0, value: t[e++] }) : Object.defineProperty(c, s, { enumerable: !0, get: i });
    }
  else
    for (var s in t)
      K.o(t, s) && !K.o(c, s) && Object.defineProperty(c, s, { enumerable: !0, get: t[s] });
};
K.o = (c, t) => Object.prototype.hasOwnProperty.call(c, t);
K(4423);
K(4114);
K(8111);
K(2489);
K(5367);
K(2731);
K(7642);
K(8004);
K(3853);
K(5876);
K(2475);
K(5024);
K(1698);
K(9577);
K(6632);
K(4226);
K(9486);
K(456);
K(5781);
const Bt = typeof process == "object" && process + "" == "[object process]" && !process.versions.nw && !(process.versions.electron && process.type && process.type !== "browser"), oe = [1 / 0, 1 / 0, -1 / 0, -1 / 0], ge = new Float32Array(oe), Ks = [1e-3, 0, 0, 1e-3, 0, 0], Ot = "http://www.w3.org/2000/svg", Ft = {
  ANY: 1,
  DISPLAY: 2,
  PRINT: 4,
  ANNOTATIONS_FORMS: 16,
  ANNOTATIONS_STORAGE: 32,
  ANNOTATIONS_DISABLE: 64,
  IS_EDITING: 128,
  OPLIST: 256
}, le = {
  DISABLE: 0,
  ENABLE: 1,
  ENABLE_FORMS: 2,
  ENABLE_STORAGE: 3
}, Re = "pdfjs_internal_id_", Ne = "pdfjs_internal_editor_", X = {
  DISABLE: -1,
  NONE: 0,
  FREETEXT: 3,
  HIGHLIGHT: 9,
  STAMP: 13,
  INK: 15,
  POPUP: 16,
  SIGNATURE: 101,
  COMMENT: 102
}, q = {
  RESIZE: 1,
  CREATE: 2,
  FREETEXT_SIZE: 11,
  FREETEXT_COLOR: 12,
  FREETEXT_OPACITY: 13,
  INK_COLOR: 21,
  INK_THICKNESS: 22,
  INK_OPACITY: 23,
  INK_COLOR_AND_OPACITY: 24,
  HIGHLIGHT_COLOR: 31,
  HIGHLIGHT_THICKNESS: 32,
  HIGHLIGHT_FREE: 33,
  HIGHLIGHT_SHOW_ALL: 34,
  DRAW_STEP: 41
}, sr = {
  PRINT: 4,
  MODIFY_CONTENTS: 8,
  COPY: 16,
  MODIFY_ANNOTATIONS: 32,
  FILL_INTERACTIVE_FORMS: 256,
  COPY_FOR_ACCESSIBILITY: 512,
  ASSEMBLE: 1024,
  PRINT_HIGH_QUALITY: 2048
}, At = {
  FILL: 0,
  STROKE: 1,
  FILL_STROKE: 2,
  INVISIBLE: 3,
  FILL_STROKE_MASK: 3,
  ADD_TO_PATH_FLAG: 4
}, gs = {
  GRAYSCALE_1BPP: 1,
  RGB_24BPP: 2,
  RGBA_32BPP: 3
}, pt = {
  TEXT: 1,
  LINK: 2,
  FREETEXT: 3,
  LINE: 4,
  SQUARE: 5,
  CIRCLE: 6,
  POLYGON: 7,
  POLYLINE: 8,
  HIGHLIGHT: 9,
  UNDERLINE: 10,
  SQUIGGLY: 11,
  STRIKEOUT: 12,
  STAMP: 13,
  CARET: 14,
  INK: 15,
  POPUP: 16,
  FILEATTACHMENT: 17,
  SOUND: 18,
  MOVIE: 19,
  WIDGET: 20,
  SCREEN: 21,
  PRINTERMARK: 22,
  TRAPNET: 23,
  WATERMARK: 24,
  THREED: 25,
  REDACT: 26,
  RICHMEDIA: 27
}, Ie = {
  SOLID: 1,
  DASHED: 2,
  BEVELED: 3,
  INSET: 4,
  UNDERLINE: 5
}, Ts = {
  ERRORS: 0,
  WARNINGS: 1,
  INFOS: 5
}, se = {
  dependency: 1,
  setLineWidth: 2,
  setLineCap: 3,
  setLineJoin: 4,
  setMiterLimit: 5,
  setDash: 6,
  setRenderingIntent: 7,
  setFlatness: 8,
  setGState: 9,
  save: 10,
  restore: 11,
  transform: 12,
  moveTo: 13,
  lineTo: 14,
  curveTo: 15,
  curveTo2: 16,
  curveTo3: 17,
  closePath: 18,
  rectangle: 19,
  stroke: 20,
  closeStroke: 21,
  fill: 22,
  eoFill: 23,
  fillStroke: 24,
  eoFillStroke: 25,
  closeFillStroke: 26,
  closeEOFillStroke: 27,
  endPath: 28,
  clip: 29,
  eoClip: 30,
  beginText: 31,
  endText: 32,
  setCharSpacing: 33,
  setWordSpacing: 34,
  setHScale: 35,
  setLeading: 36,
  setFont: 37,
  setTextRenderingMode: 38,
  setTextRise: 39,
  moveText: 40,
  setLeadingMoveText: 41,
  setTextMatrix: 42,
  nextLine: 43,
  showText: 44,
  showSpacedText: 45,
  nextLineShowText: 46,
  nextLineSetSpacingShowText: 47,
  setCharWidth: 48,
  setCharWidthAndBounds: 49,
  setStrokeColorSpace: 50,
  setFillColorSpace: 51,
  setStrokeColor: 52,
  setStrokeColorN: 53,
  setFillColor: 54,
  setFillColorN: 55,
  setStrokeGray: 56,
  setFillGray: 57,
  setStrokeRGBColor: 58,
  setFillRGBColor: 59,
  setStrokeCMYKColor: 60,
  setFillCMYKColor: 61,
  shadingFill: 62,
  beginInlineImage: 63,
  beginImageData: 64,
  endInlineImage: 65,
  paintXObject: 66,
  markPoint: 67,
  markPointProps: 68,
  beginMarkedContent: 69,
  beginMarkedContentProps: 70,
  endMarkedContent: 71,
  beginCompat: 72,
  endCompat: 73,
  paintFormXObjectBegin: 74,
  paintFormXObjectEnd: 75,
  beginGroup: 76,
  endGroup: 77,
  beginAnnotation: 80,
  endAnnotation: 81,
  paintImageMaskXObject: 83,
  paintImageMaskXObjectGroup: 84,
  paintImageXObject: 85,
  paintInlineImageXObject: 86,
  paintInlineImageXObjectGroup: 87,
  paintImageXObjectRepeat: 88,
  paintImageMaskXObjectRepeat: 89,
  paintSolidColorImageMask: 90,
  constructPath: 91,
  setStrokeTransparent: 92,
  setFillTransparent: 93,
  rawFillPath: 94
}, je = {
  moveTo: 0,
  lineTo: 1,
  curveTo: 2,
  quadraticCurveTo: 3,
  closePath: 4
}, ir = {
  NEED_PASSWORD: 1,
  INCORRECT_PASSWORD: 2
};
let Cs = Ts.WARNINGS;
function nr(c) {
  Number.isInteger(c) && (Cs = c);
}
function rr() {
  return Cs;
}
function Ps(c) {
  Cs >= Ts.INFOS && console.info(`Info: ${c}`);
}
function V(c) {
  Cs >= Ts.WARNINGS && console.warn(`Warning: ${c}`);
}
function st(c) {
  throw new Error(c);
}
function gt(c, t) {
  c || st(t);
}
function ar(c) {
  switch (c?.protocol) {
    case "http:":
    case "https:":
    case "ftp:":
    case "mailto:":
    case "tel:":
      return !0;
    default:
      return !1;
  }
}
function bn(c, t = null, e = null) {
  if (!c)
    return null;
  if (e && typeof c == "string" && (e.addDefaultProtocol && c.startsWith("www.") && c.match(/\./g)?.length >= 2 && (c = `http://${c}`), e.tryConvertEncoding))
    try {
      c = hr(c);
    } catch {
    }
  const s = t ? URL.parse(c, t) : URL.parse(c);
  return ar(s) ? s : null;
}
function An(c, t, e = !1) {
  const s = URL.parse(c);
  return s ? (s.hash = t, s.href) : e && bn(c, "http://example.com") ? c.split("#", 1)[0] + `${t ? `#${t}` : ""}` : "";
}
function Js(c) {
  return c.substring(c.lastIndexOf("/") + 1);
}
function j(c, t, e, s = !1) {
  return Object.defineProperty(c, t, {
    value: e,
    enumerable: !s,
    configurable: !0,
    writable: !1
  }), e;
}
const Ee = (function() {
  function t(e, s) {
    this.message = e, this.name = s;
  }
  return t.prototype = new Error(), t.constructor = t, t;
})();
class Qs extends Ee {
  constructor(t, e) {
    super(t, "PasswordException"), this.code = e;
  }
}
class $s extends Ee {
  constructor(t, e) {
    super(t, "UnknownErrorException"), this.details = e;
  }
}
class Zs extends Ee {
  constructor(t) {
    super(t, "InvalidPDFException");
  }
}
class bs extends Ee {
  constructor(t, e, s) {
    super(t, "ResponseException"), this.status = e, this.missing = s;
  }
}
class or extends Ee {
  constructor(t) {
    super(t, "FormatError");
  }
}
class ce extends Ee {
  constructor(t) {
    super(t, "AbortException");
  }
}
function lr(c) {
  (typeof c != "object" || c?.length === void 0) && st("Invalid argument for bytesToString");
  const t = c.length, e = 8192;
  if (t < e)
    return String.fromCharCode.apply(null, c);
  const s = [];
  for (let i = 0; i < t; i += e) {
    const n = Math.min(i + e, t), r = c.subarray(i, n);
    s.push(String.fromCharCode.apply(null, r));
  }
  return s.join("");
}
function Is(c) {
  typeof c != "string" && st("Invalid argument for stringToBytes");
  const t = c.length, e = new Uint8Array(t);
  for (let s = 0; s < t; ++s)
    e[s] = c.charCodeAt(s) & 255;
  return e;
}
class at {
  static get isLittleEndian() {
    const t = new Uint8Array(4);
    t[0] = 1;
    const e = new Uint32Array(t.buffer, 0, 1);
    return j(this, "isLittleEndian", e[0] === 1);
  }
  static get isOffscreenCanvasSupported() {
    return j(this, "isOffscreenCanvasSupported", typeof OffscreenCanvas < "u");
  }
  static get isImageDecoderSupported() {
    return j(this, "isImageDecoderSupported", typeof ImageDecoder < "u");
  }
  static get isFloat16ArraySupported() {
    return j(this, "isFloat16ArraySupported", typeof Float16Array < "u");
  }
  static get isSanitizerSupported() {
    return j(this, "isSanitizerSupported", typeof Sanitizer < "u");
  }
  static get platform() {
    const {
      platform: t,
      userAgent: e
    } = navigator;
    return j(this, "platform", {
      isAndroid: e.includes("Android"),
      isLinux: t.includes("Linux"),
      isMac: t.includes("Mac"),
      isWindows: t.includes("Win"),
      isFirefox: e.includes("Firefox")
    });
  }
  static get isCanvasFilterSupported() {
    let t;
    return this.isOffscreenCanvasSupported ? t = new OffscreenCanvas(1, 1).getContext("2d") : typeof document < "u" && (t = document.createElement("canvas").getContext("2d")), j(this, "isCanvasFilterSupported", t?.filter !== void 0);
  }
  static get isAlphaColorInputSupported() {
    if (typeof document > "u")
      return j(this, "isAlphaColorInputSupported", !1);
    const t = document.createElement("input");
    return t.type = "color", t.setAttribute("alpha", ""), t.value = "#ff000080", j(this, "isAlphaColorInputSupported", t.value !== "#ff0000");
  }
  static get isBackdropFilterSupported() {
    return j(this, "isBackdropFilterSupported", typeof CSS < "u" && CSS.supports("backdrop-filter", "blur(1px)"));
  }
}
class N {
  static get hexNums() {
    return j(this, "hexNums", Array.from({
      length: 256
    }, (t, e) => e.toString(16).padStart(2, "0")));
  }
  static makeHexColor(t, e, s) {
    return `#${this.hexNums[t]}${this.hexNums[e]}${this.hexNums[s]}`;
  }
  static transform(t, e) {
    return [t[0] * e[0] + t[2] * e[1], t[1] * e[0] + t[3] * e[1], t[0] * e[2] + t[2] * e[3], t[1] * e[2] + t[3] * e[3], t[0] * e[4] + t[2] * e[5] + t[4], t[1] * e[4] + t[3] * e[5] + t[5]];
  }
  static multiplyByDOMMatrix(t, e) {
    return [t[0] * e.a + t[2] * e.b, t[1] * e.a + t[3] * e.b, t[0] * e.c + t[2] * e.d, t[1] * e.c + t[3] * e.d, t[0] * e.e + t[2] * e.f + t[4], t[1] * e.e + t[3] * e.f + t[5]];
  }
  static applyTransform(t, e, s = 0) {
    const i = t[s], n = t[s + 1];
    t[s] = i * e[0] + n * e[2] + e[4], t[s + 1] = i * e[1] + n * e[3] + e[5];
  }
  static applyTransformToBezier(t, e, s = 0) {
    const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5];
    for (let h = 0; h < 6; h += 2) {
      const d = t[s + h], u = t[s + h + 1];
      t[s + h] = d * i + u * r + o, t[s + h + 1] = d * n + u * a + l;
    }
  }
  static applyInverseTransform(t, e) {
    const s = t[0], i = t[1], n = e[0] * e[3] - e[1] * e[2];
    t[0] = (s * e[3] - i * e[2] + e[2] * e[5] - e[4] * e[3]) / n, t[1] = (-s * e[1] + i * e[0] + e[4] * e[1] - e[5] * e[0]) / n;
  }
  static axialAlignedBoundingBox(t, e, s) {
    const i = e[0], n = e[1], r = e[2], a = e[3], o = e[4], l = e[5], h = t[0], d = t[1], u = t[2], f = t[3];
    let p = i * h + o, g = p, m = i * u + o, v = m, y = a * d + l, b = y, w = a * f + l, A = w;
    if (n !== 0 || r !== 0) {
      const S = n * h, E = n * u, T = r * d, x = r * f;
      p += T, v += T, m += x, g += x, y += S, A += S, w += E, b += E;
    }
    s[0] = Math.min(s[0], p, m, g, v), s[1] = Math.min(s[1], y, w, b, A), s[2] = Math.max(s[2], p, m, g, v), s[3] = Math.max(s[3], y, w, b, A);
  }
  static inverseTransform(t) {
    const e = t[0] * t[3] - t[1] * t[2];
    return [t[3] / e, -t[1] / e, -t[2] / e, t[0] / e, (t[2] * t[5] - t[4] * t[3]) / e, (t[4] * t[1] - t[5] * t[0]) / e];
  }
  static singularValueDecompose2dScale(t, e) {
    const s = t[0], i = t[1], n = t[2], r = t[3], a = s ** 2 + i ** 2, o = s * n + i * r, l = n ** 2 + r ** 2, h = (a + l) / 2, d = Math.sqrt(h ** 2 - (a * l - o ** 2));
    e[0] = Math.sqrt(h + d || 1), e[1] = Math.sqrt(h - d || 1);
  }
  static normalizeRect(t) {
    const e = t.slice(0);
    return t[0] > t[2] && (e[0] = t[2], e[2] = t[0]), t[1] > t[3] && (e[1] = t[3], e[3] = t[1]), e;
  }
  static intersect(t, e) {
    const s = Math.max(Math.min(t[0], t[2]), Math.min(e[0], e[2])), i = Math.min(Math.max(t[0], t[2]), Math.max(e[0], e[2]));
    if (s > i)
      return null;
    const n = Math.max(Math.min(t[1], t[3]), Math.min(e[1], e[3])), r = Math.min(Math.max(t[1], t[3]), Math.max(e[1], e[3]));
    return n > r ? null : [s, n, i, r];
  }
  static pointBoundingBox(t, e, s) {
    s[0] = Math.min(s[0], t), s[1] = Math.min(s[1], e), s[2] = Math.max(s[2], t), s[3] = Math.max(s[3], e);
  }
  static rectBoundingBox(t, e, s, i, n) {
    n[0] = Math.min(n[0], t, s), n[1] = Math.min(n[1], e, i), n[2] = Math.max(n[2], t, s), n[3] = Math.max(n[3], e, i);
  }
  static #t(t, e, s, i, n, r, a, o, l, h) {
    if (l <= 0 || l >= 1)
      return;
    const d = 1 - l, u = l * l, f = u * l, p = d * (d * (d * t + 3 * l * e) + 3 * u * s) + f * i, g = d * (d * (d * n + 3 * l * r) + 3 * u * a) + f * o;
    h[0] = Math.min(h[0], p), h[1] = Math.min(h[1], g), h[2] = Math.max(h[2], p), h[3] = Math.max(h[3], g);
  }
  static #e(t, e, s, i, n, r, a, o, l, h, d, u) {
    if (Math.abs(l) < 1e-12) {
      Math.abs(h) >= 1e-12 && this.#t(t, e, s, i, n, r, a, o, -d / h, u);
      return;
    }
    const f = h ** 2 - 4 * d * l;
    if (f < 0)
      return;
    const p = Math.sqrt(f), g = 2 * l;
    this.#t(t, e, s, i, n, r, a, o, (-h + p) / g, u), this.#t(t, e, s, i, n, r, a, o, (-h - p) / g, u);
  }
  static bezierBoundingBox(t, e, s, i, n, r, a, o, l) {
    l[0] = Math.min(l[0], t, a), l[1] = Math.min(l[1], e, o), l[2] = Math.max(l[2], t, a), l[3] = Math.max(l[3], e, o), this.#e(t, s, n, a, e, i, r, o, 3 * (-t + 3 * (s - n) + a), 6 * (t - 2 * s + n), 3 * (s - t), l), this.#e(t, s, n, a, e, i, r, o, 3 * (-e + 3 * (i - r) + o), 6 * (e - 2 * i + r), 3 * (i - e), l);
  }
}
function hr(c) {
  return decodeURIComponent(escape(c));
}
let Gs = null, ji = null;
function cr(c) {
  return Gs || (Gs = /([\u00a0\u00b5\u037e\u0eb3\u2000-\u200a\u202f\u2126\ufb00-\ufb04\ufb06\ufb20-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufba1\ufba4-\ufba9\ufbae-\ufbb1\ufbd3-\ufbdc\ufbde-\ufbe7\ufbea-\ufbf8\ufbfc\ufbfd\ufc00-\ufc5d\ufc64-\ufcf1\ufcf5-\ufd3d\ufd88\ufdf4\ufdfa\ufdfb\ufe71\ufe77\ufe79\ufe7b\ufe7d]+)|(\ufb05+)/gu, ji = /* @__PURE__ */ new Map([["\uFB05", "\u017Ft"]])), c.replaceAll(Gs, (t, e, s) => e ? e.normalize("NFKC") : ji.get(s));
}
function Sn() {
  if (typeof crypto.randomUUID == "function")
    return crypto.randomUUID();
  const c = new Uint8Array(32);
  return crypto.getRandomValues(c), lr(c);
}
function dr(c, t, e) {
  if (!Array.isArray(e) || e.length < 2)
    return !1;
  const [s, i, ...n] = e;
  if (!c(s) && !Number.isInteger(s) || !t(i))
    return !1;
  const r = n.length;
  let a = !0;
  switch (i.name) {
    case "XYZ":
      if (r < 2 || r > 3)
        return !1;
      break;
    case "Fit":
    case "FitB":
      return r === 0;
    case "FitH":
    case "FitBH":
    case "FitV":
    case "FitBV":
      if (r > 1)
        return !1;
      break;
    case "FitR":
      if (r !== 4)
        return !1;
      a = !1;
      break;
    default:
      return !1;
  }
  for (const o of n)
    if (!(typeof o == "number" || a && o === null))
      return !1;
  return !0;
}
const Le = () => [], di = () => /* @__PURE__ */ new Map(), qs = () => /* @__PURE__ */ Object.create(null), ur = () => /* @__PURE__ */ new Set();
typeof Blob.prototype.bytes != "function" && (Blob.prototype.bytes = async function() {
  return new Uint8Array(await this.arrayBuffer());
});
typeof Response.prototype.bytes != "function" && (Response.prototype.bytes = async function() {
  return new Uint8Array(await this.arrayBuffer());
});
typeof Iterator.prototype.join != "function" && (Iterator.prototype.join = function(c) {
  return [...this].join(c);
});
K(1701);
function ct(c, t, e) {
  return Math.min(Math.max(c, t), e);
}
class es {
  constructor({
    viewBox: t,
    userUnit: e,
    scale: s,
    rotation: i,
    offsetX: n = 0,
    offsetY: r = 0,
    dontFlip: a = !1
  }) {
    this.viewBox = t, this.userUnit = e, this.scale = s, this.rotation = i, this.offsetX = n, this.offsetY = r, s *= e;
    const o = (t[2] + t[0]) / 2, l = (t[3] + t[1]) / 2;
    let h, d, u, f;
    switch (i %= 360, i < 0 && (i += 360), i) {
      case 180:
        h = -1, d = 0, u = 0, f = 1;
        break;
      case 90:
        h = 0, d = 1, u = 1, f = 0;
        break;
      case 270:
        h = 0, d = -1, u = -1, f = 0;
        break;
      case 0:
        h = 1, d = 0, u = 0, f = -1;
        break;
      default:
        throw new Error("PageViewport: Invalid rotation, must be a multiple of 90 degrees.");
    }
    a && (u = -u, f = -f);
    let p, g, m, v;
    h === 0 ? (p = Math.abs(l - t[1]) * s + n, g = Math.abs(o - t[0]) * s + r, m = (t[3] - t[1]) * s, v = (t[2] - t[0]) * s) : (p = Math.abs(o - t[0]) * s + n, g = Math.abs(l - t[1]) * s + r, m = (t[2] - t[0]) * s, v = (t[3] - t[1]) * s), this.transform = [h * s, d * s, u * s, f * s, p - h * s * o - u * s * l, g - d * s * o - f * s * l], this.width = m, this.height = v;
  }
  get rawDims() {
    const t = this.viewBox;
    return j(this, "rawDims", {
      pageWidth: t[2] - t[0],
      pageHeight: t[3] - t[1],
      pageX: t[0],
      pageY: t[1]
    });
  }
  clone({
    scale: t = this.scale,
    rotation: e = this.rotation,
    offsetX: s = this.offsetX,
    offsetY: i = this.offsetY,
    dontFlip: n = !1
  } = {}) {
    return new es({
      viewBox: this.viewBox.slice(),
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: n
    });
  }
  convertToViewportPoint(t, e) {
    const s = [t, e];
    return N.applyTransform(s, this.transform), s;
  }
  convertToPdfPoint(t, e) {
    const s = [t, e];
    return N.applyInverseTransform(s, this.transform), s;
  }
}
class Je {
  static textContent(t) {
    const e = [], s = {
      items: e,
      styles: /* @__PURE__ */ Object.create(null)
    };
    function i(n) {
      if (!n)
        return;
      let r = null;
      const a = n.name;
      if (a === "#text")
        r = n.value;
      else if (Je.shouldBuildText(a))
        n?.attributes?.textContent ? r = n.attributes.textContent : n.value && (r = n.value);
      else return;
      if (r !== null && e.push({
        str: r
      }), !!n.children)
        for (const o of n.children)
          i(o);
    }
    return i(t), s;
  }
  static shouldBuildText(t) {
    return !(t === "textarea" || t === "input" || t === "option" || t === "select");
  }
}
const fr = /url\(|image-set\(/i, pr = /^on/i;
class wn {
  static get _allowedHtmlElements() {
    return j(this, "_allowedHtmlElements", /* @__PURE__ */ new Set(["a", "b", "br", "button", "div", "i", "img", "input", "label", "li", "ol", "option", "p", "select", "span", "sub", "sup", "textarea", "ul"]));
  }
  static get _allowedSvgElements() {
    return j(this, "_allowedSvgElements", /* @__PURE__ */ new Set(["ellipse", "line", "path", "rect", "svg"]));
  }
  static get _allowedRichTextElements() {
    return j(this, "_allowedRichTextElements", /* @__PURE__ */ new Set(["a", "b", "br", "div", "i", "li", "ol", "p", "span", "sub", "sup", "ul"]));
  }
  static get _allowedRichTextAttributes() {
    return j(this, "_allowedRichTextAttributes", /* @__PURE__ */ new Set(["class", "dir", "style"]));
  }
  static get _allowedRichTextStyles() {
    return j(this, "_allowedRichTextStyles", /* @__PURE__ */ new Set(["color", "font", "fontFamily", "fontSize", "fontStretch", "fontStyle", "fontWeight", "kerningMode", "letterSpacing", "lineHeight", "margin", "marginBottom", "marginLeft", "marginRight", "marginTop", "orphans", "paddingLeft", "paddingRight", "breakAfter", "breakBefore", "breakInside", "tabInterval", "tabStop", "textAlign", "textDecoration", "textIndent", "transform", "verticalAlign", "widows"]));
  }
  static setupStorage(t, e, s, i, n) {
    const r = i.getValue(e, {
      value: null
    });
    switch (s.name) {
      case "textarea":
        if (r.value !== null && (t.textContent = r.value), n === "print")
          break;
        t.addEventListener("input", (a) => {
          i.setValue(e, {
            value: a.target.value
          });
        });
        break;
      case "input":
        if (s.attributes.type === "radio" || s.attributes.type === "checkbox") {
          if (r.value === s.attributes.xfaOn ? t.setAttribute("checked", !0) : r.value === s.attributes.xfaOff && t.removeAttribute("checked"), n === "print")
            break;
          t.addEventListener("change", (a) => {
            i.setValue(e, {
              value: a.target.checked ? a.target.getAttribute("xfaOn") : a.target.getAttribute("xfaOff")
            });
          });
        } else {
          if (r.value !== null && t.setAttribute("value", r.value), n === "print")
            break;
          t.addEventListener("input", (a) => {
            i.setValue(e, {
              value: a.target.value
            });
          });
        }
        break;
      case "select":
        if (r.value !== null) {
          t.setAttribute("value", r.value);
          for (const a of s.children)
            a.attributes.value === r.value ? a.attributes.selected = !0 : Object.hasOwn(a.attributes, "selected") && delete a.attributes.selected;
        }
        t.addEventListener("input", (a) => {
          const o = a.target.options, l = o.selectedIndex === -1 ? "" : o[o.selectedIndex].value;
          i.setValue(e, {
            value: l
          });
        });
        break;
    }
  }
  static setAttributes({
    html: t,
    element: e,
    storage: s = null,
    intent: i,
    linkService: n
  }) {
    const {
      attributes: r
    } = e, a = t instanceof HTMLAnchorElement;
    r.type === "radio" && (r.name = `${r.name}-${i}`);
    for (const [o, l] of Object.entries(r))
      if (l != null && !pr.test(o) && !(i === "richText" && !this._allowedRichTextAttributes.has(o)))
        switch (o) {
          case "class":
            l.length && t.setAttribute(o, l.join(" "));
            break;
          case "dataId":
            break;
          case "id":
            t.setAttribute("data-element-id", l);
            break;
          case "style":
            if (i === "richText") {
              const h = this._allowedRichTextStyles;
              for (const [d, u] of Object.entries(l))
                h.has(d) && !fr.test(u) && (t.style[d] = u);
            } else
              Object.assign(t.style, l);
            break;
          case "textContent":
            t.textContent = l;
            break;
          default:
            (!a || o !== "href" && o !== "newWindow") && t.setAttribute(o, l);
        }
    a && n?.addLinkAttributes(t, r.href, r.newWindow), s && r.dataId && this.setupStorage(t, r.dataId, e, s);
  }
  static #t(t, e, s) {
    return s === "richText" ? !e && this._allowedRichTextElements.has(t) ? document.createElement(t) : null : e ? e === Ot && this._allowedSvgElements.has(t) ? document.createElementNS(Ot, t) : null : this._allowedHtmlElements.has(t) ? document.createElement(t) : null;
  }
  static render(t) {
    const e = t.annotationStorage, s = t.linkService, i = t.xfaHtml, n = t.intent || "display", r = this.#t(i.name, i.attributes?.xmlns, n) ?? document.createElement("div");
    i.attributes && this.setAttributes({
      html: r,
      element: i,
      intent: n,
      linkService: s
    });
    const a = n !== "richText", o = t.div;
    if (o.append(r), t.viewport) {
      const d = `matrix(${t.viewport.transform.join(",")})`;
      o.style.transform = d;
    }
    a && o.setAttribute("class", "xfaLayer xfaFont");
    const l = [];
    if (i.children.length === 0) {
      if (i.value) {
        const d = document.createTextNode(i.value);
        r.append(d), a && Je.shouldBuildText(i.name) && l.push(d);
      }
      return {
        textDivs: l
      };
    }
    const h = [[i, -1, r]];
    for (; h.length > 0; ) {
      const [d, u, f] = h.at(-1);
      if (u + 1 === d.children.length) {
        h.pop();
        continue;
      }
      const p = d.children[++h.at(-1)[1]];
      if (p === null)
        continue;
      const {
        name: g
      } = p;
      if (g === "#text") {
        const v = document.createTextNode(p.value);
        l.push(v), f.append(v);
        continue;
      }
      const m = this.#t(g, p.attributes?.xmlns, n);
      if (m) {
        if (f.append(m), p.attributes && this.setAttributes({
          html: m,
          element: p,
          storage: e,
          intent: n,
          linkService: s
        }), p.children?.length > 0)
          h.push([p, -1, m]);
        else if (p.value) {
          const v = document.createTextNode(p.value);
          a && Je.shouldBuildText(g) && l.push(v), m.append(v);
        }
      }
    }
    for (const d of o.querySelectorAll(".xfaNonInteractive input, .xfaNonInteractive textarea"))
      d.setAttribute("readOnly", !0);
    return {
      textDivs: l
    };
  }
  static update(t) {
    const e = `matrix(${t.viewport.transform.join(",")})`;
    t.div.style.transform = e, t.div.hidden = !1;
  }
  static getPageViewport(t, {
    scale: e = 1,
    rotation: s = 0
  }) {
    const {
      width: i,
      height: n
    } = t.attributes.style;
    return new es({
      viewBox: [0, 0, parseInt(i, 10), parseInt(n, 10)],
      userUnit: 1,
      scale: e,
      rotation: s
    });
  }
}
class Fe {
  static CSS = 96;
  static PDF = 72;
  static PDF_TO_CSS_UNITS = this.CSS / this.PDF;
}
async function ui(c, t = "text") {
  if (We(c, document.baseURI)) {
    const e = await fetch(c);
    if (!e.ok)
      throw new Error(e.statusText);
    switch (t) {
      case "blob":
        return e.blob();
      case "bytes":
        return e.bytes();
      case "json":
        return e.json();
    }
    return e.text();
  }
  return new Promise((e, s) => {
    const i = new XMLHttpRequest();
    i.open("GET", c, !0), i.responseType = t === "bytes" ? "arraybuffer" : t, i.onreadystatechange = () => {
      if (i.readyState === XMLHttpRequest.DONE) {
        if (i.status === 200 || i.status === 0) {
          switch (t) {
            case "bytes":
              e(new Uint8Array(i.response));
              return;
            case "blob":
            case "json":
              e(i.response);
              return;
          }
          e(i.responseText);
          return;
        }
        s(new Error(i.statusText));
      }
    }, i.send(null);
  });
}
class fi extends Ee {
  constructor(t, e = 0) {
    super(t, "RenderingCancelledException"), this.extraDelay = e;
  }
}
function Os(c) {
  const t = c.length;
  let e = 0;
  for (; e < t && c[e].trim() === ""; )
    e++;
  return c.substring(e, e + 5).toLowerCase() === "data:";
}
function pi(c) {
  return typeof c == "string" && /\.pdf$/i.test(c);
}
function gr(c) {
  return [c] = c.split(/[#?]/, 1), Js(c);
}
function mr(c, t = "document.pdf") {
  if (typeof c != "string")
    return t;
  if (Os(c))
    return V('getPdfFilenameFromUrl: ignore "data:"-URL for performance reasons.'), t;
  const s = ((a) => {
    try {
      return new URL(a);
    } catch {
    }
    try {
      return new URL(decodeURIComponent(a));
    } catch {
    }
    try {
      return new URL(a, "https://foo.bar");
    } catch {
    }
    try {
      return new URL(decodeURIComponent(a), "https://foo.bar");
    } catch {
    }
    return null;
  })(c);
  if (!s)
    return t;
  const i = (a) => {
    try {
      let o = decodeURIComponent(a);
      return o.includes("/") && (o = Js(o), o.length === 4 && n.test(o)) ? a : o;
    } catch {
      return a;
    }
  }, n = /\.pdf$/i, r = Js(s.pathname);
  if (n.test(r))
    return i(r);
  if (s.searchParams.size > 0) {
    const a = (l) => [...l].findLast((h) => n.test(h)), o = a(s.searchParams.values()) ?? a(s.searchParams.keys());
    if (o)
      return i(o);
  }
  if (s.hash) {
    const {
      hash: a
    } = s;
    let o = -1;
    for (const {
      index: l
    } of a.matchAll(/\.pdf\b/gi))
      o = l;
    if (o > 0) {
      let l = o;
      for (; l > 0 && !"/?#=".includes(a[l - 1]); )
        l--;
      if (l < o)
        return i(a.slice(l, o + 4));
    }
  }
  return t;
}
class $i {
  #t = /* @__PURE__ */ new Map();
  times = [];
  time(t) {
    this.#t.has(t) && V(`Timer is already running for ${t}`), this.#t.set(t, Date.now());
  }
  timeEnd(t) {
    this.#t.has(t) || V(`Timer has not been started for ${t}`), this.times.push({
      name: t,
      start: this.#t.get(t),
      end: Date.now()
    }), this.#t.delete(t);
  }
  toString() {
    const t = Math.max(...this.times.map((e) => e.name.length));
    return this.times.map((e) => `${e.name.padEnd(t)} ${e.end - e.start}ms
`).join("");
  }
}
function We(c, t) {
  const e = t ? URL.parse(c, t) : URL.parse(c);
  return /https?:/.test(e?.protocol ?? "");
}
function Yt(c) {
  c.preventDefault();
}
function St(c) {
  c.preventDefault(), c.stopPropagation();
}
class ti {
  static #t;
  static toDateObject(t) {
    if (t instanceof Date)
      return t;
    if (!t || typeof t != "string")
      return null;
    this.#t ||= new RegExp("^D:(\\d{4})(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?(\\d{2})?([Z|+\\-])?(\\d{2})?'?(\\d{2})?'?");
    const e = this.#t.exec(t);
    if (!e)
      return null;
    const s = parseInt(e[1], 10);
    let i = parseInt(e[2], 10);
    i = i >= 1 && i <= 12 ? i - 1 : 0;
    let n = parseInt(e[3], 10);
    n = n >= 1 && n <= 31 ? n : 1;
    let r = parseInt(e[4], 10);
    r = r >= 0 && r <= 23 ? r : 0;
    let a = parseInt(e[5], 10);
    a = a >= 0 && a <= 59 ? a : 0;
    let o = parseInt(e[6], 10);
    o = o >= 0 && o <= 59 ? o : 0;
    const l = e[7] || "Z";
    let h = parseInt(e[8], 10);
    h = h >= 0 && h <= 23 ? h : 0;
    let d = parseInt(e[9], 10) || 0;
    return d = d >= 0 && d <= 59 ? d : 0, l === "-" ? (r += h, a += d) : l === "+" && (r -= h, a -= d), new Date(Date.UTC(s, i, n, r, a, o));
  }
}
function ss(c) {
  if (c.startsWith("#")) {
    const e = c.slice(1);
    return [parseInt(e.slice(0, 2), 16), parseInt(e.slice(2, 4), 16), parseInt(e.slice(4, 6), 16), e.length >= 8 ? parseInt(e.slice(6, 8), 16) / 255 : 1];
  }
  if (c.startsWith("rgb(")) {
    const [e, s, i] = c.slice(4, -1).split(",").map((n) => parseInt(n, 10));
    return [e, s, i, 1];
  }
  if (c.startsWith("rgba(")) {
    const e = c.slice(5, -1).split(",");
    return [parseInt(e[0], 10), parseInt(e[1], 10), parseInt(e[2], 10), parseFloat(e[3])];
  }
  const t = c.match(/^color\(srgb\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)(?:\s*\/\s*([\d.]+|none))?\)$/);
  return t ? [Math.round(parseFloat(t[1]) * 255), Math.round(parseFloat(t[2]) * 255), Math.round(parseFloat(t[3]) * 255), t[4] !== void 0 && t[4] !== "none" ? parseFloat(t[4]) : 1] : null;
}
function is(c) {
  const t = ss(c);
  return t ? t.slice(0, 3) : (V(`Not a valid color format: "${c}"`), [0, 0, 0]);
}
function vr(c) {
  const t = document.createElement("span");
  t.style.visibility = "hidden", t.style.colorScheme = "only light", document.body.append(t);
  for (const e of c.keys()) {
    t.style.color = e;
    const s = window.getComputedStyle(t).color;
    c.set(e, is(s));
  }
  t.remove();
}
function ht(c) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: n,
    f: r
  } = c.getTransform();
  return [t, e, s, i, n, r];
}
function qt(c) {
  const {
    a: t,
    b: e,
    c: s,
    d: i,
    e: n,
    f: r
  } = c.getTransform().invertSelf();
  return [t, e, s, i, n, r];
}
function Se(c, t, e = !1, s = !0) {
  if (t instanceof es) {
    const {
      pageWidth: i,
      pageHeight: n
    } = t.rawDims, {
      style: r
    } = c, a = `round(down, var(--total-scale-factor) * ${i}px, var(--scale-round-x))`, o = `round(down, var(--total-scale-factor) * ${n}px, var(--scale-round-y))`;
    !e || t.rotation % 180 === 0 ? (r.width = a, r.height = o) : (r.width = o, r.height = a);
  }
  s && c.setAttribute("data-main-rotation", t.rotation);
}
class Kt {
  constructor() {
    const {
      pixelRatio: t
    } = Kt;
    this.sx = t, this.sy = t;
  }
  get scaled() {
    return this.sx !== 1 || this.sy !== 1;
  }
  get symmetric() {
    return this.sx === this.sy;
  }
  limitCanvas(t, e, s, i, n = -1) {
    let r = 1 / 0, a = 1 / 0, o = 1 / 0;
    s = Kt.capPixels(s, n), s > 0 && (r = Math.sqrt(s / (t * e))), i !== -1 && (a = i / t, o = i / e);
    const l = Math.min(r, a, o);
    return this.sx > l || this.sy > l ? (this.sx = l, this.sy = l, !0) : !1;
  }
  static get pixelRatio() {
    return globalThis.devicePixelRatio || 1;
  }
  static capPixels(t, e) {
    if (e >= 0) {
      const s = Math.ceil(window.screen.availWidth * window.screen.availHeight * this.pixelRatio ** 2 * (1 + e / 100));
      return t > 0 ? Math.min(t, s) : s;
    }
    return t;
  }
}
const ei = ["image/apng", "image/avif", "image/bmp", "image/gif", "image/jpeg", "image/png", "image/svg+xml", "image/webp", "image/x-icon"];
class yr {
  static get isDarkMode() {
    return j(this, "isDarkMode", !!window?.matchMedia?.("(prefers-color-scheme: dark)").matches);
  }
}
class br {
  static get commentForegroundColor() {
    const t = document.createElement("span");
    t.classList.add("comment", "sidebar");
    const {
      style: e
    } = t;
    e.width = e.height = "0", e.display = "none", e.color = "var(--comment-fg-color)", document.body.append(t);
    const {
      color: s
    } = window.getComputedStyle(t);
    return t.remove(), j(this, "commentForegroundColor", is(s));
  }
}
function Ar(c, t) {
  t = ct(t ?? 1, 0, 1);
  const e = 255 * (1 - t);
  return c.map((s) => Math.round(s * t + e));
}
function Gi(c, t) {
  const e = c[0] / 255, s = c[1] / 255, i = c[2] / 255, n = Math.max(e, s, i), r = Math.min(e, s, i), a = (n + r) / 2;
  if (n === r)
    t[0] = t[1] = 0;
  else {
    const o = n - r;
    switch (t[1] = a < 0.5 ? o / (n + r) : o / (2 - n - r), n) {
      case e:
        t[0] = ((s - i) / o + (s < i ? 6 : 0)) * 60;
        break;
      case s:
        t[0] = ((i - e) / o + 2) * 60;
        break;
      case i:
        t[0] = ((e - s) / o + 4) * 60;
        break;
    }
  }
  t[2] = a;
}
function si(c, t) {
  const e = c[0], s = c[1], i = c[2], n = (1 - Math.abs(2 * i - 1)) * s, r = n * (1 - Math.abs(e / 60 % 2 - 1)), a = i - n / 2;
  switch (Math.floor(e / 60)) {
    case 0:
      t[0] = n + a, t[1] = r + a, t[2] = a;
      break;
    case 1:
      t[0] = r + a, t[1] = n + a, t[2] = a;
      break;
    case 2:
      t[0] = a, t[1] = n + a, t[2] = r + a;
      break;
    case 3:
      t[0] = a, t[1] = r + a, t[2] = n + a;
      break;
    case 4:
      t[0] = r + a, t[1] = a, t[2] = n + a;
      break;
    case 5:
    case 6:
      t[0] = n + a, t[1] = a, t[2] = r + a;
      break;
  }
}
function ii(c) {
  return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4;
}
function Vi(c, t, e) {
  si(c, e), e.map(ii);
  const s = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  si(t, e), e.map(ii);
  const i = 0.2126 * e[0] + 0.7152 * e[1] + 0.0722 * e[2];
  return s > i ? (s + 0.05) / (i + 0.05) : (i + 0.05) / (s + 0.05);
}
const zi = /* @__PURE__ */ new Map();
function Sr(c, t) {
  const e = c[0] + c[1] * 256 + c[2] * 65536 + t[0] * 16777216 + t[1] * 4294967296 + t[2] * 1099511627776;
  let s = zi.get(e);
  if (s)
    return s;
  const i = new Float32Array(9), n = i.subarray(0, 3), r = i.subarray(3, 6);
  Gi(c, r);
  const a = i.subarray(6, 9);
  Gi(t, a);
  const o = a[2] < 0.5, l = o ? 12 : 4.5;
  if (r[2] = o ? Math.sqrt(r[2]) : 1 - Math.sqrt(1 - r[2]), Vi(r, a, n) < l) {
    let h, d;
    o ? (h = r[2], d = 1) : (h = 0, d = r[2]);
    const u = 5e-3;
    for (; d - h > u; ) {
      const f = r[2] = (h + d) / 2;
      o === Vi(r, a, n) < l ? h = f : d = f;
    }
    r[2] = o ? d : h;
  }
  return si(r, n), s = N.makeHexColor(Math.round(n[0] * 255), Math.round(n[1] * 255), Math.round(n[2] * 255)), zi.set(e, s), s;
}
function En({
  html: c,
  dir: t,
  className: e
}, s) {
  const i = document.createDocumentFragment();
  if (typeof c == "string") {
    const n = document.createElement("p");
    n.dir = t || "auto";
    const r = c.split(/\r\n?|\n/);
    for (let a = 0, o = r.length; a < o; ++a) {
      const l = r[a];
      n.append(document.createTextNode(l)), a < o - 1 && n.append(document.createElement("br"));
    }
    i.append(n);
  } else
    wn.render({
      xfaHtml: c,
      div: i,
      intent: "richText"
    });
  i.firstElementChild.classList.add("richText", e), s.append(i);
}
function xn(c) {
  const t = new Path2D();
  if (!c)
    return t;
  for (let e = 0, s = c.length; e < s; )
    switch (c[e++]) {
      case je.moveTo:
        t.moveTo(c[e++], c[e++]);
        break;
      case je.lineTo:
        t.lineTo(c[e++], c[e++]);
        break;
      case je.curveTo:
        t.bezierCurveTo(c[e++], c[e++], c[e++], c[e++], c[e++], c[e++]);
        break;
      case je.quadraticCurveTo:
        t.quadraticCurveTo(c[e++], c[e++], c[e++], c[e++]);
        break;
      case je.closePath:
        t.closePath();
        break;
      default:
        V(`Unrecognized drawing path operator: ${c[e - 1]}`);
        break;
    }
  return t;
}
K(4972);
K(8454);
K(9452);
K(4979);
K(3579);
K(3110);
K(9314);
K(1148);
K(116);
K(9112);
class Xe {
  #t = null;
  #e = null;
  #s;
  #i = null;
  #n = null;
  #a = null;
  #r = null;
  #o = null;
  static #l = null;
  constructor(t) {
    this.#s = t, Xe.#l ||= Object.freeze({
      freetext: "pdfjs-editor-remove-freetext-button",
      highlight: "pdfjs-editor-remove-highlight-button",
      ink: "pdfjs-editor-remove-ink-button",
      stamp: "pdfjs-editor-remove-stamp-button",
      signature: "pdfjs-editor-remove-signature-button"
    });
  }
  render() {
    const t = this.#t = document.createElement("div");
    t.classList.add("editToolbar", "hidden"), t.setAttribute("role", "toolbar");
    const e = this.#s._uiManager._signal;
    e instanceof AbortSignal && !e.aborted && (t.addEventListener("contextmenu", Yt, {
      signal: e
    }), t.addEventListener("pointerdown", Xe.#h, {
      signal: e
    }));
    const s = this.#i = document.createElement("div");
    s.className = "buttons", t.append(s);
    const i = this.#s.toolbarPosition;
    if (i) {
      const {
        style: n
      } = t, r = this.#s._uiManager.direction === "ltr" ? 1 - i[0] : i[0];
      n.insetInlineEnd = `${100 * r}%`, n.top = `calc(${100 * i[1]}% + var(--editor-toolbar-vert-offset))`;
    }
    return t;
  }
  get div() {
    return this.#t;
  }
  static #h(t) {
    t.stopPropagation();
  }
  #u(t) {
    this.#s._focusEventsAllowed = !1, St(t);
  }
  #d(t) {
    this.#s._focusEventsAllowed = !0, St(t);
  }
  #f(t) {
    const e = this.#s._uiManager._signal;
    return !(e instanceof AbortSignal) || e.aborted ? !1 : (t.addEventListener("focusin", this.#u.bind(this), {
      capture: !0,
      signal: e
    }), t.addEventListener("focusout", this.#d.bind(this), {
      capture: !0,
      signal: e
    }), t.addEventListener("contextmenu", Yt, {
      signal: e
    }), !0);
  }
  hide() {
    this.#t.classList.add("hidden"), this.#e?.hideDropdown();
  }
  show() {
    this.#t.classList.remove("hidden"), this.#n?.shown(), this.#a?.shown();
  }
  addDeleteButton() {
    const {
      editorType: t,
      _uiManager: e
    } = this.#s, s = document.createElement("button");
    s.classList.add("basic", "deleteButton"), s.tabIndex = 0, s.setAttribute("data-l10n-id", Xe.#l[t]), this.#f(s) && s.addEventListener("click", (i) => {
      e.delete();
    }, {
      signal: e._signal
    }), this.#i.append(s);
  }
  get #g() {
    const t = document.createElement("div");
    return t.className = "divider", t;
  }
  async addAltText(t) {
    const e = await t.render();
    this.#f(e), this.#i.append(e, this.#g), this.#n = t;
  }
  addComment(t, e = null) {
    if (this.#a)
      return;
    const s = t.renderForToolbar();
    if (!s)
      return;
    this.#f(s);
    const i = this.#r = this.#g;
    e ? (this.#i.insertBefore(s, e), this.#i.insertBefore(i, e)) : this.#i.append(s, i), this.#a = t, t.toolbar = this;
  }
  addColorPicker(t) {
    if (this.#e)
      return;
    this.#e = t;
    const e = t.renderButton();
    this.#f(e), this.#i.append(e, this.#g);
  }
  async addEditSignatureButton(t) {
    const e = this.#o = await t.renderEditButton(this.#s);
    this.#f(e), this.#i.append(e, this.#g);
  }
  removeButton(t) {
    t === "comment" && (this.#a?.removeToolbarCommentButton(), this.#a = null, this.#r?.remove(), this.#r = null);
  }
  async addButton(t, e) {
    switch (t) {
      case "colorPicker":
        e && this.addColorPicker(e);
        break;
      case "altText":
        e && await this.addAltText(e);
        break;
      case "editSignature":
        e && await this.addEditSignatureButton(e);
        break;
      case "delete":
        this.addDeleteButton();
        break;
      case "comment":
        e && this.addComment(e);
        break;
    }
  }
  async addButtonBefore(t, e, s) {
    if (!e && t === "comment")
      return;
    const i = this.#i.querySelector(s);
    i && t === "comment" && this.addComment(e, i);
  }
  updateEditSignatureButton(t) {
    this.#o && (this.#o.title = t);
  }
  remove() {
    this.#t.remove(), this.#e?.destroy(), this.#e = null;
  }
}
class wr {
  #t = null;
  #e = null;
  #s;
  constructor(t) {
    this.#s = t;
  }
  #i() {
    const t = this.#e = document.createElement("div");
    t.className = "editToolbar", t.setAttribute("role", "toolbar"), t.dir = this.#s.direction;
    const e = this.#s._signal;
    e instanceof AbortSignal && !e.aborted && t.addEventListener("contextmenu", Yt, {
      signal: e
    });
    const s = this.#t = document.createElement("div");
    return s.className = "buttons", t.append(s), this.#s.hasCommentManager() && this.#a("commentButton", "pdfjs-comment-floating-button", "pdfjs-comment-floating-button-label", () => {
      this.#s.commentSelection("floating_button");
    }), this.#a("highlightButton", "pdfjs-highlight-floating-button1", "pdfjs-highlight-floating-button-label", () => {
      this.#s.highlightSelection("floating_button");
    }), t;
  }
  #n(t, e) {
    let s = 0, i = 0;
    for (const n of t) {
      const r = n.y + n.height;
      if (r < s)
        continue;
      const a = n.x + (e ? n.width : 0);
      if (r > s) {
        i = a, s = r;
        continue;
      }
      e ? a > i && (i = a) : a < i && (i = a);
    }
    return [e ? 1 - i : i, s];
  }
  show(t, e, s) {
    const [i, n] = this.#n(e, s), {
      style: r
    } = this.#e ||= this.#i();
    t.append(this.#e), r.insetInlineEnd = `${100 * i}%`, r.top = `calc(${100 * n}% + var(--editor-toolbar-vert-offset))`;
  }
  hide() {
    this.#e.remove();
  }
  #a(t, e, s, i) {
    const n = document.createElement("button");
    n.classList.add("basic", t), n.tabIndex = 0, n.setAttribute("data-l10n-id", e);
    const r = document.createElement("span");
    n.append(r), r.className = "visuallyHidden", r.setAttribute("data-l10n-id", s);
    const a = this.#s._signal;
    a instanceof AbortSignal && !a.aborted && (n.addEventListener("contextmenu", Yt, {
      signal: a
    }), n.addEventListener("click", i, {
      signal: a
    })), this.#t.append(n);
  }
}
const Er = "59968104-cc61-4cf9-b570-014b35b3709c", Vs = Object.freeze({
  internal: Er
});
function Tn(c, t, e) {
  for (const s of e)
    t.addEventListener(s, c[s].bind(c));
}
class nt {
  static #t = NaN;
  static #e = null;
  static #s = NaN;
  static #i = null;
  static initializeAndAddPointerId(t) {
    (nt.#e ||= /* @__PURE__ */ new Set()).add(t);
  }
  static setPointer(t, e) {
    nt.#t ||= e, nt.#i ??= t;
  }
  static setTimeStamp(t) {
    nt.#s = t;
  }
  static isSamePointerId(t) {
    return nt.#t === t;
  }
  static isSamePointerIdOrRemove(t) {
    return nt.#t === t ? !0 : (nt.#e?.delete(t), !1);
  }
  static isSamePointerType(t) {
    return nt.#i === t;
  }
  static isInitializedAndDifferentPointerType(t) {
    return nt.#i !== null && !nt.isSamePointerType(t);
  }
  static isSameTimeStamp(t) {
    return nt.#s === t;
  }
  static isUsingMultiplePointers() {
    return nt.#e?.size >= 1;
  }
  static clearPointerType() {
    nt.#i = null;
  }
  static clearPointerIds() {
    nt.#t = NaN, nt.#e = null;
  }
  static clearTimeStamp() {
    nt.#s = NaN;
  }
}
class xr {
  #t = 0;
  get id() {
    return `${Ne}${this.#t++}`;
  }
}
class gi {
  #t = Sn();
  #e = 0;
  #s = null;
  static get _isSVGFittingCanvas() {
    const t = `data:image/svg+xml;charset=UTF-8,<svg viewBox="0 0 1 1" width="1" height="1" xmlns="${Ot}"><rect width="1" height="1" style="fill:red;"/></svg>`, s = new OffscreenCanvas(1, 3).getContext("2d", {
      willReadFrequently: !0
    }), i = new Image();
    i.src = t;
    const n = i.decode().then(() => (s.drawImage(i, 0, 0, 1, 1, 0, 0, 1, 3), new Uint32Array(s.getImageData(0, 0, 1, 1).data.buffer)[0] === 0));
    return j(this, "_isSVGFittingCanvas", n);
  }
  async #i(t, e) {
    this.#s ||= /* @__PURE__ */ new Map();
    let s = this.#s.get(t);
    if (s === null)
      return null;
    if (s?.bitmap)
      return s.refCounter += 1, s;
    try {
      s ||= {
        bitmap: null,
        id: `image_${this.#t}_${this.#e++}`,
        refCounter: 0,
        isSvg: !1
      };
      let i;
      if (typeof e == "string" ? (s.url = e, i = await ui(e, "blob")) : e instanceof File ? i = s.file = e : e instanceof Blob && (i = e), i.type === "image/svg+xml") {
        const n = gi._isSVGFittingCanvas, r = new FileReader(), a = new Image(), o = new Promise((l, h) => {
          a.onload = () => {
            s.bitmap = a, s.isSvg = !0, l();
          }, r.onload = async () => {
            const d = s.svgUrl = r.result;
            a.src = await n ? `${d}#svgView(preserveAspectRatio(none))` : d;
          }, a.onerror = r.onerror = h;
        });
        r.readAsDataURL(i), await o;
      } else
        s.bitmap = await createImageBitmap(i);
      s.refCounter = 1;
    } catch (i) {
      V(i), s = null;
    }
    return this.#s.set(t, s), s && this.#s.set(s.id, s), s;
  }
  async getFromFile(t) {
    const {
      lastModified: e,
      name: s,
      size: i,
      type: n
    } = t;
    return this.#i(`${e}_${s}_${i}_${n}`, t);
  }
  async getFromUrl(t) {
    return this.#i(t, t);
  }
  async getFromBlob(t, e) {
    const s = await e;
    return this.#i(t, s);
  }
  async getFromId(t) {
    this.#s ||= /* @__PURE__ */ new Map();
    const e = this.#s.get(t);
    if (!e)
      return null;
    if (e.bitmap)
      return e.refCounter += 1, e;
    if (e.file)
      return this.getFromFile(e.file);
    if (e.blobPromise) {
      const {
        blobPromise: s
      } = e;
      return delete e.blobPromise, this.getFromBlob(e.id, s);
    }
    return this.getFromUrl(e.url);
  }
  getFromCanvas(t, e) {
    this.#s ||= /* @__PURE__ */ new Map();
    let s = this.#s.get(t);
    if (s?.bitmap)
      return s.refCounter += 1, s;
    const i = new OffscreenCanvas(e.width, e.height);
    return i.getContext("2d").drawImage(e, 0, 0), s = {
      bitmap: i.transferToImageBitmap(),
      id: `image_${this.#t}_${this.#e++}`,
      refCounter: 1,
      isSvg: !1
    }, this.#s.set(t, s), this.#s.set(s.id, s), s;
  }
  getSvgUrl(t) {
    const e = this.#s.get(t);
    return e?.isSvg ? e.svgUrl : null;
  }
  deleteId(t) {
    this.#s ||= /* @__PURE__ */ new Map();
    const e = this.#s.get(t);
    if (!e || (e.refCounter -= 1, e.refCounter !== 0))
      return;
    const {
      bitmap: s
    } = e;
    if (!e.url && !e.file) {
      const i = new OffscreenCanvas(s.width, s.height);
      i.getContext("bitmaprenderer").transferFromImageBitmap(s), e.blobPromise = i.convertToBlob();
    }
    s.close?.(), e.bitmap = null;
  }
  isValidId(t) {
    return t.startsWith(`image_${this.#t}_`);
  }
}
class Tr {
  #t = [];
  #e = !1;
  #s;
  #i = -1;
  constructor(t = 128) {
    this.#s = t;
  }
  add({
    cmd: t,
    undo: e,
    post: s,
    mustExec: i,
    type: n = NaN,
    overwriteIfSameType: r = !1,
    keepUndo: a = !1
  }) {
    if (i && t(), this.#e)
      return;
    const o = {
      cmd: t,
      undo: e,
      post: s,
      type: n
    };
    if (this.#i === -1) {
      this.#t.length > 0 && (this.#t.length = 0), this.#i = 0, this.#t.push(o);
      return;
    }
    if (r && this.#t[this.#i].type === n) {
      a && (o.undo = this.#t[this.#i].undo), this.#t[this.#i] = o;
      return;
    }
    const l = this.#i + 1;
    l === this.#s ? this.#t.splice(0, 1) : (this.#i = l, l < this.#t.length && this.#t.splice(l)), this.#t.push(o);
  }
  undo() {
    if (this.#i === -1)
      return;
    this.#e = !0;
    const {
      undo: t,
      post: e
    } = this.#t[this.#i];
    t(), e?.(), this.#e = !1, this.#i -= 1;
  }
  redo() {
    if (this.#i < this.#t.length - 1) {
      this.#i += 1, this.#e = !0;
      const {
        cmd: t,
        post: e
      } = this.#t[this.#i];
      t(), e?.(), this.#e = !1;
    }
  }
  hasSomethingToUndo() {
    return this.#i !== -1;
  }
  hasSomethingToRedo() {
    return this.#i < this.#t.length - 1;
  }
  cleanType(t) {
    if (this.#i !== -1) {
      for (let e = this.#i; e >= 0; e--)
        if (this.#t[e].type !== t) {
          this.#t.splice(e + 1, this.#i - e), this.#i = e;
          return;
        }
      this.#t.length = 0, this.#i = -1;
    }
  }
  destroy() {
    this.#t = null;
  }
}
class _t {
  static ALT = 1;
  static CTRL = 2;
  static META = 4;
  static SHIFT = 8;
  constructor(t) {
    this.callbacks = /* @__PURE__ */ new Map();
    const {
      isMac: e
    } = at.platform;
    for (const [s, i, n = {}] of t) {
      const r = s.some((a) => a.startsWith("mac+"));
      for (const a of s) {
        let o = a;
        if (r) {
          const d = a.startsWith("mac+");
          if (e !== d)
            continue;
          d && (o = a.slice(4));
        }
        const [l, h] = _t.#t(o);
        l !== null && this.callbacks.getOrInsertComputed(l, Le).push({
          callback: i,
          options: n,
          modifiers: h
        });
      }
    }
  }
  static #t(t) {
    let e = null, s = 0;
    for (let i of t.split("+")) {
      if (i = i.trim(), !i)
        continue;
      const n = i.toUpperCase(), r = _t[n];
      if (r) {
        s |= r;
        continue;
      }
      if (e !== null) {
        V(`KeyboardManager: multiple keys in shortcut "${t}"`);
        break;
      }
      e = n === "SPACE" ? " " : i;
    }
    return e === null && V(`KeyboardManager: no key found in shortcut "${t}"`), [e, s];
  }
  static #e(t) {
    const e = /^(?:Key([A-Z])|(?:Digit|Numpad)(\d))$/.exec(t);
    return e ? e[1]?.toLowerCase() ?? e[2] : null;
  }
  exec(t, e) {
    let s = this.callbacks.get(e.key);
    if (!s) {
      if (/^[a-z]$/i.test(e.key))
        return;
      const h = _t.#e(e.code);
      if (h === null || h === e.key || (s = this.callbacks.get(h), !s))
        return;
    }
    const i = (e.altKey ? _t.ALT : 0) | (e.ctrlKey ? _t.CTRL : 0) | (e.metaKey ? _t.META : 0) | (e.shiftKey ? _t.SHIFT : 0), n = s.find((h) => h.modifiers === i);
    if (!n)
      return;
    const {
      callback: r,
      options: {
        bubbles: a = !1,
        args: o = [],
        checker: l = null
      }
    } = n;
    l && !l(t, e) || (r.bind(t, ...o, e)(), a || St(e));
  }
}
class mi {
  static _colorsMapping = /* @__PURE__ */ new Map([["CanvasText", [0, 0, 0]], ["Canvas", [255, 255, 255]]]);
  get _colors() {
    const t = /* @__PURE__ */ new Map([["CanvasText", null], ["Canvas", null]]);
    return vr(t), j(this, "_colors", t);
  }
  convert(t) {
    const e = is(t);
    if (!window.matchMedia("(forced-colors: active)").matches)
      return e;
    for (const [s, i] of this._colors)
      if (i.every((n, r) => n === e[r]))
        return mi._colorsMapping.get(s);
    return e;
  }
  getHexCode(t) {
    const e = this._colors.get(t);
    return e ? N.makeHexColor(...e) : t;
  }
}
class de {
  #t = new AbortController();
  #e = null;
  #s = null;
  #i = /* @__PURE__ */ new Map();
  #n = /* @__PURE__ */ new Map();
  #a = null;
  #r = null;
  #o = null;
  #l = null;
  #h = null;
  #u = new Tr();
  #d = null;
  #f = null;
  #g = null;
  #m = 0;
  #c = /* @__PURE__ */ new Set();
  #p = null;
  #v = null;
  #y = /* @__PURE__ */ new Set();
  _editorUndoBar = null;
  #b = !1;
  #A = !1;
  #E = !1;
  #w = null;
  #x = null;
  #T = null;
  #M = null;
  #I = !1;
  #P = null;
  #D = new xr();
  #R = !1;
  #k = !1;
  #H = !1;
  #N = null;
  #L = null;
  #V = null;
  #B = null;
  #j = null;
  #C = X.NONE;
  #S = /* @__PURE__ */ new Set();
  #_ = null;
  #$ = null;
  #z = null;
  #J = null;
  #Y = null;
  #K = {
    isEditing: !1,
    isEmpty: !0,
    hasSomethingToUndo: !1,
    hasSomethingToRedo: !1,
    hasSelectedEditor: !1,
    hasSelectedText: !1
  };
  #F = [0, 0];
  #W = null;
  #X = null;
  #tt = null;
  #et = null;
  #U = null;
  static TRANSLATE_SMALL = 1;
  static TRANSLATE_BIG = 10;
  static get _keyboardManager() {
    const t = de.prototype, e = (r) => r.#X.contains(document.activeElement) && document.activeElement.tagName !== "BUTTON" && r.hasSomethingToControl(), s = (r, {
      target: a
    }) => {
      if (a instanceof HTMLInputElement) {
        const {
          type: o
        } = a;
        return o !== "text" && o !== "number";
      }
      return !0;
    }, i = this.TRANSLATE_SMALL, n = this.TRANSLATE_BIG;
    return j(this, "_keyboardManager", new _t([[["ctrl+a", "mac+meta+a"], t.selectAll, {
      checker: s
    }], [["ctrl+z", "mac+meta+z"], t.undo, {
      checker: s
    }], [["ctrl+y", "ctrl+shift+z", "mac+meta+shift+z", "ctrl+shift+Z", "mac+meta+shift+Z"], t.redo, {
      checker: s
    }], [["Backspace", "alt+Backspace", "ctrl+Backspace", "shift+Backspace", "mac+Backspace", "mac+alt+Backspace", "mac+ctrl+Backspace", "Delete", "ctrl+Delete", "shift+Delete", "mac+Delete"], t.delete, {
      checker: s
    }], [["Enter"], t.addNewEditorFromKeyboard, {
      checker: (r, {
        target: a
      }) => !(a instanceof HTMLButtonElement) && r.#X.contains(a) && !r.isEnterHandled
    }], [["Space"], t.addNewEditorFromKeyboard, {
      checker: (r, {
        target: a
      }) => !(a instanceof HTMLButtonElement) && r.#X.contains(document.activeElement)
    }], [["Escape"], t.unselectAll], [["ArrowLeft"], t.translateSelectedEditors, {
      args: [-i, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t.translateSelectedEditors, {
      args: [-n, 0],
      checker: e
    }], [["ArrowRight"], t.translateSelectedEditors, {
      args: [i, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t.translateSelectedEditors, {
      args: [n, 0],
      checker: e
    }], [["ArrowUp"], t.translateSelectedEditors, {
      args: [0, -i],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t.translateSelectedEditors, {
      args: [0, -n],
      checker: e
    }], [["ArrowDown"], t.translateSelectedEditors, {
      args: [0, i],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t.translateSelectedEditors, {
      args: [0, n],
      checker: e
    }]]));
  }
  constructor(t, e, s, i, n, r, a, o, l, h, d, u, f, p, g, m) {
    const v = this._signal = this.#t.signal;
    this.#X = t, this.#tt = e, this.#et = s, this.#o = i, this.#d = n, this.#$ = r, this.#Y = o, this._eventBus = a;
    const y = {
      signal: v,
      ...Vs
    };
    a.on("editingaction", this.onEditingAction.bind(this), y), a.on("pagechanging", this.onPageChanging.bind(this), y), a.on("scalechanging", this.onScaleChanging.bind(this), y), a.on("rotationchanging", this.onRotationChanging.bind(this), y), a.on("setpreference", this.onSetPreference.bind(this), y), a.on("switchannotationeditorparams", (b) => this.updateParams(b.type, b.value), y), window.addEventListener("pointerdown", () => {
      this.#k = !0;
    }, {
      capture: !0,
      signal: v
    }), window.addEventListener("pointerup", () => {
      this.#k = !1;
    }, {
      capture: !0,
      signal: v
    }), window.addEventListener("beforeunload", this.endCurrentEditing.bind(this), {
      capture: !0,
      signal: v
    }), this.#lt(), this.#pt(), this.#it(), this.#l = o.annotationStorage, this.#w = o.filterFactory, this.#z = l, this.#M = h || null, this.#b = d, this.#A = u, this.#E = f, this.#j = p || null, this.viewParameters = {
      realScale: Fe.PDF_TO_CSS_UNITS,
      rotation: 0
    }, this.isShiftKeyDown = !1, this._editorUndoBar = g || null, this._supportsPinchToZoom = m !== !1, n?.setSidebarUiManager(this);
  }
  destroy() {
    this.#U?.resolve(), this.#U = null, this.#t?.abort(), this.#t = null, this._signal = null;
    for (const t of this.#n.values())
      t.destroy();
    this.#n.clear(), this.#i.clear(), this.#y.clear(), this.#B?.clear(), this.#e = null, this.#S.clear(), this.#u.destroy(), this.#o?.destroy(), this.#d?.destroy(), this.#$?.destroy(), this.#P?.hide(), this.#P = null, this.#V?.destroy(), this.#V = null, this.#s = null, this.#x && (clearTimeout(this.#x), this.#x = null), this.#W && (clearTimeout(this.#W), this.#W = null), this._editorUndoBar?.destroy(), this.#Y = null;
  }
  combinedSignal(t) {
    return AbortSignal.any([this._signal, t.signal]);
  }
  get mlManager() {
    return this.#j;
  }
  get useNewAltTextFlow() {
    return this.#A;
  }
  get useNewAltTextWhenAddingImage() {
    return this.#E;
  }
  get hcmFilter() {
    return j(this, "hcmFilter", this.#z ? this.#w.addHCMFilter(this.#z.foreground, this.#z.background) : "none");
  }
  get direction() {
    return j(this, "direction", getComputedStyle(this.#X).direction);
  }
  get _highlightColors() {
    return j(this, "_highlightColors", this.#M ? new Map(this.#M.split(",").map((t) => (t = t.split("=").map((e) => e.trim()), t[1] = t[1].toUpperCase(), t))) : null);
  }
  get highlightColors() {
    const {
      _highlightColors: t
    } = this;
    if (!t)
      return j(this, "highlightColors", null);
    const e = /* @__PURE__ */ new Map(), s = !!this.#z;
    for (const [i, n] of t) {
      const r = i.endsWith("_HCM");
      if (s && r) {
        e.set(i.replace("_HCM", ""), n);
        continue;
      }
      !s && !r && e.set(i, n);
    }
    return j(this, "highlightColors", e);
  }
  get highlightColorNames() {
    return j(this, "highlightColorNames", this.highlightColors ? new Map(Array.from(this.highlightColors, (t) => t.reverse())) : null);
  }
  getNonHCMColor(t) {
    if (!this._highlightColors)
      return t;
    const e = this.highlightColorNames.get(t);
    return this._highlightColors.get(e) || t;
  }
  getNonHCMColorName(t) {
    return this.highlightColorNames.get(t) || t;
  }
  setCurrentDrawingSession(t) {
    t ? (this.unselectAll(), this.disableUserSelect(!0)) : this.disableUserSelect(!1), this.#g = t;
  }
  setMainHighlightColorPicker(t) {
    this.#V = t;
  }
  editAltText(t, e = !1) {
    this.#o?.editAltText(this, t, e);
  }
  hasCommentManager() {
    return !!this.#d;
  }
  editComment(t, e, s, i) {
    this.#d?.showDialog(this, t, e, s, i);
  }
  selectComment(t, e) {
    this.#n.get(t)?.getEditorByUID(e)?.toggleComment(!0, !0);
  }
  updateComment(t) {
    this.#d?.updateComment(t.getData());
  }
  updatePopupColor(t) {
    this.#d?.updatePopupColor(t);
  }
  removeComment(t) {
    this.#d?.removeComments([t.uid]);
  }
  deleteComment(t, e) {
    const s = () => {
      t.comment = e;
    }, i = () => {
      this._editorUndoBar?.show(s, "comment"), this.toggleComment(null), t.comment = null;
    };
    this.addCommands({
      cmd: i,
      undo: s,
      mustExec: !0
    });
  }
  toggleComment(t, e, s = void 0) {
    this.#d?.toggleCommentPopup(t, e, s);
  }
  makeCommentColor(t, e) {
    return t && this.#d?.makeCommentColor(t, e) || null;
  }
  getCommentDialogElement() {
    return this.#d?.dialogElement || null;
  }
  async waitForEditorsRendered(t) {
    if (this.#n.has(t - 1))
      return;
    const {
      resolve: e,
      promise: s
    } = Promise.withResolvers(), i = (n) => {
      n.pageNumber === t && (this._eventBus.off("editorsrendered", i), e());
    };
    this._eventBus.on("editorsrendered", i, Vs), await s;
  }
  getSignature(t) {
    this.#$?.getSignature({
      uiManager: this,
      editor: t
    });
  }
  get signatureManager() {
    return this.#$;
  }
  switchToMode(t, e) {
    this._eventBus.on("annotationeditormodechanged", e, {
      once: !0,
      signal: this._signal,
      ...Vs
    }), this._eventBus.dispatch("showannotationeditorui", {
      source: this,
      mode: t
    });
  }
  setPreference(t, e) {
    this._eventBus.dispatch("setpreference", {
      source: this,
      name: t,
      value: e
    });
  }
  onSetPreference({
    name: t,
    value: e
  }) {
    t === "enableNewAltTextWhenAddingImage" && (this.#E = e);
  }
  onPageChanging({
    pageNumber: t
  }) {
    this.#m = t - 1;
  }
  deletePage(t) {
    for (const e of this.getEditors(t))
      e.remove();
    this.#n.delete(t), this.#m === t && (this.#m = 0);
  }
  focusMainContainer() {
    this.#X.focus();
  }
  findParent(t, e) {
    for (const s of this.#n.values()) {
      const {
        x: i,
        y: n,
        width: r,
        height: a
      } = s.div.getBoundingClientRect();
      if (t >= i && t <= i + r && e >= n && e <= n + a)
        return s;
    }
    return null;
  }
  disableUserSelect(t = !1) {
    this.#tt.classList.toggle("noUserSelect", t);
  }
  addShouldRescale(t) {
    this.#y.add(t);
  }
  removeShouldRescale(t) {
    this.#y.delete(t);
  }
  onScaleChanging({
    scale: t
  }) {
    this.commitOrRemove(), this.viewParameters.realScale = t * Fe.PDF_TO_CSS_UNITS;
    for (const e of this.#y)
      e.onScaleChanging();
    this.#g?.onScaleChanging();
  }
  onRotationChanging({
    pagesRotation: t
  }) {
    this.commitOrRemove(), this.viewParameters.rotation = t;
  }
  #q({
    anchorNode: t
  }) {
    return t.nodeType === Node.TEXT_NODE ? t.parentElement : t;
  }
  #st(t) {
    const {
      currentLayer: e
    } = this;
    if (e.hasTextLayer(t))
      return e;
    for (const s of this.#n.values())
      if (s.hasTextLayer(t))
        return s;
    return null;
  }
  highlightSelection(t = "", e = !1) {
    const s = document.getSelection();
    if (!s || s.isCollapsed)
      return;
    const {
      anchorNode: i,
      anchorOffset: n,
      focusNode: r,
      focusOffset: a
    } = s, o = s.toString(), h = this.#q(s).closest(".textLayer"), d = this.getSelectionBoxes(h);
    if (!d)
      return;
    s.empty();
    const u = this.#st(h), f = this.#C === X.NONE, p = () => {
      const g = u?.createAndAddNewEditor({
        x: 0,
        y: 0
      }, !1, {
        methodOfCreation: t,
        boxes: d,
        anchorNode: i,
        anchorOffset: n,
        focusNode: r,
        focusOffset: a,
        text: o
      });
      f && this.showAllEditors("highlight", !0, !0), e && g?.editComment();
    };
    if (f) {
      this.switchToMode(X.HIGHLIGHT, p);
      return;
    }
    p();
  }
  commentSelection(t = "") {
    this.highlightSelection(t, !0);
  }
  endCurrentEditing() {
    this.commitOrRemove(), this.currentLayer?.endDrawingSession(!1);
  }
  #at() {
    const t = document.getSelection();
    if (!t || t.isCollapsed)
      return;
    const s = this.#q(t).closest(".textLayer"), i = this.getSelectionBoxes(s);
    i && (this.#P ||= new wr(this), this.#P.show(s, i, this.direction === "ltr"));
  }
  getAndRemoveDataFromAnnotationStorage(t) {
    if (!this.#l)
      return null;
    const e = `${Ne}${t}`, s = this.#l.getRawValue(e);
    return s && this.#l.remove(e), s;
  }
  addToAnnotationStorage(t) {
    !t.isEmpty() && this.#l && !this.#l.has(t.id) && this.#l.setValue(t.id, t);
  }
  a11yAlert(t, e = null) {
    const s = this.#et;
    s && (s.setAttribute("data-l10n-id", t), e ? s.setAttribute("data-l10n-args", JSON.stringify(e)) : s.removeAttribute("data-l10n-args"));
  }
  #ot() {
    const t = document.getSelection();
    if (!t || t.isCollapsed) {
      this.#_ && (this.#P?.hide(), this.#_ = null, this.#O({
        hasSelectedText: !1
      }));
      return;
    }
    const {
      anchorNode: e
    } = t;
    if (e === this.#_)
      return;
    const i = this.#q(t).closest(".textLayer");
    if (!i) {
      this.#_ && (this.#P?.hide(), this.#_ = null, this.#O({
        hasSelectedText: !1
      }));
      return;
    }
    if (this.#P?.hide(), this.#_ = e, this.#O({
      hasSelectedText: !0
    }), !(this.#C !== X.HIGHLIGHT && this.#C !== X.NONE) && (this.#C === X.HIGHLIGHT && this.showAllEditors("highlight", !0, !0), this.#I = this.isShiftKeyDown, !this.isShiftKeyDown)) {
      const n = this.#C === X.HIGHLIGHT ? this.#st(i) : null;
      if (n?.toggleDrawing(), this.#k) {
        const r = new AbortController(), a = this.combinedSignal(r), o = (l) => {
          l.type === "pointerup" && l.button !== 0 || (r.abort(), n?.toggleDrawing(!0), l.type === "pointerup" && this.#Q("main_toolbar"));
        };
        window.addEventListener("pointerup", o, {
          signal: a
        }), window.addEventListener("blur", o, {
          signal: a
        });
      } else
        n?.toggleDrawing(!0), this.#Q("main_toolbar");
    }
  }
  #Q(t = "") {
    this.#C === X.HIGHLIGHT ? this.highlightSelection(t) : this.#b && this.#at();
  }
  #lt() {
    document.addEventListener("selectionchange", this.#ot.bind(this), {
      signal: this._signal
    });
  }
  #ht() {
    if (this.#T)
      return;
    this.#T = new AbortController();
    const t = this.combinedSignal(this.#T);
    window.addEventListener("focus", this.focus.bind(this), {
      signal: t
    }), window.addEventListener("blur", this.blur.bind(this), {
      signal: t
    });
  }
  #ct() {
    this.#T?.abort(), this.#T = null;
  }
  blur() {
    if (this.isShiftKeyDown = !1, this.#I && (this.#I = !1, this.#Q("main_toolbar")), !this.hasSelection)
      return;
    const {
      activeElement: t
    } = document;
    for (const e of this.#S)
      if (e.div.contains(t)) {
        this.#L = [e, t], e._focusEventsAllowed = !1;
        break;
      }
  }
  focus() {
    if (!this.#L)
      return;
    const [t, e] = this.#L;
    this.#L = null, e.addEventListener("focusin", () => {
      t._focusEventsAllowed = !0;
    }, {
      once: !0,
      signal: this._signal
    }), e.focus();
  }
  #it() {
    if (this.#N)
      return;
    this.#N = new AbortController();
    const t = this.combinedSignal(this.#N);
    window.addEventListener("keydown", this.keydown.bind(this), {
      signal: t
    }), window.addEventListener("keyup", this.keyup.bind(this), {
      signal: t
    });
  }
  #dt() {
    this.#N?.abort(), this.#N = null;
  }
  #ut() {
    if (this.#f)
      return;
    this.#f = new AbortController();
    const t = this.combinedSignal(this.#f);
    document.addEventListener("copy", this.copy.bind(this), {
      signal: t
    }), document.addEventListener("cut", this.cut.bind(this), {
      signal: t
    }), document.addEventListener("paste", this.paste.bind(this), {
      signal: t
    });
  }
  #ft() {
    this.#f?.abort(), this.#f = null;
  }
  #pt() {
    const t = this._signal;
    document.addEventListener("dragover", this.dragOver.bind(this), {
      signal: t
    }), document.addEventListener("drop", this.drop.bind(this), {
      signal: t
    });
  }
  addEditListeners() {
    this.#it(), this.setEditingState(!0);
  }
  removeEditListeners() {
    this.#dt(), this.setEditingState(!1);
  }
  dragOver(t) {
    for (const {
      type: e
    } of t.dataTransfer.items)
      for (const s of this.#v)
        if (s.isHandlingMimeForPasting(e)) {
          t.dataTransfer.dropEffect = "copy", t.preventDefault();
          return;
        }
  }
  drop(t) {
    for (const e of t.dataTransfer.items)
      for (const s of this.#v)
        if (s.isHandlingMimeForPasting(e.type)) {
          s.paste(e, this.currentLayer), t.preventDefault();
          return;
        }
  }
  copy(t) {
    if (t.preventDefault(), this.#e?.commitOrRemove(), !this.hasSelection)
      return;
    const e = [];
    for (const s of this.#S) {
      const i = s.serialize(!0);
      i && e.push(i);
    }
    e.length !== 0 && t.clipboardData.setData("application/pdfjs", JSON.stringify(e));
  }
  cut(t) {
    this.copy(t), this.delete();
  }
  async paste(t) {
    t.preventDefault();
    const {
      clipboardData: e
    } = t;
    for (const n of e.items)
      for (const r of this.#v)
        if (r.isHandlingMimeForPasting(n.type)) {
          r.paste(n, this.currentLayer);
          return;
        }
    let s = e.getData("application/pdfjs");
    if (!s)
      return;
    try {
      s = JSON.parse(s);
    } catch (n) {
      V(`paste: "${n.message}".`);
      return;
    }
    if (!Array.isArray(s))
      return;
    this.unselectAll();
    const i = this.currentLayer;
    try {
      const n = [];
      for (const o of s) {
        const l = await i.deserialize(o);
        if (!l)
          return;
        n.push(l);
      }
      const r = () => {
        for (const o of n)
          this.#nt(o);
        this.#rt(n);
      }, a = () => {
        for (const o of n)
          o.remove();
      };
      this.addCommands({
        cmd: r,
        undo: a,
        mustExec: !0
      });
    } catch (n) {
      V(`paste: "${n.message}".`);
    }
  }
  keydown(t) {
    !this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !0), this.#C !== X.NONE && !this.isEditorHandlingKeyboard && de._keyboardManager.exec(this, t);
  }
  keyup(t) {
    this.isShiftKeyDown && t.key === "Shift" && (this.isShiftKeyDown = !1, this.#I && (this.#I = !1, this.#Q("main_toolbar")));
  }
  onEditingAction({
    name: t
  }) {
    switch (t) {
      case "undo":
      case "redo":
      case "delete":
      case "selectAll":
        this[t]();
        break;
      case "highlightSelection":
        this.highlightSelection("context_menu");
        break;
      case "commentSelection":
        this.commentSelection("context_menu");
        break;
    }
  }
  updatePageIndex(t, e) {
    for (const i of this.#r.get(t) || [])
      i.pageIndex = e;
    const s = this.#a.get(t);
    s && (s.pageIndex = e, this.#n.set(e, s), this.#R ? s.enable() : s.disable());
  }
  startUpdatePages() {
    this.#a = new Map(this.#n), this.#n.clear();
    const t = this.#r = /* @__PURE__ */ new Map(), e = (s) => {
      t.getOrInsertComputed(s.pageIndex, Le).push(s);
    };
    for (const s of this.#i.values())
      e(s);
    for (const [s, i] of this.#l)
      s.startsWith(Ne) && !this.#i.has(s) && Number.isInteger(i?.pageIndex) && e(i);
  }
  endUpdatePages() {
    this.#a = null, this.#r = null;
  }
  clonePage(t, e) {
    for (const s of this.getEditors(t)) {
      const i = s.serialize(s.mode !== X.HIGHLIGHT);
      i && (i.pageIndex = e, i.id = this.getId(), i.isClone = !0, delete i.popupRef, this.#l.setValue(i.id, i));
    }
  }
  findClonesForPage(t) {
    const e = [], {
      pageIndex: s
    } = t;
    for (const [i, n] of this.#l)
      n.pageIndex === s && n.isClone && (this.#l.remove(i), e.push(t.deserialize(n).then((r) => {
        r && (r.isClone = !0, t.addOrRebuild(r));
      })));
    return Promise.all(e);
  }
  #O(t) {
    Object.entries(t).some(([s, i]) => this.#K[s] !== i) && (this._eventBus.dispatch("editingstateschanged", {
      source: this,
      details: Object.assign(this.#K, t)
    }), this.#C === X.HIGHLIGHT && t.hasSelectedEditor === !1 && this.#G([[q.HIGHLIGHT_FREE, !0]]));
  }
  #G(t) {
    this._eventBus.dispatch("annotationeditorparamschanged", {
      source: this,
      details: t
    });
  }
  setEditingState(t) {
    t ? (this.#ht(), this.#ut(), this.#O({
      isEditing: this.#C !== X.NONE,
      isEmpty: this.#Z(),
      hasSomethingToUndo: this.#u.hasSomethingToUndo(),
      hasSomethingToRedo: this.#u.hasSomethingToRedo(),
      hasSelectedEditor: !1
    })) : (this.#ct(), this.#ft(), this.#O({
      isEditing: !1
    }), this.disableUserSelect(!1));
  }
  registerEditorTypes(t) {
    if (!this.#v) {
      this.#v = t;
      for (const e of this.#v)
        this.#G(e.defaultPropertiesToUpdate);
    }
  }
  getId() {
    return this.#D.id;
  }
  get currentLayer() {
    return this.#n.get(this.#m);
  }
  getLayer(t) {
    return this.#n.get(t);
  }
  get currentPageIndex() {
    return this.#m;
  }
  addLayer(t) {
    this.#n.set(t.pageIndex, t), this.#R ? t.enable() : t.disable();
  }
  removeLayer(t) {
    this.#n.delete(t.pageIndex);
  }
  async updateMode(t, e = null, s = !1, i = !1, n = !1, r = !1) {
    if (this.#C !== t && !(this.#U && (await this.#U.promise, !this.#U))) {
      if (this.#U = Promise.withResolvers(), this.#g?.commitOrRemove(), this.#C === X.POPUP && this.#d?.hideSidebar(), this.#d?.destroyPopup(), this.#C = t, t === X.NONE) {
        this.setEditingState(!1), this.#mt();
        for (const a of this.#i.values())
          a.hideStandaloneCommentButton();
        this._editorUndoBar?.hide(), this.toggleComment(null), this.#U.resolve();
        return;
      }
      for (const a of this.#i.values())
        a.addStandaloneCommentButton();
      t === X.SIGNATURE && await this.#$?.loadSignatures(), s && nt.clearPointerType(), this.setEditingState(!0), await this.#gt(), this.unselectAll();
      for (const a of this.#n.values())
        a.updateMode(t);
      if (t === X.POPUP) {
        this.#s ||= await this.#Y.getAnnotationsByType(new Set(this.#v.map((l) => l._editorType)));
        const a = /* @__PURE__ */ new Set(), o = [];
        for (const l of this.#i.values()) {
          const {
            annotationElementId: h,
            hasComment: d,
            deleted: u
          } = l;
          h && a.add(h), d && !u && o.push(l.getData());
        }
        for (const l of this.#s) {
          const {
            id: h,
            popupRef: d,
            contentsObj: u
          } = l;
          d && u?.str && !a.has(h) && !this.#c.has(h) && o.push(l);
        }
        this.#d?.showSidebar(o);
      }
      if (!e) {
        i && this.addNewEditorFromKeyboard(), this.#U.resolve();
        return;
      }
      for (const a of this.#i.values())
        a.uid === e ? (this.setSelected(a), r ? a.editComment() : n ? a.enterInEditMode() : a.focus()) : a.unselect();
      this.#U.resolve();
    }
  }
  addNewEditorFromKeyboard() {
    this.currentLayer.canCreateNewEmptyEditor() && this.currentLayer.addNewEditor();
  }
  updateToolbar(t) {
    t.mode !== this.#C && this._eventBus.dispatch("switchannotationeditormode", {
      source: this,
      ...t
    });
  }
  updateParams(t, e) {
    if (this.#v) {
      switch (t) {
        case q.CREATE:
          this.currentLayer.addNewEditor(e);
          return;
        case q.HIGHLIGHT_SHOW_ALL:
          this._eventBus.dispatch("reporttelemetry", {
            source: this,
            details: {
              type: "editing",
              data: {
                type: "highlight",
                action: "toggle_visibility"
              }
            }
          }), (this.#J ||= /* @__PURE__ */ new Map()).set(t, e), this.showAllEditors("highlight", e);
          break;
      }
      if (this.hasSelection)
        for (const s of this.#S)
          s.updateParams(t, e);
      else
        for (const s of this.#v)
          s.updateDefaultParams(t, e);
    }
  }
  showAllEditors(t, e, s = !1) {
    for (const n of this.#i.values())
      n.editorType === t && n.show(e);
    (this.#J?.get(q.HIGHLIGHT_SHOW_ALL) ?? !0) !== e && this.#G([[q.HIGHLIGHT_SHOW_ALL, e]]);
  }
  enableWaiting(t = !1) {
    if (this.#H !== t) {
      this.#H = t;
      for (const e of this.#n.values())
        t ? e.disableClick() : e.enableClick(), e.div.classList.toggle("waiting", t);
    }
  }
  async #gt() {
    if (!this.#R) {
      this.#R = !0;
      const t = [];
      for (const e of this.#n.values())
        t.push(e.enable());
      await Promise.all(t);
      for (const e of this.#i.values())
        e.enable();
    }
  }
  #mt() {
    if (this.unselectAll(), this.#R) {
      this.#R = !1;
      for (const t of this.#n.values())
        t.disable();
      for (const t of this.#i.values())
        t.disable();
    }
  }
  *getEditors(t) {
    for (const e of this.#i.values())
      e.pageIndex === t && (yield e);
  }
  getEditor(t) {
    return this.#i.get(t);
  }
  addEditor(t) {
    this.#i.set(t.id, t);
  }
  removeEditor(t) {
    t.div.contains(document.activeElement) && (this.#x && clearTimeout(this.#x), this.#x = setTimeout(() => {
      this.focusMainContainer(), this.#x = null;
    }, 0)), this.#i.delete(t.id), t.annotationElementId && this.#B?.delete(t.annotationElementId), this.unselect(t), (!t.annotationElementId || !this.#c.has(t.annotationElementId)) && this.#l?.remove(t.id);
  }
  addDeletedAnnotationElement(t) {
    this.#c.add(t.annotationElementId), this.addChangedExistingAnnotation(t), t.deleted = !0;
  }
  isDeletedAnnotationElement(t) {
    return this.#c.has(t);
  }
  removeDeletedAnnotationElement(t) {
    this.#c.delete(t.annotationElementId), this.removeChangedExistingAnnotation(t), t.deleted = !1;
  }
  #nt(t) {
    const e = this.#n.get(t.pageIndex);
    e ? e.addOrRebuild(t) : (this.addEditor(t), this.addToAnnotationStorage(t));
  }
  setActiveEditor(t) {
    this.#e !== t && (this.#e = t, t && this.#G(t.propertiesToUpdate));
  }
  get #vt() {
    let t = null;
    for (t of this.#S)
      ;
    return t;
  }
  updateUI(t) {
    this.#vt === t && this.#G(t.propertiesToUpdate);
  }
  updateUIForDefaultProperties(t) {
    this.#G(t.defaultPropertiesToUpdate);
  }
  toggleSelected(t) {
    if (this.#S.has(t)) {
      this.#S.delete(t), t.unselect(), this.#O({
        hasSelectedEditor: this.hasSelection
      });
      return;
    }
    this.#S.add(t), t.select(), this.#G(t.propertiesToUpdate), this.#O({
      hasSelectedEditor: !0
    });
  }
  setSelected(t) {
    this.updateToolbar({
      mode: t.mode,
      editId: t.uid
    }), this.#g?.commitOrRemove();
    for (const e of this.#S)
      e !== t && e.unselect();
    this.#d?.destroyPopup(), this.#S.clear(), this.#S.add(t), t.select(), this.#G(t.propertiesToUpdate), this.#O({
      hasSelectedEditor: !0
    });
  }
  get firstSelectedEditor() {
    return this.#S.values().next().value;
  }
  unselect(t) {
    t.unselect(), this.#S.delete(t), this.#O({
      hasSelectedEditor: this.hasSelection
    });
  }
  get hasSelection() {
    return this.#S.size !== 0;
  }
  get isEnterHandled() {
    return this.#S.size === 1 && this.firstSelectedEditor.isEnterHandled;
  }
  undo() {
    this.#u.undo(), this.#O({
      hasSomethingToUndo: this.#u.hasSomethingToUndo(),
      hasSomethingToRedo: !0,
      isEmpty: this.#Z()
    }), this._editorUndoBar?.hide();
  }
  redo() {
    this.#u.redo(), this.#O({
      hasSomethingToUndo: !0,
      hasSomethingToRedo: this.#u.hasSomethingToRedo(),
      isEmpty: this.#Z()
    });
  }
  addCommands(t) {
    this.#u.add(t), this.#O({
      hasSomethingToUndo: !0,
      hasSomethingToRedo: !1,
      isEmpty: this.#Z()
    });
  }
  cleanUndoStack(t) {
    this.#u.cleanType(t);
  }
  #Z() {
    if (this.#i.size === 0)
      return !0;
    if (this.#i.size === 1)
      for (const t of this.#i.values())
        return t.isEmpty();
    return !1;
  }
  delete() {
    this.commitOrRemove();
    const t = this.currentLayer?.endDrawingSession(!0);
    if (!this.hasSelection && !t)
      return;
    const e = t ? [t] : [...this.#S], s = () => {
      this._editorUndoBar?.show(i, e.length === 1 ? e[0].editorType : e.length);
      for (const n of e)
        n.remove();
    }, i = () => {
      for (const n of e)
        this.#nt(n);
    };
    this.addCommands({
      cmd: s,
      undo: i,
      mustExec: !0
    });
  }
  commitOrRemove() {
    this.#e?.commitOrRemove();
  }
  hasSomethingToControl() {
    return this.#e || this.hasSelection;
  }
  #rt(t) {
    for (const e of this.#S)
      e.unselect();
    this.#S.clear();
    for (const e of t)
      e.isEmpty() || (this.#S.add(e), e.select());
    this.#O({
      hasSelectedEditor: this.hasSelection
    });
  }
  selectAll() {
    for (const t of this.#S)
      t.commit();
    this.#rt(this.#i.values());
  }
  unselectAll() {
    if (!(this.#e && (this.#e.commitOrRemove(), this.#C !== X.NONE)) && !this.#g?.commitOrRemove() && (this.#d?.destroyPopup(), !!this.hasSelection)) {
      for (const t of this.#S)
        t.unselect();
      this.#S.clear(), this.#O({
        hasSelectedEditor: !1
      });
    }
  }
  translateSelectedEditors(t, e, s = !1) {
    if (s || this.commitOrRemove(), !this.hasSelection)
      return;
    this.#F[0] += t, this.#F[1] += e;
    const [i, n] = this.#F, r = [...this.#S], a = 1e3;
    this.#W && clearTimeout(this.#W), this.#W = setTimeout(() => {
      this.#W = null, this.#F[0] = this.#F[1] = 0, this.addCommands({
        cmd: () => {
          for (const o of r)
            this.#i.has(o.id) && (o.translateInPage(i, n), o.translationDone());
        },
        undo: () => {
          for (const o of r)
            this.#i.has(o.id) && (o.translateInPage(-i, -n), o.translationDone());
        },
        mustExec: !1
      });
    }, a);
    for (const o of r)
      o.translateInPage(t, e), o.translationDone();
  }
  setUpDragSession() {
    if (this.hasSelection) {
      this.disableUserSelect(!0), this.#p = /* @__PURE__ */ new Map();
      for (const t of this.#S)
        this.#p.set(t, {
          savedX: t.x,
          savedY: t.y,
          savedPageIndex: t.pageIndex,
          newX: 0,
          newY: 0,
          newPageIndex: -1
        });
    }
  }
  endDragSession() {
    if (!this.#p)
      return !1;
    this.disableUserSelect(!1);
    const t = this.#p;
    this.#p = null;
    let e = !1;
    for (const [{
      x: i,
      y: n,
      pageIndex: r
    }, a] of t)
      a.newX = i, a.newY = n, a.newPageIndex = r, e ||= i !== a.savedX || n !== a.savedY || r !== a.savedPageIndex;
    if (!e)
      return !1;
    const s = (i, n, r, a) => {
      if (this.#i.has(i.id)) {
        const o = this.#n.get(a);
        o ? i._setParentAndPosition(o, n, r) : (i.pageIndex = a, i.x = n, i.y = r);
      }
    };
    return this.addCommands({
      cmd: () => {
        for (const [i, {
          newX: n,
          newY: r,
          newPageIndex: a
        }] of t)
          s(i, n, r, a);
      },
      undo: () => {
        for (const [i, {
          savedX: n,
          savedY: r,
          savedPageIndex: a
        }] of t)
          s(i, n, r, a);
      },
      mustExec: !0
    }), !0;
  }
  dragSelectedEditors(t, e) {
    if (this.#p)
      for (const s of this.#p.keys())
        s.drag(t, e);
  }
  rebuild(t) {
    if (t.parent === null) {
      const e = this.getLayer(t.pageIndex);
      e ? (e.changeParent(t), e.addOrRebuild(t)) : (this.addEditor(t), this.addToAnnotationStorage(t), t.rebuild());
    } else
      t.parent.addOrRebuild(t);
  }
  get isEditorHandlingKeyboard() {
    return this.getActive()?.shouldGetKeyboardEvents() || this.#S.size === 1 && this.firstSelectedEditor.shouldGetKeyboardEvents();
  }
  isActive(t) {
    return this.#e === t;
  }
  getActive() {
    return this.#e;
  }
  getMode() {
    return this.#C;
  }
  isEditingMode() {
    return this.#C !== X.NONE;
  }
  get imageManager() {
    return j(this, "imageManager", new gi());
  }
  getSelectionBoxes(t) {
    if (!t)
      return null;
    const e = document.getSelection();
    for (let l = 0, h = e.rangeCount; l < h; l++)
      if (!t.contains(e.getRangeAt(l).commonAncestorContainer))
        return null;
    const {
      x: s,
      y: i,
      width: n,
      height: r
    } = t.getBoundingClientRect();
    let a;
    switch (t.getAttribute("data-main-rotation")) {
      case "90":
        a = (l, h, d, u) => ({
          x: (h - i) / r,
          y: 1 - (l + d - s) / n,
          width: u / r,
          height: d / n
        });
        break;
      case "180":
        a = (l, h, d, u) => ({
          x: 1 - (l + d - s) / n,
          y: 1 - (h + u - i) / r,
          width: d / n,
          height: u / r
        });
        break;
      case "270":
        a = (l, h, d, u) => ({
          x: 1 - (h + u - i) / r,
          y: (l - s) / n,
          width: u / r,
          height: d / n
        });
        break;
      default:
        a = (l, h, d, u) => ({
          x: (l - s) / n,
          y: (h - i) / r,
          width: d / n,
          height: u / r
        });
        break;
    }
    const o = [];
    for (let l = 0, h = e.rangeCount; l < h; l++) {
      const d = e.getRangeAt(l);
      if (!d.collapsed)
        for (const {
          x: u,
          y: f,
          width: p,
          height: g
        } of d.getClientRects())
          p === 0 || g === 0 || o.push(a(u, f, p, g));
    }
    return o.length === 0 ? null : o;
  }
  addChangedExistingAnnotation({
    annotationElementId: t,
    id: e
  }) {
    (this.#h ||= /* @__PURE__ */ new Map()).set(t, e);
  }
  removeChangedExistingAnnotation({
    annotationElementId: t
  }) {
    this.#h?.delete(t);
  }
  renderAnnotationElement(t) {
    const e = this.#h?.get(t.data.id);
    if (!e)
      return;
    const s = this.#l.getRawValue(e);
    s && (this.#C === X.NONE && !s.hasBeenModified || s.renderAnnotationElement(t));
  }
  setMissingCanvas(t, e, s) {
    const i = this.#B?.get(t);
    i && (i.setCanvas(e, s), this.#B.delete(t));
  }
  addMissingCanvas(t, e) {
    (this.#B ||= /* @__PURE__ */ new Map()).set(t, e);
  }
}
class ie {
  #t = null;
  #e = !1;
  #s = null;
  #i = null;
  #n = null;
  #a = null;
  #r = !1;
  #o = null;
  #l = null;
  #h = null;
  #u = null;
  #d = !1;
  static #f = null;
  static _l10n = null;
  constructor(t) {
    this.#l = t, this.#d = t._uiManager.useNewAltTextFlow, ie.#f ||= Object.freeze({
      added: "pdfjs-editor-new-alt-text-added-button",
      "added-label": "pdfjs-editor-new-alt-text-added-button-label",
      missing: "pdfjs-editor-new-alt-text-missing-button",
      "missing-label": "pdfjs-editor-new-alt-text-missing-button-label",
      review: "pdfjs-editor-new-alt-text-to-review-button",
      "review-label": "pdfjs-editor-new-alt-text-to-review-button-label"
    });
  }
  static initialize(t) {
    ie._l10n ??= t;
  }
  async render() {
    const t = this.#s = document.createElement("button");
    t.className = "altText", t.tabIndex = "0";
    const e = this.#i = document.createElement("span");
    t.append(e), this.#d ? (t.classList.add("new"), t.setAttribute("data-l10n-id", ie.#f.missing), e.setAttribute("data-l10n-id", ie.#f["missing-label"])) : (t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button"), e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-button-label"));
    const s = this.#l._uiManager._signal;
    t.addEventListener("contextmenu", Yt, {
      signal: s
    }), t.addEventListener("pointerdown", (n) => n.stopPropagation(), {
      signal: s
    });
    const i = (n) => {
      n.preventDefault(), this.#l._uiManager.editAltText(this.#l), this.#d && this.#l._reportTelemetry({
        action: "pdfjs.image.alt_text.image_status_label_clicked",
        data: {
          label: this.#g
        }
      });
    };
    return t.addEventListener("click", i, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (n) => {
      n.target === t && n.key === "Enter" && (this.#r = !0, i(n));
    }, {
      signal: s
    }), await this.#m(), t;
  }
  get #g() {
    return this.#t && "added" || this.#t === null && this.guessedText && "review" || "missing";
  }
  finish() {
    this.#s && (this.#s.focus({
      focusVisible: this.#r
    }), this.#r = !1);
  }
  isEmpty() {
    return this.#d ? this.#t === null : !this.#t && !this.#e;
  }
  hasData() {
    return this.#d ? this.#t !== null || !!this.#h : this.isEmpty();
  }
  get guessedText() {
    return this.#h;
  }
  async setGuessedText(t) {
    this.#t === null && (this.#h = t, this.#u = await ie._l10n.get("pdfjs-editor-new-alt-text-generated-alt-text-with-disclaimer", {
      generatedAltText: t
    }), this.#m());
  }
  toggleAltTextBadge(t = !1) {
    if (!this.#d || this.#t) {
      this.#o?.remove(), this.#o = null;
      return;
    }
    if (!this.#o) {
      const e = this.#o = document.createElement("div");
      e.className = "noAltTextBadge", this.#l.div.append(e);
    }
    this.#o.classList.toggle("hidden", !t);
  }
  serialize(t) {
    let e = this.#t;
    return !t && this.#h === e && (e = this.#u), {
      altText: e,
      decorative: this.#e,
      guessedText: this.#h,
      textWithDisclaimer: this.#u
    };
  }
  get data() {
    return {
      altText: this.#t,
      decorative: this.#e
    };
  }
  set data({
    altText: t,
    decorative: e,
    guessedText: s,
    textWithDisclaimer: i,
    cancel: n = !1
  }) {
    s && (this.#h = s, this.#u = i), !(this.#t === t && this.#e === e) && (n || (this.#t = t, this.#e = e), this.#m());
  }
  toggle(t = !1) {
    this.#s && (!t && this.#a && (clearTimeout(this.#a), this.#a = null), this.#s.disabled = !t);
  }
  shown() {
    this.#l._reportTelemetry({
      action: "pdfjs.image.alt_text.image_status_label_displayed",
      data: {
        label: this.#g
      }
    });
  }
  destroy() {
    this.#s?.remove(), this.#s = null, this.#i = null, this.#n = null, this.#o?.remove(), this.#o = null;
  }
  async #m() {
    const t = this.#s;
    if (!t)
      return;
    if (this.#d) {
      if (t.classList.toggle("done", !!this.#t), t.setAttribute("data-l10n-id", ie.#f[this.#g]), this.#i?.setAttribute("data-l10n-id", ie.#f[`${this.#g}-label`]), !this.#t) {
        this.#n?.remove();
        return;
      }
    } else {
      if (!this.#t && !this.#e) {
        t.classList.remove("done"), this.#n?.remove();
        return;
      }
      t.classList.add("done"), t.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-edit-button");
    }
    let e = this.#n;
    if (!e) {
      this.#n = e = document.createElement("span"), e.className = "tooltip", e.setAttribute("role", "tooltip"), e.id = `alt-text-tooltip-${this.#l.id}`;
      const i = 100, n = this.#l._uiManager._signal;
      n.addEventListener("abort", () => {
        clearTimeout(this.#a), this.#a = null;
      }, {
        once: !0
      }), t.addEventListener("mouseenter", () => {
        this.#a = setTimeout(() => {
          this.#a = null, this.#n.classList.add("show"), this.#l._reportTelemetry({
            action: "alt_text_tooltip"
          });
        }, i);
      }, {
        signal: n
      }), t.addEventListener("mouseleave", () => {
        this.#a && (clearTimeout(this.#a), this.#a = null), this.#n?.classList.remove("show");
      }, {
        signal: n
      });
    }
    this.#e ? e.setAttribute("data-l10n-id", "pdfjs-editor-alt-text-decorative-tooltip") : (e.removeAttribute("data-l10n-id"), e.textContent = this.#t), e.parentNode || t.append(e), this.#l.getElementForAltText()?.setAttribute("aria-describedby", e.id);
  }
}
class as {
  #t = null;
  #e = null;
  #s = !1;
  #i = null;
  #n = null;
  #a = null;
  #r = null;
  #o = null;
  #l = !1;
  #h = null;
  constructor(t) {
    this.#i = t;
  }
  renderForToolbar() {
    const t = this.#e = document.createElement("button");
    return t.className = "comment", this.#u(t, !1);
  }
  renderForStandalone() {
    const t = this.#t = document.createElement("button");
    t.className = "annotationCommentButton";
    const e = this.#i.commentButtonPosition;
    if (e) {
      const {
        style: s
      } = t;
      s.insetInlineEnd = `calc(${100 * (this.#i._uiManager.direction === "ltr" ? 1 - e[0] : e[0])}% - var(--comment-button-dim))`, s.top = `calc(${100 * e[1]}% - var(--comment-button-dim))`;
      const i = this.#i.commentButtonColor;
      i && (s.backgroundColor = i);
    }
    return this.#u(t, !0);
  }
  focusButton() {
    setTimeout(() => {
      (this.#t ?? this.#e)?.focus();
    }, 0);
  }
  onUpdatedColor() {
    if (!this.#t)
      return;
    const t = this.#i.commentButtonColor;
    t && (this.#t.style.backgroundColor = t), this.#i._uiManager.updatePopupColor(this.#i);
  }
  get commentButtonWidth() {
    return (this.#t?.getBoundingClientRect().width ?? 0) / this.#i.parent.boundingClientRect.width;
  }
  get commentPopupPositionInLayer() {
    if (this.#h)
      return this.#h;
    if (!this.#t)
      return null;
    const {
      x: t,
      y: e,
      height: s
    } = this.#t.getBoundingClientRect(), {
      x: i,
      y: n,
      width: r,
      height: a
    } = this.#i.parent.boundingClientRect;
    return [(t - i) / r, (e + s - n) / a];
  }
  set commentPopupPositionInLayer(t) {
    this.#h = t;
  }
  hasDefaultPopupPosition() {
    return this.#h === null;
  }
  removeStandaloneCommentButton() {
    this.#t?.remove(), this.#t = null;
  }
  removeToolbarCommentButton() {
    this.#e?.remove(), this.#e = null;
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    this.#t && (this.#t.classList.toggle("selected", t), this.#t.ariaExpanded = e);
  }
  #u(t, e) {
    if (!this.#i._uiManager.hasCommentManager())
      return null;
    t.tabIndex = "0", t.ariaHasPopup = "dialog", e ? (t.ariaControls = "commentPopup", t.setAttribute("data-l10n-id", "pdfjs-show-comment-button")) : (t.ariaControlsElements = [this.#i._uiManager.getCommentDialogElement()], t.setAttribute("data-l10n-id", "pdfjs-editor-add-comment-button"));
    const s = this.#i._uiManager._signal;
    if (!(s instanceof AbortSignal) || s.aborted)
      return t;
    t.addEventListener("contextmenu", Yt, {
      signal: s
    }), e && (t.addEventListener("focusin", (n) => {
      this.#i._focusEventsAllowed = !1, St(n);
    }, {
      capture: !0,
      signal: s
    }), t.addEventListener("focusout", (n) => {
      this.#i._focusEventsAllowed = !0, St(n);
    }, {
      capture: !0,
      signal: s
    })), t.addEventListener("pointerdown", (n) => n.stopPropagation(), {
      signal: s
    });
    const i = (n) => {
      n.preventDefault(), t === this.#e ? this.edit() : this.#i.toggleComment(!0);
    };
    return t.addEventListener("click", i, {
      capture: !0,
      signal: s
    }), t.addEventListener("keydown", (n) => {
      n.target === t && n.key === "Enter" && (this.#s = !0, i(n));
    }, {
      signal: s
    }), t.addEventListener("pointerenter", () => {
      this.#i.toggleComment(!1, !0);
    }, {
      signal: s
    }), t.addEventListener("pointerleave", () => {
      this.#i.toggleComment(!1, !1);
    }, {
      signal: s
    }), t;
  }
  edit(t) {
    const e = this.commentPopupPositionInLayer;
    let s, i;
    if (e)
      [s, i] = e;
    else {
      [s, i] = this.#i.commentButtonPosition;
      const {
        width: h,
        height: d,
        x: u,
        y: f
      } = this.#i;
      s = u + s * h, i = f + i * d;
    }
    const n = this.#i.parent.boundingClientRect, {
      x: r,
      y: a,
      width: o,
      height: l
    } = n;
    this.#i._uiManager.editComment(this.#i, r + s * o, a + i * l, {
      ...t,
      parentDimensions: n
    });
  }
  finish() {
    this.#e && (this.#e.focus({
      focusVisible: this.#s
    }), this.#s = !1);
  }
  isDeleted() {
    return this.#l || this.#r === "";
  }
  isEmpty() {
    return this.#r === null;
  }
  hasBeenEdited() {
    return this.isDeleted() || this.#r !== this.#n;
  }
  serialize() {
    return this.data;
  }
  get data() {
    return {
      text: this.#r,
      richText: this.#a,
      date: this.#o,
      deleted: this.isDeleted()
    };
  }
  set data(t) {
    if (t !== this.#r && (this.#a = null), t === null) {
      this.#r = "", this.#l = !0;
      return;
    }
    this.#r = t, this.#o = /* @__PURE__ */ new Date(), this.#l = !1;
  }
  restoreData({
    text: t,
    richText: e,
    date: s
  }) {
    this.#r = t, this.#a = e, this.#o = s, this.#l = !1;
  }
  setInitialText(t, e = null) {
    this.#n = t, this.data = t, this.#o = null, this.#a = e;
  }
  shown() {
  }
  destroy() {
    this.#e?.remove(), this.#e = null, this.#t?.remove(), this.#t = null, this.#r = "", this.#a = null, this.#o = null, this.#i = null, this.#s = !1, this.#l = !1;
  }
}
function Wi(c) {
  c.preventDefault();
}
const Xi = 1e-4;
function zs(c) {
  return c.cancelable ? (St(c), !0) : (c.stopPropagation(), !1);
}
class Cn {
  #t;
  #e = !1;
  #s = null;
  #i;
  #n;
  #a;
  #r;
  #o;
  #l = !1;
  #h = null;
  #u;
  #d = /* @__PURE__ */ new Set();
  #f = null;
  #g;
  #m = null;
  #c = 0;
  constructor({
    container: t,
    isPinchingDisabled: e = null,
    isPinchingStopped: s = null,
    onPinchStart: i = null,
    onPinching: n = null,
    onPinchEnd: r = null,
    onPanning: a = null,
    signal: o
  }) {
    this.#t = t, this.#s = s, this.#i = e, this.#n = i, this.#a = n, this.#r = r, this.#o = a, this.#g = new AbortController(), this.#u = AbortSignal.any([o, this.#g.signal]), t.addEventListener("touchstart", this.#p.bind(this), {
      passive: !1,
      signal: this.#u
    });
  }
  get MIN_TOUCH_DISTANCE_TO_PINCH() {
    return 35 / Kt.pixelRatio;
  }
  get MIN_TOUCH_DISTANCE_TO_SCALE() {
    return 4 / Kt.pixelRatio;
  }
  #p(t) {
    if (this.#i?.())
      return;
    this.#y(t);
    const e = this.#d;
    for (const {
      identifier: s
    } of t.changedTouches)
      e.add(s);
    if (e.size === 1) {
      this.#v();
      return;
    }
    if (!this.#m) {
      this.#m = new AbortController();
      const s = AbortSignal.any([this.#u, this.#m.signal]), i = this.#t, n = {
        signal: s,
        capture: !1,
        passive: !1
      };
      i.addEventListener("touchmove", this.#E.bind(this), n);
      const r = this.#w.bind(this);
      i.addEventListener("touchend", r, n), i.addEventListener("touchcancel", r, n), n.capture = !0, i.addEventListener("pointerdown", St, n), i.addEventListener("pointermove", St, n), i.addEventListener("pointercancel", Wi, n), i.addEventListener("pointerup", Wi, n), this.#n?.();
    }
    this.#l = zs(t), this.#A(t);
  }
  #v() {
    if (this.#h)
      return;
    const t = this.#h = new AbortController(), e = AbortSignal.any([this.#u, t.signal]), s = this.#t, i = {
      capture: !0,
      signal: e,
      passive: !1
    }, n = (r) => {
      r.pointerType === "touch" && (this.#h?.abort(), this.#h = null);
    };
    s.addEventListener("pointerdown", (r) => {
      r.pointerType === "touch" && (St(r), n(r));
    }, i), s.addEventListener("pointerup", n, i), s.addEventListener("pointercancel", n, i);
  }
  #y(t) {
    const e = this.#d;
    if (e.size === 0)
      return;
    const s = this.#d = /* @__PURE__ */ new Set();
    for (const {
      identifier: i
    } of t.touches)
      e.has(i) && s.add(i);
  }
  #b(t) {
    const e = this.#d, s = [];
    for (const i of t.touches)
      e.has(i.identifier) && s.push(i);
    return s;
  }
  #A(t) {
    const e = this.#b(t);
    if (e.length !== 2 || this.#s?.()) {
      this.#f = null;
      return;
    }
    const [s, i] = e;
    this.#f = {
      touch0X: s.screenX,
      touch0Y: s.screenY,
      touch1X: i.screenX,
      touch1Y: i.screenY,
      panX: (s.clientX + i.clientX) / 2,
      panY: (s.clientY + i.clientY) / 2,
      screenPanX: (s.screenX + i.screenX) / 2,
      screenPanY: (s.screenY + i.screenY) / 2
    };
  }
  #E(t) {
    if (!this.#f)
      return;
    const e = this.#b(t);
    if (e.length !== 2)
      return;
    const s = this.#l;
    if (this.#l = zs(t), !this.#l)
      return;
    if (!s) {
      this.#A(t);
      return;
    }
    const [i, n] = e, {
      screenX: r,
      screenY: a
    } = i, {
      screenX: o,
      screenY: l
    } = n, h = this.#f, {
      touch0X: d,
      touch0Y: u,
      touch1X: f,
      touch1Y: p,
      panX: g,
      panY: m
    } = h, v = f - d, y = p - u, b = o - r, w = l - a, A = (i.clientX + n.clientX) / 2, S = (i.clientY + n.clientY) / 2;
    h.panX = A, h.panY = S;
    const E = A - g, T = S - m, x = (r + o) / 2, P = (a + l) / 2, C = Math.hypot(x - h.screenPanX, P - h.screenPanY);
    h.screenPanX = x, h.screenPanY = P;
    const I = Math.hypot(b, w), R = Math.hypot(v, y), D = this.#e ? this.MIN_TOUCH_DISTANCE_TO_SCALE : this.MIN_TOUCH_DISTANCE_TO_PINCH + 2 * C;
    if (I < Xi || R < Xi || Math.abs(R - I) <= D) {
      (E || T) && this.#o?.(E, T);
      return;
    }
    h.touch0X = r, h.touch0Y = a, h.touch1X = o, h.touch1Y = l;
    const _ = Math.sign(I - R);
    if (!this.#e) {
      this.#e = !0, this.#c = _, (E || T) && this.#o?.(E, T);
      return;
    }
    if (this.#c) {
      const M = this.#c;
      if (this.#c = 0, _ !== M && Math.abs(I - R) <= 2 * C) {
        this.#e = !1, (E || T) && this.#o?.(E, T);
        return;
      }
    }
    this.#a?.([g, m], R, I, E, T);
  }
  #w(t) {
    if (this.#y(t), this.#d.size >= 2) {
      this.#A(t);
      return;
    }
    const e = !!this.#f;
    this.#x(), this.#d.size === 1 && this.#v(), e && zs(t);
  }
  #x() {
    this.#f = null, this.#e = !1, this.#c = 0, this.#l = !1, this.#m && (this.#m.abort(), this.#m = null, this.#r?.());
  }
  destroy() {
    this.#x(), this.#d.clear(), this.#g?.abort(), this.#g = null, this.#h?.abort(), this.#h = null;
  }
}
class H {
  #t = null;
  #e = null;
  #s = null;
  #i = null;
  #n = null;
  #a = !1;
  #r = null;
  #o = "";
  #l = null;
  #h = null;
  #u = null;
  #d = null;
  #f = null;
  #g = "";
  #m = !1;
  #c = null;
  #p = !1;
  #v = !1;
  #y = !1;
  #b = null;
  #A = 0;
  #E = 0;
  #w = null;
  #x = null;
  isSelected = !1;
  _isCopy = !1;
  _editToolbar = null;
  _initialOptions = /* @__PURE__ */ Object.create(null);
  _initialData = null;
  _isVisible = !0;
  _uiManager = null;
  _focusEventsAllowed = !0;
  static _l10n = null;
  static _l10nAlert = null;
  static _l10nResizer = null;
  #T = !1;
  #M = H._zIndex++;
  static _borderLineWidth = -1;
  static _colorManager = new mi();
  static _zIndex = 1;
  static _telemetryTimeout = 1e3;
  static get _resizerKeyboardManager() {
    const t = H.prototype._resizeWithKeyboard, e = de.TRANSLATE_SMALL, s = de.TRANSLATE_BIG;
    return j(this, "_resizerKeyboardManager", new _t([[["ArrowLeft"], t, {
      args: [-e, 0]
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t, {
      args: [-s, 0]
    }], [["ArrowRight"], t, {
      args: [e, 0]
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t, {
      args: [s, 0]
    }], [["ArrowUp"], t, {
      args: [0, -e]
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t, {
      args: [0, -s]
    }], [["ArrowDown"], t, {
      args: [0, e]
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t, {
      args: [0, s]
    }], [["Escape"], H.prototype._stopResizingWithKeyboard]]));
  }
  constructor(t) {
    this.parent = t.parent, this.id = t.id, this.width = this.height = null, this.pageIndex = t.parent.pageIndex, this.name = t.name, this.div = null, this._uiManager = t.uiManager, this.annotationElementId = null, this._willKeepAspectRatio = !1, this._initialOptions.isCentered = t.isCentered, this._structTreeParentId = null, this.annotationElementId = t.annotationElementId || null, this.creationDate = t.creationDate || /* @__PURE__ */ new Date(), this.modificationDate = t.modificationDate || null, this.canAddComment = !0;
    const {
      rotation: e,
      rawDims: {
        pageWidth: s,
        pageHeight: i,
        pageX: n,
        pageY: r
      }
    } = this.parent.viewport;
    this.rotation = e, this.pageRotation = (360 + e - this._uiManager.viewParameters.rotation) % 360, this.pageDimensions = [s, i], this.pageTranslation = [n, r];
    const [a, o] = this.parentDimensions;
    this.x = t.x / a, this.y = t.y / o, this.isAttachedToDOM = !1, this.deleted = !1;
  }
  updatePageIndex(t) {
    this.pageIndex = t;
  }
  get editorType() {
    return Object.getPrototypeOf(this).constructor._type;
  }
  get mode() {
    return Object.getPrototypeOf(this).constructor._editorType;
  }
  static get isDrawer() {
    return !1;
  }
  static get _defaultLineColor() {
    return j(this, "_defaultLineColor", this._colorManager.getHexCode("CanvasText"));
  }
  static deleteAnnotationElement(t) {
    const e = new Cr({
      id: t._uiManager.getId(),
      parent: t.parent,
      uiManager: t._uiManager
    });
    e.annotationElementId = t.annotationElementId, e.deleted = !0, e._uiManager.addToAnnotationStorage(e);
  }
  static initialize(t, e) {
    if (H._l10n ??= t, H._l10nAlert ??= Object.freeze({
      highlight: "pdfjs-editor-highlight-added-alert",
      freetext: "pdfjs-editor-freetext-added-alert",
      ink: "pdfjs-editor-ink-added-alert",
      stamp: "pdfjs-editor-stamp-added-alert",
      signature: "pdfjs-editor-signature-added-alert"
    }), H._l10nResizer ??= Object.freeze({
      topLeft: "pdfjs-editor-resizer-top-left",
      topMiddle: "pdfjs-editor-resizer-top-middle",
      topRight: "pdfjs-editor-resizer-top-right",
      middleRight: "pdfjs-editor-resizer-middle-right",
      bottomRight: "pdfjs-editor-resizer-bottom-right",
      bottomMiddle: "pdfjs-editor-resizer-bottom-middle",
      bottomLeft: "pdfjs-editor-resizer-bottom-left",
      middleLeft: "pdfjs-editor-resizer-middle-left"
    }), H._borderLineWidth !== -1)
      return;
    const s = getComputedStyle(document.documentElement);
    H._borderLineWidth = parseFloat(s.getPropertyValue("--outline-width")) || 0;
  }
  static updateDefaultParams(t, e) {
  }
  static get defaultPropertiesToUpdate() {
    return [];
  }
  static isHandlingMimeForPasting(t) {
    return !1;
  }
  static paste(t, e) {
    st("Not implemented");
  }
  get propertiesToUpdate() {
    return [];
  }
  get _isDraggable() {
    return this.#T;
  }
  set _isDraggable(t) {
    this.#T = t, this.div?.classList.toggle("draggable", t);
  }
  get uid() {
    return this.annotationElementId || this.id;
  }
  get isEnterHandled() {
    return !0;
  }
  center() {
    const [t, e] = this.pageDimensions;
    switch (this.parentRotation) {
      case 90:
        this.x -= this.height * e / (t * 2), this.y += this.width * t / (e * 2);
        break;
      case 180:
        this.x += this.width / 2, this.y += this.height / 2;
        break;
      case 270:
        this.x += this.height * e / (t * 2), this.y -= this.width * t / (e * 2);
        break;
      default:
        this.x -= this.width / 2, this.y -= this.height / 2;
        break;
    }
    this.fixAndSetPosition();
  }
  addCommands(t) {
    this._uiManager.addCommands(t);
  }
  get currentLayer() {
    return this._uiManager.currentLayer;
  }
  setInBackground() {
    this.div.style.zIndex = 0;
  }
  setInForeground() {
    this.div.style.zIndex = this.#M;
  }
  setParent(t) {
    t !== null ? (this.pageIndex = t.pageIndex, this.pageDimensions = t.pageDimensions) : (this.#F(), this.#d?.remove(), this.#d = null), this.parent = t;
  }
  focusin(t) {
    this._focusEventsAllowed && (this.#m ? this.#m = !1 : this.parent.setSelected(this));
  }
  focusout(t) {
    !this._focusEventsAllowed || !this.isAttachedToDOM || t.relatedTarget?.closest(`#${this.id}`) || (t.preventDefault(), this.parent?.isMultipleSelection || this.commitOrRemove());
  }
  commitOrRemove() {
    this.isEmpty() ? this.remove() : this.commit();
  }
  commit() {
    this.isInEditMode() && this.addToAnnotationStorage();
  }
  addToAnnotationStorage() {
    this._uiManager.addToAnnotationStorage(this);
  }
  setAt(t, e, s, i) {
    const [n, r] = this.parentDimensions;
    [s, i] = this.screenToPageTranslation(s, i), this.x = (t + s) / n, this.y = (e + i) / r, this.fixAndSetPosition();
  }
  _moveAfterPaste(t, e) {
    if (this.isClone) {
      delete this.isClone;
      return;
    }
    const [s, i] = this.parentDimensions;
    this.setAt(t * s, e * i, this.width * s, this.height * i), this._onTranslated();
  }
  #I([t, e], s, i) {
    [s, i] = this.screenToPageTranslation(s, i), this.x += s / t, this.y += i / e, this._onTranslating(this.x, this.y), this.fixAndSetPosition();
  }
  translate(t, e) {
    this.#I(this.parentDimensions, t, e);
  }
  translateInPage(t, e) {
    this.#c ||= [this.x, this.y, this.width, this.height], this.#I(this.pageDimensions, t, e), this.div.scrollIntoView({
      block: "nearest"
    });
  }
  translationDone() {
    this._onTranslated(this.x, this.y);
  }
  drag(t, e) {
    this.#c ||= [this.x, this.y, this.width, this.height];
    const {
      div: s,
      parentDimensions: [i, n]
    } = this;
    if (this.x += t / i, this.y += e / n, this.parent && (this.x < 0 || this.x > 1 || this.y < 0 || this.y > 1)) {
      const {
        x: d,
        y: u
      } = this.div.getBoundingClientRect();
      this.parent.findNewParent(this, d, u) && (this.x -= Math.floor(this.x), this.y -= Math.floor(this.y));
    }
    let {
      x: r,
      y: a
    } = this;
    const [o, l] = this.getBaseTranslation();
    r += o, a += l;
    const {
      style: h
    } = s;
    h.left = `${(100 * r).toFixed(2)}%`, h.top = `${(100 * a).toFixed(2)}%`, this._onTranslating(r, a);
  }
  _onTranslating(t, e) {
  }
  _onTranslated(t, e) {
  }
  get _hasBeenMoved() {
    return !!this.#c && (this.#c[0] !== this.x || this.#c[1] !== this.y);
  }
  get _hasBeenResized() {
    return !!this.#c && (this.#c[2] !== this.width || this.#c[3] !== this.height);
  }
  getBaseTranslation() {
    const [t, e] = this.parentDimensions, {
      _borderLineWidth: s
    } = H, i = s / t, n = s / e;
    switch (this.rotation) {
      case 90:
        return [-i, n];
      case 180:
        return [i, n];
      case 270:
        return [i, -n];
      default:
        return [-i, -n];
    }
  }
  get _mustFixPosition() {
    return !0;
  }
  fixAndSetPosition(t = this.rotation) {
    const {
      div: {
        style: e
      },
      pageDimensions: [s, i]
    } = this;
    let {
      x: n,
      y: r,
      width: a,
      height: o
    } = this;
    if (a *= s, o *= i, n *= s, r *= i, this._mustFixPosition)
      switch (t) {
        case 0:
          n = ct(n, 0, s - a), r = ct(r, 0, i - o);
          break;
        case 90:
          n = ct(n, 0, s - o), r = ct(r, a, i);
          break;
        case 180:
          n = ct(n, a, s), r = ct(r, o, i);
          break;
        case 270:
          n = ct(n, o, s), r = ct(r, 0, i - a);
          break;
      }
    this.x = n /= s, this.y = r /= i;
    const [l, h] = this.getBaseTranslation();
    n += l, r += h, e.left = `${(100 * n).toFixed(2)}%`, e.top = `${(100 * r).toFixed(2)}%`, this.moveInDOM();
  }
  static #P(t, e, s) {
    switch (s) {
      case 90:
        return [e, -t];
      case 180:
        return [-t, -e];
      case 270:
        return [-e, t];
      default:
        return [t, e];
    }
  }
  screenToPageTranslation(t, e) {
    return H.#P(t, e, this.parentRotation);
  }
  pageTranslationToScreen(t, e) {
    return H.#P(t, e, 360 - this.parentRotation);
  }
  #D(t) {
    switch (t) {
      case 90: {
        const [e, s] = this.pageDimensions;
        return [0, -e / s, s / e, 0];
      }
      case 180:
        return [-1, 0, 0, -1];
      case 270: {
        const [e, s] = this.pageDimensions;
        return [0, e / s, -s / e, 0];
      }
      default:
        return [1, 0, 0, 1];
    }
  }
  get parentScale() {
    return this._uiManager.viewParameters.realScale;
  }
  get parentRotation() {
    return (this._uiManager.viewParameters.rotation + this.pageRotation) % 360;
  }
  get parentDimensions() {
    const {
      parentScale: t,
      pageDimensions: [e, s]
    } = this;
    return [e * t, s * t];
  }
  setDims() {
    const {
      div: {
        style: t
      },
      width: e,
      height: s
    } = this;
    t.width = `${(100 * e).toFixed(2)}%`, t.height = `${(100 * s).toFixed(2)}%`;
  }
  getInitialTranslation() {
    return [0, 0];
  }
  #R() {
    if (this.#l)
      return;
    this.#l = document.createElement("div"), this.#l.classList.add("resizers");
    const t = this._willKeepAspectRatio ? ["topLeft", "topRight", "bottomRight", "bottomLeft"] : ["topLeft", "topMiddle", "topRight", "middleRight", "bottomRight", "bottomMiddle", "bottomLeft", "middleLeft"], e = this._uiManager._signal;
    for (const s of t) {
      const i = document.createElement("div");
      this.#l.append(i), i.classList.add("resizer", s), i.setAttribute("data-resizer-name", s), i.addEventListener("pointerdown", this.#k.bind(this, s), {
        signal: e
      }), i.addEventListener("contextmenu", Yt, {
        signal: e
      }), i.tabIndex = -1;
    }
    this.div.prepend(this.#l);
  }
  #k(t, e) {
    e.preventDefault();
    const {
      isMac: s
    } = at.platform;
    if (e.button !== 0 || e.ctrlKey && s)
      return;
    this.#s?.toggle(!1);
    const i = this._isDraggable;
    this._isDraggable = !1, this.#h = [e.screenX, e.screenY];
    const n = new AbortController(), r = this._uiManager.combinedSignal(n);
    this.parent.togglePointerEvents(!1), window.addEventListener("pointermove", this.#L.bind(this, t), {
      passive: !0,
      capture: !0,
      signal: r
    }), window.addEventListener("touchmove", St, {
      passive: !1,
      signal: r
    }), window.addEventListener("contextmenu", Yt, {
      signal: r
    }), this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    };
    const a = this.parent.div.style.cursor, o = this.div.style.cursor;
    this.div.style.cursor = this.parent.div.style.cursor = window.getComputedStyle(e.target).cursor;
    const l = () => {
      n.abort(), this.parent.togglePointerEvents(!0), this.#s?.toggle(!0), this._isDraggable = i, this.parent.div.style.cursor = a, this.div.style.cursor = o, this.#N();
    };
    window.addEventListener("pointerup", l, {
      signal: r
    }), window.addEventListener("blur", l, {
      signal: r
    });
  }
  #H(t, e, s, i) {
    this.width = s, this.height = i, this.x = t, this.y = e, this.setDims(), this.fixAndSetPosition(), this._onResized();
  }
  _onResized() {
  }
  #N() {
    if (!this.#u)
      return;
    const {
      savedX: t,
      savedY: e,
      savedWidth: s,
      savedHeight: i
    } = this.#u;
    this.#u = null;
    const n = this.x, r = this.y, a = this.width, o = this.height;
    n === t && r === e && a === s && o === i || this.addCommands({
      cmd: this.#H.bind(this, n, r, a, o),
      undo: this.#H.bind(this, t, e, s, i),
      mustExec: !0
    });
  }
  static _round(t) {
    return Math.round(t * 1e4) / 1e4;
  }
  #L(t, e) {
    const [s, i] = this.parentDimensions, n = this.x, r = this.y, a = this.width, o = this.height, l = H.MIN_SIZE / s, h = H.MIN_SIZE / i, d = this.#D(this.rotation), u = (M, k) => [d[0] * M + d[2] * k, d[1] * M + d[3] * k], f = this.#D(360 - this.rotation), p = (M, k) => [f[0] * M + f[2] * k, f[1] * M + f[3] * k];
    let g, m, v = !1, y = !1;
    switch (t) {
      case "topLeft":
        v = !0, g = (M, k) => [0, 0], m = (M, k) => [M, k];
        break;
      case "topMiddle":
        g = (M, k) => [M / 2, 0], m = (M, k) => [M / 2, k];
        break;
      case "topRight":
        v = !0, g = (M, k) => [M, 0], m = (M, k) => [0, k];
        break;
      case "middleRight":
        y = !0, g = (M, k) => [M, k / 2], m = (M, k) => [0, k / 2];
        break;
      case "bottomRight":
        v = !0, g = (M, k) => [M, k], m = (M, k) => [0, 0];
        break;
      case "bottomMiddle":
        g = (M, k) => [M / 2, k], m = (M, k) => [M / 2, 0];
        break;
      case "bottomLeft":
        v = !0, g = (M, k) => [0, k], m = (M, k) => [M, 0];
        break;
      case "middleLeft":
        y = !0, g = (M, k) => [0, k / 2], m = (M, k) => [M, k / 2];
        break;
    }
    const b = g(a, o), w = m(a, o);
    let A = u(...w);
    const S = H._round(n + A[0]), E = H._round(r + A[1]);
    let T = 1, x = 1, P, C;
    if (e.fromKeyboard)
      ({
        deltaX: P,
        deltaY: C
      } = e);
    else {
      const {
        screenX: M,
        screenY: k
      } = e, [$, U] = this.#h;
      [P, C] = this.screenToPageTranslation(M - $, k - U), this.#h[0] = M, this.#h[1] = k;
    }
    if ([P, C] = p(P / s, C / i), v) {
      const M = Math.hypot(a, o);
      T = x = Math.max(Math.min(Math.hypot(w[0] - b[0] - P, w[1] - b[1] - C) / M, 1 / a, 1 / o), l / a, h / o);
    } else y ? T = ct(Math.abs(w[0] - b[0] - P), l, 1) / a : x = ct(Math.abs(w[1] - b[1] - C), h, 1) / o;
    const I = H._round(a * T), R = H._round(o * x);
    A = u(...m(I, R));
    const D = S - A[0], _ = E - A[1];
    this.#c ||= [this.x, this.y, this.width, this.height], this.width = I, this.height = R, this.x = D, this.y = _, this.setDims(), this.fixAndSetPosition(), this._onResizing();
  }
  _onResizing() {
  }
  altTextFinish() {
    this.#s?.finish();
  }
  get toolbarButtons() {
    return null;
  }
  async addEditToolbar() {
    if (this._editToolbar || this.#v)
      return this._editToolbar;
    this._editToolbar = new Xe(this), this.div.append(this._editToolbar.render());
    const {
      toolbarButtons: t
    } = this;
    if (t)
      for (const [e, s] of t)
        await this._editToolbar.addButton(e, s);
    return this.hasComment || this._editToolbar.addButton("comment", this.addCommentButton()), this._editToolbar.addButton("delete"), this._editToolbar;
  }
  addCommentButtonInToolbar() {
    this._editToolbar?.addButtonBefore("comment", this.addCommentButton(), ".deleteButton");
  }
  removeCommentButtonFromToolbar() {
    this._editToolbar?.removeButton("comment");
  }
  removeEditToolbar() {
    this._editToolbar?.remove(), this._editToolbar = null, this.#s?.destroy();
  }
  addContainer(t) {
    const e = this._editToolbar?.div;
    e ? e.before(t) : this.div.append(t);
  }
  getClientDimensions() {
    return this.div.getBoundingClientRect();
  }
  createAltText() {
    return this.#s || (ie.initialize(H._l10n), this.#s = new ie(this), this.#t && (this.#s.data = this.#t, this.#t = null)), this.#s;
  }
  get altTextData() {
    return this.#s?.data;
  }
  set altTextData(t) {
    this.#s && (this.#s.data = t);
  }
  get guessedAltText() {
    return this.#s?.guessedText;
  }
  async setGuessedAltText(t) {
    await this.#s?.setGuessedText(t);
  }
  serializeAltText(t) {
    return this.#s?.serialize(t);
  }
  hasAltText() {
    return !!this.#s && !this.#s.isEmpty();
  }
  hasAltTextData() {
    return this.#s?.hasData() ?? !1;
  }
  focusCommentButton() {
    this.#i?.focusButton();
  }
  addCommentButton() {
    return this.canAddComment ? this.#i ||= new as(this) : null;
  }
  addStandaloneCommentButton() {
    if (this._uiManager.hasCommentManager()) {
      if (this.#n) {
        this._uiManager.isEditingMode() && this.#n.classList.remove("hidden");
        return;
      }
      this.hasComment && (this.#n = this.#i.renderForStandalone(), this.div.append(this.#n));
    }
  }
  removeStandaloneCommentButton() {
    this.#i.removeStandaloneCommentButton(), this.#n = null;
  }
  hideStandaloneCommentButton() {
    this.#n?.classList.add("hidden");
  }
  get comment() {
    if (!this.#i)
      return null;
    const {
      data: {
        richText: t,
        text: e,
        date: s,
        deleted: i
      }
    } = this.#i;
    return {
      text: e,
      richText: t,
      date: s,
      deleted: i,
      color: this.getNonHCMColor(),
      opacity: this.opacity ?? 1
    };
  }
  set comment(t) {
    this.#i ||= new as(this), typeof t == "object" && t !== null ? this.#i.restoreData(t) : this.#i.data = t, this.hasComment ? (this.removeCommentButtonFromToolbar(), this.addStandaloneCommentButton(), this._uiManager.updateComment(this)) : (this.addCommentButtonInToolbar(), this.removeStandaloneCommentButton(), this._uiManager.removeComment(this));
  }
  setCommentData({
    comment: t,
    popupRef: e,
    richText: s
  }) {
    if (!e || (this.#i ||= new as(this), this.#i.setInitialText(t, s), !this.annotationElementId))
      return;
    const i = this._uiManager.getAndRemoveDataFromAnnotationStorage(this.annotationElementId);
    i && this.updateFromAnnotationLayer(i);
  }
  get hasEditedComment() {
    return this.#i?.hasBeenEdited();
  }
  get hasDeletedComment() {
    return this.#i?.isDeleted();
  }
  get hasComment() {
    return !!this.#i && !this.#i.isEmpty() && !this.#i.isDeleted();
  }
  async editComment(t) {
    this.#i ||= new as(this), this.#i.edit(t);
  }
  toggleComment(t, e = void 0) {
    this.hasComment && this._uiManager.toggleComment(this, t, e);
  }
  setSelectedCommentButton(t) {
    this.#i.setSelectedButton(t);
  }
  addComment(t) {
    if (this.hasEditedComment) {
      const [, , , i] = t.rect, [n] = this.pageDimensions, [r] = this.pageTranslation, a = r + n + 1, o = i - 100, l = a + 180;
      t.popup = {
        contents: this.comment.text,
        deleted: this.comment.deleted,
        rect: [a, o, l, i]
      };
    }
  }
  updateFromAnnotationLayer({
    popup: {
      contents: t,
      deleted: e
    }
  }) {
    this.#i.data = e ? null : t;
  }
  get parentBoundingClientRect() {
    return this.parent.boundingClientRect;
  }
  render() {
    const t = this.div = document.createElement("div");
    t.setAttribute("data-editor-rotation", (360 - this.rotation) % 360), t.className = this.name, t.setAttribute("id", this.id), t.tabIndex = this.#a ? -1 : 0, t.setAttribute("role", "application"), this.defaultL10nId && t.setAttribute("data-l10n-id", this.defaultL10nId), this._isVisible || t.classList.add("hidden"), this.setInForeground(), this.#_();
    const [e, s] = this.parentDimensions;
    this.parentRotation % 180 !== 0 && (t.style.maxWidth = `${(100 * s / e).toFixed(2)}%`, t.style.maxHeight = `${(100 * e / s).toFixed(2)}%`);
    const [i, n] = this.getInitialTranslation();
    return this.translate(i, n), Tn(this, t, ["keydown", "pointerdown", "dblclick"]), this.#$(), this.addStandaloneCommentButton(), this._uiManager._editorUndoBar?.hide(), t;
  }
  #V() {
    this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    }, this.#s?.toggle(!1), this.parent.togglePointerEvents(!1);
  }
  #B(t, e, s) {
    let n = 0.7 * (s / e) + 1 - 0.7;
    if (n === 1)
      return;
    const r = this.#D(this.rotation), a = (S, E) => [r[0] * S + r[2] * E, r[1] * S + r[3] * E], [o, l] = this.parentDimensions, h = this.x, d = this.y, u = this.width, f = this.height, p = H.MIN_SIZE / o, g = H.MIN_SIZE / l;
    n = Math.max(Math.min(n, 1 / u, 1 / f), p / u, g / f);
    const m = H._round(u * n), v = H._round(f * n);
    if (m === u && v === f)
      return;
    this.#c ||= [h, d, u, f];
    const y = a(u / 2, f / 2), b = H._round(h + y[0]), w = H._round(d + y[1]), A = a(m / 2, v / 2);
    this.x = b - A[0], this.y = w - A[1], this.width = m, this.height = v, this.setDims(), this.fixAndSetPosition(), this._onResizing();
  }
  #j() {
    this.#s?.toggle(!0), this.parent.togglePointerEvents(!0), this.#N();
  }
  pointerdown(t) {
    const {
      isMac: e
    } = at.platform;
    if (t.button !== 0 || t.ctrlKey && e) {
      t.preventDefault();
      return;
    }
    if (this.#m = !0, this._isDraggable) {
      this.#S(t);
      return;
    }
    this.#C(t);
  }
  #C(t) {
    const {
      isMac: e
    } = at.platform;
    t.ctrlKey && !e || t.shiftKey || t.metaKey && e ? this.parent.toggleSelected(this) : this.parent.setSelected(this);
  }
  #S(t) {
    const {
      isSelected: e
    } = this;
    this._uiManager.setUpDragSession();
    let s = !1;
    const i = new AbortController(), n = this._uiManager.combinedSignal(i), r = {
      capture: !0,
      passive: !1,
      signal: n
    }, a = (l) => {
      i.abort(), this.#r = null, this.#m = !1, this._uiManager.endDragSession() || this.#C(l), s && this._onStopDragging();
    };
    e && (this.#A = t.clientX, this.#E = t.clientY, this.#r = t.pointerId, this.#o = t.pointerType, window.addEventListener("pointermove", (l) => {
      s || (s = !0, this._uiManager.toggleComment(this, !0, !1), this._onStartDragging());
      const {
        clientX: h,
        clientY: d,
        pointerId: u
      } = l;
      if (u !== this.#r) {
        St(l);
        return;
      }
      const [f, p] = this.screenToPageTranslation(h - this.#A, d - this.#E);
      this.#A = h, this.#E = d, this._uiManager.dragSelectedEditors(f, p), this.div.scrollIntoView({
        block: "nearest"
      });
    }, r), window.addEventListener("touchmove", St, r), window.addEventListener("pointerdown", (l) => {
      l.pointerType === this.#o && (this.#x || l.isPrimary) && a(l), St(l);
    }, r));
    const o = (l) => {
      if (!this.#r || this.#r === l.pointerId) {
        a(l);
        return;
      }
      St(l);
    };
    window.addEventListener("pointerup", o, {
      signal: n
    }), window.addEventListener("blur", o, {
      signal: n
    });
  }
  _onStartDragging() {
  }
  _onStopDragging() {
  }
  moveInDOM() {
    this.#b && clearTimeout(this.#b), this.#b = setTimeout(() => {
      this.#b = null, this.parent?.moveEditorInDOM(this);
    }, 0);
  }
  _setParentAndPosition(t, e, s) {
    t.changeParent(this), this.x = e, this.y = s, this.fixAndSetPosition(), this._onTranslated();
  }
  getRect(t, e, s = this.rotation) {
    const i = this.parentScale, [n, r] = this.pageDimensions, [a, o] = this.pageTranslation, l = t / i, h = e / i, d = this.x * n, u = this.y * r, f = this.width * n, p = this.height * r;
    switch (s) {
      case 0:
        return [d + l + a, r - u - h - p + o, d + l + f + a, r - u - h + o];
      case 90:
        return [d + h + a, r - u + l + o, d + h + p + a, r - u + l + f + o];
      case 180:
        return [d - l - f + a, r - u + h + o, d - l + a, r - u + h + p + o];
      case 270:
        return [d - h - p + a, r - u - l - f + o, d - h + a, r - u - l + o];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getRectInCurrentCoords(t, e) {
    const [s, i, n, r] = t, a = n - s, o = r - i;
    switch (this.rotation) {
      case 0:
        return [s, e - r, a, o];
      case 90:
        return [s, e - i, o, a];
      case 180:
        return [n, e - i, a, o];
      case 270:
        return [n, e - r, o, a];
      default:
        throw new Error("Invalid rotation");
    }
  }
  getPDFRect() {
    return this.getRect(0, 0);
  }
  getNonHCMColor() {
    return this.color && H._colorManager.convert(this._uiManager.getNonHCMColor(this.color));
  }
  onUpdatedColor() {
    this.#i?.onUpdatedColor();
  }
  getData() {
    const {
      comment: {
        text: t,
        color: e,
        date: s,
        opacity: i,
        deleted: n,
        richText: r
      },
      uid: a,
      pageIndex: o,
      creationDate: l,
      modificationDate: h
    } = this;
    return {
      id: a,
      pageIndex: o,
      rect: this.getPDFRect(),
      richText: r,
      contentsObj: {
        str: t
      },
      creationDate: l,
      modificationDate: s || h,
      popupRef: !n,
      color: e,
      opacity: i
    };
  }
  onceAdded(t) {
  }
  isEmpty() {
    return !1;
  }
  enableEditMode() {
    return this.isInEditMode() ? !1 : (this.parent.setEditingState(!1), this.#v = !0, !0);
  }
  disableEditMode() {
    return this.isInEditMode() ? (this.parent.setEditingState(!0), this.#v = !1, !0) : !1;
  }
  isInEditMode() {
    return this.#v;
  }
  shouldGetKeyboardEvents() {
    return this.#y;
  }
  needsToBeRebuilt() {
    return this.div && !this.isAttachedToDOM;
  }
  get isOnScreen() {
    const {
      top: t,
      left: e,
      bottom: s,
      right: i
    } = this.getClientDimensions(), {
      innerHeight: n,
      innerWidth: r
    } = window;
    return e < r && i > 0 && t < n && s > 0;
  }
  #_() {
    if (this.#f || !this.div)
      return;
    this.#f = new AbortController();
    const t = this._uiManager.combinedSignal(this.#f);
    this.div.addEventListener("focusin", this.focusin.bind(this), {
      signal: t
    }), this.div.addEventListener("focusout", this.focusout.bind(this), {
      signal: t
    });
  }
  #$() {
    this.#x || !this.div || !this.isResizable || !this._uiManager._supportsPinchToZoom || (this.#x = new Cn({
      container: this.div,
      isPinchingDisabled: () => !this.isSelected,
      onPinchStart: this.#V.bind(this),
      onPinching: this.#B.bind(this),
      onPinchEnd: this.#j.bind(this),
      signal: this._uiManager._signal
    }));
  }
  rebuild() {
    this.#_(), this.#$();
  }
  rotate(t) {
  }
  resize() {
  }
  serializeDeleted() {
    return {
      id: this.annotationElementId,
      deleted: !0,
      pageIndex: this.pageIndex,
      popupRef: this._initialData?.popupRef || ""
    };
  }
  serialize(t = !1, e = null) {
    return {
      annotationType: this.mode,
      pageIndex: this.pageIndex,
      rect: this.getPDFRect(),
      rotation: this.rotation,
      structTreeParentId: this._structTreeParentId,
      popupRef: this._initialData?.popupRef || ""
    };
  }
  static async deserialize(t, e, s) {
    const i = new this.prototype.constructor({
      parent: e,
      id: s.getId(),
      uiManager: s,
      annotationElementId: t.annotationElementId,
      creationDate: t.creationDate,
      modificationDate: t.modificationDate
    });
    i.rotation = t.rotation, i.#t = t.accessibilityData, i._isCopy = t.isCopy || !1;
    const [n, r] = i.pageDimensions, [a, o, l, h] = i.getRectInCurrentCoords(t.rect, r);
    return i.x = a / n, i.y = o / r, i.width = l / n, i.height = h / r, i;
  }
  get hasBeenModified() {
    return !!this.annotationElementId && (this.deleted || this.serialize() !== null);
  }
  remove() {
    if (this.#f?.abort(), this.#f = null, this.isEmpty() || this.commit(), this.#x?.destroy(), this.#x = null, this.parent ? this.parent.remove(this) : this._uiManager.removeEditor(this), this.hideCommentPopup(), this.#b && (clearTimeout(this.#b), this.#b = null), this.#F(), this.removeEditToolbar(), this.#w) {
      for (const t of this.#w.values())
        clearTimeout(t);
      this.#w = null;
    }
    this.parent = null, this.#d?.remove(), this.#d = null;
  }
  get isResizable() {
    return !1;
  }
  makeResizable() {
    this.isResizable && (this.#R(), this.#l.classList.remove("hidden"));
  }
  get toolbarPosition() {
    return null;
  }
  get commentButtonPosition() {
    return this._uiManager.direction === "ltr" ? [1, 0] : [0, 0];
  }
  get commentButtonPositionInPage() {
    const {
      commentButtonPosition: [t, e]
    } = this, [s, i, n, r] = this.getPDFRect();
    return [H._round(s + (n - s) * t), H._round(i + (r - i) * (1 - e))];
  }
  get commentButtonColor() {
    return this._uiManager.makeCommentColor(this.getNonHCMColor(), this.opacity);
  }
  get commentPopupPosition() {
    return this.#i.commentPopupPositionInLayer;
  }
  set commentPopupPosition(t) {
    this.#i.commentPopupPositionInLayer = t;
  }
  hasDefaultPopupPosition() {
    return this.#i.hasDefaultPopupPosition();
  }
  get commentButtonWidth() {
    return this.#i.commentButtonWidth;
  }
  get elementBeforePopup() {
    return this.div;
  }
  setCommentButtonStates(t) {
    this.#i?.setCommentButtonStates(t);
  }
  keydown(t) {
    if (!this.isResizable || t.target !== this.div || t.key !== "Enter")
      return;
    this._uiManager.setSelected(this), this.#u = {
      savedX: this.x,
      savedY: this.y,
      savedWidth: this.width,
      savedHeight: this.height
    };
    const e = this.#l.children;
    if (!this.#e) {
      this.#e = Array.from(e);
      const r = this.#z.bind(this), a = this.#J.bind(this), o = this._uiManager._signal;
      for (const l of this.#e) {
        const h = l.getAttribute("data-resizer-name");
        l.setAttribute("role", "spinbutton"), l.addEventListener("keydown", r, {
          signal: o
        }), l.addEventListener("blur", a, {
          signal: o
        }), l.addEventListener("focus", this.#Y.bind(this, h), {
          signal: o
        }), l.setAttribute("data-l10n-id", H._l10nResizer[h]);
      }
    }
    const s = this.#e[0];
    let i = 0;
    for (const r of e) {
      if (r === s)
        break;
      i++;
    }
    const n = (360 - this.rotation + this.parentRotation) % 360 / 90 * (this.#e.length / 4);
    if (n !== i) {
      if (n < i)
        for (let a = 0; a < i - n; a++)
          this.#l.append(this.#l.firstElementChild);
      else if (n > i)
        for (let a = 0; a < n - i; a++)
          this.#l.firstElementChild.before(this.#l.lastElementChild);
      let r = 0;
      for (const a of e) {
        const l = this.#e[r++].getAttribute("data-resizer-name");
        a.setAttribute("data-l10n-id", H._l10nResizer[l]);
      }
    }
    this.#K(0), this.#y = !0, this.#l.firstElementChild.focus({
      focusVisible: !0
    }), t.preventDefault(), t.stopImmediatePropagation();
  }
  #z(t) {
    H._resizerKeyboardManager.exec(this, t);
  }
  #J(t) {
    this.#y && t.relatedTarget?.parentNode !== this.#l && this.#F();
  }
  #Y(t) {
    this.#g = this.#y ? t : "";
  }
  #K(t) {
    if (this.#e)
      for (const e of this.#e)
        e.tabIndex = t;
  }
  _resizeWithKeyboard(t, e) {
    this.#y && this.#L(this.#g, {
      deltaX: t,
      deltaY: e,
      fromKeyboard: !0
    });
  }
  #F() {
    this.#y = !1, this.#K(-1), this.#N();
  }
  _stopResizingWithKeyboard() {
    this.#F(), this.div.focus();
  }
  select() {
    if (this.isSelected && this._editToolbar) {
      this._editToolbar.show();
      return;
    }
    if (this.isSelected = !0, this.makeResizable(), this.div?.classList.add("selectedEditor"), !this._editToolbar) {
      this.addEditToolbar().then(() => {
        this.div?.classList.contains("selectedEditor") && this._editToolbar?.show();
      });
      return;
    }
    this._editToolbar?.show(), this.#s?.toggleAltTextBadge(!1);
  }
  focus() {
    this.div && !this.div.contains(document.activeElement) && setTimeout(() => this.div?.focus({
      preventScroll: !0
    }), 0);
  }
  unselect() {
    this.isSelected && (this.isSelected = !1, this.#l?.classList.add("hidden"), this.div?.classList.remove("selectedEditor"), this.div?.contains(document.activeElement) && this._uiManager.currentLayer.div.focus({
      preventScroll: !0
    }), this._editToolbar?.hide(), this.#s?.toggleAltTextBadge(!0), this.hideCommentPopup());
  }
  hideCommentPopup() {
    this.hasComment && this._uiManager.toggleComment(null);
  }
  updateParams(t, e) {
  }
  disableEditing() {
  }
  enableEditing() {
  }
  get canChangeContent() {
    return !1;
  }
  enterInEditMode() {
    this.canChangeContent && (this.enableEditMode(), this.div.focus());
  }
  dblclick(t) {
    t.target.nodeName !== "BUTTON" && (this.enterInEditMode(), this.parent.updateToolbar({
      mode: this.constructor._editorType,
      editId: this.uid
    }));
  }
  getElementForAltText() {
    return this.div;
  }
  get contentDiv() {
    return this.div;
  }
  get isEditing() {
    return this.#p;
  }
  set isEditing(t) {
    this.#p = t, this.parent && (t ? (this.parent.setSelected(this), this.parent.setActiveEditor(this)) : this.parent.setActiveEditor(null));
  }
  static get MIN_SIZE() {
    return 16;
  }
  static canCreateNewEmptyEditor() {
    return !0;
  }
  get telemetryInitialData() {
    return {
      action: "added"
    };
  }
  get telemetryFinalData() {
    return null;
  }
  _reportTelemetry(t, e = !1) {
    if (e) {
      this.#w ||= /* @__PURE__ */ new Map();
      const {
        action: s
      } = t;
      let i = this.#w.get(s);
      i && clearTimeout(i), i = setTimeout(() => {
        this._reportTelemetry(t), this.#w.delete(s), this.#w.size === 0 && (this.#w = null);
      }, H._telemetryTimeout), this.#w.set(s, i);
      return;
    }
    t.type ||= this.editorType, this._uiManager._eventBus.dispatch("reporttelemetry", {
      source: this,
      details: {
        type: "editing",
        data: t
      }
    });
  }
  show(t = this._isVisible) {
    this.div.classList.toggle("hidden", !t), this._isVisible = t;
  }
  enable() {
    this.div && (this.div.tabIndex = 0), this.#a = !1;
  }
  disable() {
    this.div && (this.div.tabIndex = -1), this.#a = !0;
  }
  updateFakeAnnotationElement(t) {
    if (!this.#d && !this.deleted) {
      this.#d = t.addFakeAnnotation(this);
      return;
    }
    if (this.deleted) {
      this.#d.remove(), this.#d = null;
      return;
    }
    (this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized) && this.#d.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    });
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    let e = t.container.querySelector(".annotationContent");
    if (!e)
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), t.container.prepend(e);
    else if (e.nodeName === "CANVAS") {
      const s = e;
      e = document.createElement("div"), e.classList.add("annotationContent", this.editorType), s.before(e);
    }
    return e;
  }
  resetAnnotationElement(t) {
    const {
      firstElementChild: e
    } = t.container;
    e?.nodeName === "DIV" && e.classList.contains("annotationContent") && e.remove();
  }
}
class Cr extends H {
  constructor(t) {
    super(t), this.annotationElementId = t.annotationElementId, this.deleted = !0;
  }
  serialize() {
    return this.serializeDeleted();
  }
}
const Yi = 3285377520, Ht = 4294901760, te = 65535;
class ni {
  constructor(t) {
    this.h1 = t ? t & 4294967295 : Yi, this.h2 = t ? t & 4294967295 : Yi;
  }
  update(t) {
    let e, s;
    if (typeof t == "string") {
      e = new Uint8Array(t.length * 2), s = 0;
      for (let g = 0, m = t.length; g < m; g++) {
        const v = t.charCodeAt(g);
        v <= 255 ? e[s++] = v : (e[s++] = v >>> 8, e[s++] = v & 255);
      }
    } else if (ArrayBuffer.isView(t))
      e = t.slice(), s = e.byteLength;
    else
      throw new Error("Invalid data format, must be a string or TypedArray.");
    const i = s >> 2, n = s - i * 4, r = new Uint32Array(e.buffer, 0, i);
    let a = 0, o = 0, l = this.h1, h = this.h2;
    const d = 3432918353, u = 461845907, f = d & te, p = u & te;
    for (let g = 0; g < i; g++)
      g & 1 ? (a = r[g], a = a * d & Ht | a * f & te, a = a << 15 | a >>> 17, a = a * u & Ht | a * p & te, l ^= a, l = l << 13 | l >>> 19, l = l * 5 + 3864292196) : (o = r[g], o = o * d & Ht | o * f & te, o = o << 15 | o >>> 17, o = o * u & Ht | o * p & te, h ^= o, h = h << 13 | h >>> 19, h = h * 5 + 3864292196);
    switch (a = 0, n) {
      case 3:
        a ^= e[i * 4 + 2] << 16;
      case 2:
        a ^= e[i * 4 + 1] << 8;
      case 1:
        a ^= e[i * 4], a = a * d & Ht | a * f & te, a = a << 15 | a >>> 17, a = a * u & Ht | a * p & te, i & 1 ? l ^= a : h ^= a;
    }
    this.h1 = l, this.h2 = h;
  }
  hexdigest() {
    let t = this.h1, e = this.h2;
    return t ^= e >>> 1, t = t * 3981806797 & Ht | t * 36045 & te, e = e * 4283543511 & Ht | ((e << 16 | t >>> 16) * 2950163797 & Ht) >>> 16, t ^= e >>> 1, t = t * 444984403 & Ht | t * 60499 & te, e = e * 3301882366 & Ht | ((e << 16 | t >>> 16) * 3120437893 & Ht) >>> 16, t ^= e >>> 1, (t >>> 0).toString(16).padStart(8, "0") + (e >>> 0).toString(16).padStart(8, "0");
  }
}
const Qe = Object.freeze({
  map: null,
  hash: "",
  transfer: void 0
});
class vi {
  #t = !1;
  #e = null;
  #s = null;
  #i = /* @__PURE__ */ new Map();
  onSetModified = null;
  onResetModified = null;
  onAnnotationEditor = null;
  getValue(t, e) {
    const s = this.#i.get(t);
    return s === void 0 ? e : Object.assign(e, s);
  }
  getRawValue(t) {
    return this.#i.get(t);
  }
  remove(t) {
    const e = this.#i.get(t);
    e !== void 0 && (e instanceof H && this.#s.delete(e.annotationElementId), this.#i.delete(t), this.#i.size === 0 && this.resetModified(), !this.#i.values().some((s) => s instanceof H) && this.onAnnotationEditor?.(null));
  }
  setValue(t, e) {
    const s = this.#i.get(t);
    let i = !1;
    if (s !== void 0)
      for (const [n, r] of Object.entries(e))
        s[n] !== r && (i = !0, s[n] = r);
    else
      i = !0, this.#i.set(t, e);
    i && this.#n(), e instanceof H && ((this.#s ||= /* @__PURE__ */ new Map()).set(e.annotationElementId, e), this.onAnnotationEditor?.(e.constructor._type));
  }
  has(t) {
    return this.#i.has(t);
  }
  get size() {
    return this.#i.size;
  }
  #n() {
    this.#t || (this.#t = !0, this.onSetModified?.());
  }
  resetModified() {
    this.#t && (this.#t = !1, this.onResetModified?.());
  }
  get print() {
    return new Pn(this);
  }
  get serializable() {
    if (this.#i.size === 0)
      return Qe;
    const t = /* @__PURE__ */ new Map(), e = new ni(), s = [], i = /* @__PURE__ */ Object.create(null);
    let n = !1;
    for (const [r, a] of this.#i) {
      const o = a instanceof H ? a.serialize(!1, i) : a;
      a.page && (a.pageIndex = a.page._pageIndex, delete a.page), o && (t.set(r, o), e.update(`${r}:${JSON.stringify(o)}`), n ||= !!o.bitmap);
    }
    if (n)
      for (const r of t.values())
        r.bitmap && s.push(r.bitmap);
    return t.size > 0 ? {
      map: t,
      hash: e.hexdigest(),
      transfer: s
    } : Qe;
  }
  get editorStats() {
    let t = null;
    const e = /* @__PURE__ */ new Map();
    let s = 0, i = 0;
    for (const n of this.#i.values()) {
      if (!(n instanceof H)) {
        n.popup && (n.popup.deleted ? i += 1 : s += 1);
        continue;
      }
      n.isCommentDeleted ? i += 1 : n.hasEditedComment && (s += 1);
      const r = n.telemetryFinalData;
      if (!r)
        continue;
      const {
        type: a
      } = r;
      e.getOrInsertComputed(a, () => Object.getPrototypeOf(n).constructor), t ||= /* @__PURE__ */ Object.create(null);
      const o = t[a] ||= /* @__PURE__ */ new Map();
      for (const [l, h] of Object.entries(r)) {
        if (l === "type")
          continue;
        const d = o.getOrInsertComputed(l, di);
        d.set(h, (d.get(h) ?? 0) + 1);
      }
    }
    if ((i > 0 || s > 0) && (t ||= /* @__PURE__ */ Object.create(null), t.comments = {
      deleted: i,
      edited: s
    }), !t)
      return null;
    for (const [n, r] of e)
      t[n] = r.computeTelemetryFinalData(t[n]);
    return t;
  }
  resetModifiedIds() {
    this.#e = null;
  }
  updateEditor(t, e) {
    const s = this.#s?.get(t);
    return s ? (s.updateFromAnnotationLayer(e), !0) : !1;
  }
  getEditor(t) {
    return this.#s?.get(t) || null;
  }
  get modifiedIds() {
    if (this.#e)
      return this.#e;
    const t = [];
    if (this.#s)
      for (const s of this.#s.values())
        s.serialize() && t.push(s.annotationElementId);
    let e = "";
    if (t.length) {
      const s = new ni();
      s.update(t.join(",")), e = s.hexdigest();
    }
    return this.#e = {
      ids: new Set(t),
      hash: e
    };
  }
  [Symbol.iterator]() {
    return this.#i.entries();
  }
}
class Pn extends vi {
  #t = Qe;
  constructor(t) {
    super();
    const {
      serializable: e
    } = t;
    if (e === Qe)
      return;
    const {
      map: s,
      hash: i,
      transfer: n
    } = e, r = structuredClone(s, n ? {
      transfer: n
    } : null);
    this.#t = {
      map: r,
      hash: i,
      transfer: []
    };
  }
  get print() {
    st("Should not call PrintAnnotationStorage.print");
  }
  get serializable() {
    return this.#t;
  }
  get modifiedIds() {
    return j(this, "modifiedIds", {
      ids: /* @__PURE__ */ new Set(),
      hash: ""
    });
  }
}
K(7588);
const Pe = "__forcedDependency", {
  floor: Ki,
  ceil: Ji
} = Math;
function Qi(c, t, e, s, i, n) {
  c[t * 4 + 0] = Math.min(c[t * 4 + 0], e), c[t * 4 + 1] = Math.min(c[t * 4 + 1], s), c[t * 4 + 2] = Math.max(c[t * 4 + 2], i), c[t * 4 + 3] = Math.max(c[t * 4 + 3], n);
}
function Pr(c, t, e, s, i) {
  let n;
  c ? (c < 0 && (n = i[0], i[0] = i[2], i[2] = n), i[0] *= c, i[2] *= c, t < 0 && (n = i[1], i[1] = i[3], i[3] = n), i[1] *= t, i[3] *= t) : i.fill(0), i[0] += e, i[1] += s, i[2] += e, i[3] += s;
}
const ri = new Uint32Array(new Uint8Array([255, 255, 0, 0]).buffer)[0];
class Ir {
  #t;
  #e;
  constructor(t, e) {
    this.#t = t, this.#e = e;
  }
  get length() {
    return this.#t.length;
  }
  isEmpty(t) {
    return this.#t[t] === ri;
  }
  minX(t) {
    return this.#e[t * 4 + 0] / 256;
  }
  minY(t) {
    return this.#e[t * 4 + 1] / 256;
  }
  maxX(t) {
    return (this.#e[t * 4 + 2] + 1) / 256;
  }
  maxY(t) {
    return (this.#e[t * 4 + 3] + 1) / 256;
  }
}
const Zi = (c, t) => c?.getOrInsertComputed(t, () => ({
  dependencies: /* @__PURE__ */ new Set(),
  isRenderingOperation: !1
}));
class Or {
  #t = [[1, 0, 0, 1, 0, 0]];
  #e = [-1 / 0, -1 / 0, 1 / 0, 1 / 0];
  #s = new Float64Array(oe);
  _pendingBBoxIdx = -1;
  #i;
  #n;
  #a;
  #r;
  _savesStack = [];
  _markedContentStack = [];
  constructor(t, e) {
    this.#i = t.width, this.#n = t.height, this.#o(e);
  }
  growOperationsCount(t) {
    t >= this.#r.length && this.#o(t, this.#r);
  }
  #o(t, e) {
    const s = new ArrayBuffer(t * 4);
    this.#a = new Uint8ClampedArray(s), this.#r = new Uint32Array(s), e && e.length > 0 ? (this.#r.set(e), this.#r.fill(ri, e.length)) : this.#r.fill(ri);
  }
  get clipBox() {
    return this.#e;
  }
  save(t) {
    return this.#e = {
      __proto__: this.#e
    }, this._savesStack.push(t), this;
  }
  restore(t, e) {
    const s = Object.getPrototypeOf(this.#e);
    if (s === null)
      return this;
    this.#e = s;
    const i = this._savesStack.pop();
    return i !== void 0 && (e?.(i, t), this.#r[t] = this.#r[i]), this;
  }
  recordOpenMarker(t) {
    return this._savesStack.push(t), this;
  }
  getOpenMarker() {
    return this._savesStack.length === 0 ? null : this._savesStack.at(-1);
  }
  recordCloseMarker(t, e) {
    const s = this._savesStack.pop();
    return s !== void 0 && (e?.(s, t), this.#r[t] = this.#r[s]), this;
  }
  beginMarkedContent(t) {
    return this._markedContentStack.push(t), this;
  }
  endMarkedContent(t, e) {
    const s = this._markedContentStack.pop();
    return s !== void 0 && (e?.(s, t), this.#r[t] = this.#r[s]), this;
  }
  pushBaseTransform(t) {
    return this.#t.push(N.multiplyByDOMMatrix(this.#t.at(-1), t.getTransform())), this;
  }
  popBaseTransform() {
    return this.#t.length > 1 && this.#t.pop(), this;
  }
  resetBBox(t) {
    return this._pendingBBoxIdx !== t && (this._pendingBBoxIdx = t, this.#s.set(oe, 0)), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    const a = N.multiplyByDOMMatrix(this.#t.at(-1), e.getTransform()), o = oe.slice();
    N.axialAlignedBoundingBox([s, n, i, r], a, o);
    const l = N.intersect(this.#e, o);
    return l ? (this.#e[0] = l[0], this.#e[1] = l[1], this.#e[2] = l[2], this.#e[3] = l[3]) : (this.#e[0] = this.#e[1] = 1 / 0, this.#e[2] = this.#e[3] = -1 / 0), this;
  }
  recordBBox(t, e, s, i, n, r) {
    const a = this.#e;
    if (a[0] === 1 / 0)
      return this;
    const o = N.multiplyByDOMMatrix(this.#t.at(-1), e.getTransform());
    if (a[0] === -1 / 0)
      return N.axialAlignedBoundingBox([s, n, i, r], o, this.#s), this;
    const l = oe.slice();
    return N.axialAlignedBoundingBox([s, n, i, r], o, l), this.#s[0] = ct(l[0], a[0], this.#s[0]), this.#s[1] = ct(l[1], a[1], this.#s[1]), this.#s[2] = ct(l[2], this.#s[2], a[2]), this.#s[3] = ct(l[3], this.#s[3], a[3]), this;
  }
  recordFullPageBBox(t) {
    return this.#s[0] = Math.max(0, this.#e[0]), this.#s[1] = Math.max(0, this.#e[1]), this.#s[2] = Math.min(this.#i, this.#e[2]), this.#s[3] = Math.min(this.#n, this.#e[3]), this;
  }
  recordOperation(t, e = !1, s) {
    if (this._pendingBBoxIdx !== t)
      return this;
    const i = Ki(this.#s[0] * 256 / this.#i), n = Ki(this.#s[1] * 256 / this.#n), r = Ji(this.#s[2] * 256 / this.#i), a = Ji(this.#s[3] * 256 / this.#n);
    if (Qi(this.#a, t, i, n, r, a), s)
      for (const o of s)
        for (const l of o)
          l !== t && Qi(this.#a, l, i, n, r, a);
    return e || (this._pendingBBoxIdx = -1), this;
  }
  bboxToClipBoxDropOperation(t) {
    return this._pendingBBoxIdx === t && (this._pendingBBoxIdx = -1, this.#e[0] = Math.max(this.#e[0], this.#s[0]), this.#e[1] = Math.max(this.#e[1], this.#s[1]), this.#e[2] = Math.min(this.#e[2], this.#s[2]), this.#e[3] = Math.min(this.#e[3], this.#s[3])), this;
  }
  take() {
    return new Ir(this.#r, this.#a);
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
  recordSimpleData(t, e) {
    return this;
  }
  recordIncrementalData(t, e) {
    return this;
  }
  resetIncrementalData(t, e) {
    return this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return this;
  }
  recordFutureForcedDependency(t, e) {
    return this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return this;
  }
  recordCharacterBBox(t, e, s, i = 1, n = 0, r = 0, a) {
    return this;
  }
  getSimpleIndex(t) {
  }
  recordDependencies(t, e) {
    return this;
  }
  recordNamedDependency(t, e) {
    return this;
  }
  recordShowTextOperation(t, e = !1) {
    return this;
  }
}
class Mr {
  #t = {
    __proto__: null
  };
  #e = {
    __proto__: null,
    transform: [],
    moveText: [],
    sameLineText: [],
    [Pe]: []
  };
  #s = /* @__PURE__ */ new Map();
  #i = /* @__PURE__ */ new Set();
  #n = /* @__PURE__ */ new Map();
  #a;
  #r;
  #o;
  constructor(t, e = !1) {
    this.#o = t, e && (this.#a = /* @__PURE__ */ new Map(), this.#r = (s, i) => {
      Zi(this.#a, i).dependencies.add(s);
    });
  }
  get clipBox() {
    return this.#o.clipBox;
  }
  growOperationsCount(t) {
    this.#o.growOperationsCount(t);
  }
  save(t) {
    return this.#t = {
      __proto__: this.#t
    }, this.#e = {
      __proto__: this.#e,
      transform: {
        __proto__: this.#e.transform
      },
      moveText: {
        __proto__: this.#e.moveText
      },
      sameLineText: {
        __proto__: this.#e.sameLineText
      },
      [Pe]: {
        __proto__: this.#e[Pe]
      }
    }, this.#o.save(t), this;
  }
  restore(t) {
    this.#o.restore(t, this.#r);
    const e = Object.getPrototypeOf(this.#t);
    return e === null ? this : (this.#t = e, this.#e = Object.getPrototypeOf(this.#e), this);
  }
  recordOpenMarker(t) {
    return this.#o.recordOpenMarker(t, this.#r), this;
  }
  getOpenMarker() {
    return this.#o.getOpenMarker();
  }
  recordCloseMarker(t) {
    return this.#o.recordCloseMarker(t, this.#r), this;
  }
  beginMarkedContent(t) {
    return this.#o.beginMarkedContent(t), this;
  }
  endMarkedContent(t) {
    return this.#o.endMarkedContent(t, this.#r), this;
  }
  pushBaseTransform(t) {
    return this.#o.pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return this.#o.popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return this.#t[t] = e, this;
  }
  recordIncrementalData(t, e) {
    return this.#e[t].push(e), this;
  }
  resetIncrementalData(t, e) {
    return this.#e[t].length = 0, this;
  }
  recordNamedData(t, e) {
    return this.#s.set(t, e), this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    this.#t[t] = this.#s.get(e) ?? s;
  }
  recordFutureForcedDependency(t, e) {
    return this.recordIncrementalData(Pe, e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    for (const e of t)
      e in this.#t && this.recordFutureForcedDependency(e, this.#t[e]);
    return this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    for (const t of this.#i)
      this.recordFutureForcedDependency(Pe, t);
    return this;
  }
  resetBBox(t) {
    return this.#o.resetBBox(t), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    return this.#o.recordClipBox(t, e, s, i, n, r), this;
  }
  recordBBox(t, e, s, i, n, r) {
    return this.#o.recordBBox(t, e, s, i, n, r), this;
  }
  recordCharacterBBox(t, e, s, i = 1, n = 0, r = 0, a) {
    const o = s.bbox;
    let l, h;
    if (o && (l = o[2] !== o[0] && o[3] !== o[1] && this.#n.get(s), l !== !1 && (h = [0, 0, 0, 0], N.axialAlignedBoundingBox(o, s.fontMatrix, h), (i !== 1 || n !== 0 || r !== 0) && Pr(i, -i, n, r, h), l)))
      return this.recordBBox(t, e, h[0], h[2], h[1], h[3]);
    if (!a)
      return this.recordFullPageBBox(t);
    const d = a();
    return o && h && l === void 0 && (l = h[0] <= n - d.actualBoundingBoxLeft && h[2] >= n + d.actualBoundingBoxRight && h[1] <= r - d.actualBoundingBoxAscent && h[3] >= r + d.actualBoundingBoxDescent, this.#n.set(s, l), l) ? this.recordBBox(t, e, h[0], h[2], h[1], h[3]) : this.recordBBox(t, e, n - d.actualBoundingBoxLeft, n + d.actualBoundingBoxRight, r - d.actualBoundingBoxAscent, r + d.actualBoundingBoxDescent);
  }
  recordFullPageBBox(t) {
    return this.#o.recordFullPageBBox(t), this;
  }
  getSimpleIndex(t) {
    return this.#t[t];
  }
  recordDependencies(t, e) {
    const s = this.#i, i = this.#t, n = this.#e;
    for (const r of e)
      r in this.#t ? s.add(i[r]) : r in n && n[r].forEach(s.add, s);
    return this;
  }
  recordNamedDependency(t, e) {
    return this.#s.has(e) && this.#i.add(this.#s.get(e)), this;
  }
  recordOperation(t, e = !1) {
    if (this.recordDependencies(t, [Pe]), this.#a) {
      const i = Zi(this.#a, t), {
        dependencies: n
      } = i;
      this.#i.forEach(n.add, n), this.#o._savesStack.forEach(n.add, n), this.#o._markedContentStack.forEach(n.add, n), n.delete(t), i.isRenderingOperation = !0;
    }
    const s = !e && t === this.#o._pendingBBoxIdx;
    return this.#o.recordOperation(t, e, [this.#i, this.#o._savesStack, this.#o._markedContentStack]), s && this.#i.clear(), this;
  }
  recordShowTextOperation(t, e = !1) {
    const s = Array.from(this.#i);
    this.recordOperation(t, e), this.recordIncrementalData("sameLineText", t);
    for (const i of s)
      this.recordIncrementalData("sameLineText", i);
    return this;
  }
  bboxToClipBoxDropOperation(t, e = !1) {
    const s = !e && t === this.#o._pendingBBoxIdx;
    return this.#o.bboxToClipBoxDropOperation(t), s && this.#i.clear(), this;
  }
  take() {
    return this.#n.clear(), this.#o.take();
  }
  takeDebugMetadata() {
    return this.#a;
  }
}
class Ze {
  #t;
  #e;
  #s;
  #i = 0;
  #n = 0;
  constructor(t, e, s) {
    if (t instanceof Ze && t.#s === !!s)
      return t;
    this.#t = t, this.#e = e, this.#s = !!s;
  }
  get clipBox() {
    return this.#t.clipBox;
  }
  growOperationsCount() {
    throw new Error("Unreachable");
  }
  save(t) {
    return this.#n++, this.#t.save(this.#e), this;
  }
  restore(t) {
    return this.#n > 0 && (this.#t.restore(this.#e), this.#n--), this;
  }
  recordOpenMarker(t) {
    return this.#i++, this;
  }
  getOpenMarker() {
    return this.#i > 0 ? this.#e : this.#t.getOpenMarker();
  }
  recordCloseMarker(t) {
    return this.#i--, this;
  }
  beginMarkedContent(t) {
    return this;
  }
  endMarkedContent(t) {
    return this;
  }
  pushBaseTransform(t) {
    return this.#t.pushBaseTransform(t), this;
  }
  popBaseTransform() {
    return this.#t.popBaseTransform(), this;
  }
  recordSimpleData(t, e) {
    return this.#t.recordSimpleData(t, this.#e), this;
  }
  recordIncrementalData(t, e) {
    return this.#t.recordIncrementalData(t, this.#e), this;
  }
  resetIncrementalData(t, e) {
    return this.#t.resetIncrementalData(t, this.#e), this;
  }
  recordNamedData(t, e) {
    return this;
  }
  recordSimpleDataFromNamed(t, e, s) {
    return this.#t.recordSimpleDataFromNamed(t, e, this.#e), this;
  }
  recordFutureForcedDependency(t, e) {
    return this.#t.recordFutureForcedDependency(t, this.#e), this;
  }
  inheritSimpleDataAsFutureForcedDependencies(t) {
    return this.#t.inheritSimpleDataAsFutureForcedDependencies(t), this;
  }
  inheritPendingDependenciesAsFutureForcedDependencies() {
    return this.#t.inheritPendingDependenciesAsFutureForcedDependencies(), this;
  }
  resetBBox(t) {
    return this.#s || this.#t.resetBBox(this.#e), this;
  }
  recordClipBox(t, e, s, i, n, r) {
    return this.#s || this.#t.recordClipBox(this.#e, e, s, i, n, r), this;
  }
  recordBBox(t, e, s, i, n, r) {
    return this.#s || this.#t.recordBBox(this.#e, e, s, i, n, r), this;
  }
  recordCharacterBBox(t, e, s, i, n, r, a) {
    return this.#s || this.#t.recordCharacterBBox(this.#e, e, s, i, n, r, a), this;
  }
  recordFullPageBBox(t) {
    return this.#s || this.#t.recordFullPageBBox(this.#e), this;
  }
  getSimpleIndex(t) {
    return this.#t.getSimpleIndex(t);
  }
  recordDependencies(t, e) {
    return this.#t.recordDependencies(this.#e, e), this;
  }
  recordNamedDependency(t, e) {
    return this.#t.recordNamedDependency(this.#e, e), this;
  }
  recordOperation(t) {
    return this.#t.recordOperation(this.#e, !0), this;
  }
  recordShowTextOperation(t) {
    return this.#t.recordShowTextOperation(this.#e, !0), this;
  }
  bboxToClipBoxDropOperation(t) {
    return this.#s || this.#t.bboxToClipBoxDropOperation(this.#e, !0), this;
  }
  take() {
    throw new Error("Unreachable");
  }
  takeDebugMetadata() {
    throw new Error("Unreachable");
  }
}
const jt = {
  stroke: ["path", "transform", "filter", "strokeColor", "strokeAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "dash"],
  fill: ["path", "transform", "filter", "fillColor", "fillAlpha", "globalCompositeOperation", "SMask"],
  imageXObject: ["transform", "SMask", "filter", "fillAlpha", "strokeAlpha", "globalCompositeOperation"],
  rawFillPath: ["filter", "fillColor", "fillAlpha"],
  showText: ["transform", "leading", "charSpacing", "wordSpacing", "hScale", "textRise", "moveText", "textMatrix", "font", "fontObj", "filter", "fillColor", "textRenderingMode", "SMask", "fillAlpha", "strokeAlpha", "globalCompositeOperation", "sameLineText"],
  transform: ["transform"],
  transformAndFill: ["transform", "fillColor"]
};
class As {
  #t;
  #e;
  #s = 4;
  #i = 0;
  #n = new As.#a(this.#s * 6);
  static #a = at.isFloat16ArraySupported ? Float16Array : Float32Array;
  constructor(t) {
    this.#t = t.width, this.#e = t.height;
  }
  record(t, e, s, i) {
    if (this.#i === this.#s) {
      this.#s *= 2;
      const a = new As.#a(this.#s * 6);
      a.set(this.#n), this.#n = a;
    }
    const n = ht(t);
    let r;
    if (i[0] !== 1 / 0) {
      const a = oe.slice();
      N.axialAlignedBoundingBox([0, -s, e, 0], n, a);
      const o = N.intersect(i, a);
      if (!o)
        return;
      const [l, h, d, u] = o;
      if (l !== a[0] || h !== a[1] || d !== a[2] || u !== a[3]) {
        const f = Math.atan2(n[1], n[0]), p = Math.abs(Math.sin(f)), g = Math.abs(Math.cos(f));
        if (p < 1e-6 || g < 1e-6 || Math.abs(p - g) < 1e-6)
          r = [l, h, l, u, d, h];
        else {
          const m = d - l, v = u - h, y = p * p, b = g * g, w = g * p, A = b - y, S = (v * b - m * w) / A, E = (v * w - m * y) / A;
          r = [l + E, h, l, h + S, d, u - S];
        }
      }
    }
    r || (r = [0, -s, 0, 0, e, -s], N.applyTransform(r, n, 0), N.applyTransform(r, n, 2), N.applyTransform(r, n, 4)), r[0] /= this.#t, r[1] /= this.#e, r[2] /= this.#t, r[3] /= this.#e, r[4] /= this.#t, r[5] /= this.#e, this.#n.set(r, this.#i * 6), this.#i++;
  }
  take() {
    return this.#n.subarray(0, this.#i * 6);
  }
}
const qi = new RegExp("\\p{Cc}", "u");
function Rr(c) {
  const t = c[0];
  if (c.length < 2 || t !== '"' && t !== "'" || c.at(-1) !== t)
    return !1;
  const e = c.length - 1;
  for (let s = 1; s < e; s++) {
    const i = c[s];
    if (i === t || qi.test(i) || i === "\\" && (++s >= e || qi.test(c[s])))
      return !1;
  }
  return !0;
}
function tn(c) {
  return Rr(c) ? c : `"${c.replaceAll(/["\\\p{Cc}]/gu, (e) => e === '"' || e === "\\" ? `\\${e}` : `\\${e.codePointAt(0).toString(16)} `)}"`;
}
class Dr {
  #t = /* @__PURE__ */ new Set();
  #e = null;
  constructor({
    ownerDocument: t = globalThis.document,
    styleElement: e = null
  }) {
    this._document = t, this.nativeFontFaces = /* @__PURE__ */ new Set(), this.styleElement = null, this.loadingRequests = [], this.loadTestFontId = 0;
  }
  addNativeFontFace(t) {
    this.nativeFontFaces.add(t), this._document.fonts.add(t);
  }
  removeNativeFontFace(t) {
    this.nativeFontFaces.delete(t), this._document.fonts.delete(t);
  }
  insertRule(t) {
    const e = this.#s();
    e.insertRule(t, e.cssRules.length);
  }
  #s() {
    if (this.#e)
      return this.#e;
    const t = this._document.defaultView?.CSSStyleSheet || globalThis.CSSStyleSheet;
    if (!this.styleElement && t) {
      const {
        adoptedStyleSheets: e
      } = this._document;
      if (e) {
        const s = new t();
        return e.push(s), this.#e = s;
      }
    }
    return this.styleElement || (this.styleElement = this._document.createElement("style"), this._document.documentElement.getElementsByTagName("head")[0].append(this.styleElement)), this.#e = this.styleElement.sheet;
  }
  clear() {
    for (const t of this.nativeFontFaces)
      this._document.fonts.delete(t);
    if (this.nativeFontFaces.clear(), this.#t.clear(), this.#e) {
      const {
        adoptedStyleSheets: t
      } = this._document;
      t?.includes(this.#e) && (this._document.adoptedStyleSheets = t.filter((e) => e !== this.#e)), this.#e = null;
    }
    this.styleElement && (this.styleElement.remove(), this.styleElement = null);
  }
  async loadSystemFont({
    systemFontInfo: t,
    disableFontFace: e,
    _inspectFont: s
  }) {
    if (!(!t || this.#t.has(t.loadedName))) {
      if (gt(!e, "loadSystemFont shouldn't be called when `disableFontFace` is set."), this.isFontLoadingAPISupported) {
        const {
          loadedName: i,
          src: n,
          style: r
        } = t, a = new FontFace(i, n, r);
        this.addNativeFontFace(a);
        try {
          await a.load(), this.#t.add(i), s?.(t);
        } catch {
          V(`Cannot load system font: ${t.baseFontName}, installing it could help to improve PDF rendering.`), this.removeNativeFontFace(a);
        }
        return;
      }
      st("Not implemented: loadSystemFont without the Font Loading API.");
    }
  }
  async bind(t) {
    if (t.attached || t.missingFile && !t.systemFontInfo)
      return;
    if (t.attached = !0, t.systemFontInfo) {
      await this.loadSystemFont(t);
      return;
    }
    if (this.isFontLoadingAPISupported) {
      const s = t.createNativeFontFace();
      if (s) {
        this.addNativeFontFace(s);
        try {
          await s.loaded;
        } catch (i) {
          throw V(`Failed to load font '${s.family}': '${i}'.`), t.disableFontFace = !0, i;
        }
      }
      return;
    }
    const e = t.createFontFaceRule();
    if (e) {
      if (this.insertRule(e), this.isSyncFontLoadingSupported)
        return;
      await new Promise((s) => {
        const i = this._queueLoadingCallback(s);
        this._prepareFontLoadEvent(t, i);
      });
    }
  }
  get isFontLoadingAPISupported() {
    const t = !!this._document?.fonts;
    return j(this, "isFontLoadingAPISupported", t);
  }
  get isSyncFontLoadingSupported() {
    return j(this, "isSyncFontLoadingSupported", Bt || at.platform.isFirefox);
  }
  _queueLoadingCallback(t) {
    function e() {
      for (gt(!i.done, "completeRequest() cannot be called twice."), i.done = !0; s.length > 0 && s[0].done; ) {
        const n = s.shift();
        setTimeout(n.callback, 0);
      }
    }
    const {
      loadingRequests: s
    } = this, i = {
      done: !1,
      complete: e,
      callback: t
    };
    return s.push(i), i;
  }
  get _loadTestFont() {
    const t = atob("T1RUTwALAIAAAwAwQ0ZGIDHtZg4AAAOYAAAAgUZGVE1lkzZwAAAEHAAAABxHREVGABQAFQAABDgAAAAeT1MvMlYNYwkAAAEgAAAAYGNtYXABDQLUAAACNAAAAUJoZWFk/xVFDQAAALwAAAA2aGhlYQdkA+oAAAD0AAAAJGhtdHgD6AAAAAAEWAAAAAZtYXhwAAJQAAAAARgAAAAGbmFtZVjmdH4AAAGAAAAAsXBvc3T/hgAzAAADeAAAACAAAQAAAAEAALZRFsRfDzz1AAsD6AAAAADOBOTLAAAAAM4KHDwAAAAAA+gDIQAAAAgAAgAAAAAAAAABAAADIQAAAFoD6AAAAAAD6AABAAAAAAAAAAAAAAAAAAAAAQAAUAAAAgAAAAQD6AH0AAUAAAKKArwAAACMAooCvAAAAeAAMQECAAACAAYJAAAAAAAAAAAAAQAAAAAAAAAAAAAAAFBmRWQAwAAuAC4DIP84AFoDIQAAAAAAAQAAAAAAAAAAACAAIAABAAAADgCuAAEAAAAAAAAAAQAAAAEAAAAAAAEAAQAAAAEAAAAAAAIAAQAAAAEAAAAAAAMAAQAAAAEAAAAAAAQAAQAAAAEAAAAAAAUAAQAAAAEAAAAAAAYAAQAAAAMAAQQJAAAAAgABAAMAAQQJAAEAAgABAAMAAQQJAAIAAgABAAMAAQQJAAMAAgABAAMAAQQJAAQAAgABAAMAAQQJAAUAAgABAAMAAQQJAAYAAgABWABYAAAAAAAAAwAAAAMAAAAcAAEAAAAAADwAAwABAAAAHAAEACAAAAAEAAQAAQAAAC7//wAAAC7////TAAEAAAAAAAABBgAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAMAAAAAAAD/gwAyAAAAAQAAAAAAAAAAAAAAAAAAAAABAAQEAAEBAQJYAAEBASH4DwD4GwHEAvgcA/gXBIwMAYuL+nz5tQXkD5j3CBLnEQACAQEBIVhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYWFhYAAABAQAADwACAQEEE/t3Dov6fAH6fAT+fPp8+nwHDosMCvm1Cvm1DAz6fBQAAAAAAAABAAAAAMmJbzEAAAAAzgTjFQAAAADOBOQpAAEAAAAAAAAADAAUAAQAAAABAAAAAgABAAAAAAAAAAAD6AAAAAAAAA==");
    return j(this, "_loadTestFont", t);
  }
  _prepareFontLoadEvent(t, e) {
    function s(A, S) {
      return A.charCodeAt(S) << 24 | A.charCodeAt(S + 1) << 16 | A.charCodeAt(S + 2) << 8 | A.charCodeAt(S + 3) & 255;
    }
    function i(A) {
      return String.fromCharCode(A >> 24 & 255, A >> 16 & 255, A >> 8 & 255, A & 255);
    }
    function n(A, S, E, T) {
      const x = A.substring(0, S), P = A.substring(S + E);
      return x + T + P;
    }
    let r, a;
    const o = this._document.createElement("canvas");
    o.width = 1, o.height = 1;
    const l = o.getContext("2d");
    let h = 0;
    function d(A, S) {
      if (++h > 30) {
        V("Load test font never loaded."), S();
        return;
      }
      if (l.font = "30px " + A, l.fillText(".", 0, 20), l.getImageData(0, 0, 1, 1).data[3] > 0) {
        S();
        return;
      }
      setTimeout(d.bind(null, A, S));
    }
    const u = `lt${Date.now()}${this.loadTestFontId++}`;
    let f = this._loadTestFont;
    f = n(f, 976, u.length, u);
    const g = 16, m = 1482184792;
    let v = s(f, g);
    for (r = 0, a = u.length - 3; r < a; r += 4)
      v = v - m + s(u, r) | 0;
    r < u.length && (v = v - m + s(u + "XXX", r) | 0), f = n(f, g, 4, i(v));
    const y = `url(data:font/opentype;base64,${btoa(f)});`, b = `@font-face {font-family:"${u}";src:${y}}`;
    this.insertRule(b);
    const w = this._document.createElement("div");
    w.style.visibility = "hidden", w.style.width = w.style.height = "10px", w.style.position = "absolute", w.style.top = w.style.left = "0px";
    for (const A of [t.loadedName, u]) {
      const S = this._document.createElement("span");
      S.textContent = "Hi", S.style.fontFamily = A, w.append(S);
    }
    this._document.body.append(w), d(u, () => {
      w.remove(), e.complete();
    });
  }
}
class kr {
  compiledGlyphs = /* @__PURE__ */ Object.create(null);
  #t;
  constructor(t, e = null, s, i) {
    this.#t = t, this._inspectFont = e, s && (this.charProcOperatorList = s), i && Object.assign(this, i);
  }
  createNativeFontFace() {
    if (!this.data || this.disableFontFace)
      return null;
    let t;
    if (!this.cssFontInfo)
      t = new FontFace(this.loadedName, this.data, {});
    else {
      const e = {
        weight: this.cssFontInfo.fontWeight
      };
      this.cssFontInfo.italicAngle && (e.style = `oblique ${this.cssFontInfo.italicAngle}deg`), t = new FontFace(tn(this.cssFontInfo.fontFamily), this.data, e);
    }
    return this._inspectFont?.(this), t;
  }
  createFontFaceRule() {
    if (!this.data || this.disableFontFace)
      return null;
    const t = `url(data:${this.mimetype};base64,${this.data.toBase64()});`;
    let e;
    if (!this.cssFontInfo)
      e = `@font-face {font-family:"${this.loadedName}";src:${t}}`;
    else {
      let s = `font-weight: ${this.cssFontInfo.fontWeight};`;
      this.cssFontInfo.italicAngle && (s += `font-style: oblique ${this.cssFontInfo.italicAngle}deg;`), e = `@font-face {font-family:${tn(this.cssFontInfo.fontFamily)};${s}src:${t}}`;
    }
    return this._inspectFont?.(this, t), e;
  }
  getPathGenerator(t, e) {
    if (this.compiledGlyphs[e] !== void 0)
      return this.compiledGlyphs[e];
    const s = this.loadedName + "_path_" + e;
    let i;
    try {
      i = t.get(s);
    } catch (r) {
      V(`getPathGenerator - ignoring character: "${r}".`);
    }
    const n = xn(i?.path);
    return this.fontExtraProperties || t.delete(s), this.compiledGlyphs[e] = n;
  }
  get black() {
    return this.#t.black;
  }
  get bold() {
    return this.#t.bold;
  }
  get disableFontFace() {
    return this.#t.disableFontFace;
  }
  set disableFontFace(t) {
    j(this, "disableFontFace", !!t);
  }
  get fontExtraProperties() {
    return this.#t.fontExtraProperties;
  }
  get isInvalidPDFjsFont() {
    return this.#t.isInvalidPDFjsFont;
  }
  get isType3Font() {
    return this.#t.isType3Font;
  }
  get italic() {
    return this.#t.italic;
  }
  get missingFile() {
    return this.#t.missingFile;
  }
  get remeasure() {
    return this.#t.remeasure;
  }
  get vertical() {
    return this.#t.vertical;
  }
  get ascent() {
    return this.#t.ascent;
  }
  get defaultWidth() {
    return this.#t.defaultWidth;
  }
  get descent() {
    return this.#t.descent;
  }
  get bbox() {
    return this.#t.bbox;
  }
  get fontMatrix() {
    return this.#t.fontMatrix;
  }
  get fallbackName() {
    return this.#t.fallbackName;
  }
  get loadedName() {
    return this.#t.loadedName;
  }
  get mimetype() {
    return this.#t.mimetype;
  }
  get name() {
    return this.#t.name;
  }
  get data() {
    return this.#t.data;
  }
  clearData() {
    this.#t.clearData();
  }
  get cssFontInfo() {
    return this.#t.cssFontInfo;
  }
  get systemFontInfo() {
    return this.#t.systemFontInfo;
  }
  get defaultVMetrics() {
    return this.#t.defaultVMetrics;
  }
}
class Nr {
  static strings = ["fontFamily", "fontWeight", "italicAngle"];
}
class Fr {
  static strings = ["css", "loadedName", "baseFontName", "src"];
}
class zt {
  static bools = ["black", "bold", "disableFontFace", "fontExtraProperties", "isInvalidPDFjsFont", "isType3Font", "italic", "missingFile", "remeasure", "vertical"];
  static numbers = ["ascent", "defaultWidth", "descent"];
  static strings = ["fallbackName", "loadedName", "mimetype", "name"];
  static OFFSET_NUMBERS = Math.ceil(this.bools.length * 2 / 8);
  static OFFSET_BBOX = this.OFFSET_NUMBERS + this.numbers.length * 8;
  static OFFSET_FONT_MATRIX = this.OFFSET_BBOX + 1 + 8;
  static OFFSET_DEFAULT_VMETRICS = this.OFFSET_FONT_MATRIX + 1 + 48;
  static OFFSET_STRINGS = this.OFFSET_DEFAULT_VMETRICS + 1 + 6;
}
class ue {
  static KIND = 0;
  static HAS_BBOX = 1;
  static HAS_BACKGROUND = 2;
  static SHADING_TYPE = 3;
  static N_COORD = 4;
  static N_COLOR = 8;
  static N_STOP = 12;
  static N_FIGURES = 16;
}
class Ss {
  static get decoder() {
    return j(this, "decoder", new TextDecoder());
  }
  static get encoder() {
    return j(this, "encoder", new TextEncoder());
  }
}
class Lr {
  #t;
  #e;
  constructor(t) {
    this.#t = t, this.#e = new DataView(t);
  }
  #s(t) {
    gt(t < Nr.strings.length, "Invalid string index");
    const {
      decoder: e
    } = Ss;
    let s = 0;
    for (let n = 0; n < t; n++)
      s += this.#e.getUint32(s) + 4;
    const i = this.#e.getUint32(s);
    return e.decode(new Uint8Array(this.#t, s + 4, i));
  }
  get fontFamily() {
    return this.#s(0);
  }
  get fontWeight() {
    return this.#s(1);
  }
  get italicAngle() {
    return this.#s(2);
  }
}
class Br {
  #t;
  #e;
  constructor(t) {
    this.#t = t, this.#e = new DataView(t);
  }
  get guessFallback() {
    return this.#e.getUint8(0) !== 0;
  }
  #s(t) {
    gt(t < Fr.strings.length, "Invalid string index");
    const {
      decoder: e
    } = Ss;
    let s = 5;
    for (let n = 0; n < t; n++)
      s += this.#e.getUint32(s) + 4;
    const i = this.#e.getUint32(s);
    return e.decode(new Uint8Array(this.#t, s + 4, i));
  }
  get css() {
    return this.#s(0);
  }
  get loadedName() {
    return this.#s(1);
  }
  get baseFontName() {
    return this.#s(2);
  }
  get src() {
    return this.#s(3);
  }
  get style() {
    const {
      decoder: t
    } = Ss;
    let e = 1;
    e += 4 + this.#e.getUint32(e);
    const s = this.#e.getUint32(e), i = t.decode(new Uint8Array(this.#t, e + 4, s));
    e += 4 + s;
    const n = this.#e.getUint32(e), r = t.decode(new Uint8Array(this.#t, e + 4, n));
    return {
      style: i,
      weight: r
    };
  }
}
class _r {
  #t;
  #e;
  constructor({
    buffer: t,
    extra: e
  }) {
    this.#t = t, this.#e = new DataView(t), e && Object.assign(this, e);
  }
  #s(t) {
    gt(t < zt.bools.length, "Invalid boolean index");
    const e = Math.floor(t / 4), s = t * 2 % 8, i = this.#e.getUint8(e) >> s & 3;
    return i === 0 ? void 0 : i === 2;
  }
  get black() {
    return this.#s(0);
  }
  get bold() {
    return this.#s(1);
  }
  get disableFontFace() {
    return this.#s(2);
  }
  get fontExtraProperties() {
    return this.#s(3);
  }
  get isInvalidPDFjsFont() {
    return this.#s(4);
  }
  get isType3Font() {
    return this.#s(5);
  }
  get italic() {
    return this.#s(6);
  }
  get missingFile() {
    return this.#s(7);
  }
  get remeasure() {
    return this.#s(8);
  }
  get vertical() {
    return this.#s(9);
  }
  #i(t) {
    return gt(t < zt.numbers.length, "Invalid number index"), this.#e.getFloat64(zt.OFFSET_NUMBERS + t * 8);
  }
  get ascent() {
    return this.#i(0);
  }
  get defaultWidth() {
    return this.#i(1);
  }
  get descent() {
    return this.#i(2);
  }
  #n(t, e, s, i) {
    const n = this.#e.getUint8(t);
    if (n === 0)
      return;
    gt(n === e, "Invalid array length."), t += 1;
    const r = new Array(n);
    for (let a = 0; a < n; a++)
      r[a] = this.#e[s](t, !0), t += i;
    return r;
  }
  get bbox() {
    return this.#n(zt.OFFSET_BBOX, 4, "getInt16", 2);
  }
  get fontMatrix() {
    return this.#n(zt.OFFSET_FONT_MATRIX, 6, "getFloat64", 8);
  }
  get defaultVMetrics() {
    return this.#n(zt.OFFSET_DEFAULT_VMETRICS, 3, "getInt16", 2);
  }
  #a(t) {
    gt(t < zt.strings.length, "Invalid string index");
    const {
      decoder: e
    } = Ss;
    let s = zt.OFFSET_STRINGS + 4;
    for (let n = 0; n < t; n++)
      s += this.#e.getUint32(s) + 4;
    const i = this.#e.getUint32(s);
    return e.decode(new Uint8Array(this.#t, s + 4, i));
  }
  get fallbackName() {
    return this.#a(0);
  }
  get loadedName() {
    return this.#a(1);
  }
  get mimetype() {
    return this.#a(2);
  }
  get name() {
    return this.#a(3);
  }
  #r() {
    let t = zt.OFFSET_STRINGS;
    const e = this.#e.getUint32(t);
    t += 4 + e;
    const s = this.#e.getUint32(t);
    t += 4 + s;
    const i = this.#e.getUint32(t);
    t += 4 + i;
    const n = this.#e.getUint32(t);
    return {
      offset: t,
      length: n
    };
  }
  get data() {
    const {
      offset: t,
      length: e
    } = this.#r();
    return e === 0 ? void 0 : new Uint8Array(this.#t, t + 4, e);
  }
  clearData() {
    const {
      offset: t,
      length: e
    } = this.#r();
    e !== 0 && (this.#e.setUint32(t, 0), this.#t = new Uint8Array(this.#t, 0, t + 4).slice().buffer, this.#e = new DataView(this.#t));
  }
  get cssFontInfo() {
    let t = zt.OFFSET_STRINGS;
    const e = this.#e.getUint32(t);
    t += 4 + e;
    const s = this.#e.getUint32(t);
    t += 4 + s;
    const i = this.#e.getUint32(t);
    if (i === 0)
      return null;
    const n = new Uint8Array(i);
    return n.set(new Uint8Array(this.#t, t + 4, i)), new Lr(n.buffer);
  }
  get systemFontInfo() {
    let t = zt.OFFSET_STRINGS;
    const e = this.#e.getUint32(t);
    t += 4 + e;
    const s = this.#e.getUint32(t);
    if (s === 0)
      return null;
    const i = new Uint8Array(s);
    return i.set(new Uint8Array(this.#t, t + 4, s)), new Br(i.buffer);
  }
}
class Ur {
  constructor(t) {
    this.buffer = t, this.view = new DataView(t), this.data = new Uint8Array(t);
  }
  getIR() {
    const t = this.view, e = this.data[ue.KIND], s = !!this.data[ue.HAS_BBOX], i = !!this.data[ue.HAS_BACKGROUND], n = t.getUint32(ue.N_COORD, !0), r = t.getUint32(ue.N_COLOR, !0), a = t.getUint32(ue.N_STOP, !0);
    let o = 20;
    const l = new Float32Array(this.buffer, o, n * 2);
    o += n * 8;
    const h = new Uint8Array(this.buffer, o, r * 4);
    o += r * 4;
    const d = [];
    for (let p = 0; p < a; ++p) {
      const g = t.getFloat32(o, !0);
      o += 4;
      const m = t.getUint32(o, !0);
      o += 4, d.push([g, `#${m.toString(16).padStart(6, "0")}`]);
    }
    let u = null;
    if (s) {
      u = [];
      for (let p = 0; p < 4; ++p)
        u.push(t.getFloat32(o, !0)), o += 4;
    }
    let f = null;
    if (i && (f = new Uint8Array(this.buffer, o, 3), o += 3), e === 1)
      return ["RadialAxial", "axial", u, d, Array.from(l.slice(0, 2)), Array.from(l.slice(2, 4)), null, null];
    if (e === 2)
      return ["RadialAxial", "radial", u, d, [l[0], l[1]], [l[3], l[4]], l[2], l[5]];
    if (e === 3) {
      const p = this.data[ue.SHADING_TYPE];
      let g = null;
      if (l.length > 0) {
        g = oe.slice();
        for (let m = 0, v = l.length; m < v; m += 2)
          N.pointBoundingBox(l[m], l[m + 1], g);
      }
      return ["Mesh", p, l, h, n, g, u, f];
    }
    throw new Error(`Unsupported pattern kind: ${e}`);
  }
}
class Hr {
  #t;
  constructor(t) {
    this.#t = t;
  }
  get path() {
    return at.isFloat16ArraySupported ? new Float16Array(this.#t) : new Float32Array(this.#t);
  }
}
function jr(c) {
  if (c instanceof URL)
    return c;
  if (typeof c == "string") {
    if (Bt) {
      if (/^[a-z][a-z0-9\-+.]+:/i.test(c))
        return new URL(c);
      const e = process.getBuiltinModule("url");
      return new URL(e.pathToFileURL(c));
    }
    const t = URL.parse(c, window.location);
    if (t)
      return t;
  }
  throw new Error("Invalid PDF url data: either string or URL-object is expected in the url property.");
}
function $r(c) {
  if (Bt && typeof Buffer < "u" && c instanceof Buffer)
    throw new Error("Please provide binary data as `Uint8Array`, rather than `Buffer`.");
  if (c instanceof Uint8Array && c.byteLength === c.buffer.byteLength)
    return c;
  if (typeof c == "string")
    return Is(c);
  if (c instanceof ArrayBuffer || ArrayBuffer.isView(c) || typeof c == "object" && !isNaN(c?.length))
    return new Uint8Array(c);
  throw new Error("Invalid PDF binary data: either TypedArray, string, or array-like object is expected in the data property.");
}
function os(c) {
  if (typeof c != "string")
    return null;
  if (c.endsWith("/"))
    return c;
  throw new Error(`Invalid factory url: "${c}" must include trailing slash.`);
}
const ai = (c) => typeof c == "object" && Number.isInteger(c?.num) && c.num >= 0 && Number.isInteger(c?.gen) && c.gen >= 0, Gr = (c) => typeof c == "object" && typeof c?.name == "string", Vr = dr.bind(null, ai, Gr);
class zr {
  #t = /* @__PURE__ */ new Map();
  #e = Promise.resolve();
  postMessage(t, e) {
    const s = {
      data: structuredClone(t, e ? {
        transfer: e
      } : null)
    };
    this.#e.then(() => {
      for (const [i] of this.#t)
        i.call(this, s);
    });
  }
  addEventListener(t, e, s = null) {
    let i = null;
    if (s?.signal instanceof AbortSignal) {
      const {
        signal: n
      } = s;
      if (n.aborted) {
        V("LoopbackPort - cannot use an `aborted` signal.");
        return;
      }
      const r = () => this.removeEventListener(t, e);
      i = () => n.removeEventListener("abort", r), n.addEventListener("abort", r);
    }
    this.#t.set(e, i);
  }
  removeEventListener(t, e) {
    this.#t.get(e)?.(), this.#t.delete(e);
  }
  terminate() {
    for (const [, t] of this.#t)
      t?.();
    this.#t.clear();
  }
}
K(1689);
const ls = {
  DATA: 1,
  ERROR: 2
}, bt = {
  CANCEL: 1,
  CANCEL_COMPLETE: 2,
  CLOSE: 3,
  ENQUEUE: 4,
  ERROR: 5,
  PULL: 6,
  PULL_COMPLETE: 7,
  START_COMPLETE: 8
};
function en() {
}
function kt(c) {
  if (c instanceof ce || c instanceof Zs || c instanceof Qs || c instanceof bs || c instanceof $s)
    return c;
  switch (c instanceof Error || typeof c == "object" && c !== null || st('wrapReason: Expected "reason" to be a (possibly cloned) Error.'), c.name) {
    case "AbortException":
      return new ce(c.message);
    case "InvalidPDFException":
      return new Zs(c.message);
    case "PasswordException":
      return new Qs(c.message, c.code);
    case "ResponseException":
      return new bs(c.message, c.status, c.missing);
    case "UnknownErrorException":
      return new $s(c.message, c.details);
  }
  return new $s(c.message, c.toString());
}
class Ve {
  #t = new AbortController();
  constructor(t, e, s) {
    this.sourceName = t, this.targetName = e, this.comObj = s, this.callbackId = 1, this.streamId = 1, this.streamSinks = /* @__PURE__ */ Object.create(null), this.streamControllers = /* @__PURE__ */ Object.create(null), this.callbackCapabilities = /* @__PURE__ */ Object.create(null), this.actionHandler = /* @__PURE__ */ Object.create(null), s.addEventListener("message", this.#e.bind(this), {
      signal: this.#t.signal
    });
  }
  #e({
    data: t
  }) {
    if (t.targetName !== this.sourceName)
      return;
    if (t.stream) {
      this.#i(t);
      return;
    }
    if (t.callback) {
      const s = t.callbackId, i = this.callbackCapabilities[s];
      if (!i)
        throw new Error(`Cannot resolve callback ${s}`);
      if (delete this.callbackCapabilities[s], t.callback === ls.DATA)
        i.resolve(t.data);
      else if (t.callback === ls.ERROR)
        i.reject(kt(t.reason));
      else
        throw new Error("Unexpected callback case");
      return;
    }
    const e = this.actionHandler[t.action];
    if (!e)
      throw new Error(`Unknown action from worker: ${t.action}`);
    if (t.callbackId) {
      const s = this.sourceName, i = t.sourceName, n = this.comObj;
      Promise.try(e, t.data).then(function(r) {
        n.postMessage({
          sourceName: s,
          targetName: i,
          callback: ls.DATA,
          callbackId: t.callbackId,
          data: r
        });
      }, function(r) {
        n.postMessage({
          sourceName: s,
          targetName: i,
          callback: ls.ERROR,
          callbackId: t.callbackId,
          reason: kt(r)
        });
      });
      return;
    }
    if (t.streamId) {
      this.#s(t);
      return;
    }
    e(t.data);
  }
  on(t, e) {
    const s = this.actionHandler;
    if (s[t])
      throw new Error(`There is already an actionName called "${t}"`);
    s[t] = e;
  }
  send(t, e, s) {
    this.comObj.postMessage({
      sourceName: this.sourceName,
      targetName: this.targetName,
      action: t,
      data: e
    }, s);
  }
  sendWithPromise(t, e, s) {
    const i = this.callbackId++, n = Promise.withResolvers();
    this.callbackCapabilities[i] = n;
    try {
      this.comObj.postMessage({
        sourceName: this.sourceName,
        targetName: this.targetName,
        action: t,
        callbackId: i,
        data: e
      }, s);
    } catch (r) {
      n.reject(r);
    }
    return n.promise;
  }
  sendWithStream(t, e, s, i) {
    const n = this.streamId++, r = this.sourceName, a = this.targetName, o = this.comObj;
    return new ReadableStream({
      start: (l) => {
        const h = Promise.withResolvers();
        return this.streamControllers[n] = {
          controller: l,
          startCall: h,
          pullCall: null,
          cancelCall: null,
          isClosed: !1
        }, o.postMessage({
          sourceName: r,
          targetName: a,
          action: t,
          streamId: n,
          data: e,
          desiredSize: l.desiredSize
        }, i), h.promise;
      },
      pull: (l) => {
        const h = Promise.withResolvers();
        return this.streamControllers[n].pullCall = h, o.postMessage({
          sourceName: r,
          targetName: a,
          stream: bt.PULL,
          streamId: n,
          desiredSize: l.desiredSize
        }), h.promise;
      },
      cancel: (l) => {
        gt(l instanceof Error, "cancel must have a valid reason");
        const h = Promise.withResolvers();
        return this.streamControllers[n].cancelCall = h, this.streamControllers[n].isClosed = !0, o.postMessage({
          sourceName: r,
          targetName: a,
          stream: bt.CANCEL,
          streamId: n,
          reason: kt(l)
        }), h.promise;
      }
    }, s);
  }
  #s(t) {
    const e = t.streamId, s = this.sourceName, i = t.sourceName, n = this.comObj, r = this, a = this.actionHandler[t.action], o = {
      enqueue(l, h = 1, d) {
        if (this.isCancelled)
          return;
        const u = this.desiredSize;
        this.desiredSize -= h, u > 0 && this.desiredSize <= 0 && (this.sinkCapability = Promise.withResolvers(), this.ready = this.sinkCapability.promise), n.postMessage({
          sourceName: s,
          targetName: i,
          stream: bt.ENQUEUE,
          streamId: e,
          chunk: l
        }, d);
      },
      close() {
        this.isCancelled || (this.isCancelled = !0, n.postMessage({
          sourceName: s,
          targetName: i,
          stream: bt.CLOSE,
          streamId: e
        }), delete r.streamSinks[e]);
      },
      error(l) {
        gt(l instanceof Error, "error must have a valid reason"), !this.isCancelled && (this.isCancelled = !0, n.postMessage({
          sourceName: s,
          targetName: i,
          stream: bt.ERROR,
          streamId: e,
          reason: kt(l)
        }));
      },
      sinkCapability: Promise.withResolvers(),
      onPull: null,
      onCancel: null,
      isCancelled: !1,
      desiredSize: t.desiredSize,
      ready: null
    };
    o.sinkCapability.resolve(), o.ready = o.sinkCapability.promise, this.streamSinks[e] = o, Promise.try(a, t.data, o).then(function() {
      n.postMessage({
        sourceName: s,
        targetName: i,
        stream: bt.START_COMPLETE,
        streamId: e,
        success: !0
      });
    }, function(l) {
      n.postMessage({
        sourceName: s,
        targetName: i,
        stream: bt.START_COMPLETE,
        streamId: e,
        reason: kt(l)
      });
    });
  }
  #i(t) {
    const e = t.streamId, s = this.sourceName, i = t.sourceName, n = this.comObj, r = this.streamControllers[e], a = this.streamSinks[e];
    switch (t.stream) {
      case bt.START_COMPLETE:
        t.success ? r.startCall.resolve() : r.startCall.reject(kt(t.reason));
        break;
      case bt.PULL_COMPLETE:
        t.success ? r.pullCall.resolve() : r.pullCall.reject(kt(t.reason));
        break;
      case bt.PULL:
        if (!a) {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: bt.PULL_COMPLETE,
            streamId: e,
            success: !0
          });
          break;
        }
        a.desiredSize <= 0 && t.desiredSize > 0 && a.sinkCapability.resolve(), a.desiredSize = t.desiredSize, Promise.try(a.onPull || en).then(function() {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: bt.PULL_COMPLETE,
            streamId: e,
            success: !0
          });
        }, function(l) {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: bt.PULL_COMPLETE,
            streamId: e,
            reason: kt(l)
          });
        });
        break;
      case bt.ENQUEUE:
        if (gt(r, "enqueue should have stream controller"), r.isClosed)
          break;
        r.controller.enqueue(t.chunk);
        break;
      case bt.CLOSE:
        if (gt(r, "close should have stream controller"), r.isClosed)
          break;
        r.isClosed = !0, r.controller.close(), this.#n(r, e);
        break;
      case bt.ERROR:
        gt(r, "error should have stream controller"), r.controller.error(kt(t.reason)), this.#n(r, e);
        break;
      case bt.CANCEL_COMPLETE:
        t.success ? r.cancelCall.resolve() : r.cancelCall.reject(kt(t.reason)), this.#n(r, e);
        break;
      case bt.CANCEL:
        if (!a)
          break;
        const o = kt(t.reason);
        Promise.try(a.onCancel || en, o).then(function() {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: bt.CANCEL_COMPLETE,
            streamId: e,
            success: !0
          });
        }, function(l) {
          n.postMessage({
            sourceName: s,
            targetName: i,
            stream: bt.CANCEL_COMPLETE,
            streamId: e,
            reason: kt(l)
          });
        }), a.sinkCapability.reject(o), a.isCancelled = !0, delete this.streamSinks[e];
        break;
      default:
        throw new Error("Unexpected stream case");
    }
  }
  async #n(t, e) {
    await Promise.allSettled([t.startCall?.promise, t.pullCall?.promise, t.cancelCall?.promise]), delete this.streamControllers[e];
  }
  destroy() {
    this.#t?.abort(), this.#t = null;
  }
}
class In {
  #t = Object.freeze({
    cMapUrl: "CMap",
    standardFontDataUrl: "font",
    wasmUrl: "wasm"
  });
  constructor({
    cMapUrl: t = null,
    standardFontDataUrl: e = null,
    wasmUrl: s = null
  }) {
    this.cMapUrl = t, this.standardFontDataUrl = e, this.wasmUrl = s;
  }
  async fetch({
    kind: t,
    filename: e
  }) {
    switch (t) {
      case "cMapUrl":
      case "standardFontDataUrl":
      case "wasmUrl":
        break;
      default:
        st(`Not implemented: ${t}`);
    }
    const s = this[t];
    if (!s)
      throw new Error(`Ensure that the \`${t}\` API parameter is provided.`);
    const i = `${s}${e}`;
    return this._fetch(i, t).catch((n) => {
      throw new Error(`Unable to load ${this.#t[t]} data at: ${i}`);
    });
  }
  async _fetch(t, e) {
    st("Abstract method `_fetch` called.");
  }
}
class sn extends In {
  async _fetch(t, e) {
    const s = e === "cMapUrl" && !t.endsWith(".bcmap") ? "text" : "bytes", i = await ui(t, s);
    return i instanceof Uint8Array ? i : Is(i);
  }
}
class On {
  #t = !1;
  constructor({
    enableHWA: t = !1
  }) {
    this.#t = t;
  }
  create(t, e) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid canvas size");
    const s = this._createCanvas(t, e);
    return {
      canvas: s,
      context: s.getContext("2d", {
        willReadFrequently: !this.#t
      })
    };
  }
  reset({
    canvas: t
  }, e, s) {
    if (!t)
      throw new Error("Canvas is not specified");
    if (e <= 0 || s <= 0)
      throw new Error("Invalid canvas size");
    t.width = e, t.height = s;
  }
  destroy(t) {
    const {
      canvas: e
    } = t;
    if (!e)
      throw new Error("Canvas is not specified");
    e.width = e.height = 0, t.canvas = null, t.context = null;
  }
  _createCanvas(t, e) {
    st("Abstract method `_createCanvas` called.");
  }
}
class Wr extends On {
  constructor({
    ownerDocument: t = globalThis.document,
    enableHWA: e = !1
  }) {
    super({
      enableHWA: e
    }), this._document = t;
  }
  _createCanvas(t, e) {
    const s = this._document.createElement("canvas");
    return s.width = t, s.height = e, s;
  }
}
class Mn {
  addFilter(t) {
    return "none";
  }
  addHCMFilter(t, e) {
    return "none";
  }
  addAlphaFilter(t) {
    return "none";
  }
  addLuminosityFilter(t) {
    return "none";
  }
  addKnockoutFilter(t = 0) {
    return "none";
  }
  addHighlightHCMFilter(t, e, s, i, n) {
    return "none";
  }
  addSelectionHCMFilter(t, e) {
    return "none";
  }
  addSelectionFilter() {
    return "none";
  }
  createSelectionStyle(t = null) {
    return null;
  }
  destroy(t = !1) {
  }
}
class Xr extends Mn {
  #t;
  #e;
  #s;
  #i;
  #n;
  #a;
  #r = 0;
  constructor({
    docId: t,
    ownerDocument: e = globalThis.document
  }) {
    super(), this.#i = t, this.#n = e;
  }
  get #o() {
    return this.#e ||= /* @__PURE__ */ new Map();
  }
  get #l() {
    return this.#a ||= /* @__PURE__ */ new Map();
  }
  get #h() {
    if (!this.#s) {
      const t = this.#n.createElement("div"), {
        style: e
      } = t;
      e.colorScheme = "only light", e.visibility = "hidden", e.contain = "strict", e.width = e.height = 0, e.position = "absolute", e.top = e.left = 0, e.zIndex = -1;
      const s = this.#n.createElementNS(Ot, "svg");
      s.setAttribute("width", 0), s.setAttribute("height", 0), this.#s = this.#n.createElementNS(Ot, "defs"), t.append(s), s.append(this.#s), this.#n.body.append(t);
    }
    return this.#s;
  }
  #u(t) {
    if (t.length === 1) {
      const o = t[0], l = new Array(256);
      for (let d = 0; d < 256; d++)
        l[d] = o[d] / 255;
      const h = l.join(",");
      return [h, h, h];
    }
    const [e, s, i] = t, n = new Array(256), r = new Array(256), a = new Array(256);
    for (let o = 0; o < 256; o++)
      n[o] = e[o] / 255, r[o] = s[o] / 255, a[o] = i[o] / 255;
    return [n.join(","), r.join(","), a.join(",")];
  }
  #d(t) {
    if (this.#t === void 0) {
      this.#t = "";
      const e = this.#n.URL;
      e !== this.#n.baseURI && (Os(e) ? V('#createUrl: ignore "data:"-URL for performance reasons.') : this.#t = An(e, ""));
    }
    return `url(${this.#t}#${t})`;
  }
  addFilter(t) {
    if (!t)
      return "none";
    let e = this.#o.get(t);
    if (e)
      return e;
    const [s, i, n] = this.#u(t), r = t.length === 1 ? s : `${s}${i}${n}`;
    if (e = this.#o.get(r), e)
      return this.#o.set(t, e), e;
    const a = `g_${this.#i}_transfer_map_${this.#r++}`, o = this.#d(a);
    this.#o.set(t, o), this.#o.set(r, o);
    const l = this.#m(a);
    return this.#p(s, i, n, l), o;
  }
  addHCMFilter(t, e) {
    const s = `${t}-${e}`, i = "base";
    let n = this.#l.get(i);
    if (n?.key === s || (n ? (n.filter?.remove(), n.key = s, n.url = "none", n.filter = null) : (n = {
      key: s,
      url: "none",
      filter: null
    }, this.#l.set(i, n)), !t || !e))
      return n.url;
    const r = this.#y(t);
    t = N.makeHexColor(...r);
    const a = this.#y(e);
    if (e = N.makeHexColor(...a), this.#A(), t === "#000000" && e === "#ffffff" || t === e)
      return n.url;
    const l = Array.from({
      length: 256
    }, (f, p) => ii(p / 255)).join(","), h = `g_${this.#i}_hcm_filter`, d = n.filter = this.#m(h);
    this.#p(l, l, l, d), this.#g(d);
    const u = (f, p) => {
      const g = r[f] / 255, m = a[f] / 255, v = new Array(p + 1);
      for (let y = 0; y <= p; y++)
        v[y] = g + y / p * (m - g);
      return v.join(",");
    };
    return this.#p(u(0, 5), u(1, 5), u(2, 5), d), n.url = this.#d(h), n.url;
  }
  addSelectionHCMFilter(t, e) {
    return this.addHighlightHCMFilter("selection", t, e, "HighlightText", "Highlight");
  }
  addSelectionFilter() {
    return this.addHighlightHCMFilter("selection_default", "black", "white", "HighlightText", "Highlight");
  }
  createSelectionStyle(t = null) {
    const e = t ? this.addSelectionHCMFilter(t.foreground, t.background) : this.addSelectionFilter();
    return e === "none" || !at.platform.isFirefox ? null : {
      "backdrop-filter": e,
      "background-color": "transparent"
    };
  }
  addAlphaFilter(t) {
    let e = this.#o.get(t);
    if (e)
      return e;
    const [s] = this.#u([t]), i = `alpha_${s}`;
    if (e = this.#o.get(i), e)
      return this.#o.set(t, e), e;
    const n = `g_${this.#i}_alpha_map_${this.#r++}`, r = this.#d(n);
    this.#o.set(t, r), this.#o.set(i, r);
    const a = this.#m(n);
    return this.#v(s, a), r;
  }
  addLuminosityFilter(t) {
    let e = this.#o.get(t || "luminosity");
    if (e)
      return e;
    let s, i;
    if (t ? ([s] = this.#u([t]), i = `luminosity_${s}`) : i = "luminosity", e = this.#o.get(i), e)
      return this.#o.set(t, e), e;
    const n = `g_${this.#i}_luminosity_map_${this.#r++}`, r = this.#d(n);
    this.#o.set(t, r), this.#o.set(i, r);
    const a = this.#m(n);
    return this.#f(a), t && this.#v(s, a), r;
  }
  addKnockoutFilter(t = 0) {
    const e = t > 0 ? Math.min(1 / t, 1e6) : 1e6, s = `knockout_${e}`, i = this.#o.get(s);
    if (i)
      return i;
    const n = `g_${this.#i}_knockout_filter_${this.#r++}`, r = this.#d(n);
    this.#o.set(s, r);
    const a = this.#m(n), o = this.#n.createElementNS(Ot, "feComponentTransfer");
    a.append(o);
    const l = this.#n.createElementNS(Ot, "feFuncA");
    return l.setAttribute("type", "linear"), l.setAttribute("slope", `${e}`), l.setAttribute("intercept", "0"), o.append(l), r;
  }
  addHighlightHCMFilter(t, e, s, i, n) {
    const r = `${e}-${s}-${i}-${n}`;
    let a = this.#l.get(t);
    if (a?.key === r || (a ? (a.filter?.remove(), a.key = r, a.url = "none", a.filter = null) : (a = {
      key: r,
      url: "none",
      filter: null
    }, this.#l.set(t, a)), !e || !s))
      return a.url;
    const [o, l] = [e, s].map(this.#y.bind(this));
    let h = Math.round(0.2126 * o[0] + 0.7152 * o[1] + 0.0722 * o[2]), d = Math.round(0.2126 * l[0] + 0.7152 * l[1] + 0.0722 * l[2]), [u, f] = [i, n].map(this.#E.bind(this));
    d < h && ([h, d, u, f] = [d, h, f, u]), this.#A();
    const p = (v, y, b) => {
      const w = new Array(256), A = (d - h) / b, S = v / 255, E = (y - v) / (255 * b);
      let T = 0;
      for (let x = 0; x <= b; x++) {
        const P = Math.round(h + x * A), C = S + x * E;
        for (let I = T; I <= P; I++)
          w[I] = C;
        T = P + 1;
      }
      for (let x = T; x < 256; x++)
        w[x] = w[T - 1];
      return w.join(",");
    }, g = `g_${this.#i}_hcm_${t}_filter`, m = a.filter = this.#m(g);
    return this.#g(m), this.#p(p(u[0], f[0], 5), p(u[1], f[1], 5), p(u[2], f[2], 5), m), a.url = this.#d(g), a.url;
  }
  destroy(t = !1) {
    t && this.#a?.size || (this.#s?.parentNode.parentNode.remove(), this.#s = null, this.#e?.clear(), this.#e = null, this.#a?.clear(), this.#a = null, this.#r = 0);
  }
  #f(t) {
    const e = this.#n.createElementNS(Ot, "feColorMatrix");
    e.setAttribute("type", "matrix"), e.setAttribute("values", "0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0.59 0.11 0 0"), t.append(e);
  }
  #g(t) {
    const e = this.#n.createElementNS(Ot, "feColorMatrix");
    e.setAttribute("type", "matrix"), e.setAttribute("values", "0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0.2126 0.7152 0.0722 0 0 0 0 0 1 0"), t.append(e);
  }
  #m(t) {
    const e = this.#n.createElementNS(Ot, "filter");
    return e.setAttribute("color-interpolation-filters", "sRGB"), e.setAttribute("id", t), this.#h.append(e), e;
  }
  #c(t, e, s) {
    const i = this.#n.createElementNS(Ot, e);
    i.setAttribute("type", "discrete"), i.setAttribute("tableValues", s), t.append(i);
  }
  #p(t, e, s, i) {
    const n = this.#n.createElementNS(Ot, "feComponentTransfer");
    i.append(n), this.#c(n, "feFuncR", t), this.#c(n, "feFuncG", e), this.#c(n, "feFuncB", s);
  }
  #v(t, e) {
    const s = this.#n.createElementNS(Ot, "feComponentTransfer");
    e.append(s), this.#c(s, "feFuncA", t);
  }
  #y(t) {
    return this.#h.style.color = "CanvasText", this.#h.style.backgroundColor = t, is(getComputedStyle(this.#h).getPropertyValue("background-color"));
  }
  #b(t) {
    return this.#h.style.color = "CanvasText", this.#h.style.backgroundColor = t, ss(getComputedStyle(this.#h).getPropertyValue("background-color"));
  }
  #A() {
    this.#h.style.color = "", this.#h.style.backgroundColor = "";
  }
  #E(t) {
    const [e, s, i, n] = this.#b(t);
    if (n === 1)
      return [e, s, i];
    const [r, a, o] = this.#y("Canvas");
    return [Ws(e, r, n), Ws(s, a, n), Ws(i, o, n)];
  }
}
function Ws(c, t, e) {
  return Math.round(e * c + (1 - e) * t);
}
if (Bt) {
  let c;
  try {
    const t = process.getBuiltinModule("module").createRequire(self.location.href);
    try {
      c = t("@napi-rs/canvas");
    } catch (e) {
      V(`Cannot load "@napi-rs/canvas" package: "${e}".`);
    }
  } catch (t) {
    V(`Cannot access the \`require\` function: "${t}".`);
  }
  globalThis.DOMMatrix || (c?.DOMMatrix ? globalThis.DOMMatrix = c.DOMMatrix : V("Cannot polyfill `DOMMatrix`, rendering may be broken.")), globalThis.Path2D || (c?.Path2D ? globalThis.Path2D = c.Path2D : V("Cannot polyfill `Path2D`, rendering may be broken.")), globalThis.navigator?.language || (globalThis.navigator = {
    language: "en-US",
    platform: "",
    userAgent: ""
  });
}
async function Yr(c) {
  const e = await process.getBuiltinModule("fs/promises").readFile(c);
  return new Uint8Array(e);
}
class Kr extends Mn {
}
class Jr extends On {
  _createCanvas(t, e) {
    return process.getBuiltinModule("module").createRequire(self.location.href)("@napi-rs/canvas").createCanvas(t, e);
  }
}
class Qr extends In {
  async _fetch(t, e) {
    return Yr(t);
  }
}
function Rn({
  src: c,
  srcPos: t = 0,
  dest: e,
  width: s,
  height: i,
  nonBlackColor: n = 4294967295,
  inverseDecode: r = !1
}) {
  const a = at.isLittleEndian ? 4278190080 : 255, [o, l] = r ? [n, a] : [a, n], h = s >> 3, d = s & 7, u = o ^ l, f = c.length;
  e = new Uint32Array(e.buffer);
  let p = 0;
  for (let g = 0; g < i; ++g) {
    for (const v = t + h; t < v; ++t, p += 8) {
      const y = c[t];
      e[p] = o ^ -(y >> 7 & 1) & u, e[p + 1] = o ^ -(y >> 6 & 1) & u, e[p + 2] = o ^ -(y >> 5 & 1) & u, e[p + 3] = o ^ -(y >> 4 & 1) & u, e[p + 4] = o ^ -(y >> 3 & 1) & u, e[p + 5] = o ^ -(y >> 2 & 1) & u, e[p + 6] = o ^ -(y >> 1 & 1) & u, e[p + 7] = o ^ -(y & 1) & u;
    }
    if (d === 0)
      continue;
    const m = t < f ? c[t++] : 255;
    for (let v = 0; v < d; ++v, ++p)
      e[p] = o ^ -(m >> 7 - v & 1) & u;
  }
  return {
    srcPos: t,
    destPos: p
  };
}
function Zr({
  src: c,
  srcPos: t = 0,
  dest: e,
  destPos: s = 0,
  width: i,
  height: n
}) {
  let r = 0;
  const a = i * n * 3, o = a >> 2, l = new Uint32Array(c.buffer, t, o), h = at.isLittleEndian ? 4278190080 : 255;
  if (at.isLittleEndian) {
    for (; r < o - 2; r += 3, s += 4) {
      const d = l[r], u = l[r + 1], f = l[r + 2];
      e[s] = d | h, e[s + 1] = d >>> 24 | u << 8 | h, e[s + 2] = u >>> 16 | f << 16 | h, e[s + 3] = f >>> 8 | h;
    }
    for (let d = r * 4, u = t + a; d < u; d += 3)
      e[s++] = c[d] | c[d + 1] << 8 | c[d + 2] << 16 | h;
  } else {
    for (; r < o - 2; r += 3, s += 4) {
      const d = l[r], u = l[r + 1], f = l[r + 2];
      e[s] = d | h, e[s + 1] = d << 24 | u >>> 8 | h, e[s + 2] = u << 16 | f >>> 16 | h, e[s + 3] = f << 8 | h;
    }
    for (let d = r * 4, u = t + a; d < u; d += 3)
      e[s++] = c[d] << 24 | c[d + 1] << 16 | c[d + 2] << 8 | h;
  }
  return {
    srcPos: t + a,
    destPos: s
  };
}
const qr = `
struct Uniforms {
  offsetX      : f32,
  offsetY      : f32,
  scaleX       : f32,
  scaleY       : f32,
  paddedWidth  : f32,
  paddedHeight : f32,
  borderSize   : f32,
  _pad         : f32,
};

@group(0) @binding(0) var<uniform> u : Uniforms;

struct VertexInput {
  @location(0) position : vec2<f32>,
  @location(1) color    : vec4<f32>,
};

struct VertexOutput {
  @builtin(position) position : vec4<f32>,
  @location(0)       color    : vec3<f32>,
};

@vertex
fn vs_main(in : VertexInput) -> VertexOutput {
  var out : VertexOutput;
  let cx = (in.position.x + u.offsetX) * u.scaleX;
  let cy = (in.position.y + u.offsetY) * u.scaleY;
  out.position = vec4<f32>(
    ((cx + u.borderSize) / u.paddedWidth) * 2.0 - 1.0,
    1.0 - ((cy + u.borderSize) / u.paddedHeight) * 2.0,
    0.0,
    1.0
  );
  out.color = in.color.rgb;
  return out;
}

@fragment
fn fs_main(in : VertexOutput) -> @location(0) vec4<f32> {
  return vec4<f32>(in.color, 1.0);
}
`;
class ta {
  #t = null;
  #e = null;
  #s = null;
  #i = null;
  async #n() {
    if (!globalThis.navigator?.gpu)
      return !1;
    try {
      const t = await navigator.gpu.requestAdapter();
      return t ? (this.#i = navigator.gpu.getPreferredCanvasFormat(), this.#e = await t.requestDevice(), !0) : !1;
    } catch {
      return !1;
    }
  }
  init() {
    return this.#t ||= this.#n();
  }
  get isReady() {
    return this.#e !== null;
  }
  loadMeshShader() {
    if (!this.#e || this.#s)
      return;
    const t = this.#e.createShaderModule({
      code: qr
    });
    this.#s = this.#e.createRenderPipeline({
      layout: "auto",
      vertex: {
        module: t,
        entryPoint: "vs_main",
        buffers: [{
          arrayStride: 8,
          attributes: [{
            shaderLocation: 0,
            offset: 0,
            format: "float32x2"
          }]
        }, {
          arrayStride: 4,
          attributes: [{
            shaderLocation: 1,
            offset: 0,
            format: "unorm8x4"
          }]
        }]
      },
      fragment: {
        module: t,
        entryPoint: "fs_main",
        targets: [{
          format: this.#i
        }]
      },
      primitive: {
        topology: "triangle-list"
      }
    });
  }
  draw(t, e, s, i, n, r, a, o) {
    this.loadMeshShader();
    const l = this.#e, {
      offsetX: h,
      offsetY: d,
      scaleX: u,
      scaleY: f
    } = i, p = l.createBuffer({
      size: Math.max(t.byteLength, 4),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
    });
    t.byteLength > 0 && l.queue.writeBuffer(p, 0, t);
    const g = l.createBuffer({
      size: Math.max(e.byteLength, 4),
      usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
    });
    e.byteLength > 0 && l.queue.writeBuffer(g, 0, e);
    const m = l.createBuffer({
      size: 32,
      usage: GPUBufferUsage.UNIFORM | GPUBufferUsage.COPY_DST
    });
    l.queue.writeBuffer(m, 0, new Float32Array([h, d, u, f, r, a, o, 0]));
    const v = l.createBindGroup({
      layout: this.#s.getBindGroupLayout(0),
      entries: [{
        binding: 0,
        resource: {
          buffer: m
        }
      }]
    }), y = new OffscreenCanvas(r, a), b = y.getContext("webgpu");
    b.configure({
      device: l,
      format: this.#i,
      alphaMode: n ? "opaque" : "premultiplied"
    });
    const w = n ? {
      r: n[0] / 255,
      g: n[1] / 255,
      b: n[2] / 255,
      a: 1
    } : {
      r: 0,
      g: 0,
      b: 0,
      a: 0
    }, A = l.createCommandEncoder(), S = A.beginRenderPass({
      colorAttachments: [{
        view: b.getCurrentTexture().createView(),
        clearValue: w,
        loadOp: "clear",
        storeOp: "store"
      }]
    });
    return s > 0 && (S.setPipeline(this.#s), S.setBindGroup(0, v), S.setVertexBuffer(0, p), S.setVertexBuffer(1, g), S.draw(s)), S.end(), l.queue.submit([A.finish()]), p.destroy(), g.destroy(), m.destroy(), y.transferToImageBitmap();
  }
}
const Ms = new ta();
function ea() {
  return Ms.init();
}
function sa() {
  return Ms.isReady;
}
function ia() {
  Ms.loadMeshShader();
}
function na(c, t, e, s, i, n, r, a) {
  return Ms.draw(c, t, e, s, i, n, r, a);
}
const Ct = {
  FILL: "Fill",
  STROKE: "Stroke",
  SHADING: "Shading"
};
function ms(c, t) {
  if (!t)
    return;
  const e = t[2] - t[0], s = t[3] - t[1], i = new Path2D();
  i.rect(t[0], t[1], e, s), c.clip(i);
}
class yi {
  matrix = null;
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern() {
    st("Abstract method `getPattern` called.");
  }
}
class ra extends yi {
  constructor(t) {
    super(), this._type = t[1], this._bbox = t[2], this._colorStops = t[3], this._p0 = t[4], this._p1 = t[5], this._r0 = t[6], this._r1 = t[7];
  }
  isOriginBased() {
    return this._p0[0] === 0 && this._p0[1] === 0 && (!this.isRadial() || this._p1[0] === 0 && this._p1[1] === 0);
  }
  isRadial() {
    return this._type === "radial";
  }
  areConic() {
    if (!this.isRadial())
      return !1;
    const t = Math.hypot(this._p0[0] - this._p1[0], this._p0[1] - this._p1[1]);
    return t + this._r1 > this._r0 && t + this._r0 > this._r1;
  }
  _createGradient(t, e = null) {
    let s, i = this._p0, n = this._p1;
    if (e && (i = i.slice(), n = n.slice(), N.applyTransform(i, e), N.applyTransform(n, e)), this._type === "axial")
      s = t.createLinearGradient(i[0], i[1], n[0], n[1]);
    else if (this._type === "radial") {
      let r = this._r0, a = this._r1;
      if (e) {
        const o = new Float32Array(2);
        N.singularValueDecompose2dScale(e, o), r *= o[0], a *= o[0];
      }
      s = t.createRadialGradient(i[0], i[1], r, n[0], n[1], a);
    }
    for (const r of this._colorStops)
      s.addColorStop(r[0], r[1]);
    return s;
  }
  _createReversedGradient(t, e = null) {
    let s = this._p1, i = this._p0;
    e && (s = s.slice(), i = i.slice(), N.applyTransform(s, e), N.applyTransform(i, e));
    let n = this._r1, r = this._r0;
    if (e) {
      const l = new Float32Array(2);
      N.singularValueDecompose2dScale(e, l), n *= l[0], r *= l[0];
    }
    const a = t.createRadialGradient(s[0], s[1], n, i[0], i[1], r), o = this._colorStops.map(([l, h]) => [1 - l, h]).reverse();
    for (const [l, h] of o)
      a.addColorStop(l, h);
    return a;
  }
  getPattern(t, e, s, i) {
    let n;
    if (i === Ct.STROKE || i === Ct.FILL) {
      if (this.isOriginBased()) {
        let u = N.transform(s, e.baseTransform);
        this.matrix && (u = N.transform(u, this.matrix));
        const f = 1e-3, p = Math.hypot(u[0], u[1]), g = Math.hypot(u[2], u[3]), m = (u[0] * u[2] + u[1] * u[3]) / (p * g);
        if (Math.abs(m) < f)
          if (this.isRadial()) {
            if (Math.abs(p - g) < f)
              return this._createGradient(t, u);
          } else
            return this._createGradient(t, u);
      }
      const r = e.current.getClippedPathBoundingBox(i, ht(t)) || [0, 0, 0, 0], a = Math.ceil(r[2] - r[0]) || 1, o = Math.ceil(r[3] - r[1]) || 1, l = e.canvasFactory.create(a, o), h = l.context;
      h.clearRect(0, 0, h.canvas.width, h.canvas.height), h.beginPath(), h.rect(0, 0, h.canvas.width, h.canvas.height), h.translate(-r[0], -r[1]), s = N.transform(s, [1, 0, 0, 1, r[0], r[1]]), h.transform(...e.baseTransform), this.matrix && h.transform(...this.matrix), ms(h, this._bbox), this.areConic() && (h.fillStyle = this._createReversedGradient(h), h.fill()), h.fillStyle = this._createGradient(h), h.fill(), n = t.createPattern(l.canvas, "no-repeat"), e.canvasFactory.destroy(l);
      const d = new DOMMatrix(s);
      n.setTransform(d);
    } else
      this.areConic() && (t.save(), ms(t, this._bbox), t.fillStyle = this._createReversedGradient(t), t.fillRect(-1e10, -1e10, 2e10, 2e10), t.restore()), ms(t, this._bbox), n = this._createGradient(t);
    return n;
  }
}
function aa(c, t, e, s, i, n, r, a) {
  const o = t.coords, l = t.colors, h = c.data, d = c.width * 4;
  let u;
  o[e * 2 + 1] > o[s * 2 + 1] && (u = e, e = s, s = u, u = n, n = r, r = u), o[s * 2 + 1] > o[i * 2 + 1] && (u = s, s = i, i = u, u = r, r = a, a = u), o[e * 2 + 1] > o[s * 2 + 1] && (u = e, e = s, s = u, u = n, n = r, r = u);
  const f = (o[e * 2] + t.offsetX) * t.scaleX, p = (o[e * 2 + 1] + t.offsetY) * t.scaleY, g = (o[s * 2] + t.offsetX) * t.scaleX, m = (o[s * 2 + 1] + t.offsetY) * t.scaleY, v = (o[i * 2] + t.offsetX) * t.scaleX, y = (o[i * 2 + 1] + t.offsetY) * t.scaleY;
  if (p >= y)
    return;
  const b = l[n * 4], w = l[n * 4 + 1], A = l[n * 4 + 2], S = l[r * 4], E = l[r * 4 + 1], T = l[r * 4 + 2], x = l[a * 4], P = l[a * 4 + 1], C = l[a * 4 + 2], I = Math.round(p), R = Math.round(y);
  let D, _, M, k, $, U, tt, vt;
  for (let Y = I; Y <= R; Y++) {
    if (Y < m) {
      const O = Y < p ? 0 : (p - Y) / (p - m);
      D = f - (f - g) * O, _ = b - (b - S) * O, M = w - (w - E) * O, k = A - (A - T) * O;
    } else {
      let O;
      Y > y ? O = 1 : m === y ? O = 0 : O = (m - Y) / (m - y), D = g - (g - v) * O, _ = S - (S - x) * O, M = E - (E - P) * O, k = T - (T - C) * O;
    }
    let J;
    Y < p ? J = 0 : Y > y ? J = 1 : J = (p - Y) / (p - y), $ = f - (f - v) * J, U = b - (b - x) * J, tt = w - (w - P) * J, vt = A - (A - C) * J;
    const rt = Math.round(Math.min(D, $)), Rt = Math.round(Math.max(D, $));
    let F = d * Y + rt * 4;
    for (let O = rt; O <= Rt; O++)
      J = (D - O) / (D - $), J < 0 ? J = 0 : J > 1 && (J = 1), h[F++] = _ - (_ - U) * J | 0, h[F++] = M - (M - tt) * J | 0, h[F++] = k - (k - vt) * J | 0, h[F++] = 255;
  }
}
class oa extends yi {
  constructor(t) {
    super(), this._posData = t[2], this._colData = t[3], this._vertexCount = t[4], this._bounds = t[5], this._bbox = t[6], this._background = t[7], ia();
  }
  _createMeshCanvas(t, e, s) {
    const a = Math.floor(this._bounds[0]), o = Math.floor(this._bounds[1]), l = Math.ceil(this._bounds[2]) - a, h = Math.ceil(this._bounds[3]) - o, d = Math.min(Math.ceil(Math.abs(l * t[0] * 1.1)), 3e3) || 1, u = Math.min(Math.ceil(Math.abs(h * t[1] * 1.1)), 3e3) || 1, f = l ? l / d : 1, p = h ? h / u : 1, g = {
      coords: this._posData,
      colors: this._colData,
      offsetX: -a,
      offsetY: -o,
      scaleX: 1 / f,
      scaleY: 1 / p
    }, m = d + 4, v = u + 4, y = s.create(m, v);
    if (sa() && this._vertexCount > 48)
      y.context.drawImage(na(this._posData, this._colData, this._vertexCount, g, e, m, v, 2), 0, 0);
    else {
      const b = y.context.createImageData(d, u);
      if (e) {
        const w = b.data;
        for (let A = 0, S = w.length; A < S; A += 4)
          w[A] = e[0], w[A + 1] = e[1], w[A + 2] = e[2], w[A + 3] = 255;
      }
      for (let w = 0, A = this._vertexCount; w < A; w += 3)
        aa(b, g, w, w + 1, w + 2, w, w + 1, w + 2);
      y.context.putImageData(b, 2, 2);
    }
    return {
      canvas: y.canvas,
      offsetX: a - 2 * f,
      offsetY: o - 2 * p,
      scaleX: f,
      scaleY: p
    };
  }
  isModifyingCurrentTransform() {
    return !0;
  }
  getPattern(t, e, s, i) {
    ms(t, this._bbox);
    const n = new Float32Array(2);
    if (i === Ct.SHADING)
      N.singularValueDecompose2dScale(ht(t), n);
    else if (this.matrix) {
      N.singularValueDecompose2dScale(this.matrix, n);
      const [o, l] = n;
      N.singularValueDecompose2dScale(e.baseTransform, n), n[0] *= o, n[1] *= l;
    } else
      N.singularValueDecompose2dScale(e.baseTransform, n);
    const r = this._createMeshCanvas(n, i === Ct.SHADING ? null : this._background, e.canvasFactory);
    i !== Ct.SHADING && (t.setTransform(...e.baseTransform), this.matrix && t.transform(...this.matrix)), t.translate(r.offsetX, r.offsetY), t.scale(r.scaleX, r.scaleY);
    const a = t.createPattern(r.canvas, "no-repeat");
    return e.canvasFactory.destroy(r), a;
  }
}
class la extends yi {
  getPattern() {
    return "hotpink";
  }
}
function ha(c) {
  switch (c[0]) {
    case "RadialAxial":
      return new ra(c);
    case "Mesh":
      return new oa(c);
    case "Dummy":
      return new la();
  }
  throw new Error(`Unknown IR type: ${c[0]}`);
}
const nn = {
  COLORED: 1,
  UNCOLORED: 2
};
class Ye {
  static MAX_PATTERN_SIZE = 3e3;
  constructor(t, e, s, i) {
    this.color = t[1], this.operatorList = t[2], this.matrix = t[3], this.bbox = t[4], this.xstep = t[5], this.ystep = t[6], this.paintType = t[7], this.tilingType = t[8], this.needsIsolation = t[9] ?? !0, this.ctx = e, this.canvasGraphicsFactory = s, this.baseTransform = i, this.patternBaseMatrix = this.matrix ? N.transform(i, this.matrix) : i;
  }
  canSkipPatternCanvas([t, e, s, i]) {
    const [n, r, a, o] = this.bbox, l = Math.abs(this.xstep), h = Math.abs(this.ystep);
    if (t > l + 1e-6 || e > h + 1e-6)
      return null;
    const d = Math.floor((s - a) / l) + 1, u = Math.ceil((s + t - n) / l) - 1, f = Math.floor((i - o) / h) + 1, p = Math.ceil((i + e - r) / h) - 1;
    return u <= d && p <= f ? [d, f] : null;
  }
  updatePatternDims(t, e) {
    const s = N.inverseTransform(this.patternBaseMatrix), i = [t[0], t[1]], n = [t[2], t[3]];
    N.applyTransform(i, s), N.applyTransform(n, s), e[0] = Math.abs(n[0] - i[0]), e[1] = Math.abs(n[1] - i[1]), e[2] = Math.min(i[0], n[0]), e[3] = Math.min(i[1], n[1]);
  }
  _renderTileCanvas(t, e, s, i) {
    const [n, r, a, o] = this.bbox, l = t.canvasFactory.create(s.size, i.size), h = l.context, d = this.canvasGraphicsFactory.createCanvasGraphics(h, e);
    return d.groupLevel = t.groupLevel, this.setFillAndStrokeStyleToContext(d, this.paintType, this.color), h.translate(-s.scale * n, -i.scale * r), d.transform(0, s.scale, 0, 0, i.scale, 0, 0), h.save(), d.dependencyTracker?.save(), this.clipBbox(d, n, r, a, o), d.baseTransform = ht(d.ctx), d.executeOperatorList(this.operatorList), d.endDrawing(), d.dependencyTracker?.restore(), h.restore(), l;
  }
  _getCombinedScales() {
    const t = new Float32Array(2);
    N.singularValueDecompose2dScale(this.matrix, t);
    const [e, s] = t;
    return N.singularValueDecompose2dScale(this.baseTransform, t), [e * t[0], s * t[1]];
  }
  drawPattern(t, e, s = !1, [i, n], r) {
    const [a, o, l, h] = this.bbox, d = t.dependencyTracker;
    if (d && (t.dependencyTracker = new Ze(d, r)), t.save(), s ? t.ctx.clip(e, "evenodd") : t.ctx.clip(e), t.ctx.setTransform(...this.patternBaseMatrix), t.ctx.translate(i * this.xstep, n * this.ystep), this.needsIsolation || t.ctx.globalAlpha !== 1 || t.ctx.globalCompositeOperation !== "source-over" || t.inSMaskMode) {
      const u = l - a, f = h - o, [p, g] = this._getCombinedScales(), m = this.getSizeAndScale(u, this.ctx.canvas.width, p), v = this.getSizeAndScale(f, this.ctx.canvas.height, g), y = this._renderTileCanvas(t, r, m, v);
      t.ctx.drawImage(y.canvas, a, o, u, f), t.canvasFactory.destroy(y);
    } else
      this.setFillAndStrokeStyleToContext(t, this.paintType, this.color), this.clipBbox(t, a, o, l, h), t.baseTransformStack.push(t.baseTransform), t.baseTransform = ht(t.ctx), t.executeOperatorList(this.operatorList), t.baseTransform = t.baseTransformStack.pop();
    t.restore(), d && (t.dependencyTracker = d);
  }
  createPatternCanvas(t, e) {
    const [s, i, n, r] = this.bbox, a = n - s, o = r - i;
    let {
      xstep: l,
      ystep: h
    } = this;
    l = Math.abs(l), h = Math.abs(h), Ps("TilingType: " + this.tilingType);
    const [d, u] = this._getCombinedScales();
    let f = a, p = o, g = !1, m = !1;
    Math.ceil(l * d) >= Math.ceil(a * d) ? f = l : g = !0, Math.ceil(h * u) >= Math.ceil(o * u) ? p = h : m = !0;
    const v = this.getSizeAndScale(f, this.ctx.canvas.width, d), y = this.getSizeAndScale(p, this.ctx.canvas.height, u), b = this._renderTileCanvas(t, e, v, y);
    if (g || m) {
      const w = b.canvas;
      g && (f = l), m && (p = h);
      const A = this.getSizeAndScale(f, this.ctx.canvas.width, d), S = this.getSizeAndScale(p, this.ctx.canvas.height, u), E = A.size, T = S.size, x = t.canvasFactory.create(E, T), P = x.context, C = g ? Math.floor(a / l) : 0, I = m ? Math.floor(o / h) : 0;
      for (let R = 0; R <= C; R++)
        for (let D = 0; D <= I; D++)
          P.drawImage(w, E * R, T * D, E, T, 0, 0, E, T);
      return t.canvasFactory.destroy(b), {
        canvas: x.canvas,
        canvasEntry: x,
        scaleX: A.scale,
        scaleY: S.scale,
        offsetX: s,
        offsetY: i
      };
    }
    return {
      canvas: b.canvas,
      canvasEntry: b,
      scaleX: v.scale,
      scaleY: y.scale,
      offsetX: s,
      offsetY: i
    };
  }
  getSizeAndScale(t, e, s) {
    const i = Math.max(Ye.MAX_PATTERN_SIZE, e);
    let n = Math.ceil(t * s);
    return n >= i ? n = i : s = n / t, {
      scale: s,
      size: n
    };
  }
  clipBbox(t, e, s, i, n) {
    const r = i - e, a = n - s, o = new Path2D();
    o.rect(e, s, r, a), N.axialAlignedBoundingBox([e, s, i, n], ht(t.ctx), t.current.minMax), t.ctx.clip(o), t.current.updateClipFromPath();
  }
  setFillAndStrokeStyleToContext(t, e, s) {
    const i = t.ctx, n = t.current;
    switch (n.patternFill = n.patternStroke = !1, e) {
      case nn.COLORED:
        const {
          fillStyle: r,
          strokeStyle: a
        } = this.ctx;
        i.fillStyle = n.fillColor = r, i.strokeStyle = n.strokeColor = a;
        break;
      case nn.UNCOLORED:
        i.fillStyle = i.strokeStyle = s, n.fillColor = n.strokeColor = s;
        break;
      default:
        throw new or(`Unsupported paint type: ${e}`);
    }
  }
  isModifyingCurrentTransform() {
    return !1;
  }
  getPattern(t, e, s, i, n) {
    const r = i !== Ct.SHADING ? N.transform(s, this.patternBaseMatrix) : s, a = this.createPatternCanvas(e, n);
    let o = new DOMMatrix(r);
    o = o.translate(a.offsetX, a.offsetY), o = o.scale(1 / a.scaleX, 1 / a.scaleY);
    const l = t.createPattern(a.canvas, "repeat");
    return e.canvasFactory.destroy(a.canvasEntry), l.setTransform(o), l;
  }
}
const ca = 16, da = 100, ua = 15, rn = 10, Nt = 16, Ut = new Float32Array(2);
function an(c, t) {
  if (c._removeMirroring)
    throw new Error("Context is already forwarding operations.");
  const e = /* @__PURE__ */ new Map();
  for (const s of ["save", "restore", "rotate", "scale", "translate", "transform", "setTransform", "resetTransform", "clip", "moveTo", "lineTo", "bezierCurveTo", "quadraticCurveTo", "arc", "arcTo", "ellipse", "rect", "roundRect", "closePath", "beginPath"]) {
    const i = c[s];
    typeof i != "function" || typeof t[s] != "function" || (e.set(s, i), c[s] = function(...n) {
      return t[s](...n), i.apply(this, n);
    });
  }
  c._removeMirroring = () => {
    for (const [s, i] of e)
      c[s] = i;
    delete c._removeMirroring;
  };
}
function hs(c, t, e, s, i, n, r, a, o, l) {
  const [h, d, u, f, p, g] = ht(c);
  if (d === 0 && u === 0) {
    const y = r * h + p, b = Math.round(y), w = a * f + g, A = Math.round(w), S = (r + o) * h + p, E = Math.abs(Math.round(S) - b) || 1, T = (a + l) * f + g, x = Math.abs(Math.round(T) - A) || 1;
    return c.setTransform(Math.sign(h), 0, 0, Math.sign(f), b, A), c.drawImage(t, e, s, i, n, 0, 0, E, x), c.setTransform(h, d, u, f, p, g), [E, x];
  }
  if (h === 0 && f === 0) {
    const y = a * u + p, b = Math.round(y), w = r * d + g, A = Math.round(w), S = (a + l) * u + p, E = Math.abs(Math.round(S) - b) || 1, T = (r + o) * d + g, x = Math.abs(Math.round(T) - A) || 1;
    return c.setTransform(0, Math.sign(d), Math.sign(u), 0, b, A), c.drawImage(t, e, s, i, n, 0, 0, x, E), c.setTransform(h, d, u, f, p, g), [x, E];
  }
  c.drawImage(t, e, s, i, n, r, a, o, l);
  const m = Math.hypot(h, d), v = Math.hypot(u, f);
  return [m * o, v * l];
}
class on {
  alphaIsShape = !1;
  fontSize = 0;
  fontSizeScale = 1;
  textMatrix = null;
  textMatrixScale = 1;
  fontMatrix = Ks;
  leading = 0;
  x = 0;
  y = 0;
  lineX = 0;
  lineY = 0;
  charSpacing = 0;
  wordSpacing = 0;
  textHScale = 1;
  textRenderingMode = At.FILL;
  textRise = 0;
  fillColor = "#000000";
  strokeColor = "#000000";
  tilingPatternDims = null;
  patternFill = !1;
  patternStroke = !1;
  fillAlpha = 1;
  strokeAlpha = 1;
  lineWidth = 1;
  activeSMask = null;
  transferMaps = "none";
  minMax = ge.slice();
  constructor(t, e) {
    this.clipBox = new Float32Array([0, 0, t, e]);
  }
  clone() {
    const t = Object.create(this);
    return t.clipBox = this.clipBox.slice(), t.minMax = this.minMax.slice(), t.tilingPatternDims = this.tilingPatternDims?.slice(), t;
  }
  getPathBoundingBox(t = Ct.FILL, e = null) {
    const s = this.minMax.slice();
    if (t === Ct.STROKE) {
      e || st("Stroke bounding box must include transform."), N.singularValueDecompose2dScale(e, Ut);
      const i = Ut[0] * this.lineWidth / 2, n = Ut[1] * this.lineWidth / 2;
      s[0] -= i, s[1] -= n, s[2] += i, s[3] += n;
    }
    return s;
  }
  updateClipFromPath() {
    const t = N.intersect(this.clipBox, this.getPathBoundingBox());
    this.startNewPathAndClipBox(t || [0, 0, 0, 0]);
  }
  isEmptyClip() {
    return this.minMax[0] === 1 / 0;
  }
  startNewPathAndClipBox(t) {
    this.clipBox.set(t, 0), this.minMax.set(ge, 0);
  }
  getClippedPathBoundingBox(t = Ct.FILL, e = null) {
    return N.intersect(this.clipBox, this.getPathBoundingBox(t, e));
  }
}
function ln(c, t) {
  const {
    width: e,
    height: s,
    kind: i
  } = t, n = s % Nt, r = (s - n) / Nt, a = n === 0 ? r : r + 1, o = c.createImageData(e, Nt);
  let l = 0;
  const h = t.data, d = o.data;
  let u;
  if (i === gs.GRAYSCALE_1BPP)
    for (u = 0; u < a; u++)
      ({
        srcPos: l
      } = Rn({
        src: h,
        srcPos: l,
        dest: d,
        width: e,
        height: u < r ? Nt : n
      })), c.putImageData(o, 0, u * Nt);
  else if (i === gs.RGBA_32BPP) {
    let f = 0, p = e * Nt * 4;
    for (u = 0; u < r; u++)
      d.set(h.subarray(l, l + p)), l += p, c.putImageData(o, 0, f), f += Nt;
    u < a && (p = e * n * 4, d.set(h.subarray(l, l + p)), c.putImageData(o, 0, f));
  } else if (i === gs.RGB_24BPP)
    for (u = 0; u < a; u++)
      ({
        srcPos: l
      } = Zr({
        src: h,
        srcPos: l,
        dest: new Uint32Array(d.buffer),
        width: e,
        height: u < r ? Nt : n
      })), c.putImageData(o, 0, u * Nt);
  else
    throw new Error(`bad image kind: ${i}`);
}
function hn(c, t) {
  if (t.bitmap) {
    c.drawImage(t.bitmap, 0, 0);
    return;
  }
  const {
    width: e,
    height: s
  } = t, i = s % Nt, n = (s - i) / Nt, r = i === 0 ? n : n + 1, a = c.createImageData(e, Nt);
  let o = 0;
  const l = t.data, h = a.data;
  for (let d = 0; d < r; d++)
    ({
      srcPos: o
    } = Rn({
      src: l,
      srcPos: o,
      dest: h,
      width: e,
      height: d < n ? Nt : i,
      nonBlackColor: 0
    })), c.putImageData(a, 0, d * Nt);
}
function fe(c, t) {
  const e = ["strokeStyle", "fillStyle", "fillRule", "globalAlpha", "lineWidth", "lineCap", "lineJoin", "miterLimit", "globalCompositeOperation", "font", "filter"];
  for (const s of e)
    c[s] !== void 0 && (t[s] = c[s]);
  c.setLineDash !== void 0 && (t.setLineDash(c.getLineDash()), t.lineDashOffset = c.lineDashOffset);
}
function cs(c) {
  c.strokeStyle = c.fillStyle = "#000000", c.fillRule = "nonzero", c.globalAlpha = 1, c.lineWidth = 1, c.lineCap = "butt", c.lineJoin = "miter", c.miterLimit = 10, c.globalCompositeOperation = "source-over", c.font = "10px sans-serif", c.setLineDash !== void 0 && (c.setLineDash([]), c.lineDashOffset = 0);
  const {
    filter: t
  } = c;
  t !== "none" && t !== "" && (c.filter = "none");
}
function cn(c, t) {
  if (t)
    return !0;
  N.singularValueDecompose2dScale(c, Ut);
  const e = Math.fround(Kt.pixelRatio * Fe.PDF_TO_CSS_UNITS);
  return Ut[0] <= e && Ut[1] <= e;
}
const fa = ["butt", "round", "square"], pa = ["miter", "round", "bevel"], ga = {}, dn = {};
class Ae {
  static #t = null;
  #e = 0;
  #s = 0;
  #i = null;
  #n = null;
  #a = null;
  #r = null;
  #o = 1;
  #l;
  #h = null;
  #u = [];
  constructor(t, e, s, i, n, {
    optionalContentConfig: r,
    markedContentStack: a = null
  }, o, l, h, d) {
    this.ctx = t, this.current = new on(this.ctx.canvas.width, this.ctx.canvas.height), this.stateStack = [], this.pendingClip = null, this.pendingEOFill = !1, this.commonObjs = e, this.objs = s, this.canvasFactory = i, this.filterFactory = n, this.groupStack = [], this.baseTransform = null, this.baseTransformStack = [], this.groupLevel = 0, this.smaskStack = [], this.tempSMask = null, this.smaskGroupCanvases = [], this.smaskPreparedEntry = null, this.smaskPreparedFor = null, this.smaskPreparedOffsetX = 0, this.smaskPreparedOffsetY = 0, this.smaskPreparedOOBAlpha = null, this.suspendedCtx = null, this.contentVisible = !0, this.markedContentStack = a || [], this.optionalContentConfig = r, this.cachedPatterns = /* @__PURE__ */ new Map(), this.annotationCanvasMap = o, this.viewportScale = 1, this.outputScaleX = 1, this.outputScaleY = 1, this.pageColors = l, this._cachedScaleForStroking = [-1, 0], this._cachedGetSinglePixelWidth = null, this._cachedBitmapsMap = /* @__PURE__ */ new Map(), this.dependencyTracker = h ?? null, this.imagesTracker = d ?? null;
  }
  getObject(t, e, s = null) {
    return typeof e == "string" ? (this.dependencyTracker?.recordNamedDependency(t, e), e.startsWith("g_") ? this.commonObjs.get(e) : this.objs.get(e)) : s;
  }
  beginDrawing({
    transform: t,
    viewport: e,
    transparency: s = !1,
    background: i = null
  }) {
    const n = this.ctx.canvas.width, r = this.ctx.canvas.height, a = this.ctx.fillStyle;
    if (this.ctx.fillStyle = i || "#ffffff", this.ctx.fillRect(0, 0, n, r), this.ctx.fillStyle = a, s) {
      const o = this.transparentCanvasEntry = this.canvasFactory.create(n, r);
      this.compositeCtx = this.ctx, {
        canvas: this.transparentCanvas,
        context: this.ctx
      } = o, this.ctx.save(), this.ctx.transform(...ht(this.compositeCtx));
    }
    this.ctx.save(), cs(this.ctx), t && (this.ctx.transform(...t), this.outputScaleX = t[0], this.outputScaleY = t[3]), this.ctx.transform(...e.transform), this.viewportScale = e.scale, this.baseTransform = ht(this.ctx);
  }
  executeOperatorList(t, e, s, i, n) {
    const r = t.argsArray, a = t.fnArray;
    let o = e || 0;
    const l = r.length;
    if (l === o)
      return o;
    const h = l - o > rn && typeof s == "function", d = h ? Date.now() + ua : 0;
    let u = 0;
    const f = this.commonObjs, p = this.objs;
    let g, m;
    for (; ; ) {
      if (i !== void 0) {
        if (o === i.nextBreakPoint)
          return i.breakIt(o, s), o;
        if (i.shouldSkip(o)) {
          if (++o === l)
            return o;
          continue;
        }
      }
      if (!n || n(o))
        if (g = a[o], m = r[o] ?? null, g !== se.dependency)
          m === null ? this[g](o) : this[g](o, ...m);
        else
          for (const v of m) {
            this.dependencyTracker?.recordNamedData(v, o);
            const y = v.startsWith("g_") ? f : p;
            if (!y.has(v))
              return y.get(v, s), o;
          }
      if (o++, o === l)
        return o;
      if (h && ++u > rn) {
        if (Date.now() > d)
          return s(), o;
        u = 0;
      }
    }
  }
  #d() {
    for (; this.stateStack.length || this.inSMaskMode; )
      this.restore();
    this.current.activeSMask = null, this.ctx.restore(), this.transparentCanvas && (this.ctx = this.compositeCtx, this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.drawImage(this.transparentCanvas, 0, 0), this.ctx.restore(), this.canvasFactory.destroy(this.transparentCanvasEntry), this.transparentCanvas = null, this.transparentCanvasEntry = null);
  }
  endDrawing() {
    this.#d();
    for (const t of this.smaskGroupCanvases)
      this.canvasFactory.destroy(t);
    this.smaskGroupCanvases.length = 0, this._clearPreparedSMask(), this.tempSMask = null, this.smaskStack.length = 0;
    for (const t of this.#u)
      this.#A(t);
    this.#u.length = 0, this.#i = null, this.#n = null, this.#a = null, this.#r = null, this.#o = 1, this.#h = null, this.#s = 0, this.#e = 0, this.cachedPatterns.clear();
    for (const t of this._cachedBitmapsMap.values()) {
      for (const e of t.values())
        typeof HTMLCanvasElement < "u" && e instanceof HTMLCanvasElement && (e.width = e.height = 0);
      t.clear();
    }
    this._cachedBitmapsMap.clear(), this.#f();
  }
  #f() {
    if (this.pageColors) {
      const t = this.filterFactory.addHCMFilter(this.pageColors.foreground, this.pageColors.background);
      if (t !== "none") {
        const e = this.ctx.filter;
        this.ctx.filter = t, this.ctx.drawImage(this.ctx.canvas, 0, 0), this.ctx.filter = e;
      }
    }
  }
  _scaleImage(t, e) {
    const s = t.width ?? t.displayWidth, i = t.height ?? t.displayHeight, n = Math.max(Math.hypot(e[0], e[1]), 1), r = Math.max(Math.hypot(e[2], e[3]), 1), a = [];
    let o = n, l = r, h = s, d = i;
    for (; o > 2 && h > 1 || l > 2 && d > 1; ) {
      let v = h, y = d;
      o > 2 && h > 1 && (v = Math.ceil(h / 2), o /= h / v), l > 2 && d > 1 && (y = Math.ceil(d / 2), l /= d / y), a.push({
        newWidth: v,
        newHeight: y
      }), h = v, d = y;
    }
    if (a.length === 0)
      return {
        img: t,
        paintWidth: s,
        paintHeight: i,
        tmpCanvas: null
      };
    if (a.length === 1) {
      const {
        newWidth: v,
        newHeight: y
      } = a[0], b = this.canvasFactory.create(v, y);
      return b.context.drawImage(t, 0, 0, s, i, 0, 0, v, y), {
        img: b.canvas,
        paintWidth: v,
        paintHeight: y,
        tmpCanvas: b
      };
    }
    let u = this.canvasFactory.create(1, 1), f = this.canvasFactory.create(1, 1), p = s, g = i, m = t;
    for (const {
      newWidth: v,
      newHeight: y
    } of a)
      this.canvasFactory.reset(f, v, y), f.context.drawImage(m, 0, 0, p, g, 0, 0, v, y), [u, f] = [f, u], m = u.canvas, p = v, g = y;
    return this.canvasFactory.destroy(f), {
      img: u.canvas,
      paintWidth: p,
      paintHeight: g,
      tmpCanvas: u
    };
  }
  _createMaskCanvas(t, e) {
    const s = this.ctx, {
      width: i,
      height: n
    } = e, r = this.current.fillColor, a = this.current.patternFill, o = ht(s);
    let l, h, d, u;
    if ((e.bitmap || e.data) && e.count > 1) {
      const C = e.bitmap || e.data.buffer;
      h = JSON.stringify(a ? o : [o.slice(0, 4), r]), l = this._cachedBitmapsMap.getOrInsertComputed(C, di);
      const I = l.get(h);
      if (I && !a) {
        const R = Math.round(Math.min(o[0], o[2]) + o[4]), D = Math.round(Math.min(o[1], o[3]) + o[5]);
        return this.dependencyTracker?.recordDependencies(t, jt.transformAndFill), {
          canvas: I,
          offsetX: R,
          offsetY: D
        };
      }
      d = I;
    }
    d || (u = this.canvasFactory.create(i, n), hn(u.context, e));
    let f = N.transform(o, [1 / i, 0, 0, -1 / n, 0, 0]);
    f = N.transform(f, [1, 0, 0, 1, 0, -n]);
    const p = ge.slice();
    N.axialAlignedBoundingBox([0, 0, i, n], f, p);
    const [g, m, v, y] = p, b = Math.round(v - g) || 1, w = Math.round(y - m) || 1, A = this.canvasFactory.create(b, w), S = A.context, E = g, T = m;
    S.translate(-E, -T), S.transform(...f);
    let x = null;
    if (!d) {
      const C = this._scaleImage(u.canvas, qt(S));
      d = C.img, x = C.tmpCanvas, d !== u.canvas && (this.canvasFactory.destroy(u), u = null), l && a && (l.set(h, d), x = null, u = null);
    }
    S.imageSmoothingEnabled = cn(ht(S), e.interpolate), hs(S, d, 0, 0, d.width, d.height, 0, 0, i, n), x && this.canvasFactory.destroy(x), u && this.canvasFactory.destroy(u), S.globalCompositeOperation = "source-in";
    const P = N.transform(qt(S), [1, 0, 0, 1, -E, -T]);
    return S.fillStyle = a ? r.getPattern(s, this, P, Ct.FILL, t) : r, S.fillRect(0, 0, i, n), l && !a && l.set(h, A.canvas), this.dependencyTracker?.recordDependencies(t, jt.transformAndFill), {
      canvas: A.canvas,
      canvasEntry: l && !a ? null : A,
      offsetX: Math.round(E),
      offsetY: Math.round(T)
    };
  }
  setLineWidth(t, e) {
    this.dependencyTracker?.recordSimpleData("lineWidth", t), e !== this.current.lineWidth && (this._cachedScaleForStroking[0] = -1), this.current.lineWidth = e, this.ctx.lineWidth = e;
  }
  setLineCap(t, e) {
    this.dependencyTracker?.recordSimpleData("lineCap", t), this.ctx.lineCap = fa[e];
  }
  setLineJoin(t, e) {
    this.dependencyTracker?.recordSimpleData("lineJoin", t), this.ctx.lineJoin = pa[e];
  }
  setMiterLimit(t, e) {
    this.dependencyTracker?.recordSimpleData("miterLimit", t), this.ctx.miterLimit = e;
  }
  setDash(t, e, s) {
    this.dependencyTracker?.recordSimpleData("dash", t);
    const i = this.ctx;
    i.setLineDash !== void 0 && (i.setLineDash(e), i.lineDashOffset = s);
  }
  setRenderingIntent(t, e) {
  }
  setFlatness(t, e) {
  }
  setGState(t, e) {
    for (const [s, i] of e)
      switch (s) {
        case "LW":
          this.setLineWidth(t, i);
          break;
        case "LC":
          this.setLineCap(t, i);
          break;
        case "LJ":
          this.setLineJoin(t, i);
          break;
        case "ML":
          this.setMiterLimit(t, i);
          break;
        case "D":
          this.setDash(t, i[0], i[1]);
          break;
        case "RI":
          this.setRenderingIntent(t, i);
          break;
        case "FL":
          this.setFlatness(t, i);
          break;
        case "Font":
          this.setFont(t, i[0], i[1]);
          break;
        case "CA":
          this.dependencyTracker?.recordSimpleData("strokeAlpha", t), this.current.strokeAlpha = i;
          break;
        case "ca":
          this.dependencyTracker?.recordSimpleData("fillAlpha", t), this.ctx.globalAlpha = this.current.fillAlpha = i;
          break;
        case "BM":
          this.dependencyTracker?.recordSimpleData("globalCompositeOperation", t), this.ctx.globalCompositeOperation = i;
          break;
        case "SMask":
          this.dependencyTracker?.recordSimpleData("SMask", t), this.current.activeSMask = i ? this.tempSMask : null, this.current.activeSMask && (this.current.activeSMask.blendMode = this.ctx.globalCompositeOperation), this.tempSMask = null, this.checkSMaskState(t);
          break;
        case "TR":
          this.dependencyTracker?.recordSimpleData("filter", t), this.ctx.filter = this.current.transferMaps = this.filterFactory.addFilter(i);
          break;
      }
  }
  get inSMaskMode() {
    return !!this.suspendedCtx;
  }
  _clearPreparedSMask() {
    this.smaskPreparedEntry && (this.canvasFactory.destroy(this.smaskPreparedEntry), this.smaskPreparedEntry = null), this.smaskPreparedFor = null, this.smaskPreparedOffsetX = 0, this.smaskPreparedOffsetY = 0, this.smaskPreparedOOBAlpha = null;
  }
  _ensurePreparedSMask(t) {
    t !== this.smaskPreparedFor && (this._clearPreparedSMask(), this._prepareSMaskCanvas(t));
  }
  checkSMaskState(t) {
    const e = this.inSMaskMode;
    this.current.activeSMask && !e ? this.beginSMaskMode(t) : !this.current.activeSMask && e ? this.endSMaskMode() : this.current.activeSMask && e && this._ensurePreparedSMask(this.current.activeSMask);
  }
  _prepareSMaskCanvas(t) {
    const {
      canvas: e,
      subtype: s,
      backdrop: i,
      transferMap: n
    } = t, r = s === "Luminosity" || s === "Alpha" && n;
    if (!r && !(s === "Luminosity" && i)) {
      this.smaskPreparedFor = t;
      return;
    }
    let a;
    if (s === "Luminosity" && i) {
      const [y, b, w] = ss(i), A = Math.round(0.3 * y + 0.59 * b + 0.11 * w);
      a = n?.[A] ?? A;
    } else
      a = n?.[0] ?? 0;
    const o = 4, {
      width: l,
      height: h
    } = this.ctx.canvas, d = e.width * e.height, u = l * h < o * d, f = r ? {
      url: s === "Alpha" ? this.filterFactory.addAlphaFilter(n) : this.filterFactory.addLuminosityFilter(n),
      subtype: s,
      transferMap: n
    } : null, p = s === "Luminosity" ? i : null;
    let g, m, v;
    u ? (g = this._bakeSMaskCanvas(e, t.offsetX, t.offsetY, l, h, p, f), m = 0, v = 0) : (g = this._bakeSMaskCanvas(e, 0, 0, e.width, e.height, p, f), m = t.offsetX, v = t.offsetY), this.smaskPreparedEntry = g, this.smaskPreparedFor = t, this.smaskPreparedOffsetX = m, this.smaskPreparedOffsetY = v, this.smaskPreparedOOBAlpha = !u && a !== 0 ? a : null;
  }
  _bakeSMaskCanvas(t, e, s, i, n, r, a) {
    !r && !a && st("_bakeSMaskCanvas with neither backdrop nor filter");
    const o = this.canvasFactory.create(i, n), l = o.context;
    if (l.drawImage(t, e, s), r && (l.globalCompositeOperation = "destination-atop", l.fillStyle = r, l.fillRect(0, 0, i, n)), !a)
      return o;
    const h = this.canvasFactory.create(i, n), d = h.context;
    d.filter = a.url;
    const u = at.isCanvasFilterSupported && d.filter !== "none" && d.filter !== "";
    if (d.drawImage(o.canvas, 0, 0), at.isCanvasFilterSupported && (d.filter = "none"), !u) {
      const f = d.getImageData(0, 0, i, n), {
        data: p
      } = f, {
        transferMap: g
      } = a;
      if (a.subtype === "Luminosity")
        for (let m = 0, v = p.length; m < v; m += 4) {
          const y = 0.3 * p[m] + 0.59 * p[m + 1] + 0.11 * p[m + 2] + 0.5 | 0;
          p[m] = p[m + 1] = p[m + 2] = 0, p[m + 3] = g?.[y] ?? y;
        }
      else
        for (let m = 3, v = p.length; m < v; m += 4)
          p[m] = g[p[m]];
      d.putImageData(f, 0, 0);
    }
    return this.canvasFactory.destroy(o), h;
  }
  beginSMaskMode(t) {
    if (this.inSMaskMode)
      throw new Error("beginSMaskMode called while already in smask mode");
    const {
      width: e,
      height: s
    } = this.ctx.canvas, i = this.canvasFactory.create(e, s);
    this.smaskScratchCanvas = i, this.suspendedCtx = this.ctx;
    const n = this.ctx = i.context;
    n.setTransform(this.suspendedCtx.getTransform()), fe(this.suspendedCtx, n), an(n, this.suspendedCtx), this._ensurePreparedSMask(this.current.activeSMask), this.setGState(t, [["BM", "source-over"]]);
  }
  endSMaskMode() {
    if (!this.inSMaskMode)
      throw new Error("endSMaskMode called while not in smask mode");
    this.ctx._removeMirroring(), fe(this.ctx, this.suspendedCtx), this.ctx = this.suspendedCtx, this.suspendedCtx = null, this.canvasFactory.destroy(this.smaskScratchCanvas), this.smaskScratchCanvas = null, this._clearPreparedSMask();
  }
  #g(t, e = null, s = 1) {
    const {
      width: i,
      height: n
    } = t, r = e ?? this.canvasFactory.create(i, n), a = r.context;
    s = Math.round(s * 255) / 255;
    const o = s < 1;
    o && this.#l === void 0 && (this.#l = at.isCanvasFilterSupported ? /* @__PURE__ */ new Map() : "none");
    let l = "none";
    if (o && this.#l instanceof Map && (l = this.#l.getOrInsertComputed(s, () => this.filterFactory.addKnockoutFilter(s))), !o || l !== "none")
      return e && (a.save(), a.setTransform(1, 0, 0, 1, 0, 0), a.clearRect(0, 0, i, n), a.restore()), a.filter = l, a.drawImage(t, 0, 0), a.filter = "none", r;
    const h = t.getContext("2d", {
      willReadFrequently: !0
    }).getImageData(0, 0, i, n), d = a.createImageData(i, n), u = h.data, f = d.data, p = s > 0 ? 1 / s : 1e6;
    for (let g = 3, m = u.length; g < m; g += 4)
      f[g] = Math.min(Math.round(u[g] * p), 255);
    return a.putImageData(d, 0, 0), r;
  }
  #m(t, e, s, i) {
    let n = t?.[e] ?? null;
    if (n && (n.canvas.width !== s || n.canvas.height !== i) && (this.canvasFactory.destroy(n), n = null), !n)
      return n = this.canvasFactory.create(s, i), t && (t[e] = n), n;
    const r = n.context;
    return r.save(), r.setTransform(1, 0, 0, 1, 0, 0), r.clearRect(0, 0, s, i), r.restore(), n;
  }
  #c(t, e, s = {}) {
    const {
      backdropCanvas: i = null,
      destTransform: n = [1, 0, 0, 1, 0, 0],
      backdropOffset: r = [0, 0],
      reuseMaskEntry: a = null,
      poolMeta: o = null,
      sourceAlpha: l = 1,
      sourceFilter: h = "none",
      knockoutAlpha: d = 1
    } = s, {
      width: u,
      height: f
    } = e, p = this.#g(e, a, d), g = t.globalCompositeOperation;
    if (t.save(), t.setTransform(...n), t.globalAlpha = 1, at.isCanvasFilterSupported && (t.filter = "none"), t.globalCompositeOperation = "destination-out", t.drawImage(p.canvas, 0, 0), i) {
      const [m, v] = r, y = this.#m(o, "knockoutBackdropEntry", u, f), b = y.context;
      b.drawImage(i, m, v, u, f, 0, 0, u, f), b.globalCompositeOperation = "destination-in", b.drawImage(p.canvas, 0, 0), b.globalCompositeOperation = "source-over", t.globalCompositeOperation = "destination-over", t.drawImage(y.canvas, 0, 0), o || this.canvasFactory.destroy(y);
    }
    t.globalCompositeOperation = g, t.globalAlpha = l, at.isCanvasFilterSupported && (t.filter = h ?? "none"), t.drawImage(e, 0, 0), t.restore(), a || this.canvasFactory.destroy(p);
  }
  #p(t = 1) {
    if (this.#e === 0 || this.#s > 0 || !this.contentVisible)
      return !1;
    this.#s++, this.#o = t;
    const e = this.#u.at(-1), {
      canvas: s
    } = this.ctx, i = this.#m(e, "knockoutTempEntry", s.width, s.height);
    this.#i = i;
    const n = i.context;
    return n.save(), n.setTransform(this.ctx.getTransform()), fe(this.ctx, n), this.#r = n.globalCompositeOperation, n.globalCompositeOperation = "source-over", an(n, this.ctx), this.#h = e, this.#n = this.ctx, this.#a = this.suspendedCtx, this.ctx = n, this.inSMaskMode && (this.suspendedCtx = n), !0;
  }
  #v(t) {
    if (!t)
      return;
    const e = this.#i, s = this.#n, i = this.#a, n = e.context;
    this.#i = null, this.#n = null, this.#a = null, this.inSMaskMode && this.suspendedCtx === n && this.ctx !== n && this.endSMaskMode(), this.inSMaskMode && (this.suspendedCtx = i), this.ctx._removeMirroring(), this.ctx.globalCompositeOperation = this.#r, this.#r = null, fe(this.ctx, s), this.ctx = s;
    const r = this.#h;
    this.#h = null;
    const a = this.#o;
    this.#o = 1;
    try {
      this.#c(i ?? s, e.canvas, {
        backdropCanvas: r?.backdropCtx?.canvas ?? null,
        backdropOffset: r?.backdropCtx ? [r.offsetX, r.offsetY] : [0, 0],
        reuseMaskEntry: r?.knockoutMaskEntry ?? null,
        poolMeta: r,
        knockoutAlpha: a
      });
    } finally {
      n.restore(), this.#s--, r || this.canvasFactory.destroy(e);
    }
  }
  compose(t) {
    if (!this.current.activeSMask)
      return;
    t = t ? [Math.floor(t[0]), Math.floor(t[1]), Math.ceil(t[2]), Math.ceil(t[3])] : [0, 0, this.ctx.canvas.width, this.ctx.canvas.height];
    const e = this.current.activeSMask, s = this.suspendedCtx, i = this.#s > 0 && s === this.ctx;
    this.composeSMask(i ? null : s, e, this.ctx, t), !i && (this.ctx.save(), this.ctx.setTransform(1, 0, 0, 1, 0, 0), this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height), this.ctx.restore());
  }
  composeSMask(t, e, s, i) {
    const n = i[0], r = i[1], a = i[2] - n, o = i[3] - r;
    if (a === 0 || o === 0)
      return;
    const l = this.smaskPreparedEntry;
    if (l) {
      let h = n, d = r, u = a, f = o;
      const p = this.smaskPreparedOOBAlpha, g = p !== null;
      if (g) {
        h = Math.max(n, e.offsetX), d = Math.max(r, e.offsetY);
        const m = Math.min(n + a, e.offsetX + e.canvas.width), v = Math.min(r + o, e.offsetY + e.canvas.height);
        u = m - h, f = v - d;
      }
      if (u > 0 && f > 0) {
        const m = h - this.smaskPreparedOffsetX, v = d - this.smaskPreparedOffsetY;
        s.save(), s.globalAlpha = 1, s.setTransform(1, 0, 0, 1, 0, 0);
        const y = new Path2D();
        y.rect(h, d, u, f), s.clip(y), s.globalCompositeOperation = "destination-in", s.drawImage(l.canvas, m, v, u, f, h, d, u, f), s.restore();
      }
      g && p < 255 && this._applySMaskOOBAlpha(s, n, r, a, o, h, d, h + u, d + f, p);
    } else
      this.genericComposeSMask(e, s, a, o, n, r);
    t && (t.save(), t.globalAlpha = 1, t.globalCompositeOperation = e.blendMode || "source-over", t.setTransform(1, 0, 0, 1, 0, 0), t.drawImage(s.canvas, n, r, a, o, n, r, a, o), t.restore());
  }
  _applySMaskOOBAlpha(t, e, s, i, n, r, a, o, l, h) {
    const d = r < o && a < l;
    if (d && r === e && a === s && o === e + i && l === s + n)
      return;
    const u = new Path2D();
    u.rect(e, s, i, n), d && u.rect(r, a, o - r, l - a), t.save(), t.globalAlpha = h / 255, t.setTransform(1, 0, 0, 1, 0, 0), t.clip(u, "evenodd"), t.globalCompositeOperation = "destination-in", t.fillStyle = "#000000", t.fillRect(e, s, i, n), t.restore();
  }
  genericComposeSMask(t, e, s, i, n, r) {
    const {
      context: a,
      offsetX: o,
      offsetY: l
    } = t;
    e.save(), e.globalAlpha = 1, e.setTransform(1, 0, 0, 1, 0, 0);
    const h = new Path2D();
    h.rect(n, r, s, i), e.clip(h), e.globalCompositeOperation = "destination-in", e.drawImage(a.canvas, n - o, r - l, s, i, n, r, s, i), e.restore();
  }
  save(t) {
    this.inSMaskMode && fe(this.ctx, this.suspendedCtx), this.ctx.save();
    const e = this.current;
    this.stateStack.push(e), this.current = e.clone(), this.dependencyTracker?.save(t);
  }
  restore(t) {
    if (this.dependencyTracker?.restore(t), this.stateStack.length === 0) {
      this.inSMaskMode && this.endSMaskMode();
      return;
    }
    this.current = this.stateStack.pop(), this.ctx.restore(), this.inSMaskMode && (fe(this.suspendedCtx, this.ctx), this.ctx.setTransform(this.suspendedCtx.getTransform())), this.checkSMaskState(t), this.pendingClip = null, this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  transform(t, e, s, i, n, r, a) {
    this.dependencyTracker?.recordIncrementalData("transform", t), this.ctx.transform(e, s, i, n, r, a), this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null;
  }
  constructPath(t, e, s, i) {
    let [n] = s;
    if (!i) {
      n ||= s[0] = new Path2D(), e !== se.stroke && e !== se.closeStroke && (this.current.tilingPatternDims = null), this[e](t, n);
      return;
    }
    if (this.dependencyTracker !== null) {
      const a = e === se.stroke ? this.current.lineWidth / 2 : 0;
      this.dependencyTracker.resetBBox(t).recordBBox(t, this.ctx, i[0] - a, i[2] + a, i[1] - a, i[3] + a).recordDependencies(t, ["transform"]);
    }
    n instanceof Path2D || (n = s[0] = xn(n)), N.axialAlignedBoundingBox(i, ht(this.ctx), this.current.minMax);
    const r = this.current.tilingPatternDims;
    if (r && e !== se.stroke && e !== se.closeStroke && this.current.fillColor instanceof Ye) {
      const a = N.intersect(this.current.clipBox, this.current.minMax);
      a ? this.current.fillColor.updatePatternDims(a, r) : this.current.tilingPatternDims = null;
    }
    this[e](t, n), this._pathStartIdx = t;
  }
  closePath(t) {
    this.ctx.closePath();
  }
  stroke(t, e, s = !0) {
    const i = s && this.#p(this.current.strokeAlpha), n = this.ctx, r = this.current.strokeColor;
    if (n.globalAlpha = this.current.strokeAlpha, this.contentVisible)
      if (typeof r == "object" && r?.getPattern) {
        const a = r.isModifyingCurrentTransform() ? n.getTransform() : null;
        if (n.save(), n.strokeStyle = r.getPattern(n, this, qt(n), Ct.STROKE, t), a) {
          const o = new Path2D();
          o.addPath(e, n.getTransform().invertSelf().multiplySelf(a)), e = o;
        }
        this.rescaleAndStroke(e, !1), n.restore();
      } else
        this.rescaleAndStroke(e, !0);
    this.dependencyTracker?.recordDependencies(t, jt.stroke), s && this.consumePath(t, e, this.current.getClippedPathBoundingBox(Ct.STROKE, ht(this.ctx))), n.globalAlpha = this.current.fillAlpha, this.#v(i);
  }
  closeStroke(t, e) {
    this.stroke(t, e);
  }
  fill(t, e, s = !0) {
    const i = s && this.#p(this.current.fillAlpha), n = this.ctx, r = this.current.fillColor, a = this.current.patternFill;
    let o = !1;
    const l = this.current.getClippedPathBoundingBox();
    if (this.dependencyTracker?.recordDependencies(t, jt.fill), a) {
      const h = this.current.tilingPatternDims, d = h && r.canSkipPatternCanvas(h);
      if (d) {
        r.drawPattern(this, e, this.pendingEOFill, d, t), this.pendingEOFill = !1, s && this.consumePath(t, e, l), this.current.tilingPatternDims = null, this.#v(i);
        return;
      }
      const u = r.isModifyingCurrentTransform() ? n.getTransform() : null;
      if (this.dependencyTracker?.save(t), n.save(), n.fillStyle = r.getPattern(n, this, qt(n), Ct.FILL, t), u) {
        const f = new Path2D();
        f.addPath(e, n.getTransform().invertSelf().multiplySelf(u)), e = f;
      }
      o = !0;
    }
    this.contentVisible && l !== null && (this.pendingEOFill ? (n.fill(e, "evenodd"), this.pendingEOFill = !1) : n.fill(e)), o && (n.restore(), this.dependencyTracker?.restore(t)), s && this.consumePath(t, e, l), this.#v(i);
  }
  eoFill(t, e) {
    this.pendingEOFill = !0, this.fill(t, e);
  }
  fillStroke(t, e) {
    const s = this.#p(Math.min(this.current.fillAlpha, this.current.strokeAlpha));
    this.fill(t, e, !1), this.stroke(t, e, !1), this.consumePath(t, e), this.#v(s);
  }
  eoFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  closeFillStroke(t, e) {
    this.fillStroke(t, e);
  }
  closeEOFillStroke(t, e) {
    this.pendingEOFill = !0, this.fillStroke(t, e);
  }
  endPath(t, e) {
    this.consumePath(t, e);
  }
  rawFillPath(t, e) {
    const s = this.#p(this.current.fillAlpha);
    this.ctx.fill(e), this.dependencyTracker?.recordDependencies(t, jt.rawFillPath).recordOperation(t), this.#v(s);
  }
  clip(t) {
    this.dependencyTracker?.recordFutureForcedDependency("clipMode", t), this.pendingClip = ga;
  }
  eoClip(t) {
    this.dependencyTracker?.recordFutureForcedDependency("clipMode", t), this.pendingClip = dn;
  }
  beginText(t) {
    this.current.textMatrix = null, this.current.textMatrixScale = 1, this.current.x = this.current.lineX = 0, this.current.y = this.current.lineY = 0, this.dependencyTracker?.recordOpenMarker(t).resetIncrementalData("sameLineText").resetIncrementalData("moveText", t);
  }
  endText(t) {
    const e = this.pendingTextPaths, s = this.ctx;
    if (this.dependencyTracker) {
      const {
        dependencyTracker: i
      } = this;
      e !== void 0 && i.recordFutureForcedDependency("textClip", i.getOpenMarker()).recordFutureForcedDependency("textClip", t), i.recordCloseMarker(t);
    }
    if (e !== void 0) {
      const i = new Path2D(), n = s.getTransform().invertSelf();
      for (const {
        transform: r,
        x: a,
        y: o,
        fontSize: l,
        path: h
      } of e)
        h && i.addPath(h, new DOMMatrix(r).preMultiplySelf(n).translate(a, o).scale(l, -l));
      s.clip(i);
    }
    delete this.pendingTextPaths;
  }
  setCharSpacing(t, e) {
    this.dependencyTracker?.recordSimpleData("charSpacing", t), this.current.charSpacing = e;
  }
  setWordSpacing(t, e) {
    this.dependencyTracker?.recordSimpleData("wordSpacing", t), this.current.wordSpacing = e;
  }
  setHScale(t, e) {
    this.dependencyTracker?.recordSimpleData("hScale", t), this.current.textHScale = e / 100;
  }
  setLeading(t, e) {
    this.dependencyTracker?.recordSimpleData("leading", t), this.current.leading = -e;
  }
  setFont(t, e, s) {
    this.dependencyTracker?.recordSimpleData("font", t).recordSimpleDataFromNamed("fontObj", e, t);
    const i = this.commonObjs.get(e), n = this.current;
    if (!i)
      throw new Error(`Can't find font for ${e}`);
    if (n.fontMatrix = i.fontMatrix || Ks, (n.fontMatrix[0] === 0 || n.fontMatrix[3] === 0) && V("Invalid font matrix for font " + e), s < 0 ? (s = -s, n.fontDirection = -1) : n.fontDirection = 1, this.current.font = i, this.current.fontSize = s, i.isType3Font)
      return;
    const r = i.loadedName || "sans-serif", a = i.systemFontInfo?.css || `"${r}", ${i.fallbackName}`;
    let o = "normal";
    i.black ? o = "900" : i.bold && (o = "bold");
    const l = i.italic ? "italic" : "normal", h = ct(s, ca, da);
    this.current.fontSizeScale = s / h, this.ctx.font = `${l} ${o} ${h}px ${a}`;
  }
  setTextRenderingMode(t, e) {
    this.dependencyTracker?.recordSimpleData("textRenderingMode", t), this.current.textRenderingMode = e;
  }
  setTextRise(t, e) {
    this.dependencyTracker?.recordSimpleData("textRise", t), this.current.textRise = e;
  }
  moveText(t, e, s) {
    this.dependencyTracker?.resetIncrementalData("sameLineText").recordIncrementalData("moveText", t), this.current.x = this.current.lineX += e, this.current.y = this.current.lineY += s;
  }
  setLeadingMoveText(t, e, s) {
    this.setLeading(t, -s), this.moveText(t, e, s);
  }
  setTextMatrix(t, e) {
    this.dependencyTracker?.resetIncrementalData("sameLineText").recordSimpleData("textMatrix", t);
    const {
      current: s
    } = this;
    s.textMatrix = e, s.textMatrixScale = Math.hypot(e[0], e[1]), s.x = s.lineX = 0, s.y = s.lineY = 0;
  }
  nextLine(t) {
    this.moveText(t, 0, this.current.leading), this.dependencyTracker?.recordIncrementalData("moveText", this.dependencyTracker.getSimpleIndex("leading") ?? t);
  }
  #y(t, e, s) {
    const i = new Path2D();
    return i.addPath(t, new DOMMatrix(s).invertSelf().multiplySelf(e)), i;
  }
  paintChar(t, e, s, i, n, r) {
    const a = this.ctx, o = this.current, l = o.font, h = o.textRenderingMode, d = o.fontSize / o.fontSizeScale, u = h & At.FILL_STROKE_MASK, f = !!(h & At.ADD_TO_PATH_FLAG), p = o.patternFill && !l.missingFile, g = o.patternStroke && !l.missingFile;
    let m;
    if ((l.disableFontFace || f || p || g) && !l.missingFile && (m = l.getPathGenerator(this.commonObjs, e)), m && (l.disableFontFace || p || g)) {
      a.save(), a.translate(s, i), a.scale(d, -d), this.dependencyTracker?.recordCharacterBBox(t, a, l);
      let v;
      if (u === At.FILL || u === At.FILL_STROKE)
        if (n) {
          v = a.getTransform(), a.setTransform(...n);
          const y = this.#y(m, v, n);
          a.fill(y);
        } else
          a.fill(m);
      if (u === At.STROKE || u === At.FILL_STROKE)
        if (r) {
          v ||= a.getTransform(), a.setTransform(...r);
          const {
            a: y,
            b,
            c: w,
            d: A
          } = v, S = N.inverseTransform(r), E = N.transform([y, b, w, A, 0, 0], S);
          N.singularValueDecompose2dScale(E, Ut), a.lineWidth *= Math.max(Ut[0], Ut[1]) / d, a.stroke(this.#y(m, v, r));
        } else
          a.lineWidth /= d, a.stroke(m);
      a.restore();
    } else
      (u === At.FILL || u === At.FILL_STROKE) && (a.fillText(e, s, i), this.dependencyTracker?.recordCharacterBBox(t, a, l, d, s, i, () => a.measureText(e))), (u === At.STROKE || u === At.FILL_STROKE) && (this.dependencyTracker && this.dependencyTracker?.recordCharacterBBox(t, a, l, d, s, i, () => a.measureText(e)).recordDependencies(t, jt.stroke), a.strokeText(e, s, i));
    f && ((this.pendingTextPaths ||= []).push({
      transform: ht(a),
      x: s,
      y: i,
      fontSize: d,
      path: m
    }), this.dependencyTracker?.recordCharacterBBox(t, a, l, d, s, i));
  }
  get isFontSubpixelAAEnabled() {
    const t = this.canvasFactory.create(10, 10), e = t.context;
    e.scale(1.5, 1), e.fillText("I", 0, 10);
    const s = e.getImageData(0, 0, 10, 10).data;
    this.canvasFactory.destroy(t);
    let i = !1;
    for (let n = 3; n < s.length; n += 4)
      if (s[n] > 0 && s[n] < 255) {
        i = !0;
        break;
      }
    return j(this, "isFontSubpixelAAEnabled", i);
  }
  showText(t, e) {
    this.dependencyTracker && (this.dependencyTracker.recordDependencies(t, jt.showText).resetBBox(t), this.current.textRenderingMode & At.ADD_TO_PATH_FLAG && this.dependencyTracker.recordFutureForcedDependency("textClip", t).inheritPendingDependenciesAsFutureForcedDependencies());
    const s = this.current, i = s.font;
    if (i.isType3Font) {
      const I = this.#p(s.fillAlpha);
      this.showType3Text(t, e), this.dependencyTracker?.recordShowTextOperation(t), this.#v(I);
      return;
    }
    const n = s.fontSize;
    if (n === 0) {
      this.dependencyTracker?.recordOperation(t);
      return;
    }
    const r = this.#p(s.fillAlpha), a = this.ctx, o = s.fontSizeScale, l = s.charSpacing, h = s.wordSpacing, d = s.fontDirection, u = s.textHScale * d, f = e.length, p = i.vertical, g = p ? 1 : -1, m = i.defaultVMetrics, v = n * s.fontMatrix[0], y = s.textRenderingMode === At.FILL && !i.disableFontFace && !s.patternFill;
    a.save(), s.textMatrix && a.transform(...s.textMatrix), a.translate(s.x, s.y + s.textRise), d > 0 ? a.scale(u, -1) : a.scale(u, 1);
    let b, w;
    const A = s.textRenderingMode & At.FILL_STROKE_MASK, S = A === At.FILL || A === At.FILL_STROKE, E = A === At.STROKE || A === At.FILL_STROKE;
    let T = s.lineWidth;
    const x = s.textMatrixScale;
    if (x === 0 || T === 0 ? E && (T = this.getSinglePixelWidth()) : T /= x, o !== 1 && (a.scale(o, o), T /= o), a.lineWidth = T, S && s.patternFill) {
      a.save();
      const I = s.fillColor.getPattern(a, this, qt(a), Ct.FILL, t);
      b = ht(a), a.restore(), a.fillStyle = I;
    }
    if (E && s.patternStroke) {
      a.save();
      const I = s.strokeColor.getPattern(a, this, qt(a), Ct.STROKE, t);
      w = ht(a), a.restore(), a.strokeStyle = I;
    }
    if (i.isInvalidPDFjsFont) {
      const I = [];
      let R = 0;
      for (const _ of e)
        I.push(_.unicode), R += _.width;
      const D = I.join("");
      if (a.fillText(D, 0, 0), this.dependencyTracker !== null) {
        const _ = a.measureText(D);
        this.dependencyTracker.recordBBox(t, this.ctx, -_.actualBoundingBoxLeft, _.actualBoundingBoxRight, -_.actualBoundingBoxAscent, _.actualBoundingBoxDescent).recordShowTextOperation(t);
      }
      s.x += R * v * u, a.restore(), this.compose(), this.#v(r);
      return;
    }
    let P = 0, C;
    for (C = 0; C < f; ++C) {
      const I = e[C];
      if (typeof I == "number") {
        P += g * I * n / 1e3;
        continue;
      }
      let R = !1;
      const D = (I.isSpace ? h : 0) + l, _ = I.fontChar, M = I.accent;
      let k, $, U = I.width;
      if (p) {
        const Y = I.vmetric || m, J = -(I.vmetric ? Y[1] : U * 0.5) * v, rt = Y[2] * v;
        U = Y ? -Y[0] : U, k = J / o, $ = (P + rt) / o;
      } else
        k = P / o, $ = 0;
      let tt;
      if (i.remeasure && U > 0) {
        tt = a.measureText(_);
        const Y = tt.width * 1e3 / n * o;
        if (U < Y && this.isFontSubpixelAAEnabled) {
          const J = U / Y;
          R = !0, a.save(), a.scale(J, 1), k /= J;
        } else U !== Y && (k += (U - Y) / 2e3 * n / o);
      }
      if (this.contentVisible && (I.isInFont || i.missingFile)) {
        if (y && !M)
          a.fillText(_, k, $), this.dependencyTracker?.recordCharacterBBox(t, a, tt ? {
            bbox: null
          } : i, n / o, k, $, () => tt ?? a.measureText(_));
        else if (this.paintChar(t, _, k, $, b, w), M) {
          const Y = k + n * M.offset.x / o, J = $ - n * M.offset.y / o;
          this.paintChar(t, M.fontChar, Y, J, b, w);
        }
      }
      const vt = p ? U * v - D * d : U * v + D * d;
      P += vt, R && a.restore();
    }
    p ? s.y -= P : s.x += P * u, a.restore(), this.compose(), this.dependencyTracker?.recordShowTextOperation(t), this.#v(r);
  }
  showType3Text(t, e) {
    const s = this.ctx, i = this.current, n = i.font, r = i.fontSize, a = i.fontDirection, o = n.vertical ? 1 : -1, l = i.charSpacing, h = i.wordSpacing, d = i.textHScale * a, u = i.fontMatrix || Ks, f = e.length, p = i.textRenderingMode === At.INVISIBLE;
    let g, m, v, y;
    if (p || r === 0)
      return;
    this._cachedScaleForStroking[0] = -1, this._cachedGetSinglePixelWidth = null, s.save(), i.textMatrix && s.transform(...i.textMatrix), s.translate(i.x, i.y + i.textRise), s.scale(d, a);
    const b = this.dependencyTracker;
    for (this.dependencyTracker = b ? new Ze(b, t) : null, g = 0; g < f; ++g) {
      if (m = e[g], typeof m == "number") {
        y = o * m * r / 1e3, this.ctx.translate(y, 0), i.x += y * d;
        continue;
      }
      const w = (m.isSpace ? h : 0) + l, A = n.charProcOperatorList.get(m.operatorListId);
      A ? this.contentVisible && (this.save(), A.fnArray[0] === se.setCharWidth && (i.fillAlpha = i.strokeAlpha = 1, s.globalAlpha = 1), s.scale(r, r), s.transform(...u), this.executeOperatorList(A), this.restore()) : V(`Type3 character "${m.operatorListId}" is not available.`);
      const S = [m.width, 0];
      N.applyTransform(S, u), v = S[0] * r + w, s.translate(v, 0), i.x += v * d;
    }
    s.restore(), b && (this.dependencyTracker = b);
  }
  setCharWidth(t, e, s) {
  }
  setCharWidthAndBounds(t, e, s, i, n, r, a) {
    const o = new Path2D();
    o.rect(i, n, r - i, a - n), this.ctx.clip(o), this.dependencyTracker?.recordBBox(t, this.ctx, i, r, n, a).recordClipBox(t, this.ctx, i, r, n, a), this.endPath(t);
  }
  getColorN_Pattern(t, e) {
    let s;
    if (e[0] === "TilingPattern") {
      const i = this.baseTransform || ht(this.ctx), n = {
        createCanvasGraphics: (r, a) => new Ae(r, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
          optionalContentConfig: this.optionalContentConfig,
          markedContentStack: this.markedContentStack
        }, void 0, void 0, this.dependencyTracker ? new Ze(this.dependencyTracker, a, !0) : null)
      };
      s = new Ye(e, this.ctx, n, i);
    } else
      s = this._getPattern(t, e[1], e[2]);
    return s;
  }
  setStrokeColorN(t, ...e) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.current.strokeColor = this.getColorN_Pattern(t, e), this.current.patternStroke = !0;
  }
  setFillColorN(t, ...e) {
    this.dependencyTracker?.recordSimpleData("fillColor", t);
    const s = this.current.fillColor = this.getColorN_Pattern(t, e);
    this.current.patternFill = !0, this.current.tilingPatternDims = s instanceof Ye ? [0, 0, 0, 0] : null;
  }
  setStrokeRGBColor(t, e) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = e, this.current.patternStroke = !1;
  }
  setStrokeTransparent(t) {
    this.dependencyTracker?.recordSimpleData("strokeColor", t), this.ctx.strokeStyle = this.current.strokeColor = "transparent", this.current.patternStroke = !1;
  }
  setFillRGBColor(t, e) {
    this.dependencyTracker?.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = e, this.current.patternFill = !1, this.current.tilingPatternDims = null;
  }
  setFillTransparent(t) {
    this.dependencyTracker?.recordSimpleData("fillColor", t), this.ctx.fillStyle = this.current.fillColor = "transparent", this.current.patternFill = !1, this.current.tilingPatternDims = null;
  }
  _getPattern(t, e, s = null) {
    const i = this.cachedPatterns.getOrInsertComputed(e, () => ha(this.getObject(t, e)));
    return s && (i.matrix = s), i;
  }
  shadingFill(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.#p(this.current.fillAlpha), i = this.ctx;
    this.save(t);
    const n = this._getPattern(t, e);
    i.fillStyle = n.getPattern(i, this, qt(i), Ct.SHADING, t);
    const r = qt(i);
    if (r) {
      const {
        width: a,
        height: o
      } = i.canvas, l = ge.slice();
      N.axialAlignedBoundingBox([0, 0, a, o], r, l);
      const [h, d, u, f] = l;
      this.ctx.fillRect(h, d, u - h, f - d);
    } else
      this.ctx.fillRect(-1e10, -1e10, 2e10, 2e10);
    this.dependencyTracker?.resetBBox(t).recordFullPageBBox(t).recordDependencies(t, jt.transform).recordDependencies(t, jt.fill).recordOperation(t), this.compose(this.current.getClippedPathBoundingBox()), this.restore(t), this.#v(s);
  }
  beginInlineImage() {
    st("Should not call beginInlineImage");
  }
  beginImageData() {
    st("Should not call beginImageData");
  }
  paintFormXObjectBegin(t, e, s) {
    if (this.contentVisible && (this.save(t), this.baseTransformStack.push(this.baseTransform), e && this.transform(t, ...e), this.baseTransform = ht(this.ctx), s)) {
      N.axialAlignedBoundingBox(s, this.baseTransform, this.current.minMax);
      const [i, n, r, a] = s, o = new Path2D();
      o.rect(i, n, r - i, a - n), this.ctx.clip(o), this.dependencyTracker?.recordClipBox(t, this.ctx, i, r, n, a), this.endPath(t);
    }
  }
  paintFormXObjectEnd(t) {
    this.contentVisible && (this.restore(t), this.baseTransform = this.baseTransformStack.pop());
  }
  beginGroup(t, e) {
    if (!this.contentVisible)
      return;
    this.save(t);
    const {
      inSMaskMode: s
    } = this;
    s && (this.endSMaskMode(), this.current.activeSMask = null);
    const i = this.ctx;
    if ((!e.needsIsolation || !e.isolated && !e.hasSoftMask) && !e.knockout && !e.isGray && this.#e === 0 && i.globalAlpha === 1 && i.globalCompositeOperation === "source-over" && !s) {
      if (e.bbox) {
        let w = new Path2D();
        const [A, S, E, T] = e.bbox;
        if (w.rect(A, S, E - A, T - S), e.matrix) {
          const x = new Path2D();
          x.addPath(w, new DOMMatrix(e.matrix)), w = x;
        }
        i.clip(w);
      }
      this.groupStack.push(null), this.#u.push(null), this.groupLevel++;
      return;
    }
    !e.isolated && !e.knockout && this.#e === 0 && Ps("TODO: Fully support non-isolated non-knockout groups.");
    const n = ht(i);
    e.matrix && i.transform(...e.matrix);
    const r = [0, 0, i.canvas.width, i.canvas.height];
    let a;
    e.bbox ? (a = ge.slice(), N.axialAlignedBoundingBox(e.bbox, ht(i), a), a = N.intersect(a, r) || [0, 0, 0, 0]) : a = r;
    const o = Math.floor(a[0]), l = Math.floor(a[1]), h = Math.max(Math.ceil(a[2]) - o, 1), d = Math.max(Math.ceil(a[3]) - l, 1);
    this.current.startNewPathAndClipBox([0, 0, h, d]);
    const u = this.canvasFactory.create(h, d);
    e.smask && this.smaskGroupCanvases.push(u);
    const f = u.context, p = e.knockout && !e.isolated ? i : null, g = !e.isolated && !e.knockout && !e.smask && e.needsIsolation && this.#e > 0, m = e.knockout ? this.canvasFactory.create(h, d) : null, v = this.#e;
    e.knockout ? this.#e++ : this.#e = 0, f.translate(-o, -l), f.transform(...n);
    const y = !e.isolated && !e.smask && e.needsIsolation, b = y && !s && v === 0 && !e.knockout && !e.isGray && e.hasSoftMask && i.globalAlpha === 1 && i.globalCompositeOperation === "source-over" && this.current.transferMaps === "none";
    if (y && (s || b) && (f.save(), f.setTransform(1, 0, 0, 1, 0, 0), f.drawImage(i.canvas, -o, -l), f.restore()), e.bbox) {
      let w = new Path2D();
      const [A, S, E, T] = e.bbox;
      if (w.rect(A, S, E - A, T - S), e.matrix) {
        const x = new Path2D();
        x.addPath(w, new DOMMatrix(e.matrix)), w = x;
      }
      f.clip(w);
    }
    e.smask && this.smaskStack.push({
      canvas: u.canvas,
      context: f,
      offsetX: o,
      offsetY: l,
      subtype: e.smask.subtype,
      backdrop: e.smask.backdrop,
      transferMap: e.smask.transferMap || null
    }), (!e.smask || this.dependencyTracker) && (i.setTransform(1, 0, 0, 1, 0, 0), i.translate(o, l), i.save()), fe(i, f), this.ctx = f, this.dependencyTracker?.inheritSimpleDataAsFutureForcedDependencies(["fillAlpha", "strokeAlpha", "globalCompositeOperation"]).pushBaseTransform(i), this.setGState(t, [["BM", "source-over"], ["ca", 1], ["CA", 1], ["TR", null]]), this.groupStack.push(i), this.#u.push({
      backdropCtx: p,
      savedKnockoutLevel: v,
      offsetX: o,
      offsetY: l,
      hasInnerBackdrop: g,
      replaceBackdrop: b,
      knockoutMaskEntry: m,
      knockoutTempEntry: null,
      knockoutBackdropEntry: null
    }), this.groupLevel++;
  }
  endGroup(t, e) {
    if (!this.contentVisible)
      return;
    this.groupLevel--;
    const s = this.ctx, i = this.groupStack.pop(), n = this.#u.pop();
    if (n && (this.#e = n.savedKnockoutLevel), i === null) {
      this.restore(t);
      return;
    }
    if (e.isGray && this.#b(s), this.ctx = i, this.ctx.imageSmoothingEnabled = !1, this.dependencyTracker?.popBaseTransform(), e.smask)
      this.tempSMask = this.smaskStack.pop(), this.restore(t), this.dependencyTracker && (this.ctx.restore(), this.inSMaskMode && this.ctx.setTransform(this.suspendedCtx.getTransform())), this.#A(n);
    else {
      this.ctx.restore();
      const r = ht(this.ctx);
      this.restore(t), this.ctx.save(), this.ctx.setTransform(...r);
      const a = ge.slice();
      N.axialAlignedBoundingBox([0, 0, s.canvas.width, s.canvas.height], r, a);
      const o = this.#u.at(-1);
      if (this.#e > 0)
        if (n.hasInnerBackdrop) {
          const {
            width: l,
            height: h
          } = s.canvas, d = this.canvasFactory.create(l, h), u = d.context;
          u.drawImage(i.canvas, n.offsetX, n.offsetY, l, h, 0, 0, l, h), u.globalCompositeOperation = "source-over", u.drawImage(s.canvas, 0, 0);
          const f = this.#g(s.canvas);
          u.globalCompositeOperation = "destination-in", u.drawImage(f.canvas, 0, 0);
          const p = this.ctx.globalCompositeOperation, g = this.ctx.globalAlpha, m = this.ctx.filter;
          this.ctx.save(), this.ctx.setTransform(...r), this.ctx.globalAlpha = 1, at.isCanvasFilterSupported && (this.ctx.filter = "none"), this.ctx.globalCompositeOperation = "destination-out", this.ctx.drawImage(f.canvas, 0, 0), this.ctx.globalCompositeOperation = p, this.ctx.globalAlpha = g, at.isCanvasFilterSupported && (this.ctx.filter = m ?? "none"), this.ctx.drawImage(d.canvas, 0, 0), this.ctx.restore(), this.canvasFactory.destroy(f), this.canvasFactory.destroy(d);
        } else {
          const l = o?.backdropCtx ?? null;
          this.#c(this.ctx, s.canvas, {
            backdropCanvas: l?.canvas ?? null,
            destTransform: r,
            backdropOffset: l ? [o.offsetX + n.offsetX, o.offsetY + n.offsetY] : [0, 0],
            sourceAlpha: this.ctx.globalAlpha,
            sourceFilter: this.ctx.filter
          });
        }
      else {
        if (n.replaceBackdrop) {
          const l = new Path2D();
          l.rect(0, 0, s.canvas.width, s.canvas.height), this.ctx.clip(l), this.ctx.globalCompositeOperation = "copy";
        }
        this.ctx.drawImage(s.canvas, 0, 0);
      }
      this.ctx.restore(), this.canvasFactory.destroy({
        canvas: s.canvas,
        context: s
      }), this.#A(n), this.compose(a);
    }
  }
  #b(t) {
    const {
      canvas: e
    } = t, {
      width: s,
      height: i
    } = e;
    if (at.isCanvasFilterSupported) {
      t.save(), t.setTransform(1, 0, 0, 1, 0, 0), t.filter = "grayscale(1)", t.globalAlpha = 1, t.globalCompositeOperation = "copy", t.drawImage(e, 0, 0), t.restore();
      return;
    }
    const n = t.getImageData(0, 0, s, i), {
      data: r
    } = n;
    for (let a = 0, o = r.length; a < o; a += 4) {
      const l = r[a] * 0.2126 + r[a + 1] * 0.7152 + r[a + 2] * 0.0722 + 0.5 | 0;
      r[a] = r[a + 1] = r[a + 2] = l;
    }
    t.putImageData(n, 0, 0);
  }
  #A(t) {
    t && (t.knockoutMaskEntry && (this.canvasFactory.destroy(t.knockoutMaskEntry), t.knockoutMaskEntry = null), t.knockoutTempEntry && (this.canvasFactory.destroy(t.knockoutTempEntry), t.knockoutTempEntry = null), t.knockoutBackdropEntry && (this.canvasFactory.destroy(t.knockoutBackdropEntry), t.knockoutBackdropEntry = null));
  }
  beginAnnotation(t, e, s, i, n, r, a) {
    if (this.#d(), cs(this.ctx), this.ctx.save(), this.save(t), this.baseTransform && this.ctx.setTransform(...this.baseTransform), s) {
      const o = s[2] - s[0], l = s[3] - s[1];
      if (r && this.annotationCanvasMap) {
        i = i.slice(), i[4] -= s[0], i[5] -= s[1], N.singularValueDecompose2dScale(ht(this.ctx), Ut);
        const {
          viewportScale: h
        } = this, d = Math.ceil(o * this.outputScaleX * h), u = Math.ceil(l * this.outputScaleY * h);
        this.annotationCanvas = this.canvasFactory.create(d, u);
        const {
          canvas: f,
          context: p
        } = this.annotationCanvas;
        if (a) {
          const g = this.annotationCanvasMap.getOrInsertComputed(e, Le);
          f.setAttribute("data-canvas-name", a);
          const m = g.findIndex((v) => v.getAttribute("data-canvas-name") === a);
          m === -1 ? g.push(f) : g[m] = f;
        } else
          this.annotationCanvasMap.set(e, f);
        this.annotationCanvas.savedCtx = this.ctx, this.ctx = p, this.ctx.save(), this.ctx.setTransform(Ut[0], 0, 0, -Ut[1], 0, l * Ut[1]), cs(this.ctx);
      } else {
        cs(this.ctx), this.endPath(t);
        const h = new Path2D();
        h.rect(s[0], s[1], o, l), this.ctx.clip(h);
      }
    }
    this.current = new on(this.ctx.canvas.width, this.ctx.canvas.height), this.baseTransformStack.push(this.baseTransform), this.transform(t, ...i), this.transform(t, ...n), this.baseTransform = ht(this.ctx);
  }
  endAnnotation(t) {
    this.annotationCanvas && (this.ctx.restore(), this.#f(), this.ctx = this.annotationCanvas.savedCtx, delete this.annotationCanvas.savedCtx, delete this.annotationCanvas), this.baseTransform = this.baseTransformStack.pop();
  }
  paintImageMaskXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = e.count;
    e = this.getObject(t, e.data, e), e.count = s;
    const i = this.#p(this.current.fillAlpha), n = this.ctx, r = this._createMaskCanvas(t, e), a = r.canvas;
    n.save(), n.setTransform(1, 0, 0, 1, 0, 0), n.drawImage(a, r.offsetX, r.offsetY), this.dependencyTracker?.resetBBox(t).recordBBox(t, this.ctx, r.offsetX, r.offsetX + a.width, r.offsetY, r.offsetY + a.height).recordOperation(t), n.restore(), r.canvasEntry && this.canvasFactory.destroy(r.canvasEntry), this.compose(), this.#v(i);
  }
  paintImageMaskXObjectRepeat(t, e, s, i = 0, n = 0, r, a) {
    if (!this.contentVisible)
      return;
    e = this.getObject(t, e.data, e);
    const o = this.#p(this.current.fillAlpha), l = this.ctx;
    l.save();
    const h = ht(l);
    l.transform(s, i, n, r, 0, 0);
    const d = this._createMaskCanvas(t, e);
    l.setTransform(1, 0, 0, 1, d.offsetX - h[4], d.offsetY - h[5]), this.dependencyTracker?.resetBBox(t);
    for (let u = 0, f = a.length; u < f; u += 2) {
      const p = N.transform(h, [s, i, n, r, a[u], a[u + 1]]);
      l.drawImage(d.canvas, p[4], p[5]), this.dependencyTracker?.recordBBox(t, this.ctx, p[4], p[4] + d.canvas.width, p[5], p[5] + d.canvas.height);
    }
    l.restore(), d.canvasEntry && this.canvasFactory.destroy(d.canvasEntry), this.compose(), this.dependencyTracker?.recordOperation(t), this.#v(o);
  }
  paintImageMaskXObjectGroup(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.#p(this.current.fillAlpha), i = this.ctx, n = this.current.fillColor, r = this.current.patternFill;
    this.dependencyTracker?.resetBBox(t).recordDependencies(t, jt.transformAndFill);
    for (const a of e) {
      const {
        data: o,
        width: l,
        height: h,
        transform: d
      } = a, u = this.canvasFactory.create(l, h), f = u.context;
      f.save();
      const p = this.getObject(t, o, a);
      hn(f, p), f.globalCompositeOperation = "source-in", f.fillStyle = r ? n.getPattern(f, this, qt(i), Ct.FILL, t) : n, f.fillRect(0, 0, l, h), f.restore(), i.save(), i.transform(...d), i.scale(1, -1), hs(i, u.canvas, 0, 0, l, h, 0, -1, 1, 1), this.canvasFactory.destroy(u), this.dependencyTracker?.recordBBox(t, i, 0, l, 0, h), i.restore();
    }
    this.compose(), this.dependencyTracker?.recordOperation(t), this.#v(s);
  }
  paintImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = this.getObject(t, e);
    if (!s) {
      V("Dependent image isn't ready yet");
      return;
    }
    this.paintInlineImageXObject(t, s);
  }
  paintImageXObjectRepeat(t, e, s, i, n) {
    if (!this.contentVisible)
      return;
    const r = this.getObject(t, e);
    if (!r) {
      V("Dependent image isn't ready yet");
      return;
    }
    const a = r.width, o = r.height, l = [];
    for (let h = 0, d = n.length; h < d; h += 2)
      l.push({
        transform: [s, 0, 0, i, n[h], n[h + 1]],
        x: 0,
        y: 0,
        w: a,
        h: o
      });
    this.paintInlineImageXObjectGroup(t, r, l);
  }
  applyTransferMapsToCanvas(t) {
    return this.current.transferMaps !== "none" && (t.filter = this.current.transferMaps, t.drawImage(t.canvas, 0, 0), t.filter = "none"), t.canvas;
  }
  applyTransferMapsToBitmap(t) {
    if (this.current.transferMaps === "none")
      return {
        img: t.bitmap,
        canvasEntry: null
      };
    const {
      bitmap: e,
      width: s,
      height: i
    } = t, n = this.canvasFactory.create(s, i), r = n.context;
    return r.filter = this.current.transferMaps, r.drawImage(e, 0, 0), r.filter = "none", {
      img: n.canvas,
      canvasEntry: n
    };
  }
  paintInlineImageXObject(t, e) {
    if (!this.contentVisible)
      return;
    const s = e.width, i = e.height, n = this.#p(this.current.fillAlpha), r = this.ctx;
    this.save(t);
    const {
      filter: a
    } = r;
    a !== "none" && a !== "" && (r.filter = "none"), r.scale(1 / s, -1 / i);
    let o, l = null;
    if (e.bitmap) {
      const d = this.applyTransferMapsToBitmap(e);
      o = d.img, l = d.canvasEntry;
    } else {
      const d = this.canvasFactory.create(s, i);
      ln(d.context, e), o = this.applyTransferMapsToCanvas(d.context), l = d;
    }
    const h = this._scaleImage(o, qt(r));
    r.imageSmoothingEnabled = cn(ht(r), e.interpolate), this.dependencyTracker && (this.dependencyTracker.resetBBox(t).recordBBox(t, r, 0, s, -i, 0).recordDependencies(t, jt.imageXObject).recordOperation(t), this.imagesTracker?.record(r, s, i, this.dependencyTracker.clipBox)), hs(r, h.img, 0, 0, h.paintWidth, h.paintHeight, 0, -i, s, i), h.tmpCanvas && this.canvasFactory.destroy(h.tmpCanvas), l && this.canvasFactory.destroy(l), this.compose(), this.restore(t), this.#v(n);
  }
  paintInlineImageXObjectGroup(t, e, s) {
    if (!this.contentVisible)
      return;
    const i = this.#p(this.current.fillAlpha), n = this.ctx;
    let r, a = null;
    if (e.bitmap)
      r = e.bitmap;
    else {
      const o = e.width, l = e.height, h = this.canvasFactory.create(o, l);
      ln(h.context, e), r = this.applyTransferMapsToCanvas(h.context), a = h;
    }
    this.dependencyTracker?.resetBBox(t);
    for (const o of s)
      n.save(), n.transform(...o.transform), n.scale(1, -1), hs(n, r, o.x, o.y, o.w, o.h, 0, -1, 1, 1), this.dependencyTracker?.recordBBox(t, n, 0, 1, -1, 0), n.restore();
    a && this.canvasFactory.destroy(a), this.dependencyTracker?.recordOperation(t), this.compose(), this.#v(i);
  }
  paintSolidColorImageMask(t) {
    if (!this.contentVisible)
      return;
    const e = this.#p(this.current.fillAlpha);
    this.dependencyTracker?.resetBBox(t).recordBBox(t, this.ctx, 0, 1, 0, 1).recordDependencies(t, jt.fill).recordOperation(t), this.ctx.fillRect(0, 0, 1, 1), this.compose(), this.#v(e);
  }
  markPoint(t, e) {
  }
  markPointProps(t, e, s) {
  }
  beginMarkedContent(t, e) {
    this.dependencyTracker?.beginMarkedContent(t), this.markedContentStack.push({
      visible: !0
    });
  }
  beginMarkedContentProps(t, e, s) {
    this.dependencyTracker?.beginMarkedContent(t), e === "OC" ? this.markedContentStack.push({
      visible: this.optionalContentConfig.isVisible(s)
    }) : this.markedContentStack.push({
      visible: !0
    }), this.contentVisible = this.isContentVisible();
  }
  endMarkedContent(t) {
    this.dependencyTracker?.endMarkedContent(t), this.markedContentStack.pop(), this.contentVisible = this.isContentVisible();
  }
  beginCompat(t) {
  }
  endCompat(t) {
  }
  consumePath(t, e, s) {
    const i = this.current.isEmptyClip();
    this.pendingClip && this.current.updateClipFromPath(), this.pendingClip || this.compose(s);
    const n = this.ctx;
    this.pendingClip ? (i || (this.pendingClip === dn ? n.clip(e, "evenodd") : n.clip(e)), this.pendingClip = null, this.dependencyTracker?.bboxToClipBoxDropOperation(t).recordFutureForcedDependency("clipPath", t)) : this.dependencyTracker?.recordOperation(t), this.current.startNewPathAndClipBox(this.current.clipBox);
  }
  getSinglePixelWidth() {
    if (!this._cachedGetSinglePixelWidth) {
      const t = ht(this.ctx);
      if (t[1] === 0 && t[2] === 0)
        this._cachedGetSinglePixelWidth = 1 / Math.min(Math.abs(t[0]), Math.abs(t[3]));
      else {
        const e = Math.abs(t[0] * t[3] - t[2] * t[1]), s = Math.hypot(t[0], t[2]), i = Math.hypot(t[1], t[3]);
        this._cachedGetSinglePixelWidth = Math.max(s, i) / e;
      }
    }
    return this._cachedGetSinglePixelWidth;
  }
  getScaleForStroking() {
    if (this._cachedScaleForStroking[0] === -1) {
      const {
        lineWidth: t
      } = this.current, {
        a: e,
        b: s,
        c: i,
        d: n
      } = this.ctx.getTransform();
      let r, a;
      if (s === 0 && i === 0) {
        const o = Math.abs(e), l = Math.abs(n);
        if (o === l)
          if (t === 0)
            r = a = 1 / o;
          else {
            const h = o * t;
            r = a = h < 1 ? 1 / h : 1;
          }
        else if (t === 0)
          r = 1 / o, a = 1 / l;
        else {
          const h = o * t, d = l * t;
          r = h < 1 ? 1 / h : 1, a = d < 1 ? 1 / d : 1;
        }
      } else {
        const o = Math.abs(e * n - s * i), l = Math.hypot(e, s), h = Math.hypot(i, n);
        if (t === 0)
          r = h / o, a = l / o;
        else {
          const d = t * o;
          r = h > d ? h / d : 1, a = l > d ? l / d : 1;
        }
      }
      this._cachedScaleForStroking[0] = r, this._cachedScaleForStroking[1] = a;
    }
    return this._cachedScaleForStroking;
  }
  rescaleAndStroke(t, e) {
    const {
      ctx: s,
      current: {
        lineWidth: i
      }
    } = this, [n, r] = this.getScaleForStroking();
    if (n === r) {
      s.lineWidth = (i || 1) * n, s.stroke(t);
      return;
    }
    const a = Ae.#t ??= new DOMMatrix(), o = s.getLineDash();
    e && s.save(), s.scale(n, r), a.a = 1 / n, a.d = 1 / r;
    const l = new Path2D();
    if (l.addPath(t, a), o.length > 0) {
      const h = Math.max(n, r);
      s.setLineDash(o.map((d) => d / h)), s.lineDashOffset /= h;
    }
    s.lineWidth = i || 1, s.stroke(l), e && s.restore();
  }
  isContentVisible() {
    for (let t = this.markedContentStack.length - 1; t >= 0; t--)
      if (!this.markedContentStack[t].visible)
        return !1;
    return !0;
  }
}
for (const c in se)
  Ae.prototype[c] !== void 0 && (Ae.prototype[se[c]] = Ae.prototype[c]);
class Rs {
  #t = null;
  #e = null;
  _fullReader = null;
  _rangeReaders = /* @__PURE__ */ new Set();
  _source = null;
  constructor(t, e, s) {
    this._source = t, this.#t = e, this.#e = s;
  }
  get _progressiveDataLength() {
    return this._fullReader?._loaded ?? 0;
  }
  getFullReader() {
    return gt(!this._fullReader, "BasePDFStream.getFullReader can only be called once."), this._fullReader = new this.#t(this);
  }
  getRangeReader(t, e) {
    if (e <= this._progressiveDataLength)
      return null;
    const s = new this.#e(this, t, e);
    return this._rangeReaders.add(s), s;
  }
  cancelAllRequests(t) {
    this._fullReader?.cancel(t);
    for (const e of new Set(this._rangeReaders))
      e.cancel(t);
  }
}
class Ds {
  onProgress = null;
  _contentLength = 0;
  _filename = null;
  _headersCapability = Promise.withResolvers();
  _isRangeSupported = !1;
  _isStreamingSupported = !1;
  _loaded = 0;
  _stream = null;
  constructor(t) {
    this._stream = t;
  }
  _callOnProgress() {
    this.onProgress?.({
      loaded: this._loaded,
      total: this._contentLength
    });
  }
  get headersReady() {
    return this._headersCapability.promise;
  }
  get filename() {
    return this._filename;
  }
  get contentLength() {
    return this._contentLength;
  }
  get isRangeSupported() {
    return this._isRangeSupported;
  }
  get isStreamingSupported() {
    return this._isStreamingSupported;
  }
  async read() {
    st("Abstract method `read` called");
  }
  cancel(t) {
    st("Abstract method `cancel` called");
  }
}
class ks {
  _stream = null;
  constructor(t, e, s) {
    this._stream = t;
  }
  async read() {
    st("Abstract method `read` called");
  }
  cancel(t) {
    st("Abstract method `cancel` called");
  }
}
function ma(c) {
  let t = !0, e = s("filename\\*", "i").exec(c);
  if (e) {
    e = e[1];
    let h = a(e);
    return h = unescape(h), h = o(h), h = l(h), n(h);
  }
  if (e = r(c), e) {
    const h = l(e);
    return n(h);
  }
  if (e = s("filename", "i").exec(c), e) {
    e = e[1];
    let h = a(e);
    return h = l(h), n(h);
  }
  function s(h, d) {
    return new RegExp("(?:^|;)\\s*" + h + '\\s*=\\s*([^";\\s][^;\\s]*|"(?:[^"\\\\]|\\\\"?)+"?)', d);
  }
  function i(h, d) {
    if (h) {
      if (!/^[\x00-\xFF]+$/.test(d))
        return d;
      try {
        const u = new TextDecoder(h, {
          fatal: !0
        }), f = Is(d);
        d = u.decode(f), t = !1;
      } catch {
      }
    }
    return d;
  }
  function n(h) {
    return t && /[\x80-\xff]/.test(h) && (h = i("utf-8", h), t && (h = i("iso-8859-1", h))), h;
  }
  function r(h) {
    const d = [];
    let u;
    const f = s("filename\\*((?!0\\d)\\d+)(\\*?)", "ig");
    for (; (u = f.exec(h)) !== null; ) {
      let [, g, m, v] = u;
      if (g = parseInt(g, 10), g in d) {
        if (g === 0)
          break;
        continue;
      }
      d[g] = [m, v];
    }
    const p = [];
    for (let g = 0; g < d.length && g in d; ++g) {
      let [m, v] = d[g];
      v = a(v), m && (v = unescape(v), g === 0 && (v = o(v))), p.push(v);
    }
    return p.join("");
  }
  function a(h) {
    if (h.startsWith('"')) {
      const d = h.slice(1).split('\\"');
      for (let u = 0; u < d.length; ++u) {
        const f = d[u].indexOf('"');
        f !== -1 && (d[u] = d[u].slice(0, f), d.length = u + 1), d[u] = d[u].replaceAll(/\\(.)/g, "$1");
      }
      h = d.join('"');
    }
    return h;
  }
  function o(h) {
    const d = h.indexOf("'");
    if (d === -1)
      return h;
    const u = h.slice(0, d), p = h.slice(d + 1).replace(/^[^']*'/, "");
    return i(u, p);
  }
  function l(h) {
    return !h.startsWith("=?") || /[\x00-\x19\x80-\xff]/.test(h) ? h : h.replaceAll(/=\?([\w-]*)\?([QB])\?((?:[^?]|\?(?!=))*)\?=/gi, function(d, u, f, p) {
      if (f === "q" || f === "Q")
        return p = p.replaceAll("_", " "), p = p.replaceAll(/=([0-9a-f]{2})/gi, function(g, m) {
          return String.fromCharCode(parseInt(m, 16));
        }), i(u, p);
      try {
        p = atob(p);
      } catch {
      }
      return i(u, p);
    });
  }
  return "";
}
function Dn(c, t) {
  const e = new Headers();
  if (!c || !t || typeof t != "object")
    return e;
  for (const s in t) {
    const i = t[s];
    i !== void 0 && e.append(s, i);
  }
  return e;
}
function va(c) {
  let t = c.length;
  for (; t > 0 && c[t - 1] !== " " && /\s/.test(c[t - 1]); )
    t--;
  return c.slice(0, t);
}
function Ns(c) {
  return URL.parse(c)?.origin ?? null;
}
function kn({
  responseHeaders: c,
  isHttp: t,
  rangeChunkSize: e,
  disableRange: s
}) {
  const i = {
    contentLength: 0,
    isRangeSupported: !1
  }, n = parseInt(c.get("Content-Length"), 10);
  return !Number.isInteger(n) || (i.contentLength = n, n <= 2 * e) || s || !t || c.get("Accept-Ranges") !== "bytes" || (c.get("Content-Encoding") || "identity") === "identity" && (i.isRangeSupported = !0), i;
}
function Nn(c) {
  const t = c.get("Content-Disposition");
  if (t) {
    let e = ma(t);
    if (e.includes("%"))
      try {
        e = decodeURIComponent(e);
      } catch {
      }
    if (pi(e))
      return e;
  }
  return null;
}
function Fs(c, t) {
  return new bs(`Unexpected server response (${c}) while retrieving PDF "${t.href}".`, c, c === 404 || c === 0 && t.protocol === "file:");
}
function Fn(c, t) {
  if (c !== t)
    throw new Error(`Expected range response-origin "${c}" to match "${t}".`);
}
function Ln(c, t, e, s) {
  return fetch(c, {
    method: "GET",
    headers: t,
    signal: s.signal,
    mode: "cors",
    credentials: e ? "include" : "same-origin",
    redirect: "follow"
  });
}
function Bn(c, t) {
  if (c !== 200 && c !== 206)
    throw Fs(c, t);
}
function Ls(c) {
  if (c instanceof Uint8Array)
    return c.buffer;
  if (c instanceof ArrayBuffer)
    return c;
  throw new Error(`getArrayBuffer - unexpected data: ${c}`);
}
class ya extends Rs {
  _responseOrigin = null;
  constructor(t) {
    super(t, ba, Aa);
    const {
      httpHeaders: e,
      url: s
    } = t;
    gt(/https?:/.test(s.protocol), "PDFFetchStream only supports http(s):// URLs."), this.headers = Dn(!0, e);
  }
}
class ba extends Ds {
  _abortController = new AbortController();
  _reader = null;
  constructor(t) {
    super(t);
    const {
      disableRange: e,
      disableStream: s,
      rangeChunkSize: i,
      url: n,
      withCredentials: r
    } = t._source;
    this._isStreamingSupported = !s;
    const a = new Headers(t.headers);
    Ln(n, a, r, this._abortController).then((o) => {
      t._responseOrigin = Ns(o.url), Bn(o.status, n), this._reader = o.body.getReader();
      const l = o.headers, {
        contentLength: h,
        isRangeSupported: d
      } = kn({
        responseHeaders: l,
        isHttp: !0,
        rangeChunkSize: i,
        disableRange: e
      });
      this._contentLength = h, this._isRangeSupported = d, this._filename = Nn(l), !this._isStreamingSupported && this._isRangeSupported && this.cancel(new ce("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch(this._headersCapability.reject);
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, this._callOnProgress(), {
      value: Ls(t),
      done: !1
    });
  }
  cancel(t) {
    this._reader?.cancel(t), this._abortController.abort();
  }
}
class Aa extends ks {
  _abortController = new AbortController();
  _readCapability = Promise.withResolvers();
  _reader = null;
  constructor(t, e, s) {
    super(t, e, s);
    const {
      url: i,
      withCredentials: n
    } = t._source, r = new Headers(t.headers);
    r.append("Range", `bytes=${e}-${s - 1}`), Ln(i, r, n, this._abortController).then((a) => {
      const o = Ns(a.url);
      Fn(o, t._responseOrigin), Bn(a.status, i), this._reader = a.body.getReader(), this._readCapability.resolve();
    }).catch(this._readCapability.reject);
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : {
      value: Ls(t),
      done: !1
    };
  }
  cancel(t) {
    this._reader?.cancel(t), this._abortController.abort();
  }
}
function un(c) {
  return c instanceof Uint8Array && c.byteLength === c.buffer.byteLength ? c.buffer : new Uint8Array(c).buffer;
}
function Bs() {
  for (const c of this._requests)
    c.resolve({
      value: void 0,
      done: !0
    });
  this._requests.length = 0;
}
class Sa extends Rs {
  _progressiveDone = !1;
  _queuedChunks = [];
  constructor(t) {
    super(t, wa, Ea);
    const {
      pdfDataRangeTransport: e
    } = t, {
      initialData: s,
      progressiveDone: i
    } = e;
    if (s?.length > 0) {
      const r = un(s);
      this._queuedChunks.push(r);
    }
    this._progressiveDone = i;
    const n = (r) => {
      switch (r.type) {
        case "range":
        case "progressiveRead":
          this.#t(r.begin, r.chunk);
          break;
        case "progressiveDone":
          this._fullReader?.progressiveDone(), this._progressiveDone = !0;
          break;
      }
    };
    e.transportReady(n);
  }
  #t(t, e) {
    const s = un(e);
    if (t === void 0)
      this._fullReader ? this._fullReader._enqueue(s) : this._queuedChunks.push(s);
    else {
      const i = this._rangeReaders.keys().find((n) => n._begin === t);
      gt(i, "#onReceiveData - no `PDFDataTransportStreamRangeReader` instance found."), i._enqueue(s);
    }
  }
  getFullReader() {
    const t = super.getFullReader();
    return this._queuedChunks = null, t;
  }
  getRangeReader(t, e) {
    const s = super.getRangeReader(t, e);
    return s && (s.onDone = () => this._rangeReaders.delete(s), this._source.pdfDataRangeTransport.requestDataRange(t, e)), s;
  }
  cancelAllRequests(t) {
    super.cancelAllRequests(t), this._source.pdfDataRangeTransport.abort();
  }
}
class wa extends Ds {
  #t = Bs.bind(this);
  _done = !1;
  _queuedChunks = null;
  _requests = [];
  constructor(t) {
    super(t);
    const {
      pdfDataRangeTransport: e,
      disableRange: s,
      disableStream: i
    } = t._source, {
      length: n,
      contentDispositionFilename: r
    } = e;
    this._queuedChunks = t._queuedChunks || [];
    for (const o of this._queuedChunks)
      this._loaded += o.byteLength;
    this._done = t._progressiveDone, this._contentLength = n, this._isStreamingSupported = !i, this._isRangeSupported = !s, pi(r) && (this._filename = r), this._headersCapability.resolve();
    const a = this._loaded;
    Promise.resolve().then(() => {
      a > 0 && this._loaded === a && this._callOnProgress();
    });
  }
  _enqueue(t) {
    this._done || (this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunks.push(t), this._loaded += t.byteLength, this._callOnProgress());
  }
  async read() {
    if (this._queuedChunks.length > 0)
      return {
        value: this._queuedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this.#t();
  }
  progressiveDone() {
    this._done ||= !0, this._queuedChunks.length === 0 && this.#t();
  }
}
class Ea extends ks {
  #t = Bs.bind(this);
  onDone = null;
  _begin = -1;
  _done = !1;
  _queuedChunk = null;
  _requests = [];
  constructor(t, e, s) {
    super(t, e, s), this._begin = e;
  }
  _enqueue(t) {
    this._done || (this._requests.length === 0 ? this._queuedChunk = t : (this._requests.shift().resolve({
      value: t,
      done: !1
    }), this.#t()), this._done = !0, this.onDone?.());
  }
  async read() {
    if (this._queuedChunk) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this.#t(), this.onDone?.();
  }
}
const Xs = 200, fn = 206;
function xa(c) {
  return typeof c != "string" ? c : Is(c).buffer;
}
class Ta extends Rs {
  #t = /* @__PURE__ */ new WeakMap();
  _responseOrigin = null;
  constructor(t) {
    super(t, Ca, Pa);
    const {
      httpHeaders: e,
      url: s
    } = t;
    this.url = s, this.isHttp = /https?:/.test(s.protocol), this.headers = Dn(this.isHttp, e);
  }
  _request(t) {
    const e = new XMLHttpRequest(), s = {
      validateStatus: null,
      onHeadersReceived: t.onHeadersReceived,
      onDone: t.onDone,
      onError: t.onError,
      onProgress: t.onProgress
    };
    this.#t.set(e, s), e.open("GET", this.url), e.withCredentials = this._source.withCredentials;
    for (const [i, n] of this.headers)
      e.setRequestHeader(i, n);
    return this.isHttp && "begin" in t && "end" in t ? (e.setRequestHeader("Range", `bytes=${t.begin}-${t.end - 1}`), s.validateStatus = (i) => i === fn || i === Xs) : s.validateStatus = (i) => i === Xs, e.responseType = "arraybuffer", gt(t.onError, "Expected `onError` callback to be provided."), e.onerror = () => t.onError(e.status), e.onreadystatechange = this.#s.bind(this, e), e.onprogress = this.#e.bind(this, e), e.send(null), e;
  }
  #e(t, e) {
    this.#t.get(t)?.onProgress?.(e);
  }
  #s(t, e) {
    const s = this.#t.get(t);
    if (!s || (t.readyState >= 2 && s.onHeadersReceived && (s.onHeadersReceived(), delete s.onHeadersReceived), t.readyState !== 4) || !this.#t.has(t))
      return;
    if (this.#t.delete(t), t.status === 0 && this.isHttp) {
      s.onError(t.status);
      return;
    }
    const i = t.status || Xs;
    if (!s.validateStatus(i)) {
      s.onError(t.status);
      return;
    }
    const n = xa(t.response);
    if (i === fn) {
      const r = t.getResponseHeader("Content-Range");
      /bytes \d+-\d+\/\d+/.test(r) ? s.onDone(n) : (V('Missing or invalid "Content-Range" header.'), s.onError(0));
    } else n ? s.onDone(n) : s.onError(t.status);
  }
  _abortRequest(t) {
    this.#t.has(t) && (this.#t.delete(t), t.abort());
  }
  getRangeReader(t, e) {
    const s = super.getRangeReader(t, e);
    return s && (s.onClosed = () => this._rangeReaders.delete(s)), s;
  }
}
class Ca extends Ds {
  #t = Bs.bind(this);
  _cachedChunks = [];
  _done = !1;
  _requests = [];
  _storedError = null;
  constructor(t) {
    super(t), this._fullRequestXhr = t._request({
      onHeadersReceived: this.#e.bind(this),
      onDone: this.#s.bind(this),
      onError: this.#i.bind(this),
      onProgress: this.#n.bind(this)
    });
  }
  #e() {
    const t = this._stream, {
      disableRange: e,
      rangeChunkSize: s
    } = t._source, i = this._fullRequestXhr;
    t._responseOrigin = Ns(i.responseURL);
    const n = i.getAllResponseHeaders(), r = new Headers(n ? va(n.trimStart()).split(/[\r\n]+/).map((l) => {
      const [h, ...d] = l.split(": ");
      return [h, d.join(": ")];
    }) : []), {
      contentLength: a,
      isRangeSupported: o
    } = kn({
      responseHeaders: r,
      isHttp: t.isHttp,
      rangeChunkSize: s,
      disableRange: e
    });
    this._contentLength = a, this._isRangeSupported = o, this._filename = Nn(r), this._isRangeSupported && t._abortRequest(i), this._headersCapability.resolve();
  }
  #s(t) {
    this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._cachedChunks.push(t), this._done = !0, this._cachedChunks.length === 0 && this.#t();
  }
  #i(t) {
    this._storedError = Fs(t, this._stream.url), this._headersCapability.reject(this._storedError);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._cachedChunks.length = 0;
  }
  #n(t) {
    this.onProgress?.({
      loaded: t.loaded,
      total: t.lengthComputable ? t.total : this._contentLength
    });
  }
  async read() {
    if (await this._headersCapability.promise, this._storedError)
      throw this._storedError;
    if (this._cachedChunks.length > 0)
      return {
        value: this._cachedChunks.shift(),
        done: !1
      };
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this._headersCapability.reject(t), this.#t(), this._stream._abortRequest(this._fullRequestXhr), this._fullRequestXhr = null;
  }
}
class Pa extends ks {
  #t = Bs.bind(this);
  onClosed = null;
  _done = !1;
  _queuedChunk = null;
  _requests = [];
  _storedError = null;
  constructor(t, e, s) {
    super(t, e, s), this._requestXhr = t._request({
      begin: e,
      end: s,
      onHeadersReceived: this.#e.bind(this),
      onDone: this.#s.bind(this),
      onError: this.#i.bind(this),
      onProgress: null
    });
  }
  #e() {
    const t = Ns(this._requestXhr?.responseURL);
    try {
      Fn(t, this._stream._responseOrigin);
    } catch (e) {
      this._storedError = e, this.#i(0);
    }
  }
  #s(t) {
    this._requests.length > 0 ? this._requests.shift().resolve({
      value: t,
      done: !1
    }) : this._queuedChunk = t, this._done = !0, this.#t(), this.onClosed?.();
  }
  #i(t) {
    this._storedError ??= Fs(t, this._stream.url);
    for (const e of this._requests)
      e.reject(this._storedError);
    this._requests.length = 0, this._queuedChunk = null;
  }
  async read() {
    if (this._storedError)
      throw this._storedError;
    if (this._queuedChunk !== null) {
      const e = this._queuedChunk;
      return this._queuedChunk = null, {
        value: e,
        done: !1
      };
    }
    if (this._done)
      return {
        value: void 0,
        done: !0
      };
    const t = Promise.withResolvers();
    return this._requests.push(t), t.promise;
  }
  cancel(t) {
    this._done = !0, this.#t(), this._stream._abortRequest(this._requestXhr), this.onClosed?.();
  }
}
function _n(c, t = null) {
  const e = process.getBuiltinModule("fs"), {
    Readable: s
  } = process.getBuiltinModule("stream"), i = e.createReadStream(c, t);
  return s.toWeb(i);
}
class Ia extends Rs {
  constructor(t) {
    super(t, Oa, Ma);
    const {
      url: e
    } = t;
    gt(e.protocol === "file:", "PDFNodeStream only supports file:// URLs.");
  }
}
class Oa extends Ds {
  _reader = null;
  constructor(t) {
    super(t);
    const {
      disableRange: e,
      disableStream: s,
      rangeChunkSize: i,
      url: n
    } = t._source;
    this._isStreamingSupported = !s, process.getBuiltinModule("fs/promises").lstat(n).then((a) => {
      const o = _n(n);
      this._reader = o.getReader();
      const {
        size: l
      } = a;
      this._contentLength = l, this._isRangeSupported = !e && l > 2 * i, !this._isStreamingSupported && this._isRangeSupported && this.cancel(new ce("Streaming is disabled.")), this._headersCapability.resolve();
    }).catch((a) => {
      a.code === "ENOENT" && (a = Fs(0, n)), this._headersCapability.reject(a);
    });
  }
  async read() {
    await this._headersCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : (this._loaded += t.byteLength, this._callOnProgress(), {
      value: Ls(t),
      done: !1
    });
  }
  cancel(t) {
    this._reader?.cancel(t);
  }
}
class Ma extends ks {
  _readCapability = Promise.withResolvers();
  _reader = null;
  constructor(t, e, s) {
    super(t, e, s);
    const {
      url: i
    } = t._source;
    try {
      const n = _n(i, {
        start: e,
        end: s - 1
      });
      this._reader = n.getReader(), this._readCapability.resolve();
    } catch (n) {
      this._readCapability.reject(n);
    }
  }
  async read() {
    await this._readCapability.promise;
    const {
      value: t,
      done: e
    } = await this._reader.read();
    return e ? {
      value: t,
      done: e
    } : {
      value: Ls(t),
      done: !1
    };
  }
  cancel(t) {
    this._reader?.cancel(t);
  }
}
function Ra(c) {
  return We(c) ? ya : Bt ? Ia : Ta;
}
class Ke {
  static #t = null;
  static #e = "";
  static get workerPort() {
    return this.#t;
  }
  static set workerPort(t) {
    if (!(typeof Worker < "u" && t instanceof Worker) && t !== null)
      throw new Error("Invalid `workerPort` type.");
    this.#t = t;
  }
  static get workerSrc() {
    return this.#e;
  }
  static set workerSrc(t) {
    if (typeof t != "string")
      throw new Error("Invalid `workerSrc` type.");
    this.#e = t;
  }
}
class Da {
  #t;
  #e;
  constructor({
    parsedData: t,
    rawData: e
  }) {
    this.#t = t, this.#e = e;
  }
  getRaw() {
    return this.#e;
  }
  get(t) {
    return this.#t.get(t) ?? null;
  }
  [Symbol.iterator]() {
    return this.#t.entries();
  }
}
const pe = /* @__PURE__ */ Symbol("INTERNAL");
class ka {
  #t = !1;
  #e = !1;
  #s = !1;
  #i = !0;
  constructor(t, {
    name: e,
    intent: s,
    usage: i,
    rbGroups: n
  }) {
    this.#t = !!(t & Ft.DISPLAY), this.#e = !!(t & Ft.PRINT), this.name = e, this.intent = s, this.usage = i, this.rbGroups = n;
  }
  get visible() {
    if (this.#s)
      return this.#i;
    if (!this.#i)
      return !1;
    const {
      print: t,
      view: e
    } = this.usage;
    return this.#t ? e?.viewState !== "OFF" : this.#e ? t?.printState !== "OFF" : !0;
  }
  _setVisible(t, e, s = !1) {
    t !== pe && st("Internal method `_setVisible` called."), this.#s = s, this.#i = e;
  }
  get serializable() {
    return {
      userSet: this.#s,
      visible: this.#i
    };
  }
}
class bi {
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #i = null;
  #n;
  creator = null;
  name = null;
  constructor(t, e = Ft.DISPLAY, s = null) {
    if (this.#n = t, this.renderingIntent = e, t !== null) {
      this.name = t.name, this.creator = t.creator, this.#i = t.order;
      for (const i of t.groups)
        this.#e.set(i.id, new ka(e, i));
      if (s) {
        s.size !== this.#e.size && st("Incorrect serialized groupState.");
        for (const [i, n] of s)
          this.#e.get(i)._setVisible(pe, n.visible, n.userSet);
      } else {
        if (t.baseState === "OFF")
          for (const i of this.#e.values())
            i._setVisible(pe, !1);
        for (const i of t.on)
          this.#e.get(i)._setVisible(pe, !0);
        for (const i of t.off)
          this.#e.get(i)._setVisible(pe, !1);
      }
      this.#s = this.getHash();
    }
  }
  #a(t) {
    const e = t.length;
    if (e < 2)
      return !0;
    const s = t[0];
    for (let i = 1; i < e; i++) {
      const n = t[i];
      let r;
      if (Array.isArray(n))
        r = this.#a(n);
      else if (this.#e.has(n))
        r = this.#e.get(n).visible;
      else
        return V(`Optional content group not found: ${n}`), !0;
      switch (s) {
        case "And":
          if (!r)
            return !1;
          break;
        case "Or":
          if (r)
            return !0;
          break;
        case "Not":
          return !r;
        default:
          return !0;
      }
    }
    return s === "And";
  }
  isVisible(t) {
    if (this.#e.size === 0)
      return !0;
    if (!t)
      return Ps("Optional content group not defined."), !0;
    if (t.type === "OCG")
      return this.#e.has(t.id) ? this.#e.get(t.id).visible : (V(`Optional content group not found: ${t.id}`), !0);
    if (t.type === "OCMD") {
      if (t.expression)
        return this.#a(t.expression);
      if (!t.policy || t.policy === "AnyOn") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return V(`Optional content group not found: ${e}`), !0;
          if (this.#e.get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOn") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return V(`Optional content group not found: ${e}`), !0;
          if (!this.#e.get(e).visible)
            return !1;
        }
        return !0;
      } else if (t.policy === "AnyOff") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return V(`Optional content group not found: ${e}`), !0;
          if (!this.#e.get(e).visible)
            return !0;
        }
        return !1;
      } else if (t.policy === "AllOff") {
        for (const e of t.ids) {
          if (!this.#e.has(e))
            return V(`Optional content group not found: ${e}`), !0;
          if (this.#e.get(e).visible)
            return !1;
        }
        return !0;
      }
      return V(`Unknown optional content policy ${t.policy}.`), !0;
    }
    return V(`Unknown group type ${t.type}.`), !0;
  }
  setVisibility(t, e = !0, s = !0) {
    const i = this.#e.get(t);
    if (!i) {
      V(`Optional content group not found: ${t}`);
      return;
    }
    if (s && e && i.rbGroups.length)
      for (const n of i.rbGroups)
        for (const r of n)
          r !== t && this.#e.get(r)?._setVisible(pe, !1, !0);
    i._setVisible(pe, !!e, !0), this.#t = null;
  }
  setOCGState({
    state: t,
    preserveRB: e
  }) {
    let s;
    for (const i of t) {
      switch (i) {
        case "ON":
        case "OFF":
        case "Toggle":
          s = i;
          continue;
      }
      const n = this.#e.get(i);
      if (n)
        switch (s) {
          case "ON":
            this.setVisibility(i, !0, e);
            break;
          case "OFF":
            this.setVisibility(i, !1, e);
            break;
          case "Toggle":
            this.setVisibility(i, !n.visible, e);
            break;
        }
    }
    this.#t = null;
  }
  get hasInitialVisibility() {
    return this.#s === null || this.getHash() === this.#s;
  }
  getOrder() {
    return this.#e.size ? this.#i ? this.#i.slice() : [...this.#e.keys()] : null;
  }
  getGroup(t) {
    return this.#e.get(t) || null;
  }
  getHash() {
    if (this.#t !== null)
      return this.#t;
    const t = new ni();
    for (const [e, s] of this.#e)
      t.update(`${e}:${s.visible}`);
    return this.#t = t.hexdigest();
  }
  [Symbol.iterator]() {
    return this.#e.entries();
  }
  get serializable() {
    const t = /* @__PURE__ */ new Map();
    for (const [e, s] of this.#e)
      t.set(e, s.serializable);
    return {
      data: this.#n,
      renderingIntent: this.renderingIntent,
      groupState: t
    };
  }
  static fromSerializable({
    data: t,
    renderingIntent: e,
    groupState: s
  }) {
    return new bi(t, e, s);
  }
}
class Na {
  #t = null;
  #e = null;
  #s = 0;
  #i = null;
  #n = null;
  get pagesNumber() {
    return this.#s;
  }
  set pagesNumber(t) {
    this.#s !== t && (this.#s = t, this.#t = null, this.#e = null);
  }
  #a() {
    if (this.#t)
      return;
    const t = this.#s, e = this.#t = new Uint32Array(t);
    for (let s = 0; s < t; s++)
      e[s] = s + 1;
    this.#e = new Int32Array(e);
  }
  #r() {
    const t = /* @__PURE__ */ new Map(), e = this.#t;
    for (let s = 0, i = this.#s; s < i; s++) {
      const n = e[s], r = t.get(n);
      r ? r.push(s + 1) : t.set(n, [s + 1]);
    }
    return t;
  }
  movePages(t, e, s) {
    this.#a();
    const i = this.#t, n = e.length, r = new Uint32Array(n);
    let a = 0;
    for (let u = 0; u < n; u++) {
      const f = e[u] - 1;
      r[u] = i[f], f < s && a++;
    }
    const o = this.#s, l = o - n, h = new Int32Array(o), d = ct(s - a, 0, l);
    for (let u = 0, f = 0; u < o; u++)
      t.has(u + 1) || (i[f] = i[u], h[f++] = u + 1);
    i.copyWithin(d + n, d, l), i.set(r, d), h.copyWithin(d + n, d, l), h.set(e, d), this.#e = h, i.every((u, f) => u === f + 1) && (this.#t = null);
  }
  deletePages(t) {
    this.#a();
    const e = this.#t, s = this.#r();
    this.#n = {
      pageNumberToId: e.slice(),
      pagesNumber: this.#s,
      prevPageNumbers: this.#e.slice()
    };
    const i = this.#s - t.length;
    this.#s = i;
    const n = this.#t = new Uint32Array(i);
    this.#e = new Int32Array(i);
    let r = 0, a = 0;
    for (const o of t) {
      const l = o - 1;
      l !== r && (n.set(e.subarray(r, l), a), a += l - r), r = l + 1;
    }
    r < e.length && n.set(e.subarray(r), a), this.#o(s, new Set(t));
  }
  cancelDelete() {
    this.#n && (this.#t = this.#n.pageNumberToId, this.#s = this.#n.pagesNumber, this.#e = this.#n.prevPageNumbers, this.#n = null);
  }
  cleanSavedData() {
    this.#n = null;
  }
  copyPages(t) {
    this.#a(), this.#i = {
      pageNumbers: t,
      pageIds: t.map((e) => this.#t[e - 1])
    };
  }
  cancelCopy() {
    this.#i = null;
  }
  pastePages(t) {
    this.#a();
    const e = this.#t, s = this.#r(), {
      pageNumbers: i,
      pageIds: n
    } = this.#i, r = this.#s + i.length;
    this.#s = r;
    const a = this.#t = new Uint32Array(r);
    this.#e = new Int32Array(r), a.set(e.subarray(0, t), 0), a.set(n, t), a.set(e.subarray(t), t + i.length), this.#o(s, null, t, i), this.#i = null;
  }
  #o(t, e = null, s = -1, i = null) {
    const n = this.#e, r = this.#t, a = s + (i?.length ?? 0), o = /* @__PURE__ */ new Map();
    for (let l = 0, h = this.#s; l < h; l++) {
      if (l >= s && l < a) {
        n[l] = -i[l - s];
        continue;
      }
      const d = r[l], u = t.get(d);
      let f = o.get(d) || 0;
      if (e && u)
        for (; f < u.length && e.has(u[f]); )
          f++;
      n[l] = u?.[f], o.set(d, f + 1);
    }
  }
  hasBeenAltered() {
    return this.#t !== null;
  }
  #l(t = null) {
    if (!this.#t)
      return null;
    const e = new Int32Array(this.#s).fill(-1), s = /* @__PURE__ */ new Map();
    if (t)
      for (const i of t) {
        const n = this.getPageId(i), r = s.get(n) ?? 0;
        s.set(n, r + 1), e[i - 1] = r;
      }
    else
      for (let i = 0, n = this.#s; i < n; i++) {
        const r = this.#t[i], a = s.get(r) ?? 0;
        s.set(r, a + 1), e[i] = a;
      }
    return e;
  }
  getPageMappingForSaving(t = null, e = this.#l()) {
    t ??= this.#r();
    let s = 0;
    for (const n of t.values())
      s = Math.max(s, n.length);
    const i = new Array(s);
    for (let n = 0; n < s; n++)
      i[n] = {
        document: null,
        pageIndices: [],
        includePages: []
      };
    for (const [n, r] of t)
      for (let a = 0, o = r.length; a < o; a++)
        i[a].includePages.push([n - 1, r[a] - 1]);
    for (const {
      includePages: n,
      pageIndices: r
    } of i) {
      n.sort((a, o) => a[0] - o[0]);
      for (let a = 0, o = n.length; a < o; a++)
        r.push(n[a][1]), n[a] = n[a][0];
    }
    return {
      pageInfos: i,
      copyLevels: e
    };
  }
  extractPages(t) {
    t = Array.from(t).sort((s, i) => s - i);
    const e = /* @__PURE__ */ new Map();
    for (let s = 0, i = t.length; s < i; s++) {
      const n = this.getPageId(t[s]);
      e.getOrInsertComputed(n, Le).push(s + 1);
    }
    return this.getPageMappingForSaving(e, this.#l(t));
  }
  getPrevPageNumber(t) {
    return this.#e?.[t - 1] ?? 0;
  }
  getPageNumber(t) {
    if (!this.#t)
      return t;
    const e = this.#t;
    for (let s = 0, i = this.#s; s < i; s++)
      if (e[s] === t)
        return s + 1;
    return 0;
  }
  getPageId(t) {
    return this.#t?.[t - 1] ?? t;
  }
  getMapping() {
    return this.#t?.subarray(0, this.pagesNumber);
  }
}
const Oe = /* @__PURE__ */ Symbol("INITIAL_DATA"), pn = () => ({
  ...Promise.withResolvers(),
  data: Oe
});
class Un {
  #t = /* @__PURE__ */ new Map();
  get(t, e = null) {
    if (e) {
      const i = this.#t.getOrInsertComputed(t, pn);
      return i.promise.then(() => e(i.data)), null;
    }
    const s = this.#t.get(t);
    if (!s || s.data === Oe)
      throw new Error(`Requesting object that isn't resolved yet ${t}.`);
    return s.data;
  }
  has(t) {
    const e = this.#t.get(t);
    return !!e && e.data !== Oe;
  }
  delete(t) {
    const e = this.#t.get(t);
    return !e || e.data === Oe ? !1 : (this.#t.delete(t), !0);
  }
  resolve(t, e = null) {
    const s = this.#t.getOrInsertComputed(t, pn);
    if (s.data !== Oe)
      throw new Error(`Object already resolved ${t}.`);
    s.data = e, s.resolve();
  }
  clear() {
    for (const {
      data: t
    } of this.#t.values())
      t?.bitmap?.close();
    this.#t.clear();
  }
  *[Symbol.iterator]() {
    for (const [t, {
      data: e
    }] of this.#t)
      e !== Oe && (yield [t, e]);
  }
}
const Fa = 1e5, gn = 30;
class Lt {
  #t = Promise.withResolvers();
  #e = null;
  #s = !1;
  #i = !!globalThis.FontInspector?.enabled;
  #n = null;
  #a = null;
  #r = null;
  #o = 0;
  #l = 0;
  #h = null;
  #u = null;
  #d = 0;
  #f = 0;
  #g = /* @__PURE__ */ Object.create(null);
  #m = [];
  #c = null;
  #p = [];
  #v = /* @__PURE__ */ new WeakMap();
  #y = null;
  static #b = /* @__PURE__ */ new Map();
  static #A = /* @__PURE__ */ new Map();
  static #E = /* @__PURE__ */ new WeakMap();
  static #w = null;
  static #x = /* @__PURE__ */ new Set();
  constructor({
    textContentSource: t,
    images: e,
    container: s,
    viewport: i
  }) {
    if (t instanceof ReadableStream)
      this.#c = t;
    else if (typeof t == "object")
      this.#c = new ReadableStream({
        start(l) {
          l.enqueue(t), l.close();
        }
      });
    else
      throw new Error('No "textContentSource" parameter specified.');
    this.#e = this.#u = s, this.#n = e, this.#f = i.scale * Kt.pixelRatio, this.#d = i.rotation, this.#r = {
      div: null,
      properties: null,
      ctx: null
    };
    const {
      pageWidth: n,
      pageHeight: r,
      pageX: a,
      pageY: o
    } = i.rawDims;
    this.#y = [1, 0, 0, -1, -a, o + r], this.#l = n, this.#o = r, Lt.#R(), s.style.setProperty("--min-font-size", Lt.#w), Se(s, i), this.#t.promise.finally(() => {
      Lt.#x.delete(this), this.#r = null, this.#g = null;
    }).catch(() => {
    });
  }
  static get fontFamilyMap() {
    const {
      isWindows: t,
      isFirefox: e
    } = at.platform;
    return j(this, "fontFamilyMap", /* @__PURE__ */ new Map([["sans-serif", `${t && e ? "Calibri, " : ""}sans-serif`], ["monospace", `${t && e ? "Lucida Console, " : ""}monospace`]]));
  }
  render() {
    this.#n && this.#e.append(this.#n.render());
    const t = () => {
      this.#h.read().then(({
        value: e,
        done: s
      }) => {
        if (s) {
          this.#t.resolve();
          return;
        }
        this.#a ??= e.lang, Object.assign(this.#g, e.styles), this.#T(e.items), t();
      }, this.#t.reject);
    };
    return this.#h = this.#c.getReader(), Lt.#x.add(this), t(), this.#t.promise;
  }
  update({
    viewport: t,
    onBefore: e = null
  }) {
    const s = t.scale * Kt.pixelRatio, i = t.rotation;
    if (i !== this.#d && (e?.(), this.#d = i, Se(this.#u, {
      rotation: i
    })), s !== this.#f) {
      e?.(), this.#f = s;
      const n = {
        div: null,
        properties: null,
        ctx: Lt.#P(this.#a)
      };
      for (const r of this.#p)
        n.properties = this.#v.get(r), n.div = r, this.#I(n);
    }
  }
  cancel() {
    const t = new ce("TextLayer task cancelled.");
    this.#h?.cancel(t).catch(() => {
    }), this.#h = null, this.#t.reject(t);
  }
  get textDivs() {
    return this.#p;
  }
  get textContentItemsStr() {
    return this.#m;
  }
  #T(t) {
    if (this.#s)
      return;
    this.#r.ctx ??= Lt.#P(this.#a);
    const e = this.#p, s = this.#m;
    for (const i of t) {
      if (e.length > Fa) {
        V("Ignoring additional textDivs for performance reasons."), this.#s = !0;
        return;
      }
      if (i.str === void 0) {
        if (i.type === "beginMarkedContentProps" || i.type === "beginMarkedContent") {
          const n = this.#e;
          this.#e = document.createElement("span"), this.#e.classList.add("markedContent"), i.id && this.#e.setAttribute("id", i.id), i.tag === "Artifact" && (this.#e.ariaHidden = !0), n.append(this.#e);
        } else i.type === "endMarkedContent" && (this.#e = this.#e.parentNode);
        continue;
      }
      s.push(i.str), this.#M(i);
    }
  }
  #M(t) {
    const e = document.createElement("span"), s = {
      angle: 0,
      canvasWidth: 0,
      hasText: t.str !== "",
      hasEOL: t.hasEOL,
      fontSize: 0
    };
    this.#p.push(e);
    const i = N.transform(this.#y, t.transform);
    let n = Math.atan2(i[1], i[0]);
    const r = this.#g[t.fontName];
    r.vertical && (n += Math.PI / 2);
    let a = this.#i && r.fontSubstitution || r.fontFamily;
    a = Lt.fontFamilyMap.get(a) || a;
    const o = Math.hypot(i[2], i[3]), l = o * Lt.#k(a, r, this.#a);
    let h, d;
    n === 0 ? (h = i[4], d = i[5] - l) : (h = i[4] + l * Math.sin(n), d = i[5] - l * Math.cos(n));
    const u = e.style;
    u.left = `${(100 * h / this.#l).toFixed(2)}%`, u.top = `${(100 * d / this.#o).toFixed(2)}%`, u.setProperty("--font-height", `${o.toFixed(2)}px`), u.fontFamily = a, s.fontSize = o, e.setAttribute("role", "presentation"), e.textContent = t.str, e.dir = t.dir, this.#i && (e.dataset.fontName = r.fontSubstitutionLoadedName || t.fontName), n !== 0 && (s.angle = n * (180 / Math.PI));
    let f = !1;
    if (t.str.length > 1)
      f = !0;
    else if (t.str !== " " && t.transform[0] !== t.transform[3]) {
      const p = Math.abs(t.transform[0]), g = Math.abs(t.transform[3]);
      p !== g && Math.max(p, g) / Math.min(p, g) > 1.5 && (f = !0);
    }
    if (f && (s.canvasWidth = r.vertical ? t.height : t.width), this.#v.set(e, s), this.#r.div = e, this.#r.properties = s, this.#I(this.#r), s.hasText && this.#e.append(e), s.hasEOL) {
      const p = document.createElement("br");
      p.setAttribute("role", "presentation"), this.#e.append(p);
    }
  }
  #I(t) {
    const {
      div: e,
      properties: s,
      ctx: i
    } = t, {
      style: n
    } = e;
    if (s.canvasWidth !== 0 && s.hasText) {
      const {
        fontFamily: r
      } = n, {
        canvasWidth: a,
        fontSize: o
      } = s;
      Lt.#D(i, o * this.#f, r);
      const {
        width: l
      } = i.measureText(e.textContent);
      l > 0 && n.setProperty("--scale-x", a * this.#f / l);
    }
    s.angle !== 0 && n.setProperty("--rotate", `${s.angle}deg`);
  }
  static cleanup() {
    if (!(this.#x.size > 0)) {
      this.#b.clear();
      for (const {
        canvas: t
      } of this.#A.values())
        t.remove();
      this.#A.clear();
    }
  }
  static #P(t = null) {
    let e = this.#A.get(t ||= "");
    if (!e) {
      const s = document.createElement("canvas");
      s.style.cssText = "position:absolute;top:0;left:0;width:0;height:0;display:none;letter-spacing:normal;word-spacing:normal", s.lang = t, document.body.append(s), e = s.getContext("2d", {
        alpha: !1,
        willReadFrequently: !0
      }), this.#A.set(t, e), this.#E.set(e, {
        size: 0,
        family: ""
      });
    }
    return e;
  }
  static #D(t, e, s) {
    const i = this.#E.get(t);
    e === i.size && s === i.family || (t.font = `${e}px ${s}`, i.size = e, i.family = s);
  }
  static #R() {
    if (this.#w !== null)
      return;
    const t = document.createElement("div");
    t.style.opacity = 0, t.style.lineHeight = 1, t.style.fontSize = "1px", t.style.position = "absolute", t.textContent = "X", document.body.append(t), this.#w = t.getBoundingClientRect().height, t.remove();
  }
  static #k(t, e, s) {
    const i = this.#b.get(t);
    if (i)
      return i;
    const n = this.#P(s);
    n.canvas.width = n.canvas.height = gn, this.#D(n, gn, t);
    const r = n.measureText(""), a = r.fontBoundingBoxAscent, o = Math.abs(r.fontBoundingBoxDescent);
    n.canvas.width = n.canvas.height = 0;
    let l = 0.8;
    return a ? l = a / (a + o) : (at.platform.isFirefox && V("Enable the `dom.textMetrics.fontBoundingBox.enabled` preference in `about:config` to improve TextLayer rendering."), e.ascent ? l = e.ascent : e.descent && (l = 1 + e.descent)), this.#b.set(t, l), l;
  }
}
const La = 100;
function Ba(c = {}) {
  const t = new Ai(), {
    docId: e
  } = t, s = c.url ? jr(c.url) : null, i = c.data ? $r(c.data) : null, n = c.httpHeaders || null, r = c.withCredentials === !0, a = c.password ?? null, o = c.range instanceof Hn ? c.range : null, l = Number.isInteger(c.rangeChunkSize) && c.rangeChunkSize > 0 ? c.rangeChunkSize : 2 ** 16;
  let h = c.worker instanceof qe ? c.worker : null;
  const d = c.verbosity, u = typeof c.docBaseUrl == "string" && !Os(c.docBaseUrl) ? c.docBaseUrl : null, f = os(c.cMapUrl), p = c.cMapPacked !== !1, g = os(c.iccUrl), m = os(c.standardFontDataUrl), v = os(c.wasmUrl), y = c.stopAtErrors !== !0, b = Number.isInteger(c.maxImageSize) && c.maxImageSize > -1 ? c.maxImageSize : -1, w = typeof c.isOffscreenCanvasSupported == "boolean" ? c.isOffscreenCanvasSupported : !Bt, A = typeof c.isImageDecoderSupported == "boolean" ? c.isImageDecoderSupported : !Bt, S = Number.isInteger(c.canvasMaxAreaInBytes) ? c.canvasMaxAreaInBytes : -1, E = typeof c.disableFontFace == "boolean" ? c.disableFontFace : Bt, T = c.fontExtraProperties === !0, x = c.enableXfa === !0, P = c.ownerDocument || globalThis.document, C = c.disableRange === !0, I = c.disableStream === !0, R = c.disableAutoFetch === !0, D = c.pdfBug === !0, _ = c.CanvasFactory || (Bt ? Jr : Wr), M = c.FilterFactory || (Bt ? Kr : Xr), k = c.BinaryDataFactory || (Bt ? Qr : sn), $ = c.enableHWA === !0, tt = c.enableWebGPU === !0 ? ea() : Promise.resolve(!1), vt = c.useWasm !== !1, Y = c.pagesMapper || new Na(), J = typeof c.useSystemFonts == "boolean" ? c.useSystemFonts : !Bt && !E, rt = typeof c.useWorkerFetch == "boolean" ? c.useWorkerFetch : !!(k === sn && f && p && m && v && We(f, document.baseURI) && We(m, document.baseURI) && We(v, document.baseURI)), Rt = null;
  nr(d);
  const F = {
    canvasFactory: new _({
      ownerDocument: P,
      enableHWA: $
    }),
    filterFactory: new M({
      docId: e,
      ownerDocument: P
    }),
    binaryDataFactory: rt ? null : new k({
      cMapUrl: f,
      standardFontDataUrl: m,
      wasmUrl: v
    })
  };
  h || (h = qe.create({
    verbosity: d,
    port: Ke.workerPort
  }), t._worker = h);
  const O = {
    docId: e,
    apiVersion: "6.3.289",
    data: i,
    password: a,
    disableAutoFetch: R,
    rangeChunkSize: l,
    docBaseUrl: u,
    enableXfa: x,
    evaluatorOptions: {
      maxImageSize: b,
      disableFontFace: E,
      ignoreErrors: y,
      isOffscreenCanvasSupported: w,
      isImageDecoderSupported: A,
      canvasMaxAreaInBytes: S,
      fontExtraProperties: T,
      useSystemFonts: J,
      useWasm: vt,
      useWorkerFetch: rt,
      cMapUrl: f,
      cMapPacked: p,
      iccUrl: g,
      standardFontDataUrl: m,
      wasmUrl: v,
      hasGPU: !1
    }
  }, L = {
    ownerDocument: P,
    pdfBug: D,
    styleElement: Rt,
    enableHWA: $,
    loadingParams: {
      disableAutoFetch: R,
      enableXfa: x
    }
  };
  return Promise.all([h.promise, tt]).then(function([, W]) {
    if (h.destroyed)
      throw new Error("Worker was destroyed");
    O.evaluatorOptions.hasGPU = W;
    const it = h.messageHandler.sendWithPromise("GetDocRequest", O, i ? [i.buffer] : null);
    let G;
    if (!i) if (o)
      G = new Sa({
        pdfDataRangeTransport: o,
        disableRange: C,
        disableStream: I
      });
    else if (s) {
      const Q = Ra(s);
      G = new Q({
        url: s,
        httpHeaders: n,
        withCredentials: r,
        rangeChunkSize: l,
        disableRange: C,
        disableStream: I
      });
    } else
      throw new Error("getDocument - expected either `data`, `range`, or `url` parameter.");
    return it.then((Q) => {
      if (h.destroyed)
        throw new Error("Worker was destroyed");
      const ot = new Ve(e, Q, h.port), xt = new Ua(ot, t, G, L, F, Y);
      if (t._transport = xt, t.destroyed)
        throw new Error("Loading aborted");
      ot.send("Ready", null);
    });
  }).catch(t._capability.reject).finally(t._setupCapability.resolve), t;
}
class Ai {
  static #t = 0;
  _capability = Promise.withResolvers();
  _setupCapability = Promise.withResolvers();
  _transport = null;
  _worker = null;
  docId = `d${Ai.#t++}`;
  destroyed = !1;
  onPassword = null;
  onProgress = null;
  get promise() {
    return this._capability.promise;
  }
  async destroy() {
    this.destroyed = !0, this._capability.promise.catch(() => {
    });
    try {
      this._worker?.port && (this._worker._pendingDestroy = !0), await this._setupCapability.promise, await this._transport?.destroy();
    } catch (t) {
      throw this._worker?.port && delete this._worker._pendingDestroy, t;
    }
    this._transport = null, this._worker?.destroy(), this._worker = null;
  }
  async getData() {
    return this._transport.getData();
  }
}
class Hn {
  #t = Promise.withResolvers();
  #e = null;
  constructor(t, e, s = !1, i = null) {
    this.length = t, this.initialData = e, this.progressiveDone = s, this.contentDispositionFilename = i;
  }
  onDataRange(t, e) {
    this.#e({
      type: "range",
      begin: t,
      chunk: e
    });
  }
  onDataProgressiveRead(t) {
    this.#t.promise.then(() => {
      this.#e({
        type: "progressiveRead",
        chunk: t
      });
    });
  }
  onDataProgressiveDone() {
    this.#t.promise.then(() => {
      this.#e({
        type: "progressiveDone"
      });
    });
  }
  transportReady(t) {
    this.#e = t, this.#t.resolve();
  }
  requestDataRange(t, e) {
    st("Abstract method PDFDataRangeTransport.requestDataRange");
  }
  abort() {
  }
}
class _a {
  constructor(t, e) {
    this._pdfInfo = t, this._transport = e;
  }
  get pagesMapper() {
    return this._transport.pagesMapper;
  }
  get annotationStorage() {
    return this._transport.annotationStorage;
  }
  get canvasFactory() {
    return this._transport.canvasFactory;
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get numPages() {
    return this._pdfInfo.numPages;
  }
  get fingerprints() {
    return this._pdfInfo.fingerprints;
  }
  get isPureXfa() {
    return j(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  get allXfaHtml() {
    return this._transport._htmlForXfa;
  }
  getPage(t) {
    return this._transport.getPage(t);
  }
  getPageIndex(t) {
    return this._transport.getPageIndex(t);
  }
  getDestinations() {
    return this._transport.getDestinations();
  }
  getDestination(t) {
    return this._transport.getDestination(t);
  }
  getPageLabels() {
    return this._transport.getPageLabels();
  }
  getPageLayout() {
    return this._transport.getPageLayout();
  }
  getPageMode() {
    return this._transport.getPageMode();
  }
  getViewerPreferences() {
    return this._transport.getViewerPreferences();
  }
  getOpenAction() {
    return this._transport.getOpenAction();
  }
  getAttachments() {
    return this._transport.getAttachments();
  }
  getAttachmentContent(t) {
    return this._transport.getAttachmentContent(t);
  }
  getAnnotationsByType(t, e) {
    return this._transport.getAnnotationsByType(t, e);
  }
  getJSActions() {
    return this._transport.getDocJSActions();
  }
  getOutline() {
    return this._transport.getOutline();
  }
  getOptionalContentConfig({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getOptionalContentConfig(e);
  }
  getPermissions() {
    return this._transport.getPermissions();
  }
  getMetadata() {
    return this._transport.getMetadata();
  }
  getMarkInfo() {
    return this._transport.getMarkInfo();
  }
  getData() {
    return this._transport.getData();
  }
  saveDocument() {
    return this._transport.saveDocument();
  }
  extractPages(t, e = null) {
    return this._transport.extractPages(t, e);
  }
  getDownloadInfo() {
    return this._transport.downloadInfoCapability.promise;
  }
  cleanup(t = !1) {
    return this._transport.startCleanup(t || this.isPureXfa);
  }
  cachedPageNumber(t) {
    return this._transport.cachedPageNumber(t);
  }
  get loadingParams() {
    return this._transport.loadingParams;
  }
  get loadingTask() {
    return this._transport.loadingTask;
  }
  getFieldObjects() {
    return this._transport.getFieldObjects();
  }
  getSignatures() {
    return this._transport.getSignatures();
  }
  getSignatureData(t) {
    return this._transport.getSignatureData(t);
  }
  hasJSActions() {
    return this._transport.hasJSActions();
  }
  getCalculationOrderIds() {
    return this._transport.getCalculationOrderIds();
  }
}
class Si {
  #t = !1;
  #e = null;
  constructor(t, e, s, i, n = !1) {
    this._pageIndex = t, this._pageInfo = e, this._transport = s, this._stats = n ? new $i() : null, this._pdfBug = n, this.commonObjs = s.commonObjs, this.objs = new Un(), this._intentStates = /* @__PURE__ */ new Map(), this.destroyed = !1, this.recordedBBoxes = null, this.#e = i, this.imageCoordinates = null;
  }
  clone(t) {
    const e = new Si(t, this._pageInfo, this._transport, this.#e, this._pdfBug);
    return e.clonedFromIndex = this.clonedFromIndex ?? this._pageIndex, this._transport.updatePage(e), e;
  }
  get pageNumber() {
    return this._pageIndex + 1;
  }
  set pageNumber(t) {
    this._pageIndex = t - 1, this._transport.updatePage(this);
  }
  get rotate() {
    return this._pageInfo.rotate;
  }
  get ref() {
    return this._pageInfo.ref;
  }
  get userUnit() {
    return this._pageInfo.userUnit;
  }
  get view() {
    return this._pageInfo.view;
  }
  getViewport({
    scale: t,
    rotation: e = this.rotate,
    offsetX: s = 0,
    offsetY: i = 0,
    dontFlip: n = !1
  } = {}) {
    return new es({
      viewBox: this.view,
      userUnit: this.userUnit,
      scale: t,
      rotation: e,
      offsetX: s,
      offsetY: i,
      dontFlip: n
    });
  }
  getAnnotations({
    intent: t = "display"
  } = {}) {
    const {
      renderingIntent: e
    } = this._transport.getRenderingIntent(t);
    return this._transport.getAnnotations(this._pageIndex, e);
  }
  getJSActions() {
    return this._transport.getPageJSActions(this._pageIndex);
  }
  get filterFactory() {
    return this._transport.filterFactory;
  }
  get isPureXfa() {
    return j(this, "isPureXfa", !!this._transport._htmlForXfa);
  }
  async getXfa() {
    return this._transport._htmlForXfa?.children[this._pageIndex] || null;
  }
  render({
    canvasContext: t,
    canvas: e = t.canvas,
    viewport: s,
    intent: i = "display",
    annotationMode: n = le.ENABLE,
    transform: r = null,
    background: a = null,
    optionalContentConfigPromise: o = null,
    annotationCanvasMap: l = null,
    pageColors: h = null,
    printAnnotationStorage: d = null,
    isEditing: u = !1,
    recordImages: f = !1,
    recordOperations: p = !1,
    operationsFilter: g = null
  }) {
    this._stats?.time("Overall");
    const m = this._transport.getRenderingIntent(i, n, d, u), {
      renderingIntent: v,
      cacheKey: y
    } = m;
    this.#t = !1, o ||= this._transport.getOptionalContentConfig(v);
    const b = this._intentStates.getOrInsertComputed(y, qs);
    b.streamReaderCancelTimeout && (clearTimeout(b.streamReaderCancelTimeout), b.streamReaderCancelTimeout = null);
    const w = !!(v & Ft.PRINT);
    b.displayReadyCapability || (b.displayReadyCapability = Promise.withResolvers(), b.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, this._stats?.time("Page Request"), this._pumpOperatorList(m));
    const A = !!(this._pdfBug && globalThis.StepperManager?.enabled), S = !!e && !this.recordedBBoxes && (p || A), E = !!e && !this.imageCoordinates && f, T = (R) => {
      if (b.renderTasks.delete(C), S) {
        const D = C.gfx?.dependencyTracker.take();
        D && (C.stepper?.setOperatorBBoxes(D, C.gfx.dependencyTracker.takeDebugMetadata()), p && (this.recordedBBoxes = D));
      }
      E && !R && (this.imageCoordinates = C.gfx?.imagesTracker.take()), w && (this.#t = !0), this.#s(), R ? (C.capability.reject(R), this._abortOperatorList({
        intentState: b,
        reason: R instanceof Error ? R : new Error(R)
      })) : C.capability.resolve(), this._stats && (this._stats.timeEnd("Rendering"), this._stats.timeEnd("Overall"), globalThis.Stats?.enabled && globalThis.Stats.add(this.pageNumber, this._stats));
    };
    let x = null, P = null;
    (S || E) && (P = new Or(e, b.operatorList.length)), S && (x = new Mr(P, A));
    const C = new De({
      callback: T,
      params: {
        canvas: e,
        canvasContext: t,
        dependencyTracker: x ?? P,
        imagesTracker: E ? new As(e) : null,
        viewport: s,
        transform: r,
        background: a
      },
      objs: this.objs,
      commonObjs: this.commonObjs,
      annotationCanvasMap: l,
      operatorList: b.operatorList,
      pageIndex: this._pageIndex,
      canvasFactory: this._transport.canvasFactory,
      filterFactory: this._transport.filterFactory,
      useRequestAnimationFrame: !w,
      pdfBug: this._pdfBug,
      pageColors: h,
      enableHWA: this._transport.enableHWA,
      operationsFilter: g
    });
    (b.renderTasks ||= /* @__PURE__ */ new Set()).add(C);
    const I = C.task;
    return Promise.all([b.displayReadyCapability.promise, o]).then(([R, D]) => {
      if (this.destroyed) {
        T();
        return;
      }
      if (this._stats?.time("Rendering"), !(D.renderingIntent & v))
        throw new Error("Must use the same `intent`-argument when calling the `PDFPageProxy.render` and `PDFDocumentProxy.getOptionalContentConfig` methods.");
      C.initializeGraphics({
        transparency: R,
        optionalContentConfig: D
      }), C.operatorListChanged();
    }).catch(T), I;
  }
  getOperatorList({
    intent: t = "display",
    annotationMode: e = le.ENABLE,
    printAnnotationStorage: s = null,
    isEditing: i = !1
  } = {}) {
    function n() {
      a.operatorList.lastChunk && (a.opListReadCapability.resolve(a.operatorList), a.renderTasks.delete(o));
    }
    const r = this._transport.getRenderingIntent(t, e, s, i, !0), a = this._intentStates.getOrInsertComputed(r.cacheKey, qs);
    let o;
    return a.opListReadCapability || (o = /* @__PURE__ */ Object.create(null), o.operatorListChanged = n, a.opListReadCapability = Promise.withResolvers(), (a.renderTasks ||= /* @__PURE__ */ new Set()).add(o), a.operatorList = {
      fnArray: [],
      argsArray: [],
      lastChunk: !1,
      separateAnnots: null
    }, this._stats?.time("Page Request"), this._pumpOperatorList(r)), a.opListReadCapability.promise;
  }
  streamTextContent({
    includeMarkedContent: t = !1,
    disableNormalization: e = !1
  } = {}) {
    return this._transport.messageHandler.sendWithStream("GetTextContent", {
      pageId: this.#e.getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      includeMarkedContent: t === !0,
      disableNormalization: e === !0
    }, {
      highWaterMark: 100,
      size(i) {
        return i.items.length;
      }
    });
  }
  async getTextContent(t = {}) {
    if (this._transport._htmlForXfa)
      return this.getXfa().then((i) => Je.textContent(i));
    const e = this.streamTextContent(t), s = {
      items: [],
      styles: /* @__PURE__ */ Object.create(null),
      lang: null
    };
    for await (const i of e)
      s.lang ??= i.lang, Object.assign(s.styles, i.styles), s.items.push(...i.items);
    return s;
  }
  getStructTree() {
    return this._transport.getStructTree(this._pageIndex);
  }
  _destroy() {
    this.destroyed = !0;
    const t = [];
    for (const e of this._intentStates.values())
      if (this._abortOperatorList({
        intentState: e,
        reason: new Error("Page was destroyed."),
        force: !0
      }), !e.opListReadCapability)
        for (const s of e.renderTasks)
          t.push(s.completed), s.cancel();
    return this.objs.clear(), this.#t = !1, Promise.all(t);
  }
  cleanup(t = !1) {
    this.#t = !0;
    const e = this.#s();
    return t && e && (this._stats &&= new $i()), e;
  }
  #s() {
    if (!this.#t || this.destroyed)
      return !1;
    for (const {
      renderTasks: t,
      operatorList: e
    } of this._intentStates.values())
      if (t.size > 0 || !e.lastChunk)
        return !1;
    return this._intentStates.clear(), this.objs.clear(), this.#t = !1, !0;
  }
  _startRenderPage(t, e) {
    const s = this._intentStates.get(e);
    s && (this._stats?.timeEnd("Page Request"), s.displayReadyCapability?.resolve(t));
  }
  _renderPageChunk(t, e) {
    for (let s = 0, i = t.length; s < i; s++)
      e.operatorList.fnArray.push(t.fnArray[s]), e.operatorList.argsArray.push(t.argsArray[s]);
    e.operatorList.lastChunk = t.lastChunk, e.operatorList.separateAnnots = t.separateAnnots;
    for (const s of e.renderTasks)
      s.operatorListChanged();
    t.lastChunk && this.#s();
  }
  _pumpOperatorList({
    renderingIntent: t,
    cacheKey: e,
    annotationStorageSerializable: s,
    modifiedIds: i
  }) {
    const {
      map: n,
      transfer: r
    } = s, o = this._transport.messageHandler.sendWithStream("GetOperatorList", {
      pageId: this.#e.getPageId(this._pageIndex + 1) - 1,
      pageIndex: this._pageIndex,
      intent: t,
      cacheKey: e,
      annotationStorage: n,
      modifiedIds: i
    }, void 0, r).getReader(), l = this._intentStates.get(e);
    l.streamReader = o;
    const h = () => {
      o.read().then(({
        value: d,
        done: u
      }) => {
        if (u) {
          l.streamReader = null;
          return;
        }
        this._transport.destroyed || (this._renderPageChunk(d, l), h());
      }, (d) => {
        if (l.streamReader = null, !this._transport.destroyed) {
          if (l.operatorList) {
            l.operatorList.lastChunk = !0;
            for (const u of l.renderTasks)
              u.operatorListChanged();
            this.#s();
          }
          if (l.displayReadyCapability)
            l.displayReadyCapability.reject(d);
          else if (l.opListReadCapability)
            l.opListReadCapability.reject(d);
          else
            throw d;
        }
      });
    };
    h();
  }
  _abortOperatorList({
    intentState: t,
    reason: e,
    force: s = !1
  }) {
    if (t.streamReader) {
      if (t.streamReaderCancelTimeout && (clearTimeout(t.streamReaderCancelTimeout), t.streamReaderCancelTimeout = null), !s) {
        if (t.renderTasks.size > 0)
          return;
        if (e instanceof fi) {
          let i = La;
          e.extraDelay > 0 && e.extraDelay < 1e3 && (i += e.extraDelay), t.streamReaderCancelTimeout = setTimeout(() => {
            t.streamReaderCancelTimeout = null, this._abortOperatorList({
              intentState: t,
              reason: e,
              force: !0
            });
          }, i);
          return;
        }
      }
      if (t.streamReader.cancel(new ce(e.message)).catch(() => {
      }), t.streamReader = null, !this._transport.destroyed) {
        for (const [i, n] of this._intentStates)
          if (n === t) {
            this._intentStates.delete(i);
            break;
          }
        this.cleanup();
      }
    }
  }
  get stats() {
    return this._stats;
  }
}
var he, Xt, ae, ve, xs, ye, be, Mt, vs, jn, $n, ze, ke, ys;
const mt = class mt {
  constructor({
    name: t = null,
    port: e = null,
    verbosity: s = rr()
  } = {}) {
    Qt(this, Mt);
    Qt(this, he, Promise.withResolvers());
    Qt(this, Xt, null);
    Qt(this, ae, null);
    Qt(this, ve, null);
    if (this.name = t, this.destroyed = !1, this.verbosity = s, e) {
      if (dt(mt, be).has(e))
        throw new Error("Cannot use more than one PDFWorker per port.");
      dt(mt, be).set(e, this), Zt(this, Mt, jn).call(this, e);
    } else
      Zt(this, Mt, $n).call(this);
  }
  get promise() {
    return dt(this, he).promise;
  }
  get port() {
    return dt(this, ae);
  }
  get messageHandler() {
    return dt(this, Xt);
  }
  destroy() {
    this.destroyed = !0, dt(this, ve)?.terminate(), Dt(this, ve, null), dt(mt, be).delete(dt(this, ae)), Dt(this, ae, null), dt(this, Xt)?.destroy(), Dt(this, Xt, null);
  }
  static create(t) {
    const e = dt(this, be).get(t?.port);
    if (e) {
      if (e._pendingDestroy)
        throw new Error("PDFWorker.create - the worker is being destroyed.\nPlease remember to await `PDFDocumentLoadingTask.destroy()`-calls.");
      return e;
    }
    return new mt(t);
  }
  static get workerSrc() {
    if (Ke.workerSrc)
      return Ke.workerSrc;
    throw new Error('No "GlobalWorkerOptions.workerSrc" specified.');
  }
  static get _setupFakeWorkerGlobal() {
    return j(this, "_setupFakeWorkerGlobal", (async () => dt(this, ke, ys) ? dt(this, ke, ys) : (await import(
      /*webpackIgnore: true*/
      /*@vite-ignore*/
      this.workerSrc
    )).WorkerMessageHandler)());
  }
};
he = new WeakMap(), Xt = new WeakMap(), ae = new WeakMap(), ve = new WeakMap(), xs = new WeakMap(), ye = new WeakMap(), be = new WeakMap(), Mt = new WeakSet(), vs = function() {
  dt(this, he).resolve(), dt(this, Xt).send("configure", {
    verbosity: this.verbosity
  });
}, jn = function(t) {
  Dt(this, ae, t), Dt(this, Xt, new Ve("main", "worker", t)), dt(this, Xt).on("ready", () => {
  }), Zt(this, Mt, vs).call(this);
}, $n = function() {
  if (dt(mt, ye) || dt(mt, ke, ys)) {
    Zt(this, Mt, ze).call(this);
    return;
  }
  let {
    workerSrc: t
  } = mt;
  try {
    mt._isSameOrigin(window.location, t) || (t = mt._createCDNWrapper(new URL(t, window.location).href));
    const e = new Worker(t, {
      type: "module"
    }), s = new Ve("main", "worker", e), i = () => {
      n.abort(), s.destroy(), e.terminate(), this.destroyed ? dt(this, he).reject(new Error("Worker was destroyed")) : Zt(this, Mt, ze).call(this);
    }, n = new AbortController();
    e.addEventListener("error", () => {
      dt(this, ve) || i();
    }, {
      signal: n.signal
    }), s.on("test", (a) => {
      if (n.abort(), this.destroyed || !a) {
        i();
        return;
      }
      Dt(this, Xt, s), Dt(this, ae, e), Dt(this, ve, e), Zt(this, Mt, vs).call(this);
    }), s.on("ready", (a) => {
      if (n.abort(), this.destroyed) {
        i();
        return;
      }
      try {
        r();
      } catch {
        Zt(this, Mt, ze).call(this);
      }
    });
    const r = () => {
      const a = new Uint8Array();
      s.send("test", a, [a.buffer]);
    };
    r();
    return;
  } catch {
    Ps("The worker has been disabled.");
  }
  Zt(this, Mt, ze).call(this);
}, ze = function() {
  dt(mt, ye) || (V("Setting up fake worker."), Dt(mt, ye, !0)), mt._setupFakeWorkerGlobal.then((t) => {
    if (this.destroyed) {
      dt(this, he).reject(new Error("Worker was destroyed"));
      return;
    }
    const e = new zr();
    Dt(this, ae, e);
    const s = `fake${Ui(mt, xs)._++}`, i = new Ve(s + "_worker", s, e);
    t.setup(i, e), Dt(this, Xt, new Ve(s, s + "_worker", e)), Zt(this, Mt, vs).call(this);
  }).catch((t) => {
    dt(this, he).reject(new Error(`Setting up fake worker failed: "${t.message}".`));
  });
}, ke = new WeakSet(), ys = function() {
  try {
    return globalThis.pdfjsWorker?.WorkerMessageHandler || null;
  } catch {
    return null;
  }
}, Qt(mt, ke), Qt(mt, xs, 0), Qt(mt, ye, !1), Qt(mt, be, /* @__PURE__ */ new WeakMap()), Bt && (Dt(mt, ye, !0), Ke.workerSrc ||= "./pdf.worker.mjs"), mt._isSameOrigin = (t, e) => {
  const s = URL.parse(t);
  if (!s?.origin || s.origin === "null")
    return !1;
  const i = new URL(e, s);
  return s.origin === i.origin;
}, mt._createCDNWrapper = (t) => {
  const e = `await import("${t}");`;
  return URL.createObjectURL(new Blob([e], {
    type: "text/javascript"
  }));
};
let qe = mt;
class Ua {
  downloadInfoCapability = Promise.withResolvers();
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #i = /* @__PURE__ */ new Map();
  #n = /* @__PURE__ */ new Map();
  #a = /* @__PURE__ */ new Map();
  #r = null;
  constructor(t, e, s, i, n, r) {
    this.messageHandler = t, this.loadingTask = e, this.#s = s, this.commonObjs = new Un(), this.fontLoader = new Dr({
      ownerDocument: i.ownerDocument,
      styleElement: i.styleElement
    }), this.enableHWA = i.enableHWA, this.loadingParams = i.loadingParams, this._params = i, this.canvasFactory = n.canvasFactory, this.filterFactory = n.filterFactory, this.binaryDataFactory = n.binaryDataFactory, this.pagesMapper = r, this.destroyed = !1, this.destroyCapability = null, this.setupMessageHandler();
  }
  updatePage(t) {
    const {
      _pageIndex: e
    } = t;
    this.#i.set(e, t), this.#n.set(e, Promise.resolve(t));
  }
  #o(t, e = null) {
    return this.#e.getOrInsertComputed(t, () => this.messageHandler.sendWithPromise(t, e));
  }
  #l({
    loaded: t,
    total: e
  }) {
    this.loadingTask.onProgress?.({
      loaded: t,
      total: e,
      percent: e ? ct(Math.round(t / e * 100), 0, 100) : NaN
    });
  }
  get annotationStorage() {
    return j(this, "annotationStorage", new vi());
  }
  getRenderingIntent(t, e = le.ENABLE, s = null, i = !1, n = !1) {
    let r = Ft.DISPLAY, a = Qe;
    switch (t) {
      case "any":
        r = Ft.ANY;
        break;
      case "display":
        break;
      case "print":
        r = Ft.PRINT;
        break;
      default:
        V(`getRenderingIntent - invalid intent: ${t}`);
    }
    const o = r & Ft.PRINT && s instanceof Pn ? s : this.annotationStorage;
    switch (e) {
      case le.DISABLE:
        r += Ft.ANNOTATIONS_DISABLE;
        break;
      case le.ENABLE:
        break;
      case le.ENABLE_FORMS:
        r += Ft.ANNOTATIONS_FORMS;
        break;
      case le.ENABLE_STORAGE:
        r += Ft.ANNOTATIONS_STORAGE, a = o.serializable;
        break;
      default:
        V(`getRenderingIntent - invalid annotationMode: ${e}`);
    }
    i && (r += Ft.IS_EDITING), n && (r += Ft.OPLIST);
    const {
      ids: l,
      hash: h
    } = o.modifiedIds, d = [r, a.hash, h];
    return {
      renderingIntent: r,
      cacheKey: d.join("_"),
      annotationStorageSerializable: a,
      modifiedIds: l
    };
  }
  destroy() {
    if (this.destroyCapability)
      return this.destroyCapability.promise;
    this.destroyed = !0, this.destroyCapability = Promise.withResolvers(), this.#r?.reject(new Error("Worker was destroyed during onPassword callback"));
    const t = [];
    for (const s of this.#i.values())
      t.push(s._destroy());
    this.#i.clear(), this.#n.clear(), this.#a.clear(), Object.hasOwn(this, "annotationStorage") && this.annotationStorage.resetModified();
    const e = this.messageHandler.sendWithPromise("Terminate", null);
    return t.push(e), Promise.all(t).then(() => {
      this.commonObjs.clear(), this.fontLoader.clear(), this.#e.clear(), this.filterFactory.destroy(), Lt.cleanup(), this.#s?.cancelAllRequests(new ce("Worker was terminated.")), this.messageHandler?.destroy(), this.messageHandler = null, this.destroyCapability.resolve();
    }, this.destroyCapability.reject), this.destroyCapability.promise;
  }
  setupMessageHandler() {
    const {
      messageHandler: t,
      loadingTask: e
    } = this;
    t.on("GetReader", (s, i) => {
      gt(this.#s, "GetReader - no `BasePDFStream` instance available."), this.#t = this.#s.getFullReader(), this.#t.onProgress = (n) => this.#l(n), i.onPull = () => {
        this.#t.read().then(function({
          value: n,
          done: r
        }) {
          if (r) {
            i.close();
            return;
          }
          gt(n instanceof ArrayBuffer, "GetReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(n), 1, [n]);
        }).catch((n) => {
          i.error(n);
        });
      }, i.onCancel = (n) => {
        this.#t.cancel(n), i.ready.catch((r) => {
          if (!this.destroyed)
            throw r;
        });
      };
    }), t.on("ReaderHeadersReady", async (s) => {
      await this.#t.headersReady;
      const {
        isStreamingSupported: i,
        isRangeSupported: n,
        contentLength: r
      } = this.#t;
      return i && n && (this.#t.onProgress = null), {
        isStreamingSupported: i,
        isRangeSupported: n,
        contentLength: r
      };
    }), t.on("GetRangeReader", (s, i) => {
      gt(this.#s, "GetRangeReader - no `BasePDFStream` instance available.");
      const n = this.#s.getRangeReader(s.begin, s.end);
      if (!n) {
        i.close();
        return;
      }
      i.onPull = () => {
        n.read().then(function({
          value: r,
          done: a
        }) {
          if (a) {
            i.close();
            return;
          }
          gt(r instanceof ArrayBuffer, "GetRangeReader - expected an ArrayBuffer."), i.enqueue(new Uint8Array(r), 1, [r]);
        }).catch((r) => {
          i.error(r);
        });
      }, i.onCancel = (r) => {
        n.cancel(r), i.ready.catch((a) => {
          if (!this.destroyed)
            throw a;
        });
      };
    }), t.on("GetDoc", ({
      pdfInfo: s
    }) => {
      this.pagesMapper.pagesNumber = s.numPages, this._numPages = s.numPages, this._htmlForXfa = s.htmlForXfa, delete s.htmlForXfa, e._capability.resolve(new _a(s, this));
    }), t.on("DocException", (s) => {
      e._capability.reject(kt(s));
    }), t.on("PasswordRequest", (s) => {
      this.#r = Promise.withResolvers();
      try {
        if (!e.onPassword)
          throw kt(s);
        const i = (n) => {
          n instanceof Error ? this.#r.reject(n) : this.#r.resolve({
            password: n
          });
        };
        e.onPassword(i, s.code);
      } catch (i) {
        this.#r.reject(i);
      }
      return this.#r.promise;
    }), t.on("DataLoaded", (s) => {
      this.#l({
        loaded: s.length,
        total: s.length
      }), this.downloadInfoCapability.resolve(s);
    }), t.on("StartRenderPage", (s) => {
      if (this.destroyed)
        return;
      this.#i.get(s.pageIndex)._startRenderPage(s.transparency, s.cacheKey);
    }), t.on("commonobj", ([s, i, n]) => {
      if (this.destroyed || this.commonObjs.has(s))
        return null;
      switch (i) {
        case "Font":
          if ("error" in n) {
            const d = n.error;
            V(`Error during font loading: ${d}`), this.commonObjs.resolve(s, d);
            break;
          }
          const r = new _r(n), a = this._params.pdfBug && globalThis.FontInspector?.enabled ? (d, u) => globalThis.FontInspector.fontAdded(d, u) : null, o = new kr(r, a, n.charProcOperatorList, n.extra);
          this.fontLoader.bind(o).catch(() => t.sendWithPromise("FontFallback", {
            id: s
          })).finally(() => {
            o.fontExtraProperties || o.clearData(), this.commonObjs.resolve(s, o);
          });
          break;
        case "CopyLocalImage":
          const {
            imageRef: l
          } = n;
          gt(l, "The imageRef must be defined.");
          for (const d of this.#i.values())
            for (const [, u] of d.objs) {
              if (u?.ref !== l)
                continue;
              if (!u.dataLen)
                return null;
              const f = structuredClone(u);
              return this.commonObjs.resolve(s, f), u.dataLen;
            }
          break;
        case "FontPath":
          this.commonObjs.resolve(s, new Hr(n));
          break;
        case "Image":
          this.commonObjs.resolve(s, n);
          break;
        case "Pattern":
          const h = new Ur(n);
          this.commonObjs.resolve(s, h.getIR());
          break;
        default:
          throw new Error(`Got unknown common object type ${i}`);
      }
      return null;
    }), t.on("obj", ([s, i, n, r]) => {
      if (this.destroyed)
        return;
      const a = this.#i.get(i);
      if (!a.objs.has(s)) {
        if (a._intentStates.size === 0) {
          r?.bitmap?.close();
          return;
        }
        switch (n) {
          case "Image":
          case "Pattern":
            a.objs.resolve(s, r);
            break;
          default:
            throw new Error(`Got unknown object type ${n}`);
        }
      }
    }), t.on("DocProgress", (s) => {
      this.destroyed || this.#l(s);
    }), t.on("FetchBinaryData", async (s) => {
      if (this.destroyed)
        throw new Error("Worker was destroyed.");
      if (!this.binaryDataFactory)
        throw new Error("`BinaryDataFactory` not initialized, see the `useWorkerFetch` parameter.");
      return this.binaryDataFactory.fetch(s);
    });
  }
  getData() {
    return this.messageHandler.sendWithPromise("GetData", null);
  }
  saveDocument() {
    this.annotationStorage.size <= 0 && V("saveDocument called while `annotationStorage` is empty, please use the getData-method instead.");
    const {
      map: t,
      transfer: e
    } = this.annotationStorage.serializable;
    return this.messageHandler.sendWithPromise("SaveDocument", {
      isPureXfa: !!this._htmlForXfa,
      numPages: this._numPages,
      annotationStorage: t,
      filename: this.#t?.filename ?? null
    }, e).finally(() => {
      this.annotationStorage.resetModified();
    });
  }
  extractPages(t, e = null) {
    const s = {
      pageInfos: t
    };
    let i;
    const n = globalThis.ImageBitmap;
    if (typeof n == "function") {
      const r = Array.isArray(t) ? t : [t];
      for (const a of r)
        a?.image instanceof n && (i ||= []).push(a.image);
    }
    if (this.annotationStorage.size > 0) {
      const r = this.annotationStorage.serializable;
      let {
        map: a
      } = r;
      r.transfer?.length && (i ? i.push(...r.transfer) : i = r.transfer);
      const o = this.pagesMapper.getMapping();
      if (o) {
        const l = /* @__PURE__ */ new Map();
        for (const [h, d] of a) {
          if (d?.pageIndex !== void 0 && d.pageIndex >= 0 && d.pageIndex < o.length) {
            const u = e?.[d.pageIndex] ?? 0, f = o[d.pageIndex] - 1;
            if (f !== d.pageIndex || u !== 0) {
              l.set(h, {
                ...d,
                pageIndex: f,
                copyLevel: u
              });
              continue;
            }
          }
          l.set(h, d);
        }
        a = l;
      }
      s.annotationStorage = a;
    }
    return this.messageHandler.sendWithPromise("ExtractPages", s, i).finally(() => {
      this.annotationStorage.resetModified();
    });
  }
  getPage(t) {
    if (!Number.isInteger(t) || t <= 0 || t > this.pagesMapper.pagesNumber)
      return Promise.reject(new Error("Invalid page request."));
    const e = t - 1, s = this.pagesMapper.getPageId(t) - 1, i = this.#n.get(e);
    if (i)
      return i;
    const n = this.messageHandler.sendWithPromise("GetPage", {
      pageIndex: s
    }).then((r) => {
      if (this.destroyed)
        throw new Error("Transport destroyed");
      r.refStr && this.#a.set(r.refStr, s);
      const a = new Si(e, r, this, this.pagesMapper, this._params.pdfBug);
      return this.#i.set(e, a), a;
    });
    return this.#n.set(e, n), n;
  }
  async getPageIndex(t) {
    if (!ai(t))
      throw new Error("Invalid pageIndex request.");
    const e = await this.messageHandler.sendWithPromise("GetPageIndex", {
      num: t.num,
      gen: t.gen
    }), s = this.pagesMapper.getPageNumber(e + 1);
    if (s === 0)
      throw new Error("GetPageIndex: page has been removed.");
    return s - 1;
  }
  getAnnotations(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotations", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1,
      intent: e
    });
  }
  getFieldObjects() {
    return this.#o("GetFieldObjects");
  }
  getSignatures() {
    return this.#o("GetSignatures");
  }
  getSignatureData(t) {
    return this.messageHandler.sendWithPromise("GetSignatureData", t);
  }
  hasJSActions() {
    return this.#o("HasJSActions");
  }
  getCalculationOrderIds() {
    return this.messageHandler.sendWithPromise("GetCalculationOrderIds", null);
  }
  getDestinations() {
    return this.messageHandler.sendWithPromise("GetDestinations", null);
  }
  getDestination(t) {
    return typeof t != "string" ? Promise.reject(new Error("Invalid destination request.")) : this.messageHandler.sendWithPromise("GetDestination", {
      id: t
    });
  }
  getPageLabels() {
    return this.messageHandler.sendWithPromise("GetPageLabels", null);
  }
  getPageLayout() {
    return this.messageHandler.sendWithPromise("GetPageLayout", null);
  }
  getPageMode() {
    return this.messageHandler.sendWithPromise("GetPageMode", null);
  }
  getViewerPreferences() {
    return this.messageHandler.sendWithPromise("GetViewerPreferences", null);
  }
  getOpenAction() {
    return this.messageHandler.sendWithPromise("GetOpenAction", null);
  }
  getAttachments() {
    return this.messageHandler.sendWithPromise("GetAttachments", null);
  }
  getAttachmentContent(t) {
    return this.messageHandler.sendWithPromise("GetAttachmentContent", t);
  }
  getAnnotationsByType(t, e) {
    return this.messageHandler.sendWithPromise("GetAnnotationsByType", {
      types: t,
      pageIndexesToSkip: e
    });
  }
  getDocJSActions() {
    return this.#o("GetDocJSActions");
  }
  getPageJSActions(t) {
    return this.messageHandler.sendWithPromise("GetPageJSActions", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1
    });
  }
  getStructTree(t) {
    return this.messageHandler.sendWithPromise("GetStructTree", {
      pageIndex: this.pagesMapper.getPageId(t + 1) - 1
    });
  }
  getOutline() {
    return this.messageHandler.sendWithPromise("GetOutline", null);
  }
  getOptionalContentConfig(t) {
    return this.#o("GetOptionalContentConfig").then((e) => new bi(e, t));
  }
  getPermissions() {
    return this.messageHandler.sendWithPromise("GetPermissions", null);
  }
  getMetadata() {
    const t = "GetMetadata";
    return this.#e.getOrInsertComputed(t, () => this.messageHandler.sendWithPromise(t, null).then((e) => ({
      info: e[0],
      metadata: e[1] ? new Da(e[1]) : null,
      contentDispositionFilename: this.#t?.filename ?? null,
      contentLength: this.#t?.contentLength ?? null,
      hasStructTree: e[2]
    })));
  }
  getMarkInfo() {
    return this.messageHandler.sendWithPromise("GetMarkInfo", null);
  }
  async startCleanup(t = !1) {
    if (!this.destroyed) {
      await this.messageHandler.sendWithPromise("Cleanup", null);
      for (const e of this.#i.values())
        if (!e.cleanup())
          throw new Error(`startCleanup: Page ${e.pageNumber} is currently rendering.`);
      this.commonObjs.clear(), t || this.fontLoader.clear(), this.#e.clear(), this.filterFactory.destroy(!0), Lt.cleanup();
    }
  }
  cachedPageNumber(t) {
    if (!ai(t))
      return null;
    const e = t.gen === 0 ? `${t.num}R` : `${t.num}R${t.gen}`, s = this.#a.get(e);
    if (s >= 0) {
      const i = this.pagesMapper.getPageNumber(s + 1);
      if (i !== 0)
        return i;
    }
    return null;
  }
}
class Ha {
  _internalRenderTask = null;
  onContinue = null;
  onError = null;
  constructor(t) {
    this._internalRenderTask = t;
  }
  get promise() {
    return this._internalRenderTask.capability.promise;
  }
  cancel(t = 0) {
    this._internalRenderTask.cancel(null, t);
  }
  get separateAnnots() {
    const {
      separateAnnots: t
    } = this._internalRenderTask.operatorList;
    if (!t)
      return !1;
    const {
      annotationCanvasMap: e
    } = this._internalRenderTask;
    return t.form || t.canvas && e?.size > 0;
  }
  get imageCoordinates() {
    return this._internalRenderTask.imageCoordinates || null;
  }
}
class De {
  #t = null;
  static #e = /* @__PURE__ */ new WeakSet();
  constructor({
    callback: t,
    params: e,
    objs: s,
    commonObjs: i,
    annotationCanvasMap: n,
    operatorList: r,
    pageIndex: a,
    canvasFactory: o,
    filterFactory: l,
    useRequestAnimationFrame: h = !1,
    pdfBug: d = !1,
    pageColors: u = null,
    enableHWA: f = !1,
    operationsFilter: p = null
  }) {
    this.callback = t, this.params = e, this.objs = s, this.commonObjs = i, this.annotationCanvasMap = n, this.operatorListIdx = null, this.operatorList = r, this._pageIndex = a, this.canvasFactory = o, this.filterFactory = l, this._pdfBug = d, this.pageColors = u, this.running = !1, this.graphicsReadyCallback = null, this.graphicsReady = !1, this._useRequestAnimationFrame = h === !0 && typeof window < "u", this.cancelled = !1, this.capability = Promise.withResolvers(), this.task = new Ha(this), this._cancelBound = this.cancel.bind(this), this._continueBound = this._continue.bind(this), this._scheduleNextBound = this._scheduleNext.bind(this), this._nextBound = this._next.bind(this), this._canvas = e.canvas, this._canvasContext = e.canvas ? null : e.canvasContext, this._enableHWA = f, this._dependencyTracker = e.dependencyTracker, this._imagesTracker = e.imagesTracker, this._operationsFilter = p;
  }
  get completed() {
    return this.capability.promise.catch(function() {
    });
  }
  initializeGraphics({
    transparency: t = !1,
    optionalContentConfig: e
  }) {
    if (this.cancelled)
      return;
    if (this._canvas) {
      if (De.#e.has(this._canvas))
        throw new Error("Cannot use the same canvas during multiple render() operations. Use different canvas or ensure previous operations were cancelled or completed.");
      De.#e.add(this._canvas);
    }
    this._pdfBug && globalThis.StepperManager?.enabled && (this.stepper = globalThis.StepperManager.create(this._pageIndex), this.stepper.init(this.operatorList), this.stepper.nextBreakPoint = this.stepper.getNextBreakPoint());
    const {
      viewport: s,
      transform: i,
      background: n,
      dependencyTracker: r,
      imagesTracker: a
    } = this.params, o = this._canvasContext || this._canvas.getContext("2d", {
      alpha: !1,
      willReadFrequently: !this._enableHWA
    });
    this.gfx = new Ae(o, this.commonObjs, this.objs, this.canvasFactory, this.filterFactory, {
      optionalContentConfig: e
    }, this.annotationCanvasMap, this.pageColors, r, a), this.gfx.beginDrawing({
      transform: i,
      viewport: s,
      transparency: t,
      background: n
    }), this.operatorListIdx = 0, this.graphicsReady = !0, this.graphicsReadyCallback?.();
  }
  cancel(t = null, e = 0) {
    this.running = !1, this.cancelled = !0, this.gfx?.endDrawing(), this.#t && (window.cancelAnimationFrame(this.#t), this.#t = null), De.#e.delete(this._canvas), t ||= new fi(`Rendering cancelled, page ${this._pageIndex + 1}`, e), this.callback(t), this.task.onError?.(t);
  }
  operatorListChanged() {
    if (!this.graphicsReady) {
      this.graphicsReadyCallback ||= this._continueBound;
      return;
    }
    this.gfx.dependencyTracker?.growOperationsCount(this.operatorList.fnArray.length), this.stepper?.updateOperatorList(this.operatorList), !this.running && this._continue();
  }
  _continue() {
    this.running = !0, !this.cancelled && (this.task.onContinue ? this.task.onContinue(this._scheduleNextBound) : this._scheduleNext());
  }
  _scheduleNext() {
    this._useRequestAnimationFrame ? this.#t = window.requestAnimationFrame(() => {
      this.#t = null, this._nextBound().catch(this._cancelBound);
    }) : Promise.resolve().then(this._nextBound).catch(this._cancelBound);
  }
  async _next() {
    this.cancelled || (this.operatorListIdx = this.gfx.executeOperatorList(this.operatorList, this.operatorListIdx, this._continueBound, this.stepper, this._operationsFilter), this.operatorListIdx === this.operatorList.argsArray.length && (this.running = !1, this.operatorList.lastChunk && (this.gfx.endDrawing(), De.#e.delete(this._canvas), this.callback())));
  }
}
const ja = "6.3.289", $a = "1c8020a7d";
K(3068);
class $t {
  #t = null;
  #e = null;
  #s;
  #i = null;
  #n = !1;
  #a = !1;
  #r = null;
  #o;
  #l = null;
  #h = null;
  static #u = null;
  static get _keyboardManager() {
    return j(this, "_keyboardManager", new _t([[["Escape"], $t.prototype._hideDropdownFromKeyboard], [["Space"], $t.prototype._colorSelectFromKeyboard], [["ArrowDown", "ArrowRight"], $t.prototype._moveToNext], [["ArrowUp", "ArrowLeft"], $t.prototype._moveToPrevious], [["Home"], $t.prototype._moveToBeginning], [["End"], $t.prototype._moveToEnd]]));
  }
  constructor({
    editor: t = null,
    uiManager: e = null
  }) {
    t ? (this.#a = !1, this.#r = t) : this.#a = !0, this.#h = t?._uiManager || e, this.#o = this.#h._eventBus, this.#s = t?.color?.toUpperCase() || this.#h?.highlightColors.values().next().value || "#FFFF98", $t.#u ||= Object.freeze({
      blue: "pdfjs-editor-colorpicker-blue",
      green: "pdfjs-editor-colorpicker-green",
      pink: "pdfjs-editor-colorpicker-pink",
      red: "pdfjs-editor-colorpicker-red",
      yellow: "pdfjs-editor-colorpicker-yellow"
    });
  }
  renderButton() {
    const t = this.#t = document.createElement("button");
    t.className = "colorPicker", t.tabIndex = "0", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-button"), t.ariaHasPopup = "true", this.#r && (t.ariaControls = `${this.#r.id}_colorpicker_dropdown`);
    const e = this.#h._signal;
    t.addEventListener("click", this.#m.bind(this), {
      signal: e
    }), t.addEventListener("keydown", this.#g.bind(this), {
      signal: e
    });
    const s = this.#e = document.createElement("span");
    return s.className = "swatch", s.ariaHidden = "true", s.style.backgroundColor = this.#s, t.append(s), t;
  }
  renderMainDropdown() {
    const t = this.#i = this.#d();
    return t.ariaOrientation = "horizontal", t.ariaLabelledBy = "highlightColorPickerLabel", t;
  }
  #d() {
    const t = document.createElement("div"), e = this.#h._signal;
    t.addEventListener("contextmenu", Yt, {
      signal: e
    }), t.className = "dropdown", t.role = "listbox", t.ariaMultiSelectable = "false", t.ariaOrientation = "vertical", t.setAttribute("data-l10n-id", "pdfjs-editor-colorpicker-dropdown"), this.#r && (t.id = `${this.#r.id}_colorpicker_dropdown`);
    for (const [s, i] of this.#h.highlightColors) {
      const n = document.createElement("button");
      n.tabIndex = "0", n.role = "option", n.setAttribute("data-color", i), n.title = s, n.setAttribute("data-l10n-id", $t.#u[s]);
      const r = document.createElement("span");
      n.append(r), r.className = "swatch", r.style.backgroundColor = i, n.ariaSelected = i === this.#s, n.addEventListener("click", this.#f.bind(this, i), {
        signal: e
      }), t.append(n);
    }
    return t.addEventListener("keydown", this.#g.bind(this), {
      signal: e
    }), t;
  }
  #f(t, e) {
    e.stopPropagation(), this.#o.dispatch("switchannotationeditorparams", {
      source: this,
      type: q.HIGHLIGHT_COLOR,
      value: t
    }), this.update(t);
  }
  _colorSelectFromKeyboard(t) {
    if (t.target === this.#t) {
      this.#m(t);
      return;
    }
    const e = t.target.getAttribute("data-color");
    e && this.#f(e, t);
  }
  _moveToNext(t) {
    if (!this.#p) {
      this.#m(t);
      return;
    }
    if (t.target === this.#t) {
      this.#i.firstElementChild?.focus();
      return;
    }
    t.target.nextSibling?.focus();
  }
  _moveToPrevious(t) {
    if (t.target === this.#i?.firstElementChild || t.target === this.#t) {
      this.#p && this._hideDropdownFromKeyboard();
      return;
    }
    this.#p || this.#m(t), t.target.previousSibling?.focus();
  }
  _moveToBeginning(t) {
    if (!this.#p) {
      this.#m(t);
      return;
    }
    this.#i.firstElementChild?.focus();
  }
  _moveToEnd(t) {
    if (!this.#p) {
      this.#m(t);
      return;
    }
    this.#i.lastElementChild?.focus();
  }
  #g(t) {
    $t._keyboardManager.exec(this, t);
  }
  #m(t) {
    if (this.#p) {
      this.hideDropdown();
      return;
    }
    if (this.#n = t.detail === 0, this.#l || (this.#l = new AbortController(), window.addEventListener("pointerdown", this.#c.bind(this), {
      signal: this.#h.combinedSignal(this.#l)
    })), this.#t.ariaExpanded = "true", this.#i) {
      this.#i.classList.remove("hidden");
      return;
    }
    const e = this.#i = this.#d();
    this.#t.append(e);
  }
  #c(t) {
    this.#i?.contains(t.target) || this.hideDropdown();
  }
  hideDropdown() {
    this.#i?.classList.add("hidden"), this.#t.ariaExpanded = "false", this.#l?.abort(), this.#l = null;
  }
  get #p() {
    return this.#i && !this.#i.classList.contains("hidden");
  }
  _hideDropdownFromKeyboard() {
    if (!this.#a) {
      if (!this.#p) {
        this.#r?.unselect();
        return;
      }
      this.hideDropdown(), this.#t.focus({
        preventScroll: !0,
        focusVisible: this.#n
      });
    }
  }
  update(t) {
    if (this.#e && (this.#e.style.backgroundColor = t), !this.#i)
      return;
    const e = this.#h.highlightColors.values();
    for (const s of this.#i.children)
      s.ariaSelected = e.next().value === t.toUpperCase();
  }
  destroy() {
    this.#t?.remove(), this.#t = null, this.#e = null, this.#i?.remove(), this.#i = null;
  }
}
class ts {
  #t = null;
  #e = !1;
  #s = null;
  #i = null;
  static #n = null;
  constructor(t) {
    this.#s = t, this.#i = t._uiManager, ts.#n ||= Object.freeze({
      freetext: "pdfjs-editor-color-picker-free-text-input",
      ink: "pdfjs-editor-color-picker-ink-input"
    });
  }
  renderButton() {
    if (this.#t)
      return this.#t;
    const {
      editorType: t,
      colorType: e,
      colorAndOpacityType: s,
      opacityType: i,
      color: n,
      opacity: r
    } = this.#s, a = this.#e = at.isAlphaColorInputSupported && i !== void 0, o = this.#t = document.createElement("input");
    if (o.type = "color", a) {
      o.setAttribute("alpha", "");
      const l = N.hexNums[Math.round((r ?? 1) * 255)];
      o.value = (n || "#000000") + l;
    } else
      o.value = n || "#000000";
    return o.className = "basicColorPicker", o.tabIndex = 0, o.setAttribute("data-l10n-id", ts.#n[t]), o.addEventListener("input", () => {
      if (a) {
        const l = ss(o.value);
        if (!l)
          return;
        const [h, d, u, f] = l, p = N.makeHexColor(h, d, u);
        s !== void 0 ? this.#i.updateParams(s, {
          color: p,
          opacity: f
        }) : (this.#i.updateParams(e, p), this.#i.updateParams(i, f));
      } else
        this.#i.updateParams(e, o.value);
    }, {
      signal: this.#i._signal
    }), o;
  }
  update(t) {
    if (this.#t)
      if (this.#e) {
        const e = N.hexNums[Math.round(this.#s.opacity * 255)];
        this.#t.value = t + e;
      } else
        this.#t.value = t;
  }
  updateOpacity(t) {
    if (!this.#t || !this.#e)
      return;
    const e = N.hexNums[Math.round(t * 255)];
    this.#t.value = this.#s.color + e;
  }
  destroy() {
    this.#t?.remove(), this.#t = null;
  }
  hideDropdown() {
  }
}
K(531);
function mn(c) {
  return Math.floor(ct(c, 0, 1) * 255).toString(16).padStart(2, "0");
}
function $e(c) {
  return ct(c, 0, 1) * 255;
}
class vn {
  static CMYK_G([t, e, s, i]) {
    return ["G", 1 - Math.min(1, 0.3 * t + 0.59 * s + 0.11 * e + i)];
  }
  static G_CMYK([t]) {
    return ["CMYK", 0, 0, 0, 1 - t];
  }
  static G_RGB([t]) {
    return ["RGB", t, t, t];
  }
  static G_rgb([t]) {
    return t = $e(t), [t, t, t];
  }
  static G_HTML([t]) {
    const e = mn(t);
    return `#${e}${e}${e}`;
  }
  static RGB_G([t, e, s]) {
    return ["G", 0.3 * t + 0.59 * e + 0.11 * s];
  }
  static RGB_rgb(t) {
    return t.map($e);
  }
  static RGB_HTML(t) {
    return `#${t.map(mn).join("")}`;
  }
  static T_HTML() {
    return "#00000000";
  }
  static T_rgb() {
    return [null];
  }
  static CMYK_RGB([t, e, s, i]) {
    return ["RGB", 1 - Math.min(1, t + i), 1 - Math.min(1, s + i), 1 - Math.min(1, e + i)];
  }
  static CMYK_rgb([t, e, s, i]) {
    return [$e(1 - Math.min(1, t + i)), $e(1 - Math.min(1, s + i)), $e(1 - Math.min(1, e + i))];
  }
  static CMYK_HTML(t) {
    const e = this.CMYK_RGB(t).slice(1);
    return this.RGB_HTML(e);
  }
  static RGB_CMYK([t, e, s]) {
    const i = 1 - t, n = 1 - e, r = 1 - s, a = Math.min(i, n, r);
    return ["CMYK", i, n, r, a];
  }
}
class Ga {
  create(t, e, s = !1) {
    if (t <= 0 || e <= 0)
      throw new Error("Invalid SVG dimensions");
    const i = this._createSVG("svg:svg");
    return i.setAttribute("version", "1.1"), s || (i.setAttribute("width", `${t}px`), i.setAttribute("height", `${e}px`)), i.setAttribute("preserveAspectRatio", "none"), i.setAttribute("viewBox", `0 0 ${t} ${e}`), i;
  }
  createElement(t) {
    if (typeof t != "string")
      throw new Error("Invalid SVG element type");
    return this._createSVG(t);
  }
  _createSVG(t) {
    st("Abstract method `_createSVG` called.");
  }
}
class ws extends Ga {
  _createSVG(t) {
    return document.createElementNS(Ot, t);
  }
}
const Va = 9, we = /* @__PURE__ */ new WeakSet(), za = (/* @__PURE__ */ new Date()).getTimezoneOffset() * 60 * 1e3;
class Ys {
  static create(t) {
    switch (t.data.annotationType) {
      case pt.LINK:
        return new wi(t);
      case pt.TEXT:
        return new Xa(t);
      case pt.WIDGET:
        switch (t.data.fieldType) {
          case "Tx":
            return new Ya(t);
          case "Btn":
            return t.data.radioButton ? new Qa(t) : t.data.checkBox ? new Ja(t) : new Za(t);
          case "Ch":
            return new qa(t);
          case "Sig":
            return new Ka(t);
        }
        return new xe(t);
      case pt.POPUP:
        return new oi(t);
      case pt.FREETEXT:
        return new Gn(t);
      case pt.LINE:
        return new eo(t);
      case pt.SQUARE:
        return new so(t);
      case pt.CIRCLE:
        return new io(t);
      case pt.POLYLINE:
        return new Vn(t);
      case pt.CARET:
        return new ro(t);
      case pt.INK:
        return new Ei(t);
      case pt.POLYGON:
        return new no(t);
      case pt.HIGHLIGHT:
        return new zn(t);
      case pt.UNDERLINE:
        return new ao(t);
      case pt.SQUIGGLY:
        return new oo(t);
      case pt.STRIKEOUT:
        return new lo(t);
      case pt.STAMP:
        return new Wn(t);
      case pt.FILEATTACHMENT:
        return new ho(t);
      case pt.RICHMEDIA:
      case pt.SCREEN:
      case pt.SOUND:
        return new Xn(t);
      default:
        return new ut(t);
    }
  }
}
class ut {
  #t = null;
  #e = !1;
  #s = null;
  constructor(t, {
    isRenderable: e = !1,
    ignoreBorder: s = !1,
    createQuadrilaterals: i = !1
  } = {}) {
    this.isRenderable = e, this.data = t.data, this.layer = t.layer, this.linkService = t.linkService, this.downloadManager = t.downloadManager, this.imageResourcesPath = t.imageResourcesPath, this.renderForms = t.renderForms, this.svgFactory = t.svgFactory, this.annotationStorage = t.annotationStorage, this.enableComment = t.enableComment, this.enableScripting = t.enableScripting, this.hasJSActions = t.hasJSActions, this._fieldObjects = t.fieldObjects, this.parent = t.parent, this.hasOwnCommentButton = !1, e && (this.contentElement = this.container = this._createContainer(s)), i && this._createQuadrilaterals();
  }
  static _hasPopupData({
    contentsObj: t,
    richText: e
  }) {
    return !!(t?.str || e?.str);
  }
  get _isEditable() {
    return this.data.isEditable;
  }
  get hasPopupData() {
    return ut._hasPopupData(this.data) || this.enableComment && !!this.commentText;
  }
  get commentData() {
    const {
      data: t
    } = this, e = this.annotationStorage?.getEditor(t.id);
    return e ? e.getData() : t;
  }
  get hasCommentButton() {
    return this.enableComment && this.hasPopupElement;
  }
  get commentButtonPosition() {
    const t = this.annotationStorage?.getEditor(this.data.id);
    if (t)
      return t.commentButtonPositionInPage;
    const {
      quadPoints: e,
      inkLists: s,
      rect: i
    } = this.data;
    let n = -1 / 0, r = -1 / 0;
    if (e?.length >= 8) {
      for (let a = 0; a < e.length; a += 8)
        e[a + 1] > r ? (r = e[a + 1], n = e[a + 2]) : e[a + 1] === r && (n = Math.max(n, e[a + 2]));
      return [n, r];
    }
    if (s?.length >= 1) {
      for (const a of s)
        for (let o = 0, l = a.length; o < l; o += 2)
          a[o + 1] > r ? (r = a[o + 1], n = a[o]) : a[o + 1] === r && (n = Math.max(n, a[o]));
      if (n !== 1 / 0)
        return [n, r];
    }
    return i ? [i[2], i[3]] : null;
  }
  _normalizePoint(t) {
    const {
      page: {
        view: e
      },
      viewport: {
        rawDims: {
          pageWidth: s,
          pageHeight: i,
          pageX: n,
          pageY: r
        }
      }
    } = this.parent;
    return t[1] = e[3] - t[1] + e[1], t[0] = 100 * (t[0] - n) / s, t[1] = 100 * (t[1] - r) / i, t;
  }
  get commentText() {
    const {
      data: t
    } = this;
    return this.annotationStorage.getRawValue(`${Ne}${t.id}`)?.popup?.contents || t.contentsObj?.str || "";
  }
  set commentText(t) {
    const {
      data: e
    } = this, s = {
      deleted: !t,
      contents: t || ""
    };
    this.annotationStorage.updateEditor(e.id, {
      popup: s
    }) || this.annotationStorage.setValue(`${Ne}${e.id}`, {
      id: e.id,
      annotationType: e.annotationType,
      page: this.parent.page,
      popup: s,
      popupRef: e.popupRef,
      modificationDate: /* @__PURE__ */ new Date()
    }), t || this.removePopup();
  }
  removePopup() {
    (this.#s?.popup || this.popup)?.remove(), this.#s = this.popup = null;
  }
  updateEdited(t) {
    if (!this.container)
      return;
    t.rect && (this.#t ||= {
      rect: this.data.rect.slice(0)
    });
    const {
      rect: e,
      popup: s
    } = t;
    e && this.#i(e);
    let i = this.#s?.popup || this.popup;
    !i && s?.text && (this._createPopup(s), i = this.#s.popup), i && (i.updateEdited(t), s?.deleted && (i.remove(), this.#s = null, this.popup = null));
  }
  resetEdited() {
    this.#t && (this.#i(this.#t.rect), this.#s?.popup.resetEdited(), this.#t = null);
  }
  #i(t) {
    const {
      container: {
        style: e
      },
      data: {
        rect: s,
        rotation: i
      },
      parent: {
        viewport: {
          rawDims: {
            pageWidth: n,
            pageHeight: r,
            pageX: a,
            pageY: o
          }
        }
      }
    } = this;
    s?.splice(0, 4, ...t), e.left = `${100 * (t[0] - a) / n}%`, e.top = `${100 * (r - t[3] + o) / r}%`, i === 0 ? (e.width = `${100 * (t[2] - t[0]) / n}%`, e.height = `${100 * (t[3] - t[1]) / r}%`) : this.setRotation(i);
  }
  _createContainer(t) {
    const {
      data: e,
      parent: {
        page: s,
        viewport: i
      }
    } = this, n = document.createElement("section");
    n.setAttribute("data-annotation-id", e.id), !(this instanceof xe) && !(this instanceof wi) && !(this instanceof Xn) && (n.tabIndex = 0);
    const {
      style: r
    } = n;
    if (r.zIndex = this.parent.zIndex, this.parent.zIndex += 2, e.alternativeText && (n.title = e.alternativeText), e.noRotate && n.classList.add("norotate"), !e.rect || this instanceof oi) {
      const {
        rotation: g
      } = e;
      return !e.hasOwnCanvas && g !== 0 && this.setRotation(g, n), n;
    }
    const {
      width: a,
      height: o
    } = this;
    if (!t && e.borderStyle.width > 0) {
      r.borderWidth = `${e.borderStyle.width}px`;
      const g = e.borderStyle.horizontalCornerRadius, m = e.borderStyle.verticalCornerRadius;
      if (g > 0 || m > 0) {
        const y = `calc(${g}px * var(--total-scale-factor)) / calc(${m}px * var(--total-scale-factor))`;
        r.borderRadius = y;
      }
      switch (e.borderStyle.style) {
        case Ie.SOLID:
          r.borderStyle = "solid";
          break;
        case Ie.DASHED:
          r.borderStyle = "dashed";
          break;
        case Ie.BEVELED:
          V("Unimplemented border style: beveled");
          break;
        case Ie.INSET:
          V("Unimplemented border style: inset");
          break;
        case Ie.UNDERLINE:
          r.borderBottomStyle = "solid";
          break;
      }
      const v = e.borderColor || null;
      v ? (this.#e = !0, r.borderColor = N.makeHexColor(...v)) : r.borderWidth = 0;
    }
    const l = N.normalizeRect([e.rect[0], s.view[3] - e.rect[1] + s.view[1], e.rect[2], s.view[3] - e.rect[3] + s.view[1]]), {
      pageWidth: h,
      pageHeight: d,
      pageX: u,
      pageY: f
    } = i.rawDims;
    r.left = `${100 * (l[0] - u) / h}%`, r.top = `${100 * (l[1] - f) / d}%`;
    const {
      rotation: p
    } = e;
    return e.hasOwnCanvas || p === 0 ? (r.width = `${100 * a / h}%`, r.height = `${100 * o / d}%`) : this.setRotation(p, n), n;
  }
  setRotation(t, e = this.container) {
    if (!this.data.rect)
      return;
    const {
      pageWidth: s,
      pageHeight: i
    } = this.parent.viewport.rawDims;
    let {
      width: n,
      height: r
    } = this;
    t % 180 !== 0 && ([n, r] = [r, n]), e.style.width = `${100 * n / s}%`, e.style.height = `${100 * r / i}%`, e.setAttribute("data-main-rotation", (360 - t) % 360);
  }
  get _commonActions() {
    const t = (e, s, i) => {
      const n = i.detail[e], r = n[0], a = n.slice(1);
      i.target.style[s] = vn[`${r}_HTML`](a), this.annotationStorage.setValue(this.data.id, {
        [s]: vn[`${r}_rgb`](a)
      });
    };
    return j(this, "_commonActions", {
      display: (e) => {
        const {
          display: s
        } = e.detail, i = s % 2 === 1;
        this.container.style.visibility = i ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noView: i,
          noPrint: s === 1 || s === 2
        });
      },
      print: (e) => {
        this.annotationStorage.setValue(this.data.id, {
          noPrint: !e.detail.print
        });
      },
      hidden: (e) => {
        const {
          hidden: s
        } = e.detail;
        this.container.style.visibility = s ? "hidden" : "visible", this.annotationStorage.setValue(this.data.id, {
          noPrint: s,
          noView: s
        });
      },
      focus: (e) => {
        setTimeout(() => e.target.focus({
          preventScroll: !1
        }), 0);
      },
      userName: (e) => {
        e.target.title = e.detail.userName;
      },
      readonly: (e) => {
        e.target.disabled = e.detail.readonly;
      },
      required: (e) => {
        this._setRequired(e.target, e.detail.required);
      },
      bgColor: (e) => {
        t("bgColor", "backgroundColor", e);
      },
      fillColor: (e) => {
        t("fillColor", "backgroundColor", e);
      },
      fgColor: (e) => {
        t("fgColor", "color", e);
      },
      textColor: (e) => {
        t("textColor", "color", e);
      },
      borderColor: (e) => {
        t("borderColor", "borderColor", e);
      },
      strokeColor: (e) => {
        t("strokeColor", "borderColor", e);
      },
      rotation: (e) => {
        const s = e.detail.rotation;
        this.setRotation(s), this.annotationStorage.setValue(this.data.id, {
          rotation: s
        });
      }
    });
  }
  _dispatchEventFromSandbox(t, e) {
    const s = this._commonActions;
    for (const i of Object.keys(e.detail))
      (t[i] || s[i])?.(e);
  }
  _setDefaultPropertiesFromJS(t) {
    if (!this.enableScripting)
      return;
    const e = this.annotationStorage.getRawValue(this.data.id);
    if (!e)
      return;
    const s = this._commonActions;
    for (const [i, n] of Object.entries(e)) {
      const r = s[i];
      if (r) {
        const a = {
          detail: {
            [i]: n
          },
          target: t
        };
        r(a), delete e[i];
      }
    }
  }
  _createQuadrilaterals() {
    if (!this.container)
      return;
    const {
      quadPoints: t
    } = this.data;
    if (!t)
      return;
    const [e, s, i, n] = this.data.rect.map(Math.fround);
    if (t.length === 8) {
      const [g, m, v, y] = t.subarray(2, 6);
      if (i === g && n === m && e === v && s === y)
        return;
    }
    const {
      style: r
    } = this.container;
    let a;
    if (this.#e) {
      const {
        borderColor: g,
        borderWidth: m
      } = r;
      r.borderWidth = 0, a = ["url('data:image/svg+xml;utf8,", `<svg xmlns="${Ot}" preserveAspectRatio="none" viewBox="0 0 1 1">`, `<g fill="transparent" stroke="${g}" stroke-width="${m}">`], this.container.classList.add("hasBorder");
    }
    const o = i - e, l = n - s, {
      svgFactory: h
    } = this, d = h.createElement("svg");
    d.classList.add("quadrilateralsContainer"), d.setAttribute("width", 0), d.setAttribute("height", 0), d.role = "none";
    const u = h.createElement("defs");
    d.append(u);
    const f = h.createElement("clipPath"), p = `clippath_${this.data.id}`;
    f.setAttribute("id", p), f.setAttribute("clipPathUnits", "objectBoundingBox"), u.append(f);
    for (let g = 2, m = t.length; g < m; g += 8) {
      const v = t[g], y = t[g + 1], b = t[g + 2], w = t[g + 3], A = h.createElement("rect"), S = (b - e) / o, E = (n - y) / l, T = (v - b) / o, x = (y - w) / l;
      A.setAttribute("x", S), A.setAttribute("y", E), A.setAttribute("width", T), A.setAttribute("height", x), f.append(A), a?.push(`<rect vector-effect="non-scaling-stroke" x="${S}" y="${E}" width="${T}" height="${x}"/>`);
    }
    this.#e && (a.push("</g></svg>')"), r.backgroundImage = a.join("")), this.container.append(d), this.container.style.clipPath = `url(#${p})`;
  }
  _createPopup(t = null) {
    const {
      data: e
    } = this;
    let s, i;
    t ? (s = {
      str: t.text
    }, i = t.date) : (s = e.contentsObj, i = e.modificationDate), this.#s = new oi({
      data: {
        color: e.color,
        titleObj: e.titleObj,
        modificationDate: i,
        contentsObj: s,
        richText: e.richText,
        parentRect: e.rect,
        borderStyle: 0,
        id: `popup_${e.id}`,
        rotation: e.rotation,
        noRotate: !0
      },
      linkService: this.linkService,
      parent: this.parent,
      elements: [this]
    });
  }
  get hasPopupElement() {
    return !!(this.#s || this.popup || this.data.popupRef);
  }
  get extraPopupElement() {
    return this.#s;
  }
  render() {
    st("Abstract method `AnnotationElement.render` called");
  }
  _getElementsByName(t, e = null) {
    const s = [];
    if (this._fieldObjects) {
      const i = this._fieldObjects.get(t) || [];
      for (const {
        page: n,
        id: r,
        exportValues: a
      } of i) {
        if (n === -1 || r === e)
          continue;
        const o = typeof a == "string" ? a : null, l = document.querySelector(`[data-element-id="${r}"]`);
        if (l && !we.has(l)) {
          V(`_getElementsByName - element not allowed: ${r}`);
          continue;
        }
        s.push({
          id: r,
          exportValue: o,
          domElement: l
        });
      }
      return s;
    }
    for (const i of document.getElementsByName(t)) {
      const {
        exportValue: n
      } = i, r = i.getAttribute("data-element-id");
      r !== e && we.has(i) && s.push({
        id: r,
        exportValue: n,
        domElement: i
      });
    }
    return s;
  }
  show() {
    this.container && (this.container.hidden = !1), this.popup?.maybeShow();
  }
  hide() {
    this.container && (this.container.hidden = !0), this.popup?.forceHide();
  }
  getElementsToTriggerPopup() {
    return this.container;
  }
  addHighlightArea() {
    const t = this.getElementsToTriggerPopup();
    if (Array.isArray(t))
      for (const e of t)
        e.classList.add("highlightArea");
    else
      t.classList.add("highlightArea");
  }
  _editOnDoubleClick() {
    if (!this._isEditable)
      return;
    const {
      annotationEditorType: t,
      data: {
        id: e
      }
    } = this;
    this.container.addEventListener("dblclick", () => {
      this.linkService.eventBus?.dispatch("switchannotationeditormode", {
        source: this,
        mode: t,
        editId: e,
        mustEnterInEditMode: !0
      });
    });
  }
  updateOC(t) {
    if (!this.data.oc || !t)
      return;
    t.isVisible(this.data.oc) ? this.show() : this.hide();
  }
  get width() {
    return this.data.rect[2] - this.data.rect[0];
  }
  get height() {
    return this.data.rect[3] - this.data.rect[1];
  }
  _setBackgroundColor(t) {
    const e = this.data.backgroundColor || null;
    t.style.backgroundColor = e === null ? "transparent" : N.makeHexColor(...e);
  }
}
class Wa extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.editor = t.editor;
  }
  render() {
    return this.container.className = "editorAnnotation", this.container;
  }
  createOrUpdatePopup() {
    const {
      editor: t
    } = this;
    t.hasComment && this._createPopup(t.comment);
  }
  get hasCommentButton() {
    return this.enableComment && this.editor.hasComment;
  }
  get commentButtonPosition() {
    return this.editor.commentButtonPositionInPage;
  }
  get commentText() {
    return this.editor.comment.text;
  }
  set commentText(t) {
    this.editor.comment = t, t || this.removePopup();
  }
  get commentData() {
    return this.editor.getData();
  }
  remove() {
    this.parent.removeAnnotation(this.data.id), this.container.remove(), this.container = null, this.removePopup();
  }
}
class wi extends ut {
  constructor(t, e = null) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !!e?.ignoreBorder,
      createQuadrilaterals: !0
    }), this.isTooltipOnly = t.data.isTooltipOnly;
  }
  render() {
    const {
      data: t,
      linkService: e
    } = this, s = document.createElement("a");
    s.setAttribute("data-element-id", t.id);
    let i = !1;
    return t.url ? (e.addLinkAttributes(s, t.url, t.newWindow), i = !0) : t.action ? (this._bindNamedAction(s, t.action, t.overlaidText), i = !0) : t.attachment ? (this.#e(s, t.attachmentId, t.attachment, t.overlaidText, t.attachmentDest), i = !0) : t.setOCGState ? (this.#s(s, t.setOCGState, t.overlaidText), i = !0) : t.dest ? (this._bindLink(s, t.dest, t.overlaidText), i = !0) : (t.actions && (t.actions.has("Action") || t.actions.has("Mouse Up") || t.actions.has("Mouse Down")) && this.enableScripting && this.hasJSActions && (this._bindJSAction(s, t), i = !0), t.resetForm ? (this._bindResetFormAction(s, t.resetForm), i = !0) : this.isTooltipOnly && !i && (this._bindLink(s, ""), i = !0)), this.container.classList.add("linkAnnotation"), i && (this.contentElement = s, this.container.append(s)), this.container;
  }
  #t() {
    this.container.setAttribute("data-internal-link", "");
  }
  _bindLink(t, e, s = "") {
    t.href = this.linkService.getDestinationHash(e), t.onclick = () => (e && this.linkService.goToDestination(e), !1), (e || e === "") && this.#t(), s && (t.title = s);
  }
  _bindNamedAction(t, e, s = "") {
    t.href = this.linkService.getAnchorUrl(""), t.onclick = () => (this.linkService.executeNamedAction(e), !1), s && (t.title = s), this.#t();
  }
  #e(t, e, s, i = "", n = null) {
    t.href = this.linkService.getAnchorUrl(""), s.description ? t.title = s.description : i && (t.title = i);
    const r = async () => {
      const a = await this.linkService.getAttachmentContent(e);
      a && this.downloadManager?.openOrDownloadData(a, s.filename, n);
    };
    t.onclick = () => (r(), !1), this.#t();
  }
  #s(t, e, s = "") {
    t.href = this.linkService.getAnchorUrl(""), t.onclick = () => (this.linkService.executeSetOCGState(e), !1), s && (t.title = s), this.#t();
  }
  _bindJSAction(t, {
    actions: e,
    id: s,
    overlaidText: i
  }) {
    t.href = this.linkService.getAnchorUrl("");
    const n = /* @__PURE__ */ new Map([["Action", "onclick"], ["Mouse Up", "onmouseup"], ["Mouse Down", "onmousedown"]]);
    for (const r of e.keys()) {
      const a = n.get(r);
      a && (t[a] = () => (this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: s,
          name: r
        }
      }), !1));
    }
    i && (t.title = i), t.onclick ||= () => !1, this.#t();
  }
  _bindResetFormAction(t, e) {
    const s = t.onclick;
    if (s || (t.href = this.linkService.getAnchorUrl("")), this.#t(), !this._fieldObjects) {
      V('_bindResetFormAction - "resetForm" action not supported, ensure that the `fieldObjects` parameter is provided.'), s || (t.onclick = () => !1);
      return;
    }
    t.onclick = () => {
      s?.();
      const {
        fields: i,
        refs: n,
        include: r
      } = e, a = [];
      if (i.length !== 0 || n.length !== 0) {
        const h = new Set(n);
        for (const d of i) {
          const u = this._fieldObjects.get(d) || [];
          for (const {
            id: f
          } of u)
            h.add(f);
        }
        for (const d of this._fieldObjects.values())
          for (const u of d)
            h.has(u.id) === r && a.push(u);
      } else
        for (const h of this._fieldObjects.values())
          a.push(...h);
      const o = this.annotationStorage, l = [];
      for (const h of a) {
        const {
          id: d
        } = h;
        switch (l.push(d), h.type) {
          case "text": {
            const f = h.defaultValue || "";
            o.setValue(d, {
              value: f
            });
            break;
          }
          case "checkbox":
          case "radiobutton": {
            const f = h.defaultValue === h.exportValues;
            o.setValue(d, {
              value: f
            });
            break;
          }
          case "combobox":
          case "listbox": {
            const f = h.defaultValue || "";
            o.setValue(d, {
              value: f
            });
            break;
          }
          default:
            continue;
        }
        const u = document.querySelector(`[data-element-id="${d}"]`);
        if (u) {
          if (!we.has(u)) {
            V(`_bindResetFormAction - element not allowed: ${d}`);
            continue;
          }
        } else continue;
        u.dispatchEvent(new Event("resetform"));
      }
      return this.enableScripting && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: "app",
          ids: l,
          name: "ResetForm"
        }
      }), !1;
    };
  }
}
class Xa extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
  }
  render() {
    this.container.classList.add("textAnnotation");
    const t = document.createElement("img");
    return t.src = this.imageResourcesPath + "annotation-" + this.data.name.toLowerCase() + ".svg", t.setAttribute("data-l10n-id", "pdfjs-text-annotation-type"), t.setAttribute("data-l10n-args", JSON.stringify({
      type: this.data.name
    })), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(t), this.container;
  }
}
class xe extends ut {
  render() {
    return this.container;
  }
  _getKeyModifier(t) {
    return at.platform.isMac ? t.metaKey : t.ctrlKey;
  }
  _setEventListener(t, e, s, i, n) {
    s.includes("mouse") ? t.addEventListener(s, (r) => {
      this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: n(r),
          shift: r.shiftKey,
          modifier: this._getKeyModifier(r)
        }
      });
    }) : t.addEventListener(s, (r) => {
      if (s === "blur") {
        if (!e.focused || !r.relatedTarget)
          return;
        e.focused = !1;
      } else if (s === "focus") {
        if (e.focused)
          return;
        e.focused = !0;
      }
      n && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: this.data.id,
          name: i,
          value: n(r)
        }
      });
    });
  }
  _setEventListeners(t, e, s, i) {
    const {
      actions: n
    } = this.data;
    for (const [r, a] of s)
      (a === "Action" || n?.has(a)) && ((a === "Focus" || a === "Blur") && (e ||= {
        focused: !1
      }), this._setEventListener(t, e, r, a, i), a === "Focus" && !n?.has("Blur") ? this._setEventListener(t, e, "blur", "Blur", null) : a === "Blur" && !n?.has("Focus") && this._setEventListener(t, e, "focus", "Focus", null));
  }
  _setTextStyle(t) {
    const e = ["left", "center", "right"], {
      fontColor: s
    } = this.data.defaultAppearanceData, i = this.data.defaultAppearanceData.fontSize || Va, n = t.style;
    let r;
    const a = 2, o = (l) => Math.round(10 * l) / 10;
    if (this.data.multiLine) {
      const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a), h = Math.round(l / /* inlined export .LINE_FACTOR */
      (1.35 * i)) || 1, d = l / h;
      r = Math.min(i, o(d / /* inlined export .LINE_FACTOR */
      1.35));
    } else {
      const l = Math.abs(this.data.rect[3] - this.data.rect[1] - a);
      r = Math.min(i, o(l / /* inlined export .LINE_FACTOR */
      1.35));
    }
    n.fontSize = `calc(${r}px * var(--total-scale-factor))`, n.color = N.makeHexColor(...s), this.data.textAlignment !== null && !this.data.comb && (n.textAlign = e[this.data.textAlignment]);
  }
  _setRequired(t, e) {
    e ? t.setAttribute("required", !0) : t.removeAttribute("required"), t.setAttribute("aria-required", e);
  }
}
class Ya extends xe {
  constructor(t) {
    const e = t.renderForms || t.data.hasOwnCanvas || !t.data.hasAppearance && !!t.data.fieldValue;
    super(t, {
      isRenderable: e
    });
  }
  setPropertyOnSiblings(t, e, s, i) {
    const n = this.annotationStorage;
    for (const r of this._getElementsByName(t.name, t.id))
      r.domElement && (r.domElement[e] = s), n.setValue(r.id, {
        [i]: s
      });
  }
  render() {
    const t = this.annotationStorage, e = this.data.id;
    this.container.classList.add("textWidgetAnnotation");
    let s = null;
    if (this.renderForms) {
      const i = t.getValue(e, {
        value: this.data.fieldValue
      });
      let n = i.value || "";
      const r = t.getValue(e, {
        charLimit: this.data.maxLen
      }).charLimit;
      r && n.length > r && (n = n.slice(0, r));
      let a = i.formattedValue || this.data.textContent?.join(`
`) || null;
      a && this.data.comb && (a = a.replaceAll(/\s+/g, ""));
      const o = {
        userValue: n,
        formattedValue: a,
        lastCommittedValue: null,
        commitKey: 1,
        focused: !1
      };
      this.data.multiLine ? (s = document.createElement("textarea"), s.textContent = a ?? n, this.data.doNotScroll && (s.style.overflowY = "hidden")) : (s = document.createElement("input"), s.type = this.data.password ? "password" : "text", s.setAttribute("value", a ?? n), this.data.doNotScroll && (s.style.overflowX = "hidden")), this.data.hasOwnCanvas && (this.container.classList.add("hasOwnCanvas"), t.has(e) && this.container.classList.add("sandboxModified")), we.add(s), this.contentElement = s, s.setAttribute("data-element-id", e), s.disabled = this.data.readOnly, s.name = this.data.fieldName, s.tabIndex = 0;
      const {
        datetimeFormat: l,
        datetimeType: h,
        timeStep: d
      } = this.data, u = !!h && this.enableScripting;
      l && (s.title = l), this._setRequired(s, this.data.required), r && (s.maxLength = r), s.addEventListener("input", (p) => {
        t.setValue(e, {
          value: p.target.value
        }), this.setPropertyOnSiblings(s, "value", p.target.value, "value"), o.formattedValue = null;
      }), s.addEventListener("resetform", (p) => {
        const g = this.data.defaultFieldValue ?? "";
        s.value = o.userValue = g, o.formattedValue = null;
      });
      let f = (p) => {
        const {
          formattedValue: g
        } = o;
        g != null && (p.target.value = g), p.target.scrollLeft = 0;
      };
      if (this.enableScripting && this.hasJSActions) {
        s.addEventListener("focus", (g) => {
          if (o.focused)
            return;
          const {
            target: m
          } = g;
          if (u && (m.type = h, d && (m.step = d)), o.userValue) {
            const v = o.userValue;
            if (u)
              if (h === "time") {
                const y = new Date(v), b = [y.getHours(), y.getMinutes(), y.getSeconds()];
                m.value = b.map((w) => w.toString().padStart(2, "0")).join(":");
              } else
                m.value = new Date(v - za).toISOString().split(h === "date" ? "T" : ".", 1)[0];
            else
              m.value = v;
          }
          o.lastCommittedValue = m.value, o.commitKey = 1, this.data.actions?.has("Focus") || (o.focused = !0);
        }), s.addEventListener("updatefromsandbox", (g) => {
          this.container.classList.add("sandboxModified");
          const m = {
            value(v) {
              o.userValue = v.detail.value ?? "", u || t.setValue(e, {
                value: o.userValue.toString()
              }), v.target.value = o.userValue;
            },
            formattedValue(v) {
              const {
                formattedValue: y
              } = v.detail;
              o.formattedValue = y, y != null && v.target !== document.activeElement && (v.target.value = y);
              const b = {
                formattedValue: y
              };
              u && (b.value = y), t.setValue(e, b);
            },
            selRange(v) {
              v.target.setSelectionRange(...v.detail.selRange);
            },
            charLimit: (v) => {
              const {
                charLimit: y
              } = v.detail, {
                target: b
              } = v;
              if (y === 0) {
                b.removeAttribute("maxLength");
                return;
              }
              b.setAttribute("maxLength", y);
              let w = o.userValue;
              !w || w.length <= y || (w = w.slice(0, y), b.value = o.userValue = w, t.setValue(e, {
                value: w
              }), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
                source: this,
                detail: {
                  id: e,
                  name: "Keystroke",
                  value: w,
                  willCommit: !0,
                  commitKey: 1,
                  selStart: b.selectionStart,
                  selEnd: b.selectionEnd
                }
              }));
            }
          };
          this._dispatchEventFromSandbox(m, g);
        }), s.addEventListener("keydown", (g) => {
          o.commitKey = 1;
          let m = -1;
          if (g.key === "Escape" ? m = 0 : g.key === "Enter" && !this.data.multiLine ? m = 2 : g.key === "Tab" && (o.commitKey = 3), m === -1)
            return;
          const {
            value: v
          } = g.target;
          o.lastCommittedValue !== v && (o.lastCommittedValue = v, o.userValue = v, this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: v,
              willCommit: !0,
              commitKey: m,
              selStart: g.target.selectionStart,
              selEnd: g.target.selectionEnd
            }
          }));
        });
        const p = f;
        f = null, s.addEventListener("blur", (g) => {
          if (!o.focused || !g.relatedTarget)
            return;
          this.data.actions?.has("Blur") || (o.focused = !1);
          const {
            target: m
          } = g;
          let {
            value: v
          } = m;
          if (u) {
            if (v && h === "time") {
              const y = v.split(":").map((b) => parseInt(b, 10));
              v = new Date(2e3, 0, 1, y[0], y[1], y[2] || 0).valueOf(), m.step = "";
            } else
              v.includes("T") || (v = `${v}T00:00`), v = new Date(v).valueOf();
            m.type = "text";
          }
          o.userValue = v, o.lastCommittedValue !== v && this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: v,
              willCommit: !0,
              commitKey: o.commitKey,
              selStart: g.target.selectionStart,
              selEnd: g.target.selectionEnd
            }
          }), p(g);
        }), this.data.actions?.has("Keystroke") && s.addEventListener("beforeinput", (g) => {
          o.lastCommittedValue = null;
          const {
            data: m,
            target: v
          } = g, {
            value: y,
            selectionStart: b,
            selectionEnd: w
          } = v;
          let A = b, S = w;
          switch (g.inputType) {
            case "deleteWordBackward": {
              const E = /\w/;
              for (; A > 0 && !E.test(y[A - 1]); )
                A--;
              for (; A > 0 && E.test(y[A - 1]); )
                A--;
              break;
            }
            case "deleteWordForward": {
              const E = y.substring(b).match(/^\W*\w*/);
              E && (S += E[0].length);
              break;
            }
            case "deleteContentBackward":
              b === w && (A -= 1);
              break;
            case "deleteContentForward":
              b === w && (S += 1);
              break;
          }
          g.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
            source: this,
            detail: {
              id: e,
              name: "Keystroke",
              value: y,
              change: m || "",
              willCommit: !1,
              selStart: A,
              selEnd: S
            }
          });
        }), this._setEventListeners(s, o, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (g) => g.target.value);
      }
      if (f && s.addEventListener("blur", f), this.data.comb) {
        const g = (this.data.rect[2] - this.data.rect[0]) / r;
        s.classList.add("comb"), s.style.setProperty("--comb-width", `calc(${g}px * var(--total-scale-factor))`);
        const m = this.data.textAlignment;
        if (m === 1 || m === 2) {
          const v = () => {
            const y = r - s.value.length;
            s.style.setProperty("--comb-offset", `${m === 1 ? y >> 1 : y}`);
          };
          v();
          for (const y of ["input", "blur", "resetform", "updatefromsandbox"])
            s.addEventListener(y, v);
        }
      }
    } else
      s = document.createElement("div"), s.textContent = this.data.fieldValue, s.style.verticalAlign = "middle", s.style.display = "table-cell", this.data.hasOwnCanvas && (s.hidden = !0);
    return this._setTextStyle(s), this._setBackgroundColor(s), this._setDefaultPropertiesFromJS(s), this.container.append(s), this.container;
  }
}
class Ka extends xe {
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.hasOwnCanvas
    });
  }
}
class Ja extends xe {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.exportValue === e.fieldValue
    }).value;
    typeof i == "string" && (i = i !== "Off", t.setValue(s, {
      value: i
    })), this.container.classList.add("buttonWidgetAnnotation", "checkBox");
    const n = document.createElement("input");
    return we.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "checkbox", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.setAttribute("exportValue", e.exportValue), n.tabIndex = 0, n.addEventListener("change", (r) => {
      const {
        name: a,
        checked: o
      } = r.target;
      for (const l of this._getElementsByName(a, s)) {
        const h = o && l.exportValue === e.exportValue;
        l.domElement && (l.domElement.checked = h), t.setValue(l.id, {
          value: h
        });
      }
      t.setValue(s, {
        value: o
      });
    }), n.addEventListener("resetform", (r) => {
      const a = e.defaultFieldValue || "Off";
      r.target.checked = a === e.exportValue;
    }), this.enableScripting && this.hasJSActions && (n.addEventListener("updatefromsandbox", (r) => {
      const a = {
        value(o) {
          o.target.checked = o.detail.value !== "Off", t.setValue(s, {
            value: o.target.checked
          });
        }
      };
      this._dispatchEventFromSandbox(a, r);
    }), this._setEventListeners(n, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (r) => r.target.checked)), this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
  }
}
class Qa extends xe {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("buttonWidgetAnnotation", "radioButton");
    const t = this.annotationStorage, e = this.data, s = e.id;
    let i = t.getValue(s, {
      value: e.buttonValue !== null && e.fieldValue === e.buttonValue
    }).value;
    if (typeof i == "string" && (i = i !== e.buttonValue, t.setValue(s, {
      value: i
    })), i)
      for (const r of this._getElementsByName(e.fieldName, s))
        t.setValue(r.id, {
          value: !1
        });
    const n = document.createElement("input");
    if (we.add(n), n.setAttribute("data-element-id", s), n.disabled = e.readOnly, this._setRequired(n, this.data.required), n.type = "radio", n.name = e.fieldName, i && n.setAttribute("checked", !0), n.tabIndex = 0, n.addEventListener("change", (r) => {
      const {
        name: a,
        checked: o
      } = r.target;
      for (const l of this._getElementsByName(a, s))
        t.setValue(l.id, {
          value: !1
        });
      t.setValue(s, {
        value: o
      });
    }), n.addEventListener("resetform", (r) => {
      const a = e.defaultFieldValue;
      r.target.checked = a != null && a === e.buttonValue;
    }), this.enableScripting && this.hasJSActions) {
      const r = e.buttonValue;
      n.addEventListener("updatefromsandbox", (a) => {
        const o = {
          value: (l) => {
            const h = r === l.detail.value;
            for (const d of this._getElementsByName(l.target.name)) {
              const u = h && d.id === s;
              d.domElement && (d.domElement.checked = u), t.setValue(d.id, {
                value: u
              });
            }
          }
        };
        this._dispatchEventFromSandbox(o, a);
      }), this._setEventListeners(n, null, [["change", "Validate"], ["change", "Action"], ["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"]], (a) => a.target.checked);
    }
    return this._setDefaultPropertiesFromJS(n), this.container.append(n), this.container;
  }
}
class Za extends wi {
  constructor(t) {
    super(t, {
      ignoreBorder: t.data.hasAppearance
    });
  }
  render() {
    const t = super.render();
    t.classList.add("buttonWidgetAnnotation", "pushButton");
    const e = t.lastChild;
    return this.enableScripting && this.hasJSActions && e && (this._setDefaultPropertiesFromJS(e), e.addEventListener("updatefromsandbox", (s) => {
      this._dispatchEventFromSandbox({}, s);
    })), t;
  }
}
class qa extends xe {
  constructor(t) {
    super(t, {
      isRenderable: t.renderForms
    });
  }
  render() {
    this.container.classList.add("choiceWidgetAnnotation");
    const t = this.annotationStorage, e = this.data.id, s = t.getValue(e, {
      value: this.data.fieldValue
    }), i = document.createElement("select");
    we.add(i), i.setAttribute("data-element-id", e), i.disabled = this.data.readOnly, this._setRequired(i, this.data.required), i.name = this.data.fieldName, i.tabIndex = 0;
    let n = this.data.combo && this.data.options.length > 0;
    this.data.combo || (i.size = this.data.options.length, this.data.multiSelect && (i.multiple = !0)), i.addEventListener("resetform", (d) => {
      const u = this.data.defaultFieldValue;
      for (const f of i.options)
        f.selected = f.value === u;
    });
    const r = (d, u) => {
      const f = u.replaceAll(" ", "\xA0");
      d.textContent = f, f !== u && d.setAttribute("display-value", u);
    };
    for (const d of this.data.options) {
      const u = document.createElement("option");
      r(u, d.displayValue), u.value = d.exportValue, s.value.includes(d.exportValue) && (u.setAttribute("selected", !0), n = !1), i.append(u);
    }
    let a = null;
    if (n) {
      const d = document.createElement("option");
      d.value = " ", d.setAttribute("hidden", !0), d.setAttribute("selected", !0), i.prepend(d), a = () => {
        d.remove(), i.removeEventListener("input", a), a = null;
      }, i.addEventListener("input", a);
    }
    const o = (d) => {
      const u = d ? "value" : "textContent", {
        options: f,
        multiple: p
      } = i;
      return p ? Array.prototype.filter.call(f, (g) => g.selected).map((g) => g[u]) : f.selectedIndex === -1 ? null : f[f.selectedIndex][u];
    };
    let l = o(!1);
    const h = (d) => {
      const u = d.target.options;
      return Array.prototype.map.call(u, (f) => ({
        displayValue: f.getAttribute("display-value") || f.textContent,
        exportValue: f.value
      }));
    };
    return this.enableScripting && this.hasJSActions ? (i.addEventListener("updatefromsandbox", (d) => {
      const u = {
        value(f) {
          a?.();
          const p = f.detail.value, g = new Set(Array.isArray(p) ? p : [p]);
          for (const m of i.options)
            m.selected = g.has(m.value);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        multipleSelection(f) {
          i.multiple = !0;
        },
        remove(f) {
          const p = i.options, g = f.detail.remove;
          p[g].selected = !1, i.remove(g), p.length > 0 && Array.prototype.findIndex.call(p, (v) => v.selected) === -1 && (p[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        clear(f) {
          for (; i.length !== 0; )
            i.remove(0);
          t.setValue(e, {
            value: null,
            items: []
          }), l = o(!1);
        },
        insert(f) {
          const {
            index: p,
            displayValue: g,
            exportValue: m
          } = f.detail.insert, v = i.children[p], y = document.createElement("option");
          r(y, g), y.value = m, v ? v.before(y) : i.append(y), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        items(f) {
          const {
            items: p
          } = f.detail;
          for (; i.length !== 0; )
            i.remove(0);
          for (const g of p) {
            const {
              displayValue: m,
              exportValue: v
            } = g, y = document.createElement("option");
            r(y, m), y.value = v, i.append(y);
          }
          i.options.length > 0 && (i.options[0].selected = !0), t.setValue(e, {
            value: o(!0),
            items: h(f)
          }), l = o(!1);
        },
        indices(f) {
          const p = new Set(f.detail.indices);
          for (const g of f.target.options)
            g.selected = p.has(g.index);
          t.setValue(e, {
            value: o(!0)
          }), l = o(!1);
        },
        editable(f) {
          f.target.disabled = !f.detail.editable;
        }
      };
      this._dispatchEventFromSandbox(u, d);
    }), i.addEventListener("input", (d) => {
      const u = o(!0), f = o(!1);
      t.setValue(e, {
        value: u
      }), d.preventDefault(), this.linkService.eventBus?.dispatch("dispatcheventinsandbox", {
        source: this,
        detail: {
          id: e,
          name: "Keystroke",
          value: l,
          change: f,
          changeEx: u,
          willCommit: !1,
          commitKey: 1,
          keyDown: !1
        }
      });
    }), this._setEventListeners(i, null, [["focus", "Focus"], ["blur", "Blur"], ["mousedown", "Mouse Down"], ["mouseenter", "Mouse Enter"], ["mouseleave", "Mouse Exit"], ["mouseup", "Mouse Up"], ["input", "Action"], ["input", "Validate"]], (d) => d.target.value)) : i.addEventListener("input", function(d) {
      t.setValue(e, {
        value: o(!0)
      });
    }), this.data.combo && this._setTextStyle(i), this._setBackgroundColor(i), this._setDefaultPropertiesFromJS(i), this.container.append(i), this.container;
  }
}
class oi extends ut {
  constructor(t) {
    const {
      data: e,
      elements: s,
      parent: i
    } = t, n = !!i._commentManager;
    if (super(t, {
      isRenderable: !n && ut._hasPopupData(e)
    }), this.elements = s, n && ut._hasPopupData(e)) {
      const r = this.popup = this.#t();
      for (const a of s)
        a.popup = r;
    } else
      this.popup = null;
  }
  #t() {
    return new to({
      container: this.container,
      color: this.data.color,
      titleObj: this.data.titleObj,
      modificationDate: this.data.modificationDate || this.data.creationDate,
      contentsObj: this.data.contentsObj,
      richText: this.data.richText,
      rect: this.data.rect,
      parentRect: this.data.parentRect || null,
      parent: this.parent,
      elements: this.elements,
      open: this.data.open,
      commentManager: this.parent._commentManager
    });
  }
  render() {
    const {
      container: t
    } = this;
    t.classList.add("popupAnnotation"), t.role = "comment";
    const e = this.popup = this.#t(), s = [];
    for (const i of this.elements)
      i.popup = e, i.container.ariaHasPopup = "dialog", s.push(i.data.id), i.addHighlightArea();
    return this.container.setAttribute("aria-controls", s.map((i) => `${Re}${i}`).join(",")), this.container;
  }
}
class to {
  #t = null;
  #e = this.#V.bind(this);
  #s = this.#S.bind(this);
  #i = this.#C.bind(this);
  #n = this.#j.bind(this);
  #a = null;
  #r = null;
  #o = null;
  #l = null;
  #h = null;
  #u = null;
  #d = null;
  #f = !1;
  #g = null;
  #m = null;
  #c = null;
  #p = null;
  #v = null;
  #y = null;
  #b = null;
  #A = null;
  #E = null;
  #w = null;
  #x = !1;
  #T = null;
  #M = null;
  constructor({
    container: t,
    color: e,
    elements: s,
    titleObj: i,
    modificationDate: n,
    contentsObj: r,
    richText: a,
    parent: o,
    rect: l,
    parentRect: h,
    open: d,
    commentManager: u = null
  }) {
    this.#r = t, this.#E = i, this.#o = r, this.#A = a, this.#u = o, this.#a = e, this.#b = l, this.#d = h, this.#h = s, this.#t = u, this.#T = s[0], this.#l = ti.toDateObject(n), this.trigger = s.flatMap((f) => f.getElementsToTriggerPopup()), u || (this.#I(), this.#r.hidden = !0, d && this.#j());
  }
  #I() {
    if (this.#m)
      return;
    this.#m = new AbortController();
    const {
      signal: t
    } = this.#m;
    for (const e of this.trigger)
      e.addEventListener("click", this.#n, {
        signal: t
      }), e.addEventListener("pointerenter", this.#i, {
        signal: t
      }), e.addEventListener("pointerleave", this.#s, {
        signal: t
      }), e.classList.add("popupTriggerArea");
    for (const e of this.#h)
      e.container?.addEventListener("keydown", this.#e, {
        signal: t
      });
  }
  #P() {
    const t = this.#h.find((e) => e.hasCommentButton);
    t && (this.#v = t._normalizePoint(t.commentButtonPosition));
  }
  renderCommentButton() {
    if (this.#p) {
      this.#p.parentNode || this.#T.container.after(this.#p);
      return;
    }
    if (this.#v || this.#P(), !this.#v)
      return;
    const {
      signal: t
    } = this.#m = new AbortController(), e = this.#T.hasOwnCommentButton, s = () => {
      this.#t.toggleCommentPopup(this, !0, void 0, !e);
    }, i = () => {
      this.#t.toggleCommentPopup(this, !1, !0, !e);
    }, n = () => {
      this.#t.toggleCommentPopup(this, !1, !1);
    };
    if (e) {
      this.#p = this.#T.container;
      for (const r of this.trigger)
        r.ariaHasPopup = "dialog", r.ariaControls = "commentPopup", r.addEventListener("keydown", this.#e, {
          signal: t
        }), r.addEventListener("click", s, {
          signal: t
        }), r.addEventListener("pointerenter", i, {
          signal: t
        }), r.addEventListener("pointerleave", n, {
          signal: t
        }), r.classList.add("popupTriggerArea");
    } else {
      const r = this.#p = document.createElement("button");
      r.className = "annotationCommentButton";
      const a = this.#T.container;
      r.style.zIndex = parseInt(a.style.zIndex, 10) + 1, r.tabIndex = 0, r.ariaHasPopup = "dialog", r.ariaControls = "commentPopup", r.setAttribute("data-l10n-id", "pdfjs-show-comment-button"), this.#R(), this.#D(), r.addEventListener("keydown", this.#e, {
        signal: t
      }), r.addEventListener("click", s, {
        signal: t
      }), r.addEventListener("pointerenter", i, {
        signal: t
      }), r.addEventListener("pointerleave", n, {
        signal: t
      }), a.after(r);
    }
  }
  #D() {
    if (this.#T.extraPopupElement && !this.#T.editor)
      return;
    this.#p || this.renderCommentButton();
    const [t, e] = this.#v, {
      style: s
    } = this.#p;
    s.left = `calc(${t}%)`, s.top = `calc(${e}% - var(--comment-button-dim))`;
  }
  #R() {
    this.#T.extraPopupElement || (this.#p || this.renderCommentButton(), this.#p.style.backgroundColor = this.commentButtonColor || "");
  }
  get commentButtonColor() {
    const {
      color: t,
      opacity: e
    } = this.#T.commentData;
    return t ? this.#u._commentManager.makeCommentColor(t, e) : null;
  }
  focusCommentButton() {
    setTimeout(() => {
      this.#p?.focus();
    }, 0);
  }
  getData() {
    const {
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: n
    } = this.#T.commentData;
    return {
      contentsObj: {
        str: this.comment
      },
      richText: t,
      color: e,
      opacity: s,
      creationDate: i,
      modificationDate: n
    };
  }
  get elementBeforePopup() {
    return this.#p;
  }
  get comment() {
    return this.#M ||= this.#T.commentText, this.#M;
  }
  set comment(t) {
    t !== this.comment && (this.#T.commentText = this.#M = t);
  }
  focus() {
    this.#T.container?.focus();
  }
  get parentBoundingClientRect() {
    return this.#T.layer.getBoundingClientRect();
  }
  setCommentButtonStates({
    selected: t,
    hasPopup: e
  }) {
    this.#p && (this.#p.classList.toggle("selected", t), this.#p.ariaExpanded = e);
  }
  setSelectedCommentButton(t) {
    this.#p.classList.toggle("selected", t);
  }
  get commentPopupPosition() {
    if (this.#y)
      return this.#y;
    const {
      x: t,
      y: e,
      height: s
    } = this.#p.getBoundingClientRect(), {
      x: i,
      y: n,
      width: r,
      height: a
    } = this.#T.layer.getBoundingClientRect();
    return [(t - i) / r, (e + s - n) / a];
  }
  set commentPopupPosition(t) {
    this.#y = t;
  }
  hasDefaultPopupPosition() {
    return this.#y === null;
  }
  get commentButtonPosition() {
    return this.#v;
  }
  get commentButtonWidth() {
    return this.#p.getBoundingClientRect().width / this.parentBoundingClientRect.width;
  }
  editComment(t) {
    const [e, s] = this.#y || this.commentButtonPosition.map((l) => l / 100), i = this.parentBoundingClientRect, {
      x: n,
      y: r,
      width: a,
      height: o
    } = i;
    this.#t.showDialog(null, this, n + e * a, r + s * o, {
      ...t,
      parentDimensions: i
    });
  }
  render() {
    if (this.#g)
      return;
    const t = this.#g = document.createElement("div");
    if (t.className = "popup", this.#a) {
      const s = t.style.outlineColor = N.makeHexColor(...this.#a);
      t.style.backgroundColor = `color-mix(in srgb, ${s} 30%, white)`;
    }
    const e = document.createElement("span");
    if (e.className = "header", this.#E?.str) {
      const s = document.createElement("span");
      s.className = "title", e.append(s), {
        dir: s.dir,
        str: s.textContent
      } = this.#E;
    }
    if (t.append(e), this.#l) {
      const s = document.createElement("time");
      s.className = "popupDate", s.setAttribute("data-l10n-id", "pdfjs-annotation-date-time-string"), s.setAttribute("data-l10n-args", JSON.stringify({
        dateObj: this.#l.valueOf()
      })), s.dateTime = this.#l.toISOString(), e.append(s);
    }
    En({
      html: this.#k || this.#o.str,
      dir: this.#o?.dir,
      className: "popupContent"
    }, t), this.#r.append(t);
  }
  get #k() {
    const t = this.#A, e = this.#o;
    return t?.str && (!e?.str || e.str === t.str) && this.#A.html || null;
  }
  get #H() {
    return this.#k?.attributes?.style?.fontSize || 0;
  }
  get #N() {
    return this.#k?.attributes?.style?.color || null;
  }
  #L(t) {
    const e = [], s = {
      str: t,
      html: {
        name: "div",
        attributes: {
          dir: "auto"
        },
        children: [{
          name: "p",
          children: e
        }]
      }
    }, i = {
      style: {
        color: this.#N,
        fontSize: this.#H ? `calc(${this.#H}px * var(--total-scale-factor))` : ""
      }
    };
    for (const n of t.split(`
`))
      e.push({
        name: "span",
        value: n,
        attributes: i
      });
    return s;
  }
  #V(t) {
    t.altKey || t.shiftKey || t.ctrlKey || t.metaKey || (t.key === "Enter" || t.key === "Escape" && this.#f) && this.#j();
  }
  updateEdited({
    rect: t,
    popup: e,
    deleted: s
  }) {
    if (this.#t) {
      s ? (this.remove(), this.#M = null) : e && (e.deleted ? this.remove() : (this.#R(), this.#M = e.text)), t && (this.#v = null, this.#P(), this.#D());
      return;
    }
    if (s || e?.deleted) {
      this.remove();
      return;
    }
    this.#I(), this.#w ||= {
      contentsObj: this.#o,
      richText: this.#A
    }, t && (this.#c = null), e && e.text && (this.#A = this.#L(e.text), this.#l = ti.toDateObject(e.date), this.#o = null), this.#g?.remove(), this.#g = null;
  }
  resetEdited() {
    this.#w && ({
      contentsObj: this.#o,
      richText: this.#A
    } = this.#w, this.#w = null, this.#g?.remove(), this.#g = null, this.#c = null);
  }
  remove() {
    if (this.#m?.abort(), this.#m = null, this.#g?.remove(), this.#g = null, this.#x = !1, this.#f = !1, this.#p?.remove(), this.#p = null, this.trigger)
      for (const t of this.trigger)
        t.classList.remove("popupTriggerArea");
  }
  #B() {
    if (this.#c !== null)
      return;
    const {
      page: {
        view: t
      },
      viewport: {
        rawDims: {
          pageWidth: e,
          pageHeight: s,
          pageX: i,
          pageY: n
        }
      }
    } = this.#u;
    let r = !!this.#d, a = r ? this.#d : this.#b;
    for (const p of this.#h)
      if (!a || N.intersect(p.data.rect, a) !== null) {
        a = p.data.rect, r = !0;
        break;
      }
    const o = N.normalizeRect([a[0], t[3] - a[1] + t[1], a[2], t[3] - a[3] + t[1]]), h = r ? a[2] - a[0] + 5 : 0, d = o[0] + h, u = o[1];
    this.#c = [100 * (d - i) / e, 100 * (u - n) / s];
    const {
      style: f
    } = this.#r;
    f.left = `${this.#c[0]}%`, f.top = `${this.#c[1]}%`;
  }
  #j() {
    if (this.#t) {
      this.#t.toggleCommentPopup(this, !1);
      return;
    }
    this.#f = !this.#f, this.#f ? (this.#C(), this.#r.addEventListener("click", this.#n), this.#r.addEventListener("keydown", this.#e)) : (this.#S(), this.#r.removeEventListener("click", this.#n), this.#r.removeEventListener("keydown", this.#e));
  }
  #C() {
    this.#g || this.render(), this.isVisible ? this.#f && this.#r.classList.add("focused") : (this.#B(), this.#r.hidden = !1, this.#r.style.zIndex = parseInt(this.#r.style.zIndex, 10) + 1e3);
  }
  #S() {
    this.#r.classList.remove("focused"), !(this.#f || !this.isVisible) && (this.#r.hidden = !0, this.#r.style.zIndex = parseInt(this.#r.style.zIndex, 10) - 1e3);
  }
  forceHide() {
    this.#x = this.isVisible, this.#x && (this.#r.hidden = !0);
  }
  maybeShow() {
    this.#t || (this.#I(), this.#x && (this.#g || this.#C(), this.#x = !1, this.#r.hidden = !1));
  }
  get isVisible() {
    return !this.#t && this.#r.hidden === !1;
  }
}
class Gn extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.textContent = t.data.textContent, this.textPosition = t.data.textPosition, this.annotationEditorType = X.FREETEXT;
  }
  render() {
    if (this.container.classList.add("freeTextAnnotation"), this.textContent) {
      const t = this.contentElement = document.createElement("div");
      t.classList.add("annotationTextContent"), t.setAttribute("role", "comment");
      for (const e of this.textContent) {
        const s = document.createElement("span");
        s.textContent = e, t.append(s);
      }
      this.container.append(t);
    }
    return !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
class eo extends ut {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("lineAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = this.svgFactory.create(e, s, !0), n = this.#t = this.svgFactory.createElement("svg:line");
    return n.setAttribute("x1", t.rect[2] - t.lineCoordinates[0]), n.setAttribute("y1", t.rect[3] - t.lineCoordinates[1]), n.setAttribute("x2", t.rect[2] - t.lineCoordinates[2]), n.setAttribute("y2", t.rect[3] - t.lineCoordinates[3]), n.setAttribute("stroke-width", t.borderStyle.width || 1), n.setAttribute("stroke", "transparent"), n.setAttribute("fill", "transparent"), i.append(n), this.container.append(i), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class so extends ut {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("squareAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = this.svgFactory.create(e, s, !0), n = t.borderStyle.width, r = this.#t = this.svgFactory.createElement("svg:rect");
    return r.setAttribute("x", n / 2), r.setAttribute("y", n / 2), r.setAttribute("width", e - n), r.setAttribute("height", s - n), r.setAttribute("stroke-width", n || 1), r.setAttribute("stroke", "transparent"), r.setAttribute("fill", "transparent"), i.append(r), this.container.append(i), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class io extends ut {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    this.container.classList.add("circleAnnotation");
    const {
      data: t,
      width: e,
      height: s
    } = this, i = this.svgFactory.create(e, s, !0), n = t.borderStyle.width, r = this.#t = this.svgFactory.createElement("svg:ellipse");
    return r.setAttribute("cx", e / 2), r.setAttribute("cy", s / 2), r.setAttribute("rx", e / 2 - n / 2), r.setAttribute("ry", s / 2 - n / 2), r.setAttribute("stroke-width", n || 1), r.setAttribute("stroke", "transparent"), r.setAttribute("fill", "transparent"), i.append(r), this.container.append(i), !t.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class Vn extends ut {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.containerClassName = "polylineAnnotation", this.svgElementName = "svg:polyline";
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: t,
        vertices: e,
        borderStyle: s,
        popupRef: i
      },
      width: n,
      height: r
    } = this;
    if (!e)
      return this.container;
    const a = this.svgFactory.create(n, r, !0);
    let o = [];
    for (let h = 0, d = e.length; h < d; h += 2) {
      const u = e[h] - t[0], f = t[3] - e[h + 1];
      o.push(`${u},${f}`);
    }
    o = o.join(" ");
    const l = this.#t = this.svgFactory.createElement(this.svgElementName);
    return l.setAttribute("points", o), l.setAttribute("stroke-width", s.width || 1), l.setAttribute("stroke", "transparent"), l.setAttribute("fill", "transparent"), a.append(l), this.container.append(a), !i && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class no extends Vn {
  constructor(t) {
    super(t), this.containerClassName = "polygonAnnotation", this.svgElementName = "svg:polygon";
  }
}
class ro extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    });
  }
  render() {
    return this.container.classList.add("caretAnnotation"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container;
  }
}
class Ei extends ut {
  #t = null;
  #e = [];
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.containerClassName = "inkAnnotation", this.svgElementName = "svg:polyline", this.annotationEditorType = this.data.it === "InkHighlight" ? X.HIGHLIGHT : X.INK;
  }
  #s(t, e) {
    switch (t) {
      case 90:
        return {
          transform: `rotate(90) translate(${-e[0]},${e[1]}) scale(1,-1)`,
          width: e[3] - e[1],
          height: e[2] - e[0]
        };
      case 180:
        return {
          transform: `rotate(180) translate(${-e[2]},${e[1]}) scale(1,-1)`,
          width: e[2] - e[0],
          height: e[3] - e[1]
        };
      case 270:
        return {
          transform: `rotate(270) translate(${-e[2]},${e[3]}) scale(1,-1)`,
          width: e[3] - e[1],
          height: e[2] - e[0]
        };
      default:
        return {
          transform: `translate(${-e[0]},${e[3]}) scale(1,-1)`,
          width: e[2] - e[0],
          height: e[3] - e[1]
        };
    }
  }
  render() {
    this.container.classList.add(this.containerClassName);
    const {
      data: {
        rect: t,
        rotation: e,
        inkLists: s,
        borderStyle: i,
        popupRef: n
      }
    } = this, {
      transform: r,
      width: a,
      height: o
    } = this.#s(e, t), l = this.svgFactory.create(a, o, !0), h = this.#t = this.svgFactory.createElement("svg:g");
    l.append(h), h.setAttribute("stroke-width", i.width || 1), h.setAttribute("stroke-linecap", "round"), h.setAttribute("stroke-linejoin", "round"), h.setAttribute("stroke-miterlimit", 10), h.setAttribute("stroke", "transparent"), h.setAttribute("fill", "transparent"), h.setAttribute("transform", r);
    for (const d of s) {
      const u = this.svgFactory.createElement(this.svgElementName);
      this.#e.push(u), u.setAttribute("points", d.join(",")), h.append(u);
    }
    return !n && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.append(l), this._editOnDoubleClick(), this.container;
  }
  updateEdited(t) {
    super.updateEdited(t);
    const {
      thickness: e,
      points: s,
      rect: i
    } = t, n = this.#t;
    if (e >= 0 && n.setAttribute("stroke-width", e || 1), s)
      for (let r = 0, a = this.#e.length; r < a; r++)
        this.#e[r].setAttribute("points", s[r].join(","));
    if (i) {
      const {
        transform: r,
        width: a,
        height: o
      } = this.#s(this.data.rotation, i);
      n.parentElement.setAttribute("viewBox", `0 0 ${a} ${o}`), n.setAttribute("transform", r);
    }
  }
  getElementsToTriggerPopup() {
    return this.#e;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
}
class zn extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    }), this.annotationEditorType = X.HIGHLIGHT;
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("highlightAnnotation"), this._editOnDoubleClick(), t) {
      const s = document.createElement("mark");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class ao extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("underlineAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class oo extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("squigglyAnnotation"), t) {
      const s = document.createElement("u");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class lo extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0,
      createQuadrilaterals: !0
    });
  }
  render() {
    const {
      data: {
        overlaidText: t,
        popupRef: e
      }
    } = this;
    if (!e && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this.container.classList.add("strikeoutAnnotation"), t) {
      const s = document.createElement("s");
      s.classList.add("overlaidText"), s.textContent = t, this.container.append(s);
    }
    return this.container;
  }
}
class Wn extends ut {
  constructor(t) {
    super(t, {
      isRenderable: !0,
      ignoreBorder: !0
    }), this.annotationEditorType = X.STAMP;
  }
  render() {
    return this.container.classList.add("stampAnnotation"), this.container.setAttribute("role", "img"), !this.data.popupRef && this.hasPopupData && (this.hasOwnCommentButton = !0, this._createPopup()), this._editOnDoubleClick(), this.container;
  }
}
class ho extends ut {
  #t = null;
  constructor(t) {
    super(t, {
      isRenderable: !0
    });
    const {
      fileId: e,
      file: s
    } = this.data;
    this.filename = s.filename, this.content = s.content, this.fileId = e, this.linkService.eventBus?.dispatch("fileattachmentannotation", {
      source: this,
      attachmentId: this.fileId,
      ...s
    });
  }
  render() {
    this.container.classList.add("fileAttachmentAnnotation");
    const {
      container: t,
      data: e
    } = this;
    let s;
    e.hasAppearance || e.fillAlpha === 0 ? s = document.createElement("div") : (s = document.createElement("img"), s.src = `${this.imageResourcesPath}annotation-${/paperclip/i.test(e.name) ? "paperclip" : "pushpin"}.svg`, e.fillAlpha && e.fillAlpha < 1 && (s.style = `filter: opacity(${Math.round(e.fillAlpha * 100)}%);`)), s.addEventListener("dblclick", this.#e.bind(this)), this.#t = s;
    const {
      isMac: i
    } = at.platform;
    return t.addEventListener("keydown", (n) => {
      n.key === "Enter" && (i ? n.metaKey : n.ctrlKey) && this.#e();
    }), !e.popupRef && this.hasPopupData ? (this.hasOwnCommentButton = !0, this._createPopup()) : s.classList.add("popupTriggerArea"), t.append(s), t;
  }
  getElementsToTriggerPopup() {
    return this.#t;
  }
  addHighlightArea() {
    this.container.classList.add("highlightArea");
  }
  async #e() {
    const {
      fileId: t,
      filename: e,
      content: s
    } = this, i = await this.linkService.getAttachmentContent(t) || s;
    i && this.downloadManager?.openOrDownloadData(i, e);
  }
}
class Xn extends ut {
  #t = new AbortController();
  #e = null;
  #s = null;
  constructor(t) {
    super(t, {
      isRenderable: !!t.data.richMedia
    });
  }
  render() {
    this.container.classList.add("mediaAnnotation");
    const {
      filename: t
    } = this.data.richMedia, e = document.createElement("button");
    return e.className = "mediaPlayButton", e.type = "button", e.title = e.ariaLabel = t, e.addEventListener("click", () => this.#i(e), {
      signal: this.#t.signal
    }), this.container.append(e), this.container;
  }
  async #i(t) {
    const {
      fileId: e,
      filename: s,
      contentType: i
    } = this.data.richMedia;
    t.disabled = !0;
    let n;
    try {
      n = await this.linkService.getAttachmentContent(e);
    } catch {
      return;
    } finally {
      t.disabled = !1;
    }
    if (!n || !t.isConnected)
      return;
    const {
      signal: r
    } = this.#t, a = URL.createObjectURL(new Blob([n], {
      type: i
    }));
    this.#e = a;
    const o = i.startsWith("audio/"), l = document.createElement(o ? "audio" : "video");
    if (this.#s = l, l.className = "mediaContent", this._setBackgroundColor(l), l.src = a, l.title = s, l.controls = !0, l.autoplay = !0, l.tabIndex = 0, o) {
      let h = !1, d = !1;
      const u = () => {
        l.controls = h || d;
      };
      this.container.addEventListener("pointerenter", () => {
        h = !0, u();
      }, {
        signal: r
      }), this.container.addEventListener("pointerleave", () => {
        h = !1, u();
      }, {
        signal: r
      }), this.container.addEventListener("focusin", () => {
        d = !0, u();
      }, {
        signal: r
      }), this.container.addEventListener("focusout", () => {
        d = !1, u();
      }, {
        signal: r
      });
    }
    l.addEventListener("emptied", () => this.#n(a), {
      once: !0,
      signal: r
    }), t.replaceWith(l), l.play().catch(() => {
    });
  }
  #n(t = this.#e) {
    t && t === this.#e && (URL.revokeObjectURL(t), this.#e = null);
  }
  destroy() {
    this.#t.abort(), this.#s && (this.#s.pause(), this.#s.removeAttribute("src"), this.#s.load(), this.#s = null), this.#n();
  }
}
class xi {
  #t = null;
  #e = null;
  #s = null;
  #i = /* @__PURE__ */ new Map();
  #n = null;
  #a = null;
  #r = [];
  #o = !1;
  zIndex = 0;
  constructor({
    div: t,
    accessibilityManager: e,
    annotationCanvasMap: s,
    annotationEditorUIManager: i,
    page: n,
    viewport: r,
    structTreeLayer: a,
    commentManager: o,
    linkService: l,
    annotationStorage: h
  }) {
    this.div = t, this.#t = e, this.#e = s, this.#n = a || null, this.#a = l || null, this.#s = h || new vi(), this.page = n, this.viewport = r, this._annotationEditorUIManager = i, this._commentManager = o || null;
  }
  hasEditableAnnotations() {
    return this.#i.size > 0;
  }
  async render(t) {
    const {
      annotations: e,
      optionalContentConfig: s
    } = t, i = this.div;
    Se(i, this.viewport);
    const n = /* @__PURE__ */ new Map(), r = [], a = {
      data: null,
      layer: i,
      linkService: this.#a,
      downloadManager: t.downloadManager,
      imageResourcesPath: t.imageResourcesPath || "",
      renderForms: t.renderForms !== !1,
      svgFactory: new ws(),
      annotationStorage: this.#s,
      enableComment: t.enableComment === !0,
      enableScripting: t.enableScripting === !0,
      hasJSActions: t.hasJSActions,
      fieldObjects: t.fieldObjects,
      parent: this,
      elements: null
    };
    for (const o of e) {
      if (o.noHTML)
        continue;
      const l = o.annotationType === pt.POPUP;
      if (l) {
        const u = n.get(o.id);
        if (!u)
          continue;
        if (!this._commentManager) {
          r.push(o);
          continue;
        }
        a.elements = u;
      } else if (o.rect[2] === o.rect[0] || o.rect[3] === o.rect[1])
        continue;
      a.data = o;
      const h = Ys.create(a);
      if (!h.isRenderable)
        continue;
      l || (this.#r.push(h), o.popupRef && n.getOrInsertComputed(o.popupRef, Le).push(h));
      const d = h.render();
      o.hidden && (d.style.visibility = "hidden"), h.updateOC(s), h._isEditable && (this.#i.set(h.data.id, h), this._annotationEditorUIManager?.renderAnnotationElement(h));
    }
    await this.#l();
    for (const o of r) {
      const l = a.elements = n.get(o.id);
      a.data = o;
      const h = Ys.create(a);
      if (!h.isRenderable)
        continue;
      const d = h.render();
      h.contentElement.id = `${Re}${o.id}`, o.hidden && (d.style.visibility = "hidden"), l.at(-1).container.after(d);
    }
    this.#h();
  }
  async #l() {
    if (this.#r.length === 0)
      return;
    this.div.replaceChildren();
    const t = [];
    if (!this.#o) {
      this.#o = !0;
      for (const {
        contentElement: s,
        data: {
          hidden: i,
          id: n,
          oc: r
        }
      } of this.#r) {
        const a = s.id = `${Re}${n}`, o = s.localName === "a" && !i && !r;
        t.push(this.#n?.getAriaAttributes(a, {
          enableLinkOwnership: o
        }).then((l) => {
          if (l)
            for (const [h, d] of l)
              s.setAttribute(h, d);
        }));
      }
    }
    this.#r.sort(({
      data: {
        rect: [s, i, n, r]
      }
    }, {
      data: {
        rect: [a, o, l, h]
      }
    }) => {
      if (s === n && i === r)
        return 1;
      if (a === l && o === h)
        return -1;
      const d = r, u = i, f = (i + r) / 2, p = h, g = o, m = (o + h) / 2;
      if (f >= p && m <= u)
        return -1;
      if (m >= d && f <= g)
        return 1;
      const v = (s + n) / 2, y = (a + l) / 2;
      return v - y;
    });
    const e = document.createDocumentFragment();
    for (const s of this.#r)
      e.append(s.container), this._commentManager ? (s.extraPopupElement?.popup || s.popup)?.renderCommentButton() : s.extraPopupElement && e.append(s.extraPopupElement.render());
    if (this.div.append(e), await Promise.all(t), this.#t) {
      const s = await this.#n?.getAnnotationIds();
      for (const {
        contentElement: i
      } of this.#r)
        s?.has(i.id) || this.#t.addPointerInTextLayer(i, !1);
    }
  }
  async addLinkAnnotations(t) {
    const e = {
      data: null,
      layer: this.div,
      linkService: this.#a,
      svgFactory: new ws(),
      parent: this
    };
    for (const s of t) {
      s.borderStyle ||= xi._defaultBorderStyle, e.data = s;
      const i = Ys.create(e);
      i.isRenderable && (i.render(), i.contentElement.id = `${Re}${s.id}`, this.#r.push(i));
    }
    await this.#l();
  }
  update({
    viewport: t,
    optionalContentConfig: e
  }) {
    const s = this.div;
    this.viewport = t, Se(s, {
      rotation: t.rotation
    });
    for (const i of this.#r)
      i.updateOC(e);
    this.#h(), s.hidden = !1;
  }
  destroy() {
    for (const t of this.#r)
      t.destroy?.(), this.#t?.removePointerInTextLayer(t.contentElement);
    this.#r.length = 0, this.#i.clear(), this.div.replaceChildren();
  }
  #h() {
    if (!this.#e)
      return;
    const t = this.div;
    for (const [e, s] of this.#e) {
      const i = t.querySelector(`[data-annotation-id="${e}"]`);
      if (!i)
        continue;
      if (Array.isArray(s))
        for (const l of s)
          l.className = "annotationContent", l.ariaHidden = !0;
      else
        s.className = "annotationContent", s.ariaHidden = !0;
      const n = [];
      for (const l of i.children)
        l.nodeName === "CANVAS" && n.push(l);
      for (const l of n)
        l.remove();
      const r = Array.isArray(s) ? s[0] : s, {
        firstChild: a
      } = i;
      if (a ? a.classList.contains("annotationContent") ? a.after(r) : a.before(r) : i.append(r), Array.isArray(s)) {
        let l = r;
        for (let h = 1, d = s.length; h < d; h++)
          l.after(s[h]), l = s[h];
      }
      this.#e.delete(e);
      const o = this.#i.get(e);
      o && (o._hasNoCanvas ? (this._annotationEditorUIManager?.setMissingCanvas(e, i.id, s), o._hasNoCanvas = !1) : o.canvas = s);
    }
  }
  refreshCanvases() {
    this.#h();
  }
  getEditableAnnotations() {
    return this.#i.values();
  }
  getEditableAnnotation(t) {
    return this.#i.get(t);
  }
  addFakeAnnotation(t) {
    const {
      div: e
    } = this, {
      id: s,
      rotation: i
    } = t, n = new Wa({
      data: {
        id: s,
        rect: t.getPDFRect(),
        rotation: i
      },
      editor: t,
      layer: e,
      parent: this,
      enableComment: !!this._commentManager,
      linkService: this.#a,
      annotationStorage: this.#s
    });
    return n.render(), n.contentElement.id = `${Re}${s}`, n.createOrUpdatePopup(), this.#r.push(n), n;
  }
  removeAnnotation(t) {
    const e = this.#r.findIndex((i) => i.data.id === t);
    if (e < 0)
      return;
    const [s] = this.#r.splice(e, 1);
    this.#t?.removePointerInTextLayer(s.contentElement);
  }
  updateFakeAnnotations(t) {
    if (t.length !== 0) {
      for (const e of t)
        e.updateFakeAnnotationElement(this);
      this.#l();
    }
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  static get _defaultBorderStyle() {
    return j(this, "_defaultBorderStyle", Object.freeze({
      width: 1,
      rawWidth: 1,
      style: Ie.SOLID,
      dashArray: [3],
      horizontalCornerRadius: 0,
      verticalCornerRadius: 0
    }));
  }
}
const ds = /\r\n?|\n/g;
class Et extends H {
  #t = "";
  #e = `${this.id}-editor`;
  #s = null;
  #i;
  _colorPicker = null;
  static _freeTextDefaultContent = "";
  static _internalPadding = 0;
  static _defaultColor = null;
  static _defaultFontSize = 10;
  static get _keyboardManager() {
    const t = Et.prototype, e = (n) => n.isEmpty(), s = de.TRANSLATE_SMALL, i = de.TRANSLATE_BIG;
    return j(this, "_keyboardManager", new _t([[["ctrl+s", "mac+meta+s", "ctrl+p", "mac+meta+p"], t.commitOrRemove, {
      bubbles: !0
    }], [["ctrl+Enter", "mac+meta+Enter"], t.commitOrRemove], [["Escape"], t.commitOrRemove], [["ArrowLeft"], t._translateEmpty, {
      args: [-s, 0],
      checker: e
    }], [["ctrl+ArrowLeft", "mac+shift+ArrowLeft"], t._translateEmpty, {
      args: [-i, 0],
      checker: e
    }], [["ArrowRight"], t._translateEmpty, {
      args: [s, 0],
      checker: e
    }], [["ctrl+ArrowRight", "mac+shift+ArrowRight"], t._translateEmpty, {
      args: [i, 0],
      checker: e
    }], [["ArrowUp"], t._translateEmpty, {
      args: [0, -s],
      checker: e
    }], [["ctrl+ArrowUp", "mac+shift+ArrowUp"], t._translateEmpty, {
      args: [0, -i],
      checker: e
    }], [["ArrowDown"], t._translateEmpty, {
      args: [0, s],
      checker: e
    }], [["ctrl+ArrowDown", "mac+shift+ArrowDown"], t._translateEmpty, {
      args: [0, i],
      checker: e
    }]]));
  }
  static _type = "freetext";
  static _editorType = X.FREETEXT;
  constructor(t) {
    super({
      ...t,
      name: "freeTextEditor"
    }), this.color = t.color || Et._defaultColor || H._defaultLineColor, this.#i = t.fontSize || Et._defaultFontSize, this.annotationElementId || this._uiManager.a11yAlert(H._l10nAlert.freetext), this.canAddComment = !1;
  }
  static initialize(t, e) {
    H.initialize(t, e);
    const s = getComputedStyle(document.documentElement);
    this._internalPadding = parseFloat(s.getPropertyValue("--freetext-padding"));
  }
  static updateDefaultParams(t, e) {
    switch (t) {
      case q.FREETEXT_SIZE:
        Et._defaultFontSize = e;
        break;
      case q.FREETEXT_COLOR:
        Et._defaultColor = e;
        break;
    }
  }
  updateParams(t, e) {
    switch (t) {
      case q.FREETEXT_SIZE:
        this.#n(e);
        break;
      case q.FREETEXT_COLOR:
        this.#a(e);
        break;
    }
  }
  static get defaultPropertiesToUpdate() {
    return [[q.FREETEXT_SIZE, Et._defaultFontSize], [q.FREETEXT_COLOR, Et._defaultColor || H._defaultLineColor]];
  }
  get propertiesToUpdate() {
    return [[q.FREETEXT_SIZE, this.#i], [q.FREETEXT_COLOR, this.color]];
  }
  get toolbarButtons() {
    return this._colorPicker ||= new ts(this), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return q.FREETEXT_COLOR;
  }
  #n(t) {
    const e = (i) => {
      this.editorDiv.style.fontSize = `calc(${i}px * var(--total-scale-factor))`, this.translate(0, -(i - this.#i) * this.parentScale), this.#i = i, this.#o();
    }, s = this.#i;
    this.addCommands({
      cmd: e.bind(this, t),
      undo: e.bind(this, s),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: q.FREETEXT_SIZE,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  onUpdatedColor() {
    this.editorDiv.style.color = this.color, this._colorPicker?.update(this.color), super.onUpdatedColor();
  }
  #a(t) {
    const e = (i) => {
      this.color = i, this.onUpdatedColor();
    }, s = this.color;
    this.addCommands({
      cmd: e.bind(this, t),
      undo: e.bind(this, s),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: q.FREETEXT_COLOR,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _translateEmpty(t, e) {
    this._uiManager.translateSelectedEditors(t, e, !0);
  }
  getInitialTranslation() {
    const t = this.parentScale;
    return [-Et._internalPadding * t, -(Et._internalPadding + this.#i) * t];
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.isAttachedToDOM || this.parent.add(this)));
  }
  enableEditMode() {
    if (!super.enableEditMode())
      return !1;
    this.overlayDiv.classList.remove("enabled"), this.editorDiv.contentEditable = !0, this._isDraggable = !1, this.div.removeAttribute("aria-activedescendant"), this.#s = new AbortController();
    const t = this._uiManager.combinedSignal(this.#s);
    return this.editorDiv.addEventListener("keydown", this.editorDivKeydown.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("focus", this.editorDivFocus.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("blur", this.editorDivBlur.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("input", this.editorDivInput.bind(this), {
      signal: t
    }), this.editorDiv.addEventListener("paste", this.editorDivPaste.bind(this), {
      signal: t
    }), !0;
  }
  disableEditMode() {
    return super.disableEditMode() ? (this.overlayDiv.classList.add("enabled"), this.editorDiv.contentEditable = !1, this.div.setAttribute("aria-activedescendant", this.#e), this._isDraggable = !0, this.#s?.abort(), this.#s = null, this.div.focus({
      preventScroll: !0
    }), this.isEditing = !1, this.parent.div.classList.add("freetextEditing"), !0) : !1;
  }
  focusin(t) {
    this._focusEventsAllowed && (super.focusin(t), t.target !== this.editorDiv && this.editorDiv.focus());
  }
  onceAdded(t) {
    this.width || (this.enableEditMode(), t && this.editorDiv.focus(), this._initialOptions?.isCentered && this.center(), this._initialOptions = null);
  }
  isEmpty() {
    return !this.editorDiv || this.editorDiv.innerText.trim() === "";
  }
  remove() {
    this.isEditing = !1, this.parent && (this.parent.setEditingState(!0), this.parent.div.classList.add("freetextEditing")), super.remove();
  }
  #r() {
    const t = [];
    this.editorDiv.normalize();
    let e = null;
    for (const s of this.editorDiv.childNodes)
      e?.nodeType === Node.TEXT_NODE && s.nodeName === "BR" || (t.push(Et.#l(s)), e = s);
    return t.join(`
`);
  }
  #o() {
    const [t, e] = this.parentDimensions;
    let s;
    if (this.isAttachedToDOM)
      s = this.div.getBoundingClientRect();
    else {
      const {
        currentLayer: i,
        div: n
      } = this, r = n.style.display, a = n.classList.contains("hidden");
      n.classList.remove("hidden"), n.style.display = "hidden", i.div.append(this.div), s = n.getBoundingClientRect(), n.remove(), n.style.display = r, n.classList.toggle("hidden", a);
    }
    this.rotation % 180 === this.parentRotation % 180 ? (this.width = s.width / t, this.height = s.height / e) : (this.width = s.height / t, this.height = s.width / e), this.fixAndSetPosition();
  }
  commit() {
    if (!this.isInEditMode())
      return;
    super.commit(), this.disableEditMode();
    const t = this.#t, e = this.#t = this.#r().trimEnd();
    if (t === e)
      return;
    const s = (i) => {
      if (this.#t = i, !i) {
        this.remove();
        return;
      }
      this.#h(), this._uiManager.rebuild(this), this.#o();
    };
    this.addCommands({
      cmd: () => {
        s(e);
      },
      undo: () => {
        s(t);
      },
      mustExec: !1
    }), this.#o();
  }
  shouldGetKeyboardEvents() {
    return this.isInEditMode();
  }
  enterInEditMode() {
    this.enableEditMode(), this.editorDiv.focus();
  }
  keydown(t) {
    t.target === this.div && t.key === "Enter" && (this.enterInEditMode(), t.preventDefault());
  }
  editorDivKeydown(t) {
    Et._keyboardManager.exec(this, t);
  }
  editorDivFocus(t) {
    this.isEditing = !0;
  }
  editorDivBlur(t) {
    this.isEditing = !1;
  }
  editorDivInput(t) {
    this.parent.div.classList.toggle("freetextEditing", this.isEmpty());
  }
  disableEditing() {
    this.editorDiv.setAttribute("role", "comment"), this.editorDiv.removeAttribute("aria-multiline");
  }
  enableEditing() {
    this.editorDiv.setAttribute("role", "textbox"), this.editorDiv.setAttribute("aria-multiline", !0);
  }
  get canChangeContent() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    (this._isCopy || this.annotationElementId) && (t = this.x, e = this.y), super.render(), this.editorDiv = document.createElement("div"), this.editorDiv.className = "internal", this.editorDiv.setAttribute("id", this.#e), this.editorDiv.setAttribute("data-l10n-id", "pdfjs-free-text2"), this.editorDiv.setAttribute("data-l10n-attrs", "default-content"), this.enableEditing(), this.editorDiv.contentEditable = !0;
    const {
      style: s
    } = this.editorDiv;
    if (s.fontSize = `calc(${this.#i}px * var(--total-scale-factor))`, s.color = this.color, this.div.append(this.editorDiv), this.overlayDiv = document.createElement("div"), this.overlayDiv.classList.add("overlay", "enabled"), this.div.append(this.overlayDiv), this._isCopy || this.annotationElementId) {
      const [i, n] = this.parentDimensions;
      if (this.annotationElementId) {
        const {
          position: r
        } = this._initialData;
        let [a, o] = this.getInitialTranslation();
        [a, o] = this.pageTranslationToScreen(a, o);
        const [l, h] = this.pageDimensions, [d, u] = this.pageTranslation;
        let f, p;
        switch (this.rotation) {
          case 0:
            f = t + (r[0] - d) / l, p = e + this.height - (r[1] - u) / h;
            break;
          case 90:
            f = t + (r[0] - d) / l, p = e - (r[1] - u) / h, [a, o] = [o, -a];
            break;
          case 180:
            f = t - this.width + (r[0] - d) / l, p = e - (r[1] - u) / h, [a, o] = [-a, -o];
            break;
          case 270:
            f = t + (r[0] - d - this.height * h) / l, p = e + (r[1] - u - this.width * l) / h, [a, o] = [-o, a];
            break;
        }
        this.setAt(f * i, p * n, a, o);
      } else
        this._moveAfterPaste(t, e);
      this.#h(), this._isDraggable = !0, this.editorDiv.contentEditable = !1;
    } else
      this._isDraggable = !1, this.editorDiv.contentEditable = !0;
    return this.div;
  }
  static #l(t) {
    return (t.nodeType === Node.TEXT_NODE ? t.nodeValue : t.innerText).replaceAll(ds, "");
  }
  editorDivPaste(t) {
    const e = t.clipboardData || window.clipboardData, {
      types: s
    } = e;
    if (s.length === 1 && s[0] === "text/plain")
      return;
    t.preventDefault();
    const i = Et.#d(e.getData("text") || "").replaceAll(ds, `
`);
    if (!i)
      return;
    const n = window.getSelection();
    if (!n.rangeCount)
      return;
    this.editorDiv.normalize(), n.deleteFromDocument();
    const r = n.getRangeAt(0);
    if (!i.includes(`
`)) {
      r.insertNode(document.createTextNode(i)), this.editorDiv.normalize(), n.collapseToStart();
      return;
    }
    const {
      startContainer: a,
      startOffset: o
    } = r, l = [], h = [];
    if (a.nodeType === Node.TEXT_NODE) {
      const f = a.parentElement;
      if (h.push(a.nodeValue.slice(o).replaceAll(ds, "")), f !== this.editorDiv) {
        let p = l;
        for (const g of this.editorDiv.childNodes) {
          if (g === f) {
            p = h;
            continue;
          }
          p.push(Et.#l(g));
        }
      }
      l.push(a.nodeValue.slice(0, o).replaceAll(ds, ""));
    } else if (a === this.editorDiv) {
      let f = l, p = 0;
      for (const g of this.editorDiv.childNodes)
        p++ === o && (f = h), f.push(Et.#l(g));
    }
    this.#t = `${l.join(`
`)}${i}${h.join(`
`)}`, this.#h();
    const d = new Range();
    let u = Math.sumPrecise(l.map((f) => f.length));
    for (const {
      firstChild: f
    } of this.editorDiv.childNodes)
      if (f.nodeType === Node.TEXT_NODE) {
        const p = f.nodeValue.length;
        if (u <= p) {
          d.setStart(f, u), d.setEnd(f, u);
          break;
        }
        u -= p;
      }
    n.removeAllRanges(), n.addRange(d);
  }
  #h() {
    if (this.editorDiv.replaceChildren(), !!this.#t)
      for (const t of this.#t.split(`
`)) {
        const e = document.createElement("div");
        e.append(t ? document.createTextNode(t) : document.createElement("br")), this.editorDiv.append(e);
      }
  }
  #u() {
    return this.#t.replaceAll("\xA0", " ");
  }
  static #d(t) {
    return t.replaceAll(" ", "\xA0");
  }
  get contentDiv() {
    return this.editorDiv;
  }
  getPDFRect() {
    const t = Et._internalPadding * this.parentScale;
    return this.getRect(t, t);
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof Gn) {
      const {
        data: {
          defaultAppearanceData: {
            fontSize: r,
            fontColor: a
          },
          rect: o,
          rotation: l,
          id: h,
          popupRef: d,
          richText: u,
          contentsObj: f,
          creationDate: p,
          modificationDate: g
        },
        textContent: m,
        textPosition: v,
        parent: {
          page: {
            pageNumber: y
          }
        }
      } = t;
      if (!m?.length)
        return null;
      i = t = {
        annotationType: X.FREETEXT,
        color: Array.from(a),
        fontSize: r,
        value: m.join(`
`),
        position: v,
        pageIndex: y - 1,
        rect: o.slice(0),
        rotation: l,
        annotationElementId: h,
        id: h,
        deleted: !1,
        popupRef: d,
        comment: f?.str || null,
        richText: u,
        creationDate: p,
        modificationDate: g
      };
    }
    const n = await super.deserialize(t, e, s);
    return n.#i = t.fontSize, n.color = N.makeHexColor(...t.color), n.#t = Et.#d(t.value), n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const e = H._colorManager.convert(this.isAttachedToDOM ? getComputedStyle(this.editorDiv).color : this.color), s = Object.assign(super.serialize(t), {
      color: e,
      fontSize: this.#i,
      value: this.#u()
    });
    return this.addComment(s), t ? (s.isCopy = !0, s) : this.annotationElementId && !this.#f(s) ? null : (s.id = this.annotationElementId, s);
  }
  #f(t) {
    const {
      value: e,
      fontSize: s,
      color: i,
      pageIndex: n
    } = this._initialData;
    return this.hasEditedComment || this._hasBeenMoved || t.value !== e || t.fontSize !== s || t.color.some((r, a) => r !== i[a]) || t.pageIndex !== n;
  }
  renderAnnotationElement(t) {
    const e = super.renderAnnotationElement(t);
    if (!e)
      return null;
    const {
      style: s
    } = e;
    s.fontSize = `calc(${this.#i}px * var(--total-scale-factor))`, s.color = this.color, e.replaceChildren();
    for (const i of this.#t.split(`
`)) {
      const n = document.createElement("div");
      n.append(i ? document.createTextNode(i) : document.createElement("br")), e.append(n);
    }
    return t.updateEdited({
      rect: this.getPDFRect(),
      popup: this._uiManager.hasCommentManager() || this.hasEditedComment ? this.comment : {
        text: this.#t
      }
    }), e;
  }
  resetAnnotationElement(t) {
    super.resetAnnotationElement(t), t.resetEdited();
  }
}
class Ti {
  #t = /* @__PURE__ */ Object.create(null);
  updateProperty(t, e) {
    this[t] = e, this.updateSVGProperty(t, e);
  }
  updateProperties(t) {
    if (t)
      for (const [e, s] of Object.entries(t))
        e.startsWith("_") || this.updateProperty(e, s);
  }
  updateSVGProperty(t, e) {
    this.#t[t] = e;
  }
  toSVGProperties() {
    const t = this.#t;
    return this.#t = /* @__PURE__ */ Object.create(null), {
      root: t
    };
  }
  reset() {
    this.#t = /* @__PURE__ */ Object.create(null);
  }
  updateAll(t = this) {
    this.updateProperties(t);
  }
  clone() {
    st("Not implemented");
  }
}
class Z extends H {
  #t = null;
  #e;
  _clipPathId = null;
  _colorPicker = null;
  _drawId = null;
  _drawOutlines = null;
  _focusDrawId = null;
  static _currentDrawId = -1;
  static _currentParent = null;
  static #s = null;
  static #i = null;
  static #n = null;
  static #a = null;
  static _INNER_MARGIN = 3;
  constructor(t) {
    super(t), this.#e = t.mustBeCommitted || !1, this._addOutlines(t);
  }
  onUpdatedColor() {
    this._colorPicker?.update(this.color), super.onUpdatedColor();
  }
  onUpdatedOpacity() {
    this._colorPicker?.updateOpacity?.(this.opacity);
  }
  _addOutlines(t) {
    t.drawOutlines && (this.#r(t), this.#m());
  }
  #r({
    drawOutlines: t,
    drawId: e,
    drawingOptions: s,
    clipPathId: i
  }) {
    this._drawOutlines = t, this._drawingOptions ||= s, this.annotationElementId || this._uiManager.a11yAlert(H._l10nAlert[this.editorType]), e >= 0 ? (this._drawId = e, this._clipPathId = i ?? null, this.parent.drawLayer.finalizeDraw(e, t.defaultProperties), this.#l(this.parent)) : this._drawId = this.#o(t, this.parent), this.#v(t.box);
  }
  #o(t, e) {
    const {
      id: s,
      clipPathId: i
    } = e.drawLayer.draw(Z._mergeSVGProperties(this._drawingOptions.toSVGProperties(), t.defaultSVGProperties), !1, this.constructor._hasClipPath);
    return this.constructor._hasClipPath && (this._clipPathId = i), this.#l(e), s;
  }
  #l(t) {
    const e = this._drawOutlines.getFocusSVGProperties(this.#f);
    e && (this._focusDrawId = t.drawLayer.drawOutline(e, this._drawOutlines.focusMustRemoveSelfIntersections));
  }
  #h(t = this.#f) {
    this._focusDrawId !== null && this.parent?.drawLayer.updateProperties(this._focusDrawId, this._drawOutlines.getFocusSVGProperties(t));
  }
  #u(t) {
    this._focusDrawId !== null && this.parent?.drawLayer.updateProperties(this._focusDrawId, {
      rootClass: t
    });
  }
  #d() {
    const {
      parent: t,
      _drawId: e,
      _focusDrawId: s,
      _isVisible: i
    } = this;
    if (!t || e === null)
      return;
    const n = {
      hidden: !i
    };
    t.drawLayer.updateProperties(e, {
      rootClass: n
    }), s !== null && t.drawLayer.updateProperties(s, {
      rootClass: n
    });
  }
  static _mergeSVGProperties(t, e) {
    const s = new Set(Object.keys(t));
    for (const [i, n] of Object.entries(e))
      s.has(i) ? Object.assign(t[i], n) : t[i] = n;
    return t;
  }
  static getDefaultDrawingOptions(t) {
    st("Not implemented");
  }
  static get typesMap() {
    st("Not implemented");
  }
  static get isDrawer() {
    return !0;
  }
  static get _hasClipPath() {
    return !1;
  }
  static get _hasDrawClass() {
    return !0;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  get _drawRotation() {
    return this.rotation;
  }
  get _opacityName() {
    return this.constructor.typesMap.get(this.opacityType);
  }
  get #f() {
    return (this.parentRotation - this._drawRotation + 360) % 360;
  }
  static updateDefaultParams(t, e) {
    const s = this.typesMap.get(t);
    s && this._defaultDrawingOptions.updateProperty(s, e), this._currentParent && (Z.#s.updateProperty(s, e), this._currentParent.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  updateParams(t, e) {
    const s = this.constructor.typesMap.get(t);
    s && this._updateProperty(t, s, e);
  }
  static get defaultPropertiesToUpdate() {
    const t = [], e = this._defaultDrawingOptions;
    for (const [s, i] of this.typesMap)
      t.push([s, e[i]]);
    return t;
  }
  get propertiesToUpdate() {
    const t = [], {
      _drawingOptions: e
    } = this;
    for (const [s, i] of this.constructor.typesMap)
      t.push([s, e[i]]);
    return t;
  }
  _updateProperty(t, e, s) {
    const i = this._drawingOptions, n = i[e], r = (a) => {
      i.updateProperty(e, a);
      const o = this._drawOutlines.updateProperty(e, a);
      o && this.#v(o), this.parent?.drawLayer.updateProperties(this._drawId, i.toSVGProperties()), t === this.colorType ? this.onUpdatedColor() : t === this.opacityType && this.onUpdatedOpacity();
    };
    this.addCommands({
      cmd: r.bind(this, s),
      undo: r.bind(this, n),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: t,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _updateColorAndOpacity(t, e, s = this.colorAndOpacityType) {
    const i = this.constructor.typesMap.get(this.colorType), n = this._opacityName, r = this._drawingOptions, a = r[i], o = r[n], l = (h, d) => {
      r.updateProperty(i, h), r.updateProperty(n, d), this._drawOutlines.updateProperty(i, h), this._drawOutlines.updateProperty(n, d), this.parent?.drawLayer.updateProperties(this._drawId, r.toSVGProperties()), this.onUpdatedColor(), this.onUpdatedOpacity();
    };
    this.addCommands({
      cmd: l.bind(this, t, e),
      undo: l.bind(this, a, o),
      post: this._uiManager.updateUI.bind(this._uiManager, this),
      mustExec: !0,
      type: s,
      overwriteIfSameType: !0,
      keepUndo: !0
    });
  }
  _onResizing() {
    this.parent?.drawLayer.updateProperties(this._drawId, Z._mergeSVGProperties(this._drawOutlines.getPathResizingSVGProperties(this.#p()), {
      bbox: this.#y()
    }));
  }
  _onResized() {
    this.parent?.drawLayer.updateProperties(this._drawId, Z._mergeSVGProperties(this._drawOutlines.getPathResizedSVGProperties(this.#p()), {
      bbox: this.#y()
    })), this.#h();
  }
  _onTranslating(t, e) {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      bbox: this.#y()
    });
  }
  _onTranslated() {
    this.parent?.drawLayer.updateProperties(this._drawId, Z._mergeSVGProperties(this._drawOutlines.getPathTranslatedSVGProperties(this.#p(), this.parentDimensions), {
      bbox: this.#y()
    }));
  }
  _onStartDragging() {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !0
      }
    });
  }
  _onStopDragging() {
    this.parent?.drawLayer.updateProperties(this._drawId, {
      rootClass: {
        moving: !1
      }
    });
  }
  get _mustBeDisabledOnCommit() {
    return !0;
  }
  commit() {
    super.commit(), this._mustBeDisabledOnCommit && (this.disableEditMode(), this.disableEditing());
  }
  disableEditing() {
    super.disableEditing(), this.div.classList.toggle("disabled", !0);
  }
  enableEditing() {
    super.enableEditing(), this.div.classList.toggle("disabled", !1);
  }
  getBaseTranslation() {
    return [0, 0];
  }
  get isResizable() {
    return !0;
  }
  onceAdded(t) {
    this.annotationElementId || this.parent.addUndoableEditor(this), this._isDraggable = !0, this.#e && (this.#e = !1, this.commit(), this.parent.setSelected(this), t && this.isOnScreen && this.div.focus());
  }
  remove() {
    this._uiManager.removeShouldRescale(this), this.#g(), super.remove();
  }
  rebuild() {
    this.parent && (super.rebuild(), this.div !== null && (this.#m(), this.#v(this._drawOutlines.box), this.isAttachedToDOM || this.parent.add(this)));
  }
  setParent(t) {
    let e = !1;
    this.parent && !t ? (this._uiManager.removeShouldRescale(this), this.#g()) : t && (this._uiManager.addShouldRescale(this), this.#m(t), e = !this.parent && this.div?.classList.contains("selectedEditor")), super.setParent(t), this.#d(), e && this.select();
  }
  #g() {
    if (this._drawId === null || !this.parent)
      return;
    const {
      drawLayer: t
    } = this.parent;
    t.remove(this._drawId), this._drawId = null, this._focusDrawId !== null && (t.remove(this._focusDrawId), this._focusDrawId = null), this._drawingOptions.reset();
  }
  #m(t = this.parent) {
    if (!(this._drawId !== null && this.parent === t)) {
      if (this._drawId !== null) {
        const {
          drawLayer: e
        } = this.parent;
        e.updateParent(this._drawId, t.drawLayer), this._focusDrawId !== null && e.updateParent(this._focusDrawId, t.drawLayer);
        return;
      }
      this._drawingOptions.updateAll(), this._drawId = this.#o(this._drawOutlines, t), this._clipPathId && this.#t && (this.#t.style.clipPath = this._clipPathId);
    }
  }
  #c([t, e, s, i]) {
    const {
      parentDimensions: [n, r],
      _drawRotation: a
    } = this;
    switch (a) {
      case 90:
        return [e, 1 - t, s * (r / n), i * (n / r)];
      case 180:
        return [1 - t, 1 - e, s, i];
      case 270:
        return [1 - e, t, s * (r / n), i * (n / r)];
      default:
        return [t, e, s, i];
    }
  }
  #p() {
    const {
      x: t,
      y: e,
      width: s,
      height: i,
      parentDimensions: [n, r],
      _drawRotation: a
    } = this;
    switch (a) {
      case 90:
        return [1 - e, t, s * (n / r), i * (r / n)];
      case 180:
        return [1 - t, 1 - e, s, i];
      case 270:
        return [e, 1 - t, s * (n / r), i * (r / n)];
      default:
        return [t, e, s, i];
    }
  }
  #v(t) {
    [this.x, this.y, this.width, this.height] = this.#c(t), this.div && (this.fixAndSetPosition(), this.setDims()), this._onResized();
  }
  #y(t = this.parentRotation) {
    const {
      x: e,
      y: s,
      width: i,
      height: n,
      _drawRotation: r,
      parentDimensions: [a, o]
    } = this;
    switch ((r * 4 + t) / 90) {
      case 1:
        return [1 - s - n, e, n, i];
      case 2:
        return [1 - e - i, 1 - s - n, i, n];
      case 3:
        return [s, 1 - e - i, n, i];
      case 4:
        return [e, s - i * (a / o), n * (o / a), i * (a / o)];
      case 5:
        return [1 - s, e, i * (a / o), n * (o / a)];
      case 6:
        return [1 - e - n * (o / a), 1 - s, n * (o / a), i * (a / o)];
      case 7:
        return [s - i * (a / o), 1 - e - n * (o / a), i * (a / o), n * (o / a)];
      case 8:
        return [e - i, s - n, i, n];
      case 9:
        return [1 - s, e - i, n, i];
      case 10:
        return [1 - e, 1 - s, i, n];
      case 11:
        return [s - n, 1 - e, n, i];
      case 12:
        return [e - n * (o / a), s, n * (o / a), i * (a / o)];
      case 13:
        return [1 - s - i * (a / o), e - n * (o / a), i * (a / o), n * (o / a)];
      case 14:
        return [1 - e, 1 - s - i * (a / o), n * (o / a), i * (a / o)];
      case 15:
        return [s, 1 - e, i * (a / o), n * (o / a)];
      default:
        return [e, s, i, n];
    }
  }
  rotate(t = this.parentRotation) {
    if (!this.parent || this._drawId === null)
      return;
    const e = (t - this._drawRotation + 360) % 360;
    this.parent.drawLayer.updateProperties(this._drawId, Z._mergeSVGProperties({
      bbox: this.#y(t)
    }, this._drawOutlines.updateRotation(e))), this.#h(e);
  }
  show(t = this._isVisible) {
    super.show(t), this.#d();
  }
  select() {
    super.select(), this.#u({
      hovered: !1,
      selected: !0
    });
  }
  unselect() {
    super.unselect(), this.#u({
      selected: !1
    });
  }
  pointerover() {
    this.isSelected || this.#u({
      hovered: !0
    });
  }
  pointerleave() {
    this.isSelected || this.#u({
      hovered: !1
    });
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    const t = this._drawOutlines.updateParentDimensions(this.parentDimensions, this.parent.scale);
    t && this.#v(t);
  }
  static onScaleChangingWhenDrawing() {
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    this._isCopy && (t = this.x, e = this.y);
    const s = super.render();
    this.constructor._hasDrawClass && s.classList.add("draw");
    const i = this.#t = document.createElement("div");
    return s.append(i), i.setAttribute("aria-hidden", "true"), i.className = "internal", this._clipPathId && (i.style.clipPath = this._clipPathId), Tn(this, i, ["pointerover", "pointerleave"]), this.setDims(), this._uiManager.addShouldRescale(this), this.disableEditing(), this._isCopy && this._moveAfterPaste(t, e), s;
  }
  static createDrawerInstance(t) {
    st("Not implemented");
  }
  static _getDrawingTarget(t, {
    target: e
  }) {
    return e;
  }
  static _getPointerCoords({
    offsetX: t,
    offsetY: e,
    clientX: s,
    clientY: i
  }, n = null) {
    if (!n)
      return [t, e];
    let r = s - n.clientX, a = i - n.clientY;
    switch (this._currentParent.viewport.rotation) {
      case 90:
        [r, a] = [a, -r];
        break;
      case 180:
        [r, a] = [-r, -a];
        break;
      case 270:
        [r, a] = [-a, r];
        break;
    }
    return [n.offsetX + r, n.offsetY + a];
  }
  static _addDrawingListeners(t, e) {
  }
  static _endDrawingSession(t = !1) {
    return this._currentParent.endDrawingSession(t);
  }
  static startDrawing(t, e, s, i) {
    const {
      pointerId: n,
      pointerType: r
    } = i;
    if (nt.isInitializedAndDifferentPointerType(r))
      return;
    const a = this._getDrawingTarget(t, i), [o, l] = this._getPointerCoords(i), {
      viewport: {
        rotation: h
      }
    } = t, {
      x: d,
      y: u,
      width: f,
      height: p
    } = a.getBoundingClientRect(), g = Z.#i = new AbortController(), m = t.combinedSignal(g);
    if (nt.setPointer(r, n), window.addEventListener("pointerup", (b) => {
      nt.isSamePointerIdOrRemove(b.pointerId) && this._endDraw(b);
    }, {
      signal: m
    }), window.addEventListener("pointercancel", (b) => {
      nt.isSamePointerIdOrRemove(b.pointerId) && this._endDrawingSession();
    }, {
      signal: m
    }), window.addEventListener("pointerdown", (b) => {
      nt.isSamePointerType(b.pointerType) && (nt.initializeAndAddPointerId(b.pointerId), Z.#s.isCancellable() && (Z.#s.removeLastElement(), Z.#s.isEmpty() ? this._endDrawingSession(!0) : this._endDraw(null)));
    }, {
      capture: !0,
      passive: !1,
      signal: m
    }), window.addEventListener("contextmenu", Yt, {
      signal: m
    }), a.addEventListener("pointermove", this._drawMove.bind(this), {
      signal: m
    }), a.addEventListener("touchmove", (b) => {
      nt.isSameTimeStamp(b.timeStamp) && St(b);
    }, {
      signal: m
    }), this._addDrawingListeners(a, m), t.toggleDrawing(), e._editorUndoBar?.hide(), Z.#s) {
      t.drawLayer.updateProperties(this._currentDrawId, Z.#s.startNew(o, l, f, p, h));
      return;
    }
    e.updateUIForDefaultProperties(this), Z.#s = this.createDrawerInstance({
      x: o,
      y: l,
      box: [d, u, f, p],
      rotation: h,
      parent: t,
      isLTR: s
    }), Z.#n = this.getDefaultDrawingOptions(), this._currentParent = t;
    const {
      id: v,
      clipPathId: y
    } = t.drawLayer.draw(this._mergeSVGProperties(Z.#n.toSVGProperties(), Z.#s.defaultSVGProperties), !0, this._hasClipPath);
    this._currentDrawId = v, Z.#a = this._hasClipPath ? y : null;
  }
  static _drawMove(t) {
    if (nt.isSameTimeStamp(t.timeStamp), !Z.#s || !nt.isSamePointerId(t.pointerId))
      return;
    if (nt.isUsingMultiplePointers()) {
      this._endDraw(t);
      return;
    }
    let e;
    const s = t.getCoalescedEvents?.();
    if (s?.length) {
      const i = [];
      for (const n of s)
        i.push(...this._getPointerCoords(n, t));
      e = Z.#s.addPoints(i);
    } else
      e = Z.#s.add(...this._getPointerCoords(t));
    this._currentParent.drawLayer.updateProperties(this._currentDrawId, e), nt.setTimeStamp(t.timeStamp), St(t);
  }
  static _cleanup(t) {
    t && (this._currentDrawId = -1, this._currentParent = null, Z.#s = null, Z.#n = null, Z.#a = null, nt.clearTimeStamp()), Z.#i && (Z.#i.abort(), Z.#i = null, nt.clearPointerIds());
  }
  static _endDraw(t) {
    const e = this._currentParent;
    if (e) {
      if (e.toggleDrawing(!0), this._cleanup(!1), e.drawLayer.updateProperties(this._currentDrawId, t?.target === e.div ? Z.#s.end(...this._getPointerCoords(t)) : Z.#s.end()), this.supportMultipleDrawings) {
        const s = Z.#s, i = this._currentDrawId, n = s.getLastElement();
        e.addCommands({
          cmd: () => {
            e.drawLayer.updateProperties(i, s.setLastElement(n));
          },
          undo: () => {
            e.drawLayer.updateProperties(i, s.removeLastElement());
          },
          mustExec: !1,
          type: q.DRAW_STEP
        });
        return;
      }
      this.endDrawing(!1);
    }
  }
  static endDrawing(t) {
    const e = this._currentParent;
    if (!e)
      return null;
    if (e.toggleDrawing(!0), e.cleanUndoStack(q.DRAW_STEP), !Z.#s.isEmpty()) {
      const {
        pageDimensions: [s, i],
        scale: n
      } = e, r = e.createAndAddNewEditor({
        offsetX: 0,
        offsetY: 0
      }, !1, {
        drawId: this._currentDrawId,
        clipPathId: Z.#a,
        drawOutlines: Z.#s.getOutlines(s * n, i * n, n, this._INNER_MARGIN),
        drawingOptions: Z.#n,
        mustBeCommitted: !t
      });
      return this._cleanup(!0), r;
    }
    return e.drawLayer.remove(this._currentDrawId), this._cleanup(!0), null;
  }
  createDrawingOptions(t) {
  }
  static deserializeDraw(t, e, s, i, n, r, a) {
    st("Not implemented");
  }
  static async deserialize(t, e, s) {
    const {
      rawDims: {
        pageWidth: i,
        pageHeight: n,
        pageX: r,
        pageY: a
      }
    } = e.viewport, o = this.deserializeDraw(r, a, i, n, this._INNER_MARGIN, t, s), l = await super.deserialize(t, e, s);
    return l.createDrawingOptions(t), l.#r({
      drawOutlines: o
    }), l.#m(), l.onScaleChanging(), l.rotate(), l;
  }
  serializeDraw(t) {
    const [e, s] = this.pageTranslation, [i, n] = this.pageDimensions;
    return this._drawOutlines.serialize([e, s, i, n], t);
  }
  renderAnnotationElement(t) {
    return t.updateEdited({
      rect: this.getPDFRect()
    }), null;
  }
  static canCreateNewEmptyEditor() {
    return !1;
  }
}
class B {
  static PRECISION = 1e-4;
  focusOutline = null;
  toSVGPath() {
    st("Abstract method `toSVGPath` must be implemented.");
  }
  get box() {
    st("Abstract getter `box` must be implemented.");
  }
  serialize(t, e) {
    st("Abstract method `serialize` must be implemented.");
  }
  get defaultSVGProperties() {
    st("Abstract getter `defaultSVGProperties` must be implemented.");
  }
  get defaultProperties() {
    return this.defaultSVGProperties;
  }
  getFocusSVGProperties(t) {
    return null;
  }
  get focusMustRemoveSelfIntersections() {
    return !1;
  }
  updateProperty(t, e) {
    return null;
  }
  updateParentDimensions(t, e) {
    return null;
  }
  serializeQuadPoints(t, e) {
    return null;
  }
  updateRotation(t) {
    return {};
  }
  getPathResizingSVGProperties(t) {
    return {};
  }
  getPathResizedSVGProperties(t) {
    return {};
  }
  getPathTranslatedSVGProperties(t, e) {
    return {};
  }
  static _rotateBox([t, e, s, i], n) {
    switch (n) {
      case 90:
        return [1 - e - i, t, i, s];
      case 180:
        return [1 - t - s, 1 - e - i, s, i];
      case 270:
        return [e, 1 - t - s, i, s];
    }
    return [t, e, s, i];
  }
  static _rescale(t, e, s, i, n, r) {
    r ||= new Float32Array(t.length);
    for (let a = 0, o = t.length; a < o; a += 2)
      r[a] = e + t[a] * i, r[a + 1] = s + t[a + 1] * n;
    return r;
  }
  static _rescaleAndSwap(t, e, s, i, n, r) {
    r ||= new Float32Array(t.length);
    for (let a = 0, o = t.length; a < o; a += 2)
      r[a] = e + t[a + 1] * i, r[a + 1] = s + t[a] * n;
    return r;
  }
  static _translate(t, e, s, i) {
    i ||= new Float32Array(t.length);
    for (let n = 0, r = t.length; n < r; n += 2)
      i[n] = e + t[n], i[n + 1] = s + t[n + 1];
    return i;
  }
  static svgRound(t) {
    return Math.round(t * 1e4);
  }
  static _normalizePoint(t, e, s, i, n) {
    switch (n) {
      case 90:
        return [1 - e / s, t / i];
      case 180:
        return [1 - t / s, 1 - e / i];
      case 270:
        return [e / s, 1 - t / i];
      default:
        return [t / s, e / i];
    }
  }
  static createBezierPoints(t, e, s, i, n, r) {
    return [(t + 5 * s) / 6, (e + 5 * i) / 6, (5 * s + n) / 6, (5 * i + r) / 6, (s + n) / 2, (i + r) / 2];
  }
}
class me {
  #t;
  #e = [];
  #s;
  #i;
  #n = [];
  #a = new Float32Array(18);
  #r;
  #o;
  #l;
  #h;
  #u;
  #d;
  #f = [];
  static #g = 8;
  static #m = 2;
  static #c = me.#g + me.#m;
  constructor(t, e, s, i, n, r, a = 0) {
    this.#t = s, this.#d = n * i, this.#i = r, this.#a.set([NaN, NaN, NaN, NaN, t, e], 6), this.#s = a, this.#h = me.#g * i, this.#l = me.#c * i, this.#u = i, this.#f.push(t, e);
  }
  isEmpty() {
    return isNaN(this.#a[8]);
  }
  isCancellable() {
    return this.#f.length <= 10;
  }
  removeLastElement() {
    return this.#a.fill(NaN), this.#n.length = this.#e.length = this.#f.length = 0, {
      path: {
        d: ""
      }
    };
  }
  #p() {
    const t = this.#a.subarray(4, 6), e = this.#a.subarray(16, 18), [s, i, n, r] = this.#t;
    return [(this.#r + (t[0] - e[0]) / 2 - s) / n, (this.#o + (t[1] - e[1]) / 2 - i) / r, (this.#r + (e[0] - t[0]) / 2 - s) / n, (this.#o + (e[1] - t[1]) / 2 - i) / r];
  }
  add(t, e) {
    this.#r = t, this.#o = e;
    const [s, i, n, r] = this.#t;
    let [a, o, l, h] = this.#a.subarray(8, 12);
    const d = t - l, u = e - h, f = Math.hypot(d, u);
    if (f < this.#l)
      return !1;
    const p = f - this.#h, g = p / f, m = g * d, v = g * u;
    let y = a, b = o;
    a = l, o = h, l += m, h += v, this.#f?.push(t, e);
    const w = -v / p, A = m / p, S = w * this.#d, E = A * this.#d;
    return this.#a.set(this.#a.subarray(2, 8), 0), this.#a.set([l + S, h + E], 4), this.#a.set(this.#a.subarray(14, 18), 12), this.#a.set([l - S, h - E], 16), isNaN(this.#a[6]) ? (this.#n.length === 0 && (this.#a.set([a + S, o + E], 2), this.#n.push(NaN, NaN, NaN, NaN, (a + S - s) / n, (o + E - i) / r), this.#a.set([a - S, o - E], 14), this.#e.push(NaN, NaN, NaN, NaN, (a - S - s) / n, (o - E - i) / r)), this.#a.set([y, b, a, o, l, h], 6), !this.isEmpty()) : (this.#a.set([y, b, a, o, l, h], 6), Math.abs(Math.atan2(b - o, y - a) - Math.atan2(v, m)) < Math.PI / 2 ? ([a, o, l, h] = this.#a.subarray(2, 6), this.#n.push(NaN, NaN, NaN, NaN, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [a, o, y, b] = this.#a.subarray(14, 18), this.#e.push(NaN, NaN, NaN, NaN, ((y + a) / 2 - s) / n, ((b + o) / 2 - i) / r), !0) : ([y, b, a, o, l, h] = this.#a.subarray(0, 6), this.#n.push(((y + 5 * a) / 6 - s) / n, ((b + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), [l, h, a, o, y, b] = this.#a.subarray(12, 18), this.#e.push(((y + 5 * a) / 6 - s) / n, ((b + 5 * o) / 6 - i) / r, ((5 * a + l) / 6 - s) / n, ((5 * o + h) / 6 - i) / r, ((a + l) / 2 - s) / n, ((o + h) / 2 - i) / r), !0));
  }
  toSVGPath() {
    if (this.isEmpty())
      return "";
    const t = this.#n, e = this.#e;
    if (isNaN(this.#a[6]) && !this.isEmpty())
      return this.#v();
    const s = [];
    s.push(`M${t[4]} ${t[5]}`);
    for (let i = 6; i < t.length; i += 6)
      isNaN(t[i]) ? s.push(`L${t[i + 4]} ${t[i + 5]}`) : s.push(`C${t[i]} ${t[i + 1]} ${t[i + 2]} ${t[i + 3]} ${t[i + 4]} ${t[i + 5]}`);
    this.#b(s);
    for (let i = e.length - 6; i >= 6; i -= 6)
      isNaN(e[i]) ? s.push(`L${e[i + 4]} ${e[i + 5]}`) : s.push(`C${e[i]} ${e[i + 1]} ${e[i + 2]} ${e[i + 3]} ${e[i + 4]} ${e[i + 5]}`);
    return this.#y(s), s.join(" ");
  }
  #v() {
    const [t, e, s, i] = this.#t, [n, r, a, o] = this.#p();
    return `M${(this.#a[2] - t) / s} ${(this.#a[3] - e) / i} L${(this.#a[4] - t) / s} ${(this.#a[5] - e) / i} L${n} ${r} L${a} ${o} L${(this.#a[16] - t) / s} ${(this.#a[17] - e) / i} L${(this.#a[14] - t) / s} ${(this.#a[15] - e) / i} Z`;
  }
  #y(t) {
    const e = this.#e;
    t.push(`L${e[4]} ${e[5]} Z`);
  }
  #b(t) {
    const [e, s, i, n] = this.#t, r = this.#a.subarray(4, 6), a = this.#a.subarray(16, 18), [o, l, h, d] = this.#p();
    t.push(`L${(r[0] - e) / i} ${(r[1] - s) / n} L${o} ${l} L${h} ${d} L${(a[0] - e) / i} ${(a[1] - s) / n}`);
  }
  newFreeDrawOutline(t, e, s, i, n, r) {
    return new Yn(t, e, s, i, n, r);
  }
  getOutlines() {
    const t = this.#n, e = this.#e, s = this.#a, [i, n, r, a] = this.#t, o = new Float32Array((this.#f?.length ?? 0) + 2);
    for (let d = 0, u = o.length - 2; d < u; d += 2)
      o[d] = (this.#f[d] - i) / r, o[d + 1] = (this.#f[d + 1] - n) / a;
    if (o[o.length - 2] = (this.#r - i) / r, o[o.length - 1] = (this.#o - n) / a, isNaN(s[6]) && !this.isEmpty())
      return this.#A(o);
    const l = new Float32Array(this.#n.length + 24 + this.#e.length);
    let h = t.length;
    for (let d = 0; d < h; d += 2) {
      if (isNaN(t[d])) {
        l[d] = l[d + 1] = NaN;
        continue;
      }
      l[d] = t[d], l[d + 1] = t[d + 1];
    }
    h = this.#w(l, h);
    for (let d = e.length - 6; d >= 6; d -= 6)
      for (let u = 0; u < 6; u += 2) {
        if (isNaN(e[d + u])) {
          l[h] = l[h + 1] = NaN, h += 2;
          continue;
        }
        l[h] = e[d + u], l[h + 1] = e[d + u + 1], h += 2;
      }
    return this.#E(l, h), this.newFreeDrawOutline(l, o, this.#t, this.#u, this.#s, this.#i);
  }
  #A(t) {
    const e = this.#a, [s, i, n, r] = this.#t, [a, o, l, h] = this.#p(), d = new Float32Array(36);
    return d.set([NaN, NaN, NaN, NaN, (e[2] - s) / n, (e[3] - i) / r, NaN, NaN, NaN, NaN, (e[4] - s) / n, (e[5] - i) / r, NaN, NaN, NaN, NaN, a, o, NaN, NaN, NaN, NaN, l, h, NaN, NaN, NaN, NaN, (e[16] - s) / n, (e[17] - i) / r, NaN, NaN, NaN, NaN, (e[14] - s) / n, (e[15] - i) / r], 0), this.newFreeDrawOutline(d, t, this.#t, this.#u, this.#s, this.#i);
  }
  #E(t, e) {
    const s = this.#e;
    return t.set([NaN, NaN, NaN, NaN, s[4], s[5]], e), e += 6;
  }
  #w(t, e) {
    const s = this.#a.subarray(4, 6), i = this.#a.subarray(16, 18), [n, r, a, o] = this.#t, [l, h, d, u] = this.#p();
    return t.set([NaN, NaN, NaN, NaN, (s[0] - n) / a, (s[1] - r) / o, NaN, NaN, NaN, NaN, l, h, NaN, NaN, NaN, NaN, d, u, NaN, NaN, NaN, NaN, (i[0] - n) / a, (i[1] - r) / o], e), e += 24;
  }
}
class Yn extends B {
  #t;
  #e = new Float32Array(4);
  #s;
  #i;
  #n;
  #a;
  #r;
  constructor(t, e, s, i, n, r) {
    super(), this.#r = t, this.#n = e, this.#t = s, this.#a = i, this.#s = n, this.#i = r, this.firstPoint = [NaN, NaN], this.lastPoint = [NaN, NaN], this.#o(r);
    const [a, o, l, h] = this.#e;
    for (let d = 0, u = t.length; d < u; d += 2)
      t[d] = (t[d] - a) / l, t[d + 1] = (t[d + 1] - o) / h;
    for (let d = 0, u = e.length; d < u; d += 2)
      e[d] = (e[d] - a) / l, e[d + 1] = (e[d + 1] - o) / h;
  }
  toSVGPath() {
    const t = [`M${this.#r[4]} ${this.#r[5]}`];
    for (let e = 6, s = this.#r.length; e < s; e += 6) {
      if (isNaN(this.#r[e])) {
        t.push(`L${this.#r[e + 4]} ${this.#r[e + 5]}`);
        continue;
      }
      t.push(`C${this.#r[e]} ${this.#r[e + 1]} ${this.#r[e + 2]} ${this.#r[e + 3]} ${this.#r[e + 4]} ${this.#r[e + 5]}`);
    }
    return t.push("Z"), t.join(" ");
  }
  serialize([t, e, s, i], n) {
    const r = s - t, a = i - e;
    let o, l;
    switch (n) {
      case 0:
        o = B._rescale(this.#r, t, i, r, -a), l = B._rescale(this.#n, t, i, r, -a);
        break;
      case 90:
        o = B._rescaleAndSwap(this.#r, t, e, r, a), l = B._rescaleAndSwap(this.#n, t, e, r, a);
        break;
      case 180:
        o = B._rescale(this.#r, s, e, -r, a), l = B._rescale(this.#n, s, e, -r, a);
        break;
      case 270:
        o = B._rescaleAndSwap(this.#r, s, i, -r, -a), l = B._rescaleAndSwap(this.#n, s, i, -r, -a);
        break;
    }
    return {
      outline: Array.from(o),
      points: [Array.from(l)]
    };
  }
  #o(t) {
    const e = this.#r;
    let s = e[4], i = e[5];
    const n = [s, i, s, i];
    let r = s, a = i, o = s, l = i;
    const h = t ? Math.max : Math.min, d = new Float32Array(4);
    for (let f = 6, p = e.length; f < p; f += 6) {
      const g = e[f + 4], m = e[f + 5];
      isNaN(e[f]) ? (N.pointBoundingBox(g, m, n), a > m ? (r = g, a = m) : a === m && (r = h(r, g)), l < m ? (o = g, l = m) : l === m && (o = h(o, g))) : (d.set(oe, 0), N.bezierBoundingBox(s, i, ...e.slice(f, f + 6), d), N.rectBoundingBox(...d, n), a > d[1] ? (r = d[0], a = d[1]) : a === d[1] && (r = h(r, d[0])), l < d[3] ? (o = d[2], l = d[3]) : l === d[3] && (o = h(o, d[2]))), s = g, i = m;
    }
    const u = this.#e;
    u[0] = n[0] - this.#s, u[1] = n[1] - this.#s, u[2] = n[2] - n[0] + 2 * this.#s, u[3] = n[3] - n[1] + 2 * this.#s, this.firstPoint = [r, a], this.lastPoint = [o, l];
  }
  get box() {
    return this.#e;
  }
  newOutliner(t, e, s, i, n, r, a = 0) {
    return new me(t, e, s, i, n, r, a);
  }
  updateThickness(t) {
    const e = this.getNewOutline(t);
    return this.#r = e.#r, this.#n = e.#n, this.#e.set(e.#e), this.firstPoint = e.firstPoint, this.lastPoint = e.lastPoint, this.#e;
  }
  getNewOutline(t, e) {
    const [s, i, n, r] = this.#e, [a, o, l, h] = this.#t, d = n * l, u = r * h, f = s * l + a, p = i * h + o, g = this.#n, m = this.newOutliner(g[0] * d + f, g[1] * u + p, this.#t, this.#a, t, this.#i, e ?? this.#s);
    for (let v = 2, y = g.length; v < y; v += 2)
      m.add(g[v] * d + f, g[v + 1] * u + p);
    return m.getOutlines();
  }
}
function Kn(c) {
  return {
    bbox: c.box,
    root: {
      viewBox: "0 0 1 1"
    },
    rootClass: {
      highlight: !0,
      free: c.isFree
    },
    path: {
      d: c.toSVGPath()
    }
  };
}
function Jn(c, t) {
  const {
    focusOutline: e
  } = c;
  return {
    bbox: B._rotateBox(e.box, t),
    root: {
      "data-main-rotation": t
    },
    rootClass: {
      highlightOutline: !0,
      free: c.isFree
    },
    path: {
      d: e.toSVGPath()
    }
  };
}
class li {
  #t;
  #e;
  #s;
  #i = [];
  #n = [];
  constructor(t, e = 0, s = 0, i = !0) {
    const n = oe.slice(), r = 10 ** -4;
    for (const {
      x: g,
      y: m,
      width: v,
      height: y
    } of t) {
      const b = Math.floor((g - e) / r) * r, w = Math.ceil((g + v + e) / r) * r, A = Math.floor((m - e) / r) * r, S = Math.ceil((m + y + e) / r) * r, E = [b, A, S, !0], T = [w, A, S, !1];
      this.#i.push(E, T), N.rectBoundingBox(b, A, w, S, n);
    }
    const a = n[2] - n[0] + 2 * s, o = n[3] - n[1] + 2 * s, l = n[0] - s, h = n[1] - s;
    let d = i ? -1 / 0 : 1 / 0, u = 1 / 0;
    const f = this.#i.at(i ? -1 : -2), p = [f[0], f[2]];
    for (const g of this.#i) {
      const [m, v, y, b] = g;
      !b && i ? v < u ? (u = v, d = m) : v === u && (d = Math.max(d, m)) : b && !i && (v < u ? (u = v, d = m) : v === u && (d = Math.min(d, m))), g[0] = (m - l) / a, g[1] = (v - h) / o, g[2] = (y - h) / o;
    }
    this.#t = new Float32Array([l, h, a, o]), this.#e = [d, u], this.#s = p;
  }
  getOutlines() {
    this.#i.sort((e, s) => e[0] - s[0] || e[1] - s[1] || e[2] - s[2]);
    const t = [];
    for (const e of this.#i)
      e[3] ? (t.push(...this.#h(e)), this.#o(e)) : (this.#l(e), t.push(...this.#h(e)));
    return this.#a(t);
  }
  #a(t) {
    const e = [], s = /* @__PURE__ */ new Set();
    for (const r of t) {
      const [a, o, l] = r;
      e.push([a, o, r], [a, l, r]);
    }
    e.sort((r, a) => r[1] - a[1] || r[0] - a[0]);
    for (let r = 0, a = e.length; r < a; r += 2) {
      const o = e[r][2], l = e[r + 1][2];
      o.push(l), l.push(o), s.add(o), s.add(l);
    }
    const i = [];
    let n;
    for (; s.size > 0; ) {
      const r = s.values().next().value;
      let [a, o, l, h, d] = r;
      s.delete(r);
      let u = a, f = o;
      for (n = [a, l], i.push(n); ; ) {
        let p;
        if (s.has(h))
          p = h;
        else if (s.has(d))
          p = d;
        else
          break;
        s.delete(p), [a, o, l, h, d] = p, u !== a && (n.push(u, f, a, f === o ? o : l), u = a), f = f === o ? l : o;
      }
      n.push(u, f);
    }
    return new hi(i, this.#t, this.#e, this.#s);
  }
  #r(t) {
    const e = this.#n;
    let s = 0, i = e.length - 1;
    for (; s <= i; ) {
      const n = s + i >> 1, r = e[n][0];
      if (r === t)
        return n;
      r < t ? s = n + 1 : i = n - 1;
    }
    return i + 1;
  }
  #o([, t, e]) {
    const s = this.#r(t);
    this.#n.splice(s, 0, [t, e]);
  }
  #l([, t, e]) {
    const s = this.#r(t);
    for (let i = s; i < this.#n.length; i++) {
      const [n, r] = this.#n[i];
      if (n !== t)
        break;
      if (n === t && r === e) {
        this.#n.splice(i, 1);
        return;
      }
    }
    for (let i = s - 1; i >= 0; i--) {
      const [n, r] = this.#n[i];
      if (n !== t)
        break;
      if (n === t && r === e) {
        this.#n.splice(i, 1);
        return;
      }
    }
  }
  #h(t) {
    const [e, s, i] = t, n = [[e, s, i]], r = this.#r(i);
    for (let a = 0; a < r; a++) {
      const [o, l] = this.#n[a];
      for (let h = 0, d = n.length; h < d; h++) {
        const [, u, f] = n[h];
        if (!(l <= u || f <= o)) {
          if (u >= o) {
            if (f > l)
              n[h][1] = l;
            else {
              if (d === 1)
                return [];
              n.splice(h, 1), h--, d--;
            }
            continue;
          }
          n[h][2] = o, f > l && n.push([e, l, f]);
        }
      }
    }
    return n;
  }
}
class hi extends B {
  #t;
  #e = null;
  #s;
  constructor(t, e, s, i) {
    super(), this.#s = t, this.#t = e, this.firstPoint = s, this.lastPoint = i;
  }
  static build(t, e) {
    const s = new li(t, 1e-3).getOutlines();
    return s.#e = t, s.focusOutline = new li(t, 25e-4, 1e-3, e).getOutlines(), s;
  }
  get isFree() {
    return !1;
  }
  get defaultSVGProperties() {
    return Kn(this);
  }
  getFocusSVGProperties(t) {
    return Jn(this, t);
  }
  updateRotation(t) {
    return {
      root: {
        "data-main-rotation": t
      }
    };
  }
  serializeQuadPoints([t, e], [s, i]) {
    const n = this.#e, r = new Float32Array(n.length * 8);
    let a = 0;
    for (const {
      x: o,
      y: l,
      width: h,
      height: d
    } of n) {
      const u = o * s + t, f = (1 - l) * i + e;
      r[a] = r[a + 4] = u, r[a + 1] = r[a + 3] = f, r[a + 2] = r[a + 6] = u + h * s, r[a + 5] = r[a + 7] = f - d * i, a += 8;
    }
    return r;
  }
  toSVGPath() {
    const t = [];
    for (const e of this.#s) {
      let [s, i] = e;
      t.push(`M${s} ${i}`);
      for (let n = 2; n < e.length; n += 2) {
        const r = e[n], a = e[n + 1];
        r === s ? (t.push(`V${a}`), i = a) : a === i && (t.push(`H${r}`), s = r);
      }
      t.push("Z");
    }
    return t.join(" ");
  }
  serialize([t, e, s, i], n) {
    const r = [], a = s - t, o = i - e;
    for (const l of this.#s) {
      const h = new Array(l.length);
      for (let d = 0; d < l.length; d += 2)
        h[d] = t + l[d] * a, h[d + 1] = i - l[d + 1] * o;
      r.push(h);
    }
    return r;
  }
  get box() {
    return this.#t;
  }
}
class Ci extends me {
  newFreeDrawOutline(t, e, s, i, n, r) {
    return new Pi(t, e, s, i, n, r);
  }
}
class co {
  #t;
  #e;
  constructor(t, e, s, i, n, r, a) {
    this.#t = new Ci(t, e, s, i, n, r, a), this.#e = n;
  }
  add(t, e) {
    return this.#t.add(t, e) ? {
      path: {
        d: this.#t.toSVGPath()
      }
    } : null;
  }
  addPoints(t) {
    let e = !1;
    for (let s = 0, i = t.length; s < i; s += 2)
      e = this.#t.add(t[s], t[s + 1]) || e;
    return e ? {
      path: {
        d: this.#t.toSVGPath()
      }
    } : null;
  }
  end(t, e) {
    return t === void 0 ? null : this.add(t, e);
  }
  isEmpty() {
    return this.#t.isEmpty();
  }
  isCancellable() {
    return this.#t.isCancellable();
  }
  removeLastElement() {
    return this.#t.removeLastElement();
  }
  updateProperty(t, e) {
    return null;
  }
  getOutlines() {
    const t = this.#t.getOutlines();
    return t.buildFocusOutline(2 * this.#e), t;
  }
  get defaultSVGProperties() {
    return {
      bbox: [0, 0, 1, 1],
      root: {
        viewBox: "0 0 1 1"
      },
      rootClass: {
        highlight: !0,
        free: !0
      },
      path: {
        d: this.#t.toSVGPath()
      }
    };
  }
}
class Pi extends Yn {
  static #t = 1.5;
  newOutliner(t, e, s, i, n, r, a = 0) {
    return new Ci(t, e, s, i, n, r, a);
  }
  get isFree() {
    return !0;
  }
  buildFocusOutline(t) {
    this.focusOutline = this.getNewOutline(t / 2 + Pi.#t, 25e-4);
  }
  get defaultSVGProperties() {
    return Kn(this);
  }
  getFocusSVGProperties(t) {
    return Jn(this, t);
  }
  get focusMustRemoveSelfIntersections() {
    return !0;
  }
  updateRotation(t) {
    return {
      root: {
        "data-main-rotation": t
      }
    };
  }
  updateProperty(t, e) {
    if (t !== "thickness")
      return null;
    const s = this.updateThickness(e / 2);
    return this.buildFocusOutline(e), s;
  }
  getPathResizedSVGProperties() {
    return {
      path: {
        d: this.toSVGPath()
      }
    };
  }
}
class Ii extends Ti {
  constructor(t = null) {
    super(), super.updateProperties(t);
  }
  updateSVGProperty(t, e) {
    t !== "thickness" && super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new Ii();
    return t.updateAll(this), t;
  }
}
class Wt extends Z {
  #t = null;
  #e = 0;
  #s = null;
  #i = 0;
  #n = "";
  #a = "";
  static _DEFAULT_OPACITY = 1;
  static _DEFAULT_THICKNESS = 12;
  static _defaultDrawingOptions = null;
  static _type = "highlight";
  static _editorType = X.HIGHLIGHT;
  static get _keyboardManager() {
    const t = Wt.prototype;
    return j(this, "_keyboardManager", new _t([[["ArrowLeft"], t._moveCaret, {
      args: [0]
    }], [["ArrowRight"], t._moveCaret, {
      args: [1]
    }], [["ArrowUp"], t._moveCaret, {
      args: [2]
    }], [["ArrowDown"], t._moveCaret, {
      args: [3]
    }]]));
  }
  constructor(t) {
    super({
      ...t,
      name: "highlightEditor"
    }), this.#t = t.anchorNode || null, this.#e = t.anchorOffset || 0, this.#s = t.focusNode || null, this.#i = t.focusOffset || 0, this.#n = t.methodOfCreation || (this._drawOutlines?.isFree ? "main_toolbar" : ""), this.#a = t.text || "", this._isDraggable = !1, this.defaultL10nId = "pdfjs-editor-highlight-editor", this.rotate();
  }
  static initialize(t, e) {
    H.initialize(t, e), this._defaultDrawingOptions ||= new Ii({
      fill: e.highlightColors?.values().next().value || "#fff066",
      "fill-opacity": Wt._DEFAULT_OPACITY,
      thickness: Wt._DEFAULT_THICKNESS
    });
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get typesMap() {
    return j(this, "typesMap", /* @__PURE__ */ new Map([[q.HIGHLIGHT_COLOR, "fill"], [q.HIGHLIGHT_THICKNESS, "thickness"]]));
  }
  static get isDrawer() {
    return !1;
  }
  static get _hasClipPath() {
    return !0;
  }
  static get _hasDrawClass() {
    return !1;
  }
  _addOutlines(t) {
    const {
      boxes: e,
      drawOutlines: s
    } = t;
    !e && !s || (this._drawingOptions ||= t.drawingOptions || Wt.getDefaultDrawingOptions(), e && (t = {
      ...t,
      drawOutlines: hi.build(e, this._uiManager.direction === "ltr")
    }), super._addOutlines(t));
  }
  get colorType() {
    return q.HIGHLIGHT_COLOR;
  }
  get color() {
    return this._drawingOptions.fill;
  }
  get opacity() {
    return this._drawingOptions["fill-opacity"];
  }
  get _opacityName() {
    return "fill-opacity";
  }
  get _drawRotation() {
    return this._drawOutlines?.isFree ? this.rotation : 0;
  }
  get isResizable() {
    return !1;
  }
  get _mustBeDisabledOnCommit() {
    return !1;
  }
  get _mustFixPosition() {
    return !this._drawOutlines?.isFree;
  }
  get telemetryInitialData() {
    return {
      action: "added",
      type: this._drawOutlines.isFree ? "free_highlight" : "highlight",
      color: this._uiManager.getNonHCMColorName(this.color),
      thickness: this._drawingOptions.thickness,
      methodOfCreation: this.#n
    };
  }
  get telemetryFinalData() {
    return {
      type: "highlight",
      color: this._uiManager.getNonHCMColorName(this.color)
    };
  }
  static computeTelemetryFinalData(t) {
    return {
      numberOfColors: t.get("color").size
    };
  }
  translateInPage(t, e) {
  }
  get toolbarPosition() {
    return this.#r(this._drawOutlines.focusOutline.lastPoint);
  }
  get commentButtonPosition() {
    return this.#r(this._drawOutlines.firstPoint);
  }
  #r([t, e]) {
    const [s, i, n, r] = this._drawOutlines.box;
    return [(t - s) / n, (e - i) / r];
  }
  updateParams(t, e) {
    switch (t) {
      case q.HIGHLIGHT_COLOR:
        this._updateColorAndOpacity(e, Wt._DEFAULT_OPACITY, t), this._reportTelemetry({
          action: "color_changed",
          color: this._uiManager.getNonHCMColorName(e)
        }, !0);
        break;
      case q.HIGHLIGHT_THICKNESS:
        super.updateParams(t, e), this._reportTelemetry({
          action: "thickness_changed",
          thickness: e
        }, !0);
        break;
    }
  }
  get propertiesToUpdate() {
    const t = super.propertiesToUpdate;
    return t.push([q.HIGHLIGHT_FREE, this._drawOutlines.isFree]), t;
  }
  get toolbarButtons() {
    return this._uiManager.highlightColors ? (this._colorPicker = new $t({
      editor: this
    }), [["colorPicker", this._colorPicker]]) : super.toolbarButtons;
  }
  fixAndSetPosition() {
    return super.fixAndSetPosition(this._drawRotation);
  }
  getRect(t, e) {
    return super.getRect(t, e, this._drawRotation);
  }
  onceAdded(t) {
    this.annotationElementId || this.parent.addUndoableEditor(this), t && this.div.focus();
  }
  remove() {
    this._reportTelemetry({
      action: "deleted"
    }), super.remove();
  }
  render() {
    if (this.div)
      return this.div;
    const t = super.render();
    return this.#a && (t.setAttribute("aria-label", this.#a), t.setAttribute("role", "mark")), this._drawOutlines.isFree ? t.classList.add("free") : t.addEventListener("keydown", this.#o.bind(this), {
      signal: this._uiManager._signal
    }), this.enableEditing(), t;
  }
  #o(t) {
    Wt._keyboardManager.exec(this, t);
  }
  _moveCaret(t) {
    switch (this.parent.unselect(this), t) {
      case 0:
      case 2:
        this.#l(!0);
        break;
      case 1:
      case 3:
        this.#l(!1);
        break;
    }
  }
  #l(t) {
    if (!this.#t)
      return;
    const e = window.getSelection();
    t ? e.setPosition(this.#t, this.#e) : e.setPosition(this.#s, this.#i);
  }
  unselect() {
    super.unselect(), this._drawOutlines.isFree || this.#l(!1);
  }
  static createDrawerInstance({
    x: t,
    y: e,
    box: s,
    parent: i,
    isLTR: n
  }) {
    return new co(t, e, s, i.scale, this._defaultDrawingOptions.thickness / 2, n, 1e-3);
  }
  static _getDrawingTarget(t, {
    target: e
  }) {
    return e.closest(".textLayer");
  }
  static _getPointerCoords({
    x: t,
    y: e
  }) {
    return [t, e];
  }
  static _addDrawingListeners(t, e) {
    t.classList.add("free"), e.addEventListener("abort", () => t.classList.remove("free"), {
      once: !0
    }), window.addEventListener("blur", () => this._endDraw(null), {
      signal: e
    }), window.addEventListener("pointerdown", St, {
      capture: !0,
      passive: !1,
      signal: e
    });
  }
  static _endDrawingSession(t = !1) {
    return this.endDrawing(t);
  }
  createDrawingOptions({
    color: t,
    opacity: e,
    thickness: s
  }) {
    const {
      _defaultDrawingOptions: i,
      _DEFAULT_OPACITY: n
    } = Wt;
    this._drawingOptions = Wt.getDefaultDrawingOptions({
      fill: N.makeHexColor(...t),
      "fill-opacity": e || n,
      thickness: s || i.thickness
    });
  }
  static deserializeDraw(t, e, s, i, n, r, a) {
    const {
      quadPoints: o
    } = r;
    if (o) {
      const f = [];
      for (let p = 0, g = o.length; p < g; p += 8)
        f.push({
          x: (o[p] - t) / s,
          y: 1 - (o[p + 1] - e) / i,
          width: (o[p + 2] - o[p]) / s,
          height: (o[p + 1] - o[p + 5]) / i
        });
      return hi.build(f, a.direction === "ltr");
    }
    const l = r.thickness || this._defaultDrawingOptions.thickness, h = (r.inkLists || r.outlines.points)[0], d = new Ci(h[0] - t, i - (h[1] - e), [0, 0, s, i], 1, l / 2, !0, 1e-3);
    for (let f = 0, p = h.length; f < p; f += 2)
      d.add(h[f] - t, i - (h[f + 1] - e));
    const u = d.getOutlines();
    return u.buildFocusOutline(l), u;
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof zn) {
      const {
        data: {
          quadPoints: r,
          rect: a,
          rotation: o,
          id: l,
          color: h,
          opacity: d,
          popupRef: u,
          richText: f,
          contentsObj: p,
          creationDate: g,
          modificationDate: m
        },
        parent: {
          page: {
            pageNumber: v
          }
        }
      } = t;
      i = t = {
        annotationType: X.HIGHLIGHT,
        color: Array.from(h),
        opacity: d,
        quadPoints: r,
        pageIndex: v - 1,
        rect: a.slice(0),
        rotation: o,
        annotationElementId: l,
        id: l,
        deleted: !1,
        popupRef: u,
        richText: f,
        comment: p?.str || null,
        creationDate: g,
        modificationDate: m
      };
    } else if (t instanceof Ei) {
      const {
        data: {
          inkLists: r,
          rect: a,
          rotation: o,
          id: l,
          color: h,
          borderStyle: {
            rawWidth: d
          },
          popupRef: u,
          richText: f,
          contentsObj: p,
          creationDate: g,
          modificationDate: m
        },
        parent: {
          page: {
            pageNumber: v
          }
        }
      } = t;
      i = t = {
        annotationType: X.HIGHLIGHT,
        color: Array.from(h),
        thickness: d,
        inkLists: r,
        pageIndex: v - 1,
        rect: a.slice(0),
        rotation: o,
        annotationElementId: l,
        id: l,
        deleted: !1,
        popupRef: u,
        richText: f,
        comment: p?.str || null,
        creationDate: g,
        modificationDate: m
      };
    }
    const n = await super.deserialize(t, e, s);
    return n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  serialize(t = !1) {
    if (this.isEmpty() || t)
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const e = super.serialize(t);
    return Object.assign(e, {
      color: H._colorManager.convert(this._uiManager.getNonHCMColor(this.color)),
      opacity: this.opacity,
      thickness: this._drawingOptions.thickness,
      quadPoints: this._drawOutlines.serializeQuadPoints(this.pageTranslation, this.pageDimensions),
      outlines: this._drawOutlines.serialize(e.rect, this._drawRotation)
    }), this.addComment(e), this.annotationElementId && !this.#h(e) ? null : (e.id = this.annotationElementId, e);
  }
  #h(t) {
    const {
      color: e
    } = this._initialData;
    return this.hasEditedComment || t.color.some((s, i) => s !== e[i]);
  }
  renderAnnotationElement(t) {
    return this.deleted ? (t.hide(), null) : (t.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
class uo {
  #t = new Float64Array(6);
  #e = new Float64Array(2);
  #s;
  #i;
  #n;
  #a;
  #r;
  #o = "";
  #l = 0;
  #h = new ns();
  #u;
  #d;
  constructor(t, e, s, i, n, r) {
    this.#u = s, this.#d = i, this.#n = n, this.#a = r, [t, e] = this.#f(t, e);
    const a = this.#s = [NaN, NaN, NaN, NaN, t, e];
    this.#r = [t, e], this.#i = [{
      line: a,
      points: this.#r
    }], this.#t.set(a, 0), this.#e.set([t, e], 0);
  }
  updateProperty(t, e) {
    t === "stroke-width" && (this.#a = e);
  }
  #f(t, e) {
    return B._normalizePoint(t, e, this.#u, this.#d, this.#n);
  }
  isEmpty() {
    return !this.#i?.length;
  }
  isCancellable() {
    return this.#r.length <= 10;
  }
  add(t, e) {
    return this.#g(t, e) && this.toSVGPath(), {
      path: {
        d: this.#m()
      }
    };
  }
  addPoints(t) {
    let e = !1;
    for (let s = 0, i = t.length; s < i; s += 2)
      this.#g(t[s], t[s + 1]) && (e = !0, this.#r.length <= 6 && (this.toSVGPath(), e = !1));
    return e && this.toSVGPath(), {
      path: {
        d: this.#m()
      }
    };
  }
  #g(t, e) {
    [t, e] = this.#f(t, e), this.#e.set([t, e], 0);
    const [s, i, n, r] = this.#t.subarray(2, 6), a = t - n, o = e - r;
    return Math.hypot(this.#u * a, this.#d * o) <= 2 ? !1 : (this.#r.push(t, e), isNaN(s) ? (this.#t.set([n, r, t, e], 2), this.#s.push(NaN, NaN, NaN, NaN, t, e), !0) : (isNaN(this.#t[0]) && this.#s.splice(6, 6), this.#t.set([s, i, n, r, t, e], 0), this.#s.push(...B.createBezierPoints(s, i, n, r, t, e)), !0));
  }
  end(t, e) {
    return t !== void 0 && this.#g(t, e) ? {
      path: {
        d: this.toSVGPath()
      }
    } : this.#r.length === 2 ? {
      path: {
        d: this.toSVGPath()
      }
    } : {
      path: {
        d: this.#o
      }
    };
  }
  startNew(t, e, s, i, n) {
    this.#u = s, this.#d = i, this.#n = n, [t, e] = this.#f(t, e);
    const r = this.#s = [NaN, NaN, NaN, NaN, t, e];
    this.#r = [t, e], this.#e.set([t, e], 0);
    const a = this.#i.at(-1);
    return a && (a.line = new Float32Array(a.line), a.points = new Float32Array(a.points)), this.#i.push({
      line: r,
      points: this.#r
    }), this.#t.set(r, 0), this.#l = 0, this.toSVGPath(), null;
  }
  getLastElement() {
    return this.#i.at(-1);
  }
  setLastElement(t) {
    return this.#i ? (this.#i.push(t), this.#s = t.line, this.#r = t.points, this.#l = 0, {
      path: {
        d: this.toSVGPath()
      }
    }) : this.#h.setLastElement(t);
  }
  removeLastElement() {
    if (!this.#i)
      return this.#h.removeLastElement();
    this.#i.pop(), this.#o = "";
    for (let t = 0, e = this.#i.length; t < e; t++) {
      const {
        line: s,
        points: i
      } = this.#i[t];
      this.#s = s, this.#r = i, this.#l = 0, this.toSVGPath();
    }
    return {
      path: {
        d: this.#o
      }
    };
  }
  #m() {
    const t = B.svgRound(this.#e[0]), e = B.svgRound(this.#e[1]);
    if (this.#r.length === 2) {
      const s = B.svgRound(this.#s[4]), i = B.svgRound(this.#s[5]);
      return `${this.#o} M ${s} ${i} L ${t} ${e}`;
    }
    return `${this.#o} L ${t} ${e}`;
  }
  toSVGPath() {
    const t = B.svgRound(this.#s[4]), e = B.svgRound(this.#s[5]);
    if (this.#r.length === 2)
      return this.#o = `${this.#o} M ${t} ${e} Z`, this.#o;
    if (this.#r.length <= 6) {
      const i = this.#o.lastIndexOf("M");
      this.#o = `${this.#o.slice(0, i)} M ${t} ${e}`, this.#l = 6;
    }
    if (this.#r.length === 4) {
      const i = B.svgRound(this.#s[10]), n = B.svgRound(this.#s[11]);
      return this.#o = `${this.#o} L ${i} ${n}`, this.#l = 12, this.#o;
    }
    const s = [];
    this.#l === 0 && (s.push(`M ${t} ${e}`), this.#l = 6);
    for (let i = this.#l, n = this.#s.length; i < n; i += 6) {
      const [r, a, o, l, h, d] = this.#s.slice(i, i + 6).map(B.svgRound);
      s.push(`C${r} ${a} ${o} ${l} ${h} ${d}`);
    }
    return this.#o += s.join(" "), this.#l = this.#s.length, this.#o;
  }
  getOutlines(t, e, s, i) {
    const n = this.#i.at(-1);
    return n.line = new Float32Array(n.line), n.points = new Float32Array(n.points), this.#h.build(this.#i, t, e, s, this.#n, this.#a, i), this.#t = null, this.#s = null, this.#i = null, this.#o = null, this.#h;
  }
  get defaultSVGProperties() {
    return {
      root: {
        viewBox: "0 0 10000 10000"
      },
      rootClass: {
        draw: !0
      },
      bbox: [0, 0, 1, 1]
    };
  }
}
class ns extends B {
  #t;
  #e = 0;
  #s;
  #i;
  #n;
  #a;
  #r;
  #o;
  #l;
  build(t, e, s, i, n, r, a) {
    this.#n = e, this.#a = s, this.#r = i, this.#o = n, this.#l = r, this.#s = a ?? 0, this.#i = t, this.#d();
  }
  get thickness() {
    return this.#l;
  }
  setLastElement(t) {
    return this.#i.push(t), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  removeLastElement() {
    return this.#i.pop(), {
      path: {
        d: this.toSVGPath()
      }
    };
  }
  toSVGPath() {
    const t = [];
    for (const {
      line: e
    } of this.#i) {
      if (t.push(`M${B.svgRound(e[4])} ${B.svgRound(e[5])}`), e.length === 6) {
        t.push("Z");
        continue;
      }
      if (e.length === 12 && isNaN(e[6])) {
        t.push(`L${B.svgRound(e[10])} ${B.svgRound(e[11])}`);
        continue;
      }
      for (let s = 6, i = e.length; s < i; s += 6) {
        const [n, r, a, o, l, h] = e.subarray(s, s + 6).map(B.svgRound);
        t.push(`C${n} ${r} ${a} ${o} ${l} ${h}`);
      }
    }
    return t.join("");
  }
  serialize([t, e, s, i], n) {
    const r = [], a = [], [o, l, h, d] = this.#u();
    let u, f, p, g, m, v, y, b, w;
    switch (this.#o) {
      case 0:
        w = B._rescale, u = t, f = e + i, p = s, g = -i, m = t + o * s, v = e + (1 - l - d) * i, y = t + (o + h) * s, b = e + (1 - l) * i;
        break;
      case 90:
        w = B._rescaleAndSwap, u = t, f = e, p = s, g = i, m = t + l * s, v = e + o * i, y = t + (l + d) * s, b = e + (o + h) * i;
        break;
      case 180:
        w = B._rescale, u = t + s, f = e, p = -s, g = i, m = t + (1 - o - h) * s, v = e + l * i, y = t + (1 - o) * s, b = e + (l + d) * i;
        break;
      case 270:
        w = B._rescaleAndSwap, u = t + s, f = e + i, p = -s, g = -i, m = t + (1 - l - d) * s, v = e + (1 - o - h) * i, y = t + (1 - l) * s, b = e + (1 - o) * i;
        break;
    }
    for (const {
      line: A,
      points: S
    } of this.#i)
      r.push(w(A, u, f, p, g, n ? new Array(A.length) : null)), a.push(w(S, u, f, p, g, n ? new Array(S.length) : null));
    return {
      lines: r,
      points: a,
      rect: [m, v, y, b]
    };
  }
  static deserialize(t, e, s, i, n, {
    paths: {
      lines: r,
      points: a
    },
    rotation: o,
    thickness: l
  }) {
    const h = [];
    let d, u, f, p, g;
    switch (o) {
      case 0:
        g = B._rescale, d = -t / s, u = e / i + 1, f = 1 / s, p = -1 / i;
        break;
      case 90:
        g = B._rescaleAndSwap, d = -e / i, u = -t / s, f = 1 / i, p = 1 / s;
        break;
      case 180:
        g = B._rescale, d = t / s + 1, u = -e / i, f = -1 / s, p = 1 / i;
        break;
      case 270:
        g = B._rescaleAndSwap, d = e / i + 1, u = t / s + 1, f = -1 / i, p = -1 / s;
        break;
    }
    if (!r) {
      r = [];
      for (const v of a) {
        const y = v.length;
        if (y === 2) {
          r.push(new Float32Array([NaN, NaN, NaN, NaN, v[0], v[1]]));
          continue;
        }
        if (y === 4) {
          r.push(new Float32Array([NaN, NaN, NaN, NaN, v[0], v[1], NaN, NaN, NaN, NaN, v[2], v[3]]));
          continue;
        }
        const b = new Float32Array(3 * (y - 2));
        r.push(b);
        let [w, A, S, E] = v.subarray(0, 4);
        b.set([NaN, NaN, NaN, NaN, w, A], 0);
        for (let T = 4; T < y; T += 2) {
          const x = v[T], P = v[T + 1];
          b.set(B.createBezierPoints(w, A, S, E, x, P), (T - 2) * 3), [w, A, S, E] = [S, E, x, P];
        }
      }
    }
    for (let v = 0, y = r.length; v < y; v++)
      h.push({
        line: g(r[v].map((b) => b ?? NaN), d, u, f, p),
        points: g(a[v].map((b) => b ?? NaN), d, u, f, p)
      });
    const m = new this.prototype.constructor();
    return m.build(h, s, i, 1, o, l, n), m;
  }
  #h(t = this.#l) {
    const e = this.#s + t / 2 * this.#r;
    return this.#o % 180 === 0 ? [e / this.#n, e / this.#a] : [e / this.#a, e / this.#n];
  }
  #u() {
    const [t, e, s, i] = this.#t, [n, r] = this.#h(0);
    return [t + n, e + r, s - 2 * n, i - 2 * r];
  }
  #d() {
    const t = this.#t = ge.slice();
    for (const {
      line: i
    } of this.#i) {
      if (i.length <= 12) {
        for (let a = 4, o = i.length; a < o; a += 6)
          N.pointBoundingBox(i[a], i[a + 1], t);
        continue;
      }
      let n = i[4], r = i[5];
      for (let a = 6, o = i.length; a < o; a += 6) {
        const [l, h, d, u, f, p] = i.subarray(a, a + 6);
        N.bezierBoundingBox(n, r, l, h, d, u, f, p, t), n = f, r = p;
      }
    }
    const [e, s] = this.#h();
    t[0] = ct(t[0] - e, 0, 1), t[1] = ct(t[1] - s, 0, 1), t[2] = ct(t[2] + e, 0, 1), t[3] = ct(t[3] + s, 0, 1), t[2] -= t[0], t[3] -= t[1];
  }
  get box() {
    return this.#t;
  }
  updateProperty(t, e) {
    return t === "stroke-width" ? this.#f(e) : null;
  }
  #f(t) {
    const [e, s] = this.#h();
    this.#l = t;
    const [i, n] = this.#h(), [r, a] = [i - e, n - s], o = this.#t;
    return o[0] -= r, o[1] -= a, o[2] += 2 * r, o[3] += 2 * a, o;
  }
  updateParentDimensions([t, e], s) {
    const [i, n] = this.#h();
    this.#n = t, this.#a = e, this.#r = s;
    const [r, a] = this.#h(), o = r - i, l = a - n, h = this.#t;
    return h[0] -= o, h[1] -= l, h[2] += 2 * o, h[3] += 2 * l, h;
  }
  updateRotation(t) {
    return this.#e = t, {
      path: {
        transform: this.rotationTransform
      }
    };
  }
  get viewBox() {
    return this.#t.map(B.svgRound).join(" ");
  }
  get defaultProperties() {
    const [t, e] = this.#t;
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${B.svgRound(t)} ${B.svgRound(e)}`
      }
    };
  }
  get rotationTransform() {
    const [, , t, e] = this.#t;
    let s = 0, i = 0, n = 0, r = 0, a = 0, o = 0;
    switch (this.#e) {
      case 90:
        i = e / t, n = -t / e, a = t;
        break;
      case 180:
        s = -1, r = -1, a = t, o = e;
        break;
      case 270:
        i = -e / t, n = t / e, o = e;
        break;
      default:
        return "";
    }
    return `matrix(${s} ${i} ${n} ${r} ${B.svgRound(a)} ${B.svgRound(o)})`;
  }
  getPathResizingSVGProperties([t, e, s, i]) {
    const [n, r] = this.#h(), [a, o, l, h] = this.#t;
    if (Math.abs(l - n) <= B.PRECISION || Math.abs(h - r) <= B.PRECISION) {
      const g = t + s / 2 - (a + l / 2), m = e + i / 2 - (o + h / 2);
      return {
        path: {
          "transform-origin": `${B.svgRound(t)} ${B.svgRound(e)}`,
          transform: `${this.rotationTransform} translate(${g} ${m})`
        }
      };
    }
    const d = (s - 2 * n) / (l - 2 * n), u = (i - 2 * r) / (h - 2 * r), f = l / s, p = h / i;
    return {
      path: {
        "transform-origin": `${B.svgRound(a)} ${B.svgRound(o)}`,
        transform: `${this.rotationTransform} scale(${f} ${p}) translate(${B.svgRound(n)} ${B.svgRound(r)}) scale(${d} ${u}) translate(${B.svgRound(-n)} ${B.svgRound(-r)})`
      }
    };
  }
  getPathResizedSVGProperties([t, e, s, i]) {
    const [n, r] = this.#h(), a = this.#t, [o, l, h, d] = a;
    if (a[0] = t, a[1] = e, a[2] = s, a[3] = i, Math.abs(h - n) <= B.PRECISION || Math.abs(d - r) <= B.PRECISION) {
      const m = t + s / 2 - (o + h / 2), v = e + i / 2 - (l + d / 2);
      for (const {
        line: y,
        points: b
      } of this.#i)
        B._translate(y, m, v, y), B._translate(b, m, v, b);
      return {
        root: {
          viewBox: this.viewBox
        },
        path: {
          "transform-origin": `${B.svgRound(t)} ${B.svgRound(e)}`,
          transform: this.rotationTransform || null,
          d: this.toSVGPath()
        }
      };
    }
    const u = (s - 2 * n) / (h - 2 * n), f = (i - 2 * r) / (d - 2 * r), p = -u * (o + n) + t + n, g = -f * (l + r) + e + r;
    if (u !== 1 || f !== 1 || p !== 0 || g !== 0)
      for (const {
        line: m,
        points: v
      } of this.#i)
        B._rescale(m, p, g, u, f, m), B._rescale(v, p, g, u, f, v);
    return {
      root: {
        viewBox: this.viewBox
      },
      path: {
        "transform-origin": `${B.svgRound(t)} ${B.svgRound(e)}`,
        transform: this.rotationTransform || null,
        d: this.toSVGPath()
      }
    };
  }
  getPathTranslatedSVGProperties([t, e], s) {
    const [i, n] = s, r = this.#t, a = t - r[0], o = e - r[1];
    if (this.#n === i && this.#a === n)
      for (const {
        line: l,
        points: h
      } of this.#i)
        B._translate(l, a, o, l), B._translate(h, a, o, h);
    else {
      const l = this.#n / i, h = this.#a / n;
      this.#n = i, this.#a = n;
      for (const {
        line: d,
        points: u
      } of this.#i)
        B._rescale(d, a, o, l, h, d), B._rescale(u, a, o, l, h, u);
      r[2] *= l, r[3] *= h;
    }
    return r[0] = t, r[1] = e, {
      root: {
        viewBox: this.viewBox
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${B.svgRound(t)} ${B.svgRound(e)}`
      }
    };
  }
  get defaultSVGProperties() {
    const t = this.#t;
    return {
      root: {
        viewBox: this.viewBox
      },
      rootClass: {
        draw: !0
      },
      path: {
        d: this.toSVGPath(),
        "transform-origin": `${B.svgRound(t[0])} ${B.svgRound(t[1])}`,
        transform: this.rotationTransform || null
      },
      bbox: t
    };
  }
}
class _s extends Ti {
  constructor(t) {
    super(), this._viewParameters = t, super.updateProperties({
      fill: "none",
      stroke: H._defaultLineColor,
      "stroke-opacity": 1,
      "stroke-width": 1,
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-miterlimit": 10
    });
  }
  updateSVGProperty(t, e) {
    t === "stroke-width" && (e ??= this["stroke-width"], e *= this._viewParameters.realScale), super.updateSVGProperty(t, e);
  }
  clone() {
    const t = new _s(this._viewParameters);
    return t.updateAll(this), t;
  }
}
class Oi extends Z {
  static _type = "ink";
  static _editorType = X.INK;
  static _defaultDrawingOptions = null;
  constructor(t) {
    super({
      ...t,
      name: "inkEditor"
    }), this._willKeepAspectRatio = !0, this.defaultL10nId = "pdfjs-editor-ink-editor";
  }
  static initialize(t, e) {
    H.initialize(t, e), this._defaultDrawingOptions = new _s(e.viewParameters);
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get supportMultipleDrawings() {
    return !0;
  }
  static get typesMap() {
    return j(this, "typesMap", /* @__PURE__ */ new Map([[q.INK_THICKNESS, "stroke-width"], [q.INK_COLOR, "stroke"], [q.INK_OPACITY, "stroke-opacity"]]));
  }
  static createDrawerInstance({
    x: t,
    y: e,
    box: [, , s, i],
    rotation: n
  }) {
    return new uo(t, e, s, i, n, this._defaultDrawingOptions["stroke-width"]);
  }
  static deserializeDraw(t, e, s, i, n, r) {
    return ns.deserialize(t, e, s, i, n, r);
  }
  static async deserialize(t, e, s) {
    let i = null;
    if (t instanceof Ei) {
      const {
        data: {
          inkLists: r,
          rect: a,
          rotation: o,
          id: l,
          color: h,
          opacity: d,
          borderStyle: {
            rawWidth: u
          },
          popupRef: f,
          richText: p,
          contentsObj: g,
          creationDate: m,
          modificationDate: v
        },
        parent: {
          page: {
            pageNumber: y
          }
        }
      } = t;
      i = t = {
        annotationType: X.INK,
        color: Array.from(h),
        thickness: u,
        opacity: d,
        paths: {
          points: r
        },
        boxes: null,
        pageIndex: y - 1,
        rect: a.slice(0),
        rotation: o,
        annotationElementId: l,
        id: l,
        deleted: !1,
        popupRef: f,
        richText: p,
        comment: g?.str || null,
        creationDate: m,
        modificationDate: v
      };
    }
    const n = await super.deserialize(t, e, s);
    return n._initialData = i, t.comment && n.setCommentData(t), n;
  }
  get toolbarButtons() {
    return this._colorPicker ||= new ts(this), [["colorPicker", this._colorPicker]];
  }
  get colorType() {
    return q.INK_COLOR;
  }
  get colorAndOpacityType() {
    return q.INK_COLOR_AND_OPACITY;
  }
  get opacityType() {
    return q.INK_OPACITY;
  }
  updateParams(t, e) {
    if (t === q.INK_COLOR_AND_OPACITY) {
      this._updateColorAndOpacity(e.color, e.opacity);
      return;
    }
    super.updateParams(t, e);
  }
  static updateDefaultParams(t, e) {
    if (t === q.INK_COLOR_AND_OPACITY) {
      super.updateDefaultParams(q.INK_COLOR, e.color), super.updateDefaultParams(q.INK_OPACITY, e.opacity);
      return;
    }
    super.updateDefaultParams(t, e);
  }
  get color() {
    return this._drawingOptions.stroke;
  }
  get opacity() {
    return this._drawingOptions["stroke-opacity"];
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    super.onScaleChanging();
    const {
      _drawId: t,
      _drawingOptions: e,
      parent: s
    } = this;
    e.updateSVGProperty("stroke-width"), s.drawLayer.updateProperties(t, e.toSVGProperties());
  }
  static onScaleChangingWhenDrawing() {
    const t = this._currentParent;
    t && (super.onScaleChangingWhenDrawing(), this._defaultDrawingOptions.updateSVGProperty("stroke-width"), t.drawLayer.updateProperties(this._currentDrawId, this._defaultDrawingOptions.toSVGProperties()));
  }
  createDrawingOptions({
    color: t,
    thickness: e,
    opacity: s
  }) {
    this._drawingOptions = Oi.getDefaultDrawingOptions({
      stroke: N.makeHexColor(...t),
      "stroke-width": e,
      "stroke-opacity": s
    });
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const {
      lines: e,
      points: s
    } = this.serializeDraw(t), {
      _drawingOptions: {
        stroke: i,
        "stroke-opacity": n,
        "stroke-width": r
      }
    } = this, a = Object.assign(super.serialize(t), {
      color: H._colorManager.convert(i),
      opacity: n,
      thickness: r,
      paths: {
        lines: e,
        points: s
      }
    });
    return this.addComment(a), t ? (a.isCopy = !0, a) : this.annotationElementId && !this.#t(a) ? null : (a.id = this.annotationElementId, a);
  }
  #t(t) {
    const {
      color: e,
      thickness: s,
      opacity: i,
      pageIndex: n
    } = this._initialData;
    return this.hasEditedComment || this._hasBeenMoved || this._hasBeenResized || t.color.some((r, a) => r !== e[a]) || t.thickness !== s || t.opacity !== i || t.pageIndex !== n;
  }
  renderAnnotationElement(t) {
    if (this.deleted)
      return t.hide(), null;
    const {
      points: e,
      rect: s
    } = this.serializeDraw(!1);
    return t.updateEdited({
      rect: s,
      thickness: this._drawingOptions["stroke-width"],
      points: e,
      popup: this.comment
    }), null;
  }
}
class ci extends ns {
  toSVGPath() {
    let t = super.toSVGPath();
    return t.endsWith("Z") || (t += "Z"), t;
  }
}
K(5213);
const us = 8, Ge = 3;
class Me {
  static #t = {
    maxDim: 512,
    sigmaSFactor: 0.02,
    sigmaR: 25,
    kernelSize: 16
  };
  static #e(t, e, s, i) {
    return s -= t, i -= e, s === 0 ? i > 0 ? 0 : 4 : s === 1 ? i + 6 : 2 - i;
  }
  static #s = new Int32Array([0, 1, -1, 1, -1, 0, -1, -1, 0, -1, 1, -1, 1, 0, 1, 1]);
  static #i(t, e, s, i, n, r, a) {
    const o = this.#e(s, i, n, r);
    for (let l = 0; l < 8; l++) {
      const h = (-l + o - a + 16) % 8, d = this.#s[2 * h], u = this.#s[2 * h + 1];
      if (t[(s + d) * e + (i + u)] !== 0)
        return h;
    }
    return -1;
  }
  static #n(t, e, s, i, n, r, a) {
    const o = this.#e(s, i, n, r);
    for (let l = 0; l < 8; l++) {
      const h = (l + o + a + 16) % 8, d = this.#s[2 * h], u = this.#s[2 * h + 1];
      if (t[(s + d) * e + (i + u)] !== 0)
        return h;
    }
    return -1;
  }
  static #a(t, e, s, i) {
    const n = t.length, r = new Int32Array(n);
    for (let h = 0; h < n; h++)
      r[h] = t[h] <= i ? 1 : 0;
    for (let h = 1; h < s - 1; h++)
      r[h * e] = r[h * e + e - 1] = 0;
    for (let h = 0; h < e; h++)
      r[h] = r[e * s - 1 - h] = 0;
    let a = 1, o;
    const l = [];
    for (let h = 1; h < s - 1; h++) {
      o = 1;
      for (let d = 1; d < e - 1; d++) {
        const u = h * e + d, f = r[u];
        if (f === 0)
          continue;
        let p = h, g = d;
        if (f === 1 && r[u - 1] === 0)
          a += 1, g -= 1;
        else if (f >= 1 && r[u + 1] === 0)
          a += 1, g += 1, f > 1 && (o = f);
        else {
          f !== 1 && (o = Math.abs(f));
          continue;
        }
        const m = [d, h], v = g === d + 1, y = {
          isHole: v,
          points: m,
          id: a,
          parent: 0
        };
        l.push(y);
        let b;
        for (const C of l)
          if (C.id === o) {
            b = C;
            break;
          }
        b ? b.isHole ? y.parent = v ? b.parent : o : y.parent = v ? o : b.parent : y.parent = v ? o : 0;
        const w = this.#i(r, e, h, d, p, g, 0);
        if (w === -1) {
          r[u] = -a, r[u] !== 1 && (o = Math.abs(r[u]));
          continue;
        }
        let A = this.#s[2 * w], S = this.#s[2 * w + 1];
        const E = h + A, T = d + S;
        p = E, g = T;
        let x = h, P = d;
        for (; ; ) {
          const C = this.#n(r, e, x, P, p, g, 1);
          A = this.#s[2 * C], S = this.#s[2 * C + 1];
          const I = x + A, R = P + S;
          m.push(R, I);
          const D = x * e + P;
          if (r[D + 1] === 0 ? r[D] = -a : r[D] === 1 && (r[D] = a), I === h && R === d && x === E && P === T) {
            r[u] !== 1 && (o = Math.abs(r[u]));
            break;
          } else
            p = x, g = P, x = I, P = R;
        }
      }
    }
    return l;
  }
  static #r(t, e, s, i) {
    if (s - e <= 4) {
      for (let E = e; E < s - 2; E += 2)
        i.push(t[E], t[E + 1]);
      return;
    }
    const n = t[e], r = t[e + 1], a = t[s - 4] - n, o = t[s - 3] - r, l = Math.hypot(a, o), h = a / l, d = o / l, u = h * r - d * n, f = o / a, p = 1 / l, g = Math.atan(f), m = Math.cos(g), v = Math.sin(g), y = p * (Math.abs(m) + Math.abs(v)), b = p * (1 - y + y ** 2), w = Math.max(Math.atan(Math.abs(v + m) * b), Math.atan(Math.abs(v - m) * b));
    let A = 0, S = e;
    for (let E = e + 2; E < s - 2; E += 2) {
      const T = Math.abs(u - h * t[E + 1] + d * t[E]);
      T > A && (S = E, A = T);
    }
    A > (l * w) ** 2 ? (this.#r(t, e, S + 2, i), this.#r(t, S, s, i)) : i.push(n, r);
  }
  static #o(t) {
    const e = [], s = t.length;
    return this.#r(t, 0, s, e), e.push(t[s - 2], t[s - 1]), e.length <= 4 ? null : e;
  }
  static #l(t, e, s, i, n, r) {
    const a = new Float32Array(r ** 2), o = -2 * i ** 2, l = r >> 1;
    for (let g = 0; g < r; g++) {
      const m = (g - l) ** 2;
      for (let v = 0; v < r; v++)
        a[g * r + v] = Math.exp((m + (v - l) ** 2) / o);
    }
    const h = new Float32Array(256), d = -2 * n ** 2;
    for (let g = 0; g < 256; g++)
      h[g] = Math.exp(g ** 2 / d);
    const u = t.length, f = new Uint8Array(u), p = new Uint32Array(256);
    for (let g = 0; g < s; g++)
      for (let m = 0; m < e; m++) {
        const v = g * e + m, y = t[v];
        let b = 0, w = 0;
        for (let S = 0; S < r; S++) {
          const E = g + S - l;
          if (!(E < 0 || E >= s))
            for (let T = 0; T < r; T++) {
              const x = m + T - l;
              if (x < 0 || x >= e)
                continue;
              const P = t[E * e + x], C = a[S * r + T] * h[Math.abs(P - y)];
              b += P * C, w += C;
            }
        }
        const A = f[v] = Math.round(b / w);
        p[A]++;
      }
    return [f, p];
  }
  static #h(t) {
    const e = new Uint32Array(256);
    for (const s of t)
      e[s]++;
    return e;
  }
  static #u(t) {
    const e = t.length, s = new Uint8ClampedArray(e >> 2);
    let i = -1 / 0, n = 1 / 0;
    for (let a = 0, o = s.length; a < o; a++) {
      const l = s[a] = t[a << 2];
      i = Math.max(i, l), n = Math.min(n, l);
    }
    const r = 255 / (i - n);
    for (let a = 0, o = s.length; a < o; a++)
      s[a] = (s[a] - n) * r;
    return s;
  }
  static #d(t) {
    let e, s = -1 / 0, i = -1 / 0;
    const n = t.findIndex((o) => o !== 0);
    let r = n, a = n;
    for (e = n; e < 256; e++) {
      const o = t[e];
      o > s && (e - r > i && (i = e - r, a = e - 1), s = o, r = e);
    }
    for (e = a - 1; e >= 0 && !(t[e] > t[e + 1]); e--)
      ;
    return e;
  }
  static #f(t) {
    const e = t, {
      width: s,
      height: i
    } = t, {
      maxDim: n
    } = this.#t;
    let r = s, a = i;
    if (s > n || i > n) {
      let u = s, f = i, p = Math.log2(Math.max(s, i) / n);
      const g = Math.floor(p);
      p = p === g ? g - 1 : g;
      for (let v = 0; v < p; v++) {
        r = Math.ceil(u / 2), a = Math.ceil(f / 2);
        const y = new OffscreenCanvas(r, a);
        y.getContext("2d").drawImage(t, 0, 0, u, f, 0, 0, r, a), u = r, f = a, t !== e && t.close(), t = y.transferToImageBitmap();
      }
      const m = Math.min(n / r, n / a);
      r = Math.round(r * m), a = Math.round(a * m);
    }
    const l = new OffscreenCanvas(r, a).getContext("2d", {
      willReadFrequently: !0
    });
    l.fillStyle = "white", l.fillRect(0, 0, r, a), l.filter = "grayscale(1)", l.drawImage(t, 0, 0, t.width, t.height, 0, 0, r, a);
    const h = l.getImageData(0, 0, r, a).data;
    return [this.#u(h), r, a];
  }
  static extractContoursFromText(t, {
    fontFamily: e,
    fontStyle: s,
    fontWeight: i
  }, n, r, a, o) {
    let l = new OffscreenCanvas(1, 1), h = l.getContext("2d", {
      alpha: !1
    });
    const d = 200, u = h.font = `${s} ${i} ${d}px ${e}`, {
      actualBoundingBoxLeft: f,
      actualBoundingBoxRight: p,
      actualBoundingBoxAscent: g,
      actualBoundingBoxDescent: m,
      fontBoundingBoxAscent: v,
      fontBoundingBoxDescent: y,
      width: b
    } = h.measureText(t), w = 1.5, A = Math.ceil(Math.max(Math.abs(f) + Math.abs(p) || 0, b) * w), S = Math.ceil(Math.max(Math.abs(g) + Math.abs(m) || d, Math.abs(v) + Math.abs(y) || d) * w);
    l = new OffscreenCanvas(A, S), h = l.getContext("2d", {
      alpha: !0,
      willReadFrequently: !0
    }), h.font = u, h.filter = "grayscale(1)", h.fillStyle = "white", h.fillRect(0, 0, A, S), h.fillStyle = "black", h.fillText(t, A * (w - 1) / 2, S * (3 - w) / 2);
    const E = this.#u(h.getImageData(0, 0, A, S).data), T = this.#h(E), x = this.#d(T), P = this.#a(E, A, S, x);
    return this.processDrawnLines({
      lines: {
        curves: P,
        width: A,
        height: S
      },
      pageWidth: n,
      pageHeight: r,
      rotation: a,
      innerMargin: o,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static process(t, e, s, i, n) {
    const [r, a, o] = this.#f(t), [l, h] = this.#l(r, a, o, Math.hypot(a, o) * this.#t.sigmaSFactor, this.#t.sigmaR, this.#t.kernelSize), d = this.#d(h), u = this.#a(l, a, o, d);
    return this.processDrawnLines({
      lines: {
        curves: u,
        width: a,
        height: o
      },
      pageWidth: e,
      pageHeight: s,
      rotation: i,
      innerMargin: n,
      mustSmooth: !0,
      areContours: !0
    });
  }
  static processDrawnLines({
    lines: t,
    pageWidth: e,
    pageHeight: s,
    rotation: i,
    innerMargin: n,
    mustSmooth: r,
    areContours: a
  }) {
    i % 180 !== 0 && ([e, s] = [s, e]);
    const {
      curves: o,
      width: l,
      height: h
    } = t, d = t.thickness ?? 0, u = [], f = Math.min(e / l, s / h), p = f / e, g = f / s, m = [];
    for (const {
      points: y
    } of o) {
      const b = r ? this.#o(y) : y;
      if (!b)
        continue;
      m.push(b);
      const w = b.length, A = new Float32Array(w), S = new Float32Array(3 * (w === 2 ? 2 : w - 2));
      if (u.push({
        line: S,
        points: A
      }), w === 2) {
        A[0] = b[0] * p, A[1] = b[1] * g, S.set([NaN, NaN, NaN, NaN, A[0], A[1]], 0);
        continue;
      }
      let [E, T, x, P] = b;
      E *= p, T *= g, x *= p, P *= g, A.set([E, T, x, P], 0), S.set([NaN, NaN, NaN, NaN, E, T], 0);
      for (let C = 4; C < w; C += 2) {
        const I = A[C] = b[C] * p, R = A[C + 1] = b[C + 1] * g;
        S.set(B.createBezierPoints(E, T, x, P, I, R), (C - 2) * 3), [E, T, x, P] = [x, P, I, R];
      }
    }
    if (u.length === 0)
      return null;
    const v = a ? new ci() : new ns();
    return v.build(u, e, s, 1, i, a ? 0 : d, n), {
      outline: v,
      newCurves: m,
      areContours: a,
      thickness: d,
      width: l,
      height: h
    };
  }
  static async compressSignature({
    outlines: t,
    areContours: e,
    thickness: s,
    width: i,
    height: n
  }) {
    let r = 1 / 0, a = -1 / 0, o = 0;
    for (const y of t) {
      o += y.length;
      for (let b = 2, w = y.length; b < w; b++) {
        const A = y[b] - y[b - 2];
        r = Math.min(r, A), a = Math.max(a, A);
      }
    }
    let l;
    r >= -128 && a <= 127 ? l = Int8Array : r >= -32768 && a <= 32767 ? l = Int16Array : l = Int32Array;
    const h = t.length, d = us + Ge * h, u = new Uint32Array(d);
    let f = 0;
    u[f++] = d * Uint32Array.BYTES_PER_ELEMENT + (o - 2 * h) * l.BYTES_PER_ELEMENT, u[f++] = 0, u[f++] = i, u[f++] = n, u[f++] = e ? 0 : 1, u[f++] = Math.max(0, Math.floor(s ?? 0)), u[f++] = h, u[f++] = l.BYTES_PER_ELEMENT;
    for (const y of t)
      u[f++] = y.length - 2, u[f++] = y[0], u[f++] = y[1];
    const p = new CompressionStream("deflate-raw"), g = p.writable.getWriter();
    await g.ready, g.write(u);
    const m = l.prototype.constructor;
    for (const y of t) {
      const b = new m(y.length - 2);
      for (let w = 2, A = y.length; w < A; w++)
        b[w - 2] = y[w] - y[w - 2];
      g.write(b);
    }
    return g.close(), (await new Response(p.readable).bytes()).toBase64();
  }
  static async decompressSignature(t) {
    try {
      const e = Uint8Array.fromBase64(t), {
        readable: s,
        writable: i
      } = new DecompressionStream("deflate-raw"), n = i.getWriter();
      await n.ready, n.write(e).then(async () => {
        await n.ready, await n.close();
      }).catch(() => {
      });
      let r = null, a = 0;
      for await (const b of s)
        r ||= new Uint8Array(new Uint32Array(b.buffer, 0, 4)[0]), r.set(b, a), a += b.length;
      const o = new Uint32Array(r.buffer, 0, r.length >> 2), l = o[1];
      if (l !== 0)
        throw new Error(`Invalid version: ${l}`);
      const h = o[2], d = o[3], u = o[4] === 0, f = o[5], p = o[6], g = o[7], m = [], v = (us + Ge * p) * Uint32Array.BYTES_PER_ELEMENT;
      let y;
      switch (g) {
        case Int8Array.BYTES_PER_ELEMENT:
          y = new Int8Array(r.buffer, v);
          break;
        case Int16Array.BYTES_PER_ELEMENT:
          y = new Int16Array(r.buffer, v);
          break;
        case Int32Array.BYTES_PER_ELEMENT:
          y = new Int32Array(r.buffer, v);
          break;
      }
      a = 0;
      for (let b = 0; b < p; b++) {
        const w = o[Ge * b + us], A = new Float32Array(w + 2);
        m.push(A);
        for (let S = 0; S < Ge - 1; S++)
          A[S] = o[Ge * b + us + S + 1];
        for (let S = 0; S < w; S++)
          A[S + 2] = A[S] + y[a++];
      }
      return {
        areContours: u,
        thickness: f,
        outlines: m,
        width: h,
        height: d
      };
    } catch (e) {
      return V(`decompressSignature: ${e}`), null;
    }
  }
}
class Mi extends Ti {
  constructor() {
    super(), super.updateProperties({
      fill: H._defaultLineColor,
      "stroke-width": 0
    });
  }
  clone() {
    const t = new Mi();
    return t.updateAll(this), t;
  }
}
class Ri extends _s {
  constructor(t) {
    super(t), super.updateProperties({
      stroke: H._defaultLineColor,
      "stroke-width": 1
    });
  }
  clone() {
    const t = new Ri(this._viewParameters);
    return t.updateAll(this), t;
  }
}
class ee extends Z {
  #t = !1;
  #e = null;
  #s = null;
  #i = null;
  static _type = "signature";
  static _editorType = X.SIGNATURE;
  static _defaultDrawingOptions = null;
  constructor(t) {
    super({
      ...t,
      mustBeCommitted: !0,
      name: "signatureEditor"
    }), this._willKeepAspectRatio = !0, this.#s = t.signatureData || null, this.#e = null, this.defaultL10nId = "pdfjs-editor-signature-editor1";
  }
  static initialize(t, e) {
    H.initialize(t, e), this._defaultDrawingOptions = new Mi(), this._defaultDrawnSignatureOptions = new Ri(e.viewParameters);
  }
  static getDefaultDrawingOptions(t) {
    const e = this._defaultDrawingOptions.clone();
    return e.updateProperties(t), e;
  }
  static get supportMultipleDrawings() {
    return !1;
  }
  static get typesMap() {
    return j(this, "typesMap", /* @__PURE__ */ new Map());
  }
  static get isDrawer() {
    return !1;
  }
  get telemetryFinalData() {
    return {
      type: "signature",
      hasDescription: !!this.#e
    };
  }
  static computeTelemetryFinalData(t) {
    const e = t.get("hasDescription");
    return {
      hasAltText: e.get(!0) ?? 0,
      hasNoAltText: e.get(!1) ?? 0
    };
  }
  get isResizable() {
    return !0;
  }
  onScaleChanging() {
    this._drawId !== null && super.onScaleChanging();
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    const {
      _isCopy: s
    } = this;
    if (s && (this._isCopy = !1, t = this.x, e = this.y), super.render(), this._drawId === null)
      if (this.#s) {
        const {
          lines: i,
          mustSmooth: n,
          areContours: r,
          description: a,
          uuid: o,
          heightInPage: l
        } = this.#s, {
          rawDims: {
            pageWidth: h,
            pageHeight: d
          },
          rotation: u
        } = this.parent.viewport, f = Me.processDrawnLines({
          lines: i,
          pageWidth: h,
          pageHeight: d,
          rotation: u,
          innerMargin: ee._INNER_MARGIN,
          mustSmooth: n,
          areContours: r
        });
        this.addSignature(f, l, a, o);
      } else
        this.div.setAttribute("data-l10n-args", JSON.stringify({
          description: ""
        })), this.div.hidden = !0, this._uiManager.getSignature(this);
    else
      this.div.setAttribute("data-l10n-args", JSON.stringify({
        description: this.#e || ""
      }));
    return s && (this._isCopy = !0, this._moveAfterPaste(t, e)), this.div;
  }
  setUuid(t) {
    this.#i = t, this.addEditToolbar();
  }
  getUuid() {
    return this.#i;
  }
  get description() {
    return this.#e;
  }
  set description(t) {
    this.#e = t, this.div && (this.div.setAttribute("data-l10n-args", JSON.stringify({
      description: t
    })), super.addEditToolbar().then((e) => {
      e?.updateEditSignatureButton(t);
    }));
  }
  getSignaturePreview() {
    const {
      newCurves: t,
      areContours: e,
      thickness: s,
      width: i,
      height: n
    } = this.#s, r = Math.max(i, n), a = Me.processDrawnLines({
      lines: {
        curves: t.map((o) => ({
          points: o
        })),
        thickness: s,
        width: i,
        height: n
      },
      pageWidth: r,
      pageHeight: r,
      rotation: 0,
      innerMargin: 0,
      mustSmooth: !1,
      areContours: e
    });
    return {
      areContours: e,
      outline: a.outline
    };
  }
  get toolbarButtons() {
    return this._uiManager.signatureManager ? [["editSignature", this._uiManager.signatureManager]] : super.toolbarButtons;
  }
  addSignature(t, e, s, i) {
    const {
      x: n,
      y: r
    } = this, {
      outline: a
    } = this.#s = t;
    this.#t = a instanceof ci, this.description = s;
    let o;
    this.#t ? o = ee.getDefaultDrawingOptions() : (o = ee._defaultDrawnSignatureOptions.clone(), o.updateProperties({
      "stroke-width": a.thickness
    })), this._addOutlines({
      drawOutlines: a,
      drawingOptions: o
    });
    const [, l] = this.pageDimensions;
    let h = e / l;
    h = h >= 1 ? 0.5 : h, this.width *= h / this.height, this.width >= 1 && (h *= 0.9 / this.width, this.width = 0.9), this.height = h, this.setDims(), this.x = n, this.y = r, this.center(), this._onResized(), this.onScaleChanging(), this.rotate(), this._uiManager.addToAnnotationStorage(this), this.setUuid(i), this._reportTelemetry({
      action: "pdfjs.signature.inserted",
      data: {
        hasBeenSaved: !!i,
        hasDescription: !!s
      }
    }), this.div.hidden = !1;
  }
  getFromImage(t) {
    const {
      rawDims: {
        pageWidth: e,
        pageHeight: s
      },
      rotation: i
    } = this.parent.viewport;
    return Me.process(t, e, s, i, ee._INNER_MARGIN);
  }
  getFromText(t, e) {
    const {
      rawDims: {
        pageWidth: s,
        pageHeight: i
      },
      rotation: n
    } = this.parent.viewport;
    return Me.extractContoursFromText(t, e, s, i, n, ee._INNER_MARGIN);
  }
  getDrawnSignature(t) {
    const {
      rawDims: {
        pageWidth: e,
        pageHeight: s
      },
      rotation: i
    } = this.parent.viewport;
    return Me.processDrawnLines({
      lines: t,
      pageWidth: e,
      pageHeight: s,
      rotation: i,
      innerMargin: ee._INNER_MARGIN,
      mustSmooth: !1,
      areContours: !1
    });
  }
  createDrawingOptions({
    areContours: t,
    thickness: e
  }) {
    t ? this._drawingOptions = ee.getDefaultDrawingOptions() : (this._drawingOptions = ee._defaultDrawnSignatureOptions.clone(), this._drawingOptions.updateProperties({
      "stroke-width": e
    }));
  }
  serialize(t = !1) {
    if (this.isEmpty())
      return null;
    const {
      lines: e,
      points: s
    } = this.serializeDraw(t), {
      _drawingOptions: {
        "stroke-width": i
      }
    } = this, n = Object.assign(super.serialize(t), {
      isSignature: !0,
      areContours: this.#t,
      color: [0, 0, 0],
      thickness: this.#t ? 0 : i
    });
    return this.addComment(n), t ? (n.paths = {
      lines: e,
      points: s
    }, n.uuid = this.#i, n.isCopy = !0) : n.lines = e, this.#e && (n.accessibilityData = {
      type: "Figure",
      alt: this.#e
    }), n;
  }
  static deserializeDraw(t, e, s, i, n, r) {
    return r.areContours ? ci.deserialize(t, e, s, i, n, r) : ns.deserialize(t, e, s, i, n, r);
  }
  static async deserialize(t, e, s) {
    const i = await super.deserialize(t, e, s);
    return i.#t = t.areContours, i.description = t.accessibilityData?.alt || "", i.#i = t.uuid, i;
  }
}
class fo extends H {
  #t = null;
  #e = null;
  #s = null;
  #i = null;
  #n = null;
  #a = "";
  #r = null;
  #o = !1;
  #l = null;
  #h = !1;
  #u = !1;
  static _type = "stamp";
  static _editorType = X.STAMP;
  constructor(t) {
    super({
      ...t,
      name: "stampEditor"
    }), this.#i = t.bitmapUrl, this.#n = t.bitmapFile, this.defaultL10nId = "pdfjs-editor-stamp-editor";
  }
  static initialize(t, e) {
    H.initialize(t, e);
  }
  static isHandlingMimeForPasting(t) {
    return ei.includes(t);
  }
  static paste(t, e) {
    e.pasteEditor({
      mode: X.STAMP
    }, {
      bitmapFile: t.getAsFile()
    });
  }
  altTextFinish() {
    this._uiManager.useNewAltTextFlow && (this.div.hidden = !1), super.altTextFinish();
  }
  get telemetryFinalData() {
    return {
      type: "stamp",
      hasAltText: !!this.altTextData?.altText
    };
  }
  static computeTelemetryFinalData(t) {
    const e = t.get("hasAltText");
    return {
      hasAltText: e.get(!0) ?? 0,
      hasNoAltText: e.get(!1) ?? 0
    };
  }
  #d(t, e = !1) {
    if (!t) {
      this.remove();
      return;
    }
    this.#t = t.bitmap, e || (this.#e = t.id, this.#h = t.isSvg), t.file && (this.#a = t.file.name), this.#m();
  }
  #f() {
    if (this.#s = null, this._uiManager.enableWaiting(!1), !!this.#r) {
      if (this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
        this.addEditToolbar().then(() => {
          this._editToolbar.hide(), this._uiManager.editAltText(this, !0);
        });
        return;
      }
      if (!this._uiManager.useNewAltTextWhenAddingImage && this._uiManager.useNewAltTextFlow && this.#t) {
        this._reportTelemetry({
          action: "pdfjs.image.image_added",
          data: {
            alt_text_modal: !1,
            alt_text_type: "empty"
          }
        });
        try {
          this.mlGuessAltText();
        } catch {
        }
      }
      this.div.focus();
    }
  }
  async mlGuessAltText(t = null, e = !0) {
    if (this.hasAltTextData())
      return null;
    const {
      mlManager: s
    } = this._uiManager;
    if (!s)
      throw new Error("No ML.");
    if (!await s.isEnabledFor("altText"))
      throw new Error("ML isn't enabled for alt text.");
    const {
      data: i,
      width: n,
      height: r
    } = t || this.copyCanvas(null, null, !0).imageData, a = await s.guess({
      name: "altText",
      request: {
        data: i,
        width: n,
        height: r,
        channels: i.length / (n * r)
      }
    });
    if (!a)
      throw new Error("No response from the AI service.");
    if (a.error)
      throw new Error("Error from the AI service.");
    if (a.cancel)
      return null;
    if (!a.output)
      throw new Error("No valid response from the AI service.");
    const o = a.output;
    return await this.setGuessedAltText(o), e && !this.hasAltTextData() && (this.altTextData = {
      alt: o,
      decorative: !1
    }), o;
  }
  #g() {
    if (this.#e) {
      this._uiManager.enableWaiting(!0), this._uiManager.imageManager.getFromId(this.#e).then((s) => this.#d(s, !0)).finally(() => this.#f());
      return;
    }
    if (this.#i) {
      const s = this.#i;
      this.#i = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromUrl(s).then((i) => this.#d(i)).finally(() => this.#f());
      return;
    }
    if (this.#n) {
      const s = this.#n;
      this.#n = null, this._uiManager.enableWaiting(!0), this.#s = this._uiManager.imageManager.getFromFile(s).then((i) => this.#d(i)).finally(() => this.#f());
      return;
    }
    const t = document.createElement("input");
    t.type = "file", t.accept = ei.join(",");
    const e = this._uiManager._signal;
    this.#s = new Promise((s) => {
      t.addEventListener("change", async () => {
        if (!t.files || t.files.length === 0)
          this.remove();
        else {
          this._uiManager.enableWaiting(!0);
          const i = await this._uiManager.imageManager.getFromFile(t.files[0]);
          this._reportTelemetry({
            action: "pdfjs.image.image_selected",
            data: {
              alt_text_modal: this._uiManager.useNewAltTextFlow
            }
          }), this.#d(i);
        }
        s();
      }, {
        signal: e
      }), t.addEventListener("cancel", () => {
        this.remove(), s();
      }, {
        signal: e
      });
    }).finally(() => this.#f()), t.click();
  }
  remove() {
    this.#e && (this.#t = null, this._uiManager.imageManager.deleteId(this.#e), this.#r?.remove(), this.#r = null, this.#l && (clearTimeout(this.#l), this.#l = null)), super.remove();
  }
  rebuild() {
    if (!this.parent) {
      this.#e && this.#g();
      return;
    }
    super.rebuild(), this.div !== null && (this.#e && this.#r === null && this.#g(), this.isAttachedToDOM || this.parent.add(this));
  }
  onceAdded(t) {
    this._isDraggable = !0, t && this.div.focus();
  }
  isEmpty() {
    return !(this.#s || this.#t || this.#i || this.#n || this.#e || this.#o);
  }
  get toolbarButtons() {
    return [["altText", this.createAltText()]];
  }
  get isResizable() {
    return !0;
  }
  render() {
    if (this.div)
      return this.div;
    let t, e;
    return this._isCopy && (t = this.x, e = this.y), super.render(), this.div.hidden = !0, this.createAltText(), this.#o || (this.#t ? this.#m() : this.#g()), this._isCopy && this._moveAfterPaste(t, e), this._uiManager.addShouldRescale(this), this.div;
  }
  setCanvas(t, e) {
    const {
      id: s,
      bitmap: i
    } = this._uiManager.imageManager.getFromCanvas(t, e);
    e.remove(), s && this._uiManager.imageManager.isValidId(s) && (this.#e = s, i && (this.#t = i), this.#o = !1, this.#m());
  }
  _onResized() {
    this.onScaleChanging();
  }
  onScaleChanging() {
    if (!this.parent)
      return;
    this.#l !== null && clearTimeout(this.#l);
    const t = 200;
    this.#l = setTimeout(() => {
      this.#l = null, this.#p();
    }, t);
  }
  #m() {
    const {
      div: t
    } = this;
    let {
      width: e,
      height: s
    } = this.#t;
    const [i, n] = this.pageDimensions, r = 0.75;
    if (this.width)
      e = this.width * i, s = this.height * n;
    else if (e > r * i || s > r * n) {
      const o = Math.min(r * i / e, r * n / s);
      e *= o, s *= o;
    }
    this._uiManager.enableWaiting(!1);
    const a = this.#r = document.createElement("canvas");
    a.setAttribute("role", "img"), this.addContainer(a), this.width = e / i, this.height = s / n, this.setDims(), this._initialOptions?.isCentered ? this.center() : this.fixAndSetPosition(), this._initialOptions = null, (!this._uiManager.useNewAltTextWhenAddingImage || !this._uiManager.useNewAltTextFlow || this.annotationElementId) && (t.hidden = !1), this.#p(), this.#u || (this.parent.addUndoableEditor(this), this.#u = !0), this._reportTelemetry({
      action: "inserted_image"
    }), this.#a && this.div.setAttribute("aria-description", this.#a), this.annotationElementId || this._uiManager.a11yAlert(H._l10nAlert.stamp);
  }
  copyCanvas(t, e, s = !1) {
    t ||= 224;
    const {
      width: i,
      height: n
    } = this.#t, r = new Kt();
    let a = this.#t, o = i, l = n, h = null;
    if (e) {
      if (i > e || n > e) {
        const S = Math.min(e / i, e / n);
        o = Math.floor(i * S), l = Math.floor(n * S);
      }
      h = document.createElement("canvas");
      const u = h.width = Math.ceil(o * r.sx), f = h.height = Math.ceil(l * r.sy);
      this.#h || (a = this.#c(u, f));
      const p = h.getContext("2d");
      p.filter = this._uiManager.hcmFilter;
      let g = "white", m = "#cfcfd8";
      this._uiManager.hcmFilter !== "none" ? m = "black" : yr.isDarkMode && (g = "#8f8f9d", m = "#42414d");
      const v = 15, y = v * r.sx, b = v * r.sy, w = new OffscreenCanvas(y * 2, b * 2), A = w.getContext("2d");
      A.fillStyle = g, A.fillRect(0, 0, y * 2, b * 2), A.fillStyle = m, A.fillRect(0, 0, y, b), A.fillRect(y, b, y, b), p.fillStyle = p.createPattern(w, "repeat"), p.fillRect(0, 0, u, f), p.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f);
    }
    let d = null;
    if (s) {
      let u, f;
      if (r.symmetric && a.width < t && a.height < t)
        u = a.width, f = a.height;
      else if (a = this.#t, i > t || n > t) {
        const m = Math.min(t / i, t / n);
        u = Math.floor(i * m), f = Math.floor(n * m), this.#h || (a = this.#c(u, f));
      }
      const g = new OffscreenCanvas(u, f).getContext("2d", {
        willReadFrequently: !0
      });
      g.drawImage(a, 0, 0, a.width, a.height, 0, 0, u, f), d = {
        width: u,
        height: f,
        data: g.getImageData(0, 0, u, f).data
      };
    }
    return {
      canvas: h,
      width: o,
      height: l,
      imageData: d
    };
  }
  #c(t, e) {
    const {
      width: s,
      height: i
    } = this.#t;
    let n = s, r = i, a = this.#t;
    for (; n > 2 * t || r > 2 * e; ) {
      const o = n, l = r;
      n > 2 * t && (n = Math.ceil(n / 2)), r > 2 * e && (r = Math.ceil(r / 2));
      const h = new OffscreenCanvas(n, r);
      h.getContext("2d").drawImage(a, 0, 0, o, l, 0, 0, n, r), a = h.transferToImageBitmap();
    }
    return a;
  }
  #p() {
    const [t, e] = this.parentDimensions, {
      width: s,
      height: i
    } = this, n = new Kt(), r = Math.ceil(s * t * n.sx), a = Math.ceil(i * e * n.sy), o = this.#r;
    if (!o || o.width === r && o.height === a)
      return;
    o.width = r, o.height = a;
    const l = this.#h ? this.#t : this.#c(r, a), h = o.getContext("2d");
    h.filter = this._uiManager.hcmFilter, h.drawImage(l, 0, 0, l.width, l.height, 0, 0, r, a);
  }
  #v(t) {
    if (t) {
      if (this.#h) {
        const i = this._uiManager.imageManager.getSvgUrl(this.#e);
        if (i)
          return i;
      }
      const e = document.createElement("canvas");
      return {
        width: e.width,
        height: e.height
      } = this.#t, e.getContext("2d").drawImage(this.#t, 0, 0), e.toDataURL();
    }
    if (this.#h) {
      const [e, s] = this.pageDimensions, i = Math.round(this.width * e * Fe.PDF_TO_CSS_UNITS), n = Math.round(this.height * s * Fe.PDF_TO_CSS_UNITS), r = new OffscreenCanvas(i, n);
      return r.getContext("2d").drawImage(this.#t, 0, 0, this.#t.width, this.#t.height, 0, 0, i, n), r.transferToImageBitmap();
    }
    return structuredClone(this.#t);
  }
  static async deserialize(t, e, s) {
    let i = null, n = !1;
    if (t instanceof Wn) {
      const {
        data: {
          rect: g,
          rotation: m,
          id: v,
          structParent: y,
          popupRef: b,
          richText: w,
          contentsObj: A,
          creationDate: S,
          modificationDate: E
        },
        container: T,
        parent: {
          page: {
            pageNumber: x
          }
        },
        canvas: P
      } = t;
      let C, I;
      P ? (delete t.canvas, {
        id: C,
        bitmap: I
      } = s.imageManager.getFromCanvas(T.id, P), P.remove()) : (n = !0, t._hasNoCanvas = !0);
      const R = (await e._structTree.getAriaAttributes(`${Re}${v}`))?.get("aria-label") || "";
      i = t = {
        annotationType: X.STAMP,
        bitmapId: C,
        bitmap: I,
        pageIndex: x - 1,
        rect: g.slice(0),
        rotation: m,
        annotationElementId: v,
        id: v,
        deleted: !1,
        accessibilityData: {
          decorative: !1,
          altText: R
        },
        isSvg: !1,
        structParent: y,
        popupRef: b,
        richText: w,
        comment: A?.str || null,
        creationDate: S,
        modificationDate: E
      };
    }
    const r = await super.deserialize(t, e, s), {
      rect: a,
      bitmap: o,
      bitmapUrl: l,
      bitmapId: h,
      isSvg: d,
      accessibilityData: u
    } = t;
    n ? (s.addMissingCanvas(t.id, r), r.#o = !0) : h && s.imageManager.isValidId(h) ? (r.#e = h, o && (r.#t = o)) : r.#i = l, r.#h = d;
    const [f, p] = r.pageDimensions;
    return r.width = (a[2] - a[0]) / f, r.height = (a[3] - a[1]) / p, u && (r.altTextData = u), r._initialData = i, t.comment && r.setCommentData(t), r.#u = !!i, r;
  }
  serialize(t = !1, e = null) {
    if (this.isEmpty())
      return null;
    if (this.deleted)
      return this.serializeDeleted();
    const s = Object.assign(super.serialize(t), {
      bitmapId: this.#e,
      isSvg: this.#h
    });
    if (this.addComment(s), t)
      return s.bitmapUrl = this.#v(!0), s.accessibilityData = this.serializeAltText(!0), s.isCopy = !0, s;
    const {
      decorative: i,
      altText: n
    } = this.serializeAltText(!1);
    if (!i && n && (s.accessibilityData = {
      type: "Figure",
      alt: n
    }), this.annotationElementId) {
      const a = this.#y(s);
      return a.isSame ? null : (a.isSameAltText ? delete s.accessibilityData : s.accessibilityData.structParent = this._initialData.structParent ?? -1, s.id = this.annotationElementId, delete s.bitmapId, s);
    }
    if (e === null)
      return s;
    e.stamps ||= /* @__PURE__ */ new Map();
    const r = this.#h ? (s.rect[2] - s.rect[0]) * (s.rect[3] - s.rect[1]) : null;
    if (!e.stamps.has(this.#e))
      e.stamps.set(this.#e, {
        area: r,
        serialized: s
      }), s.bitmap = this.#v(!1);
    else if (this.#h) {
      const a = e.stamps.get(this.#e);
      r > a.area && (a.area = r, a.serialized.bitmap.close(), a.serialized.bitmap = this.#v(!1));
    }
    return s;
  }
  #y(t) {
    const {
      pageIndex: e,
      accessibilityData: {
        altText: s
      }
    } = this._initialData, i = t.pageIndex === e, n = (t.accessibilityData?.alt || "") === s;
    return {
      isSame: !this.hasEditedComment && !this._hasBeenMoved && !this._hasBeenResized && i && n,
      isSameAltText: n
    };
  }
  renderAnnotationElement(t) {
    return this.deleted ? (t.hide(), null) : (t.updateEdited({
      rect: this.getPDFRect(),
      popup: this.comment
    }), null);
  }
}
class re {
  #t;
  #e = !1;
  #s = null;
  #i = null;
  #n = null;
  #a = /* @__PURE__ */ new Map();
  #r = !1;
  #o = !1;
  #l = !1;
  #h = null;
  #u = null;
  #d = null;
  #f = null;
  #g = null;
  #m = -1;
  #c;
  static _initialized = !1;
  static #p = new Map([Et, Oi, fo, Wt, ee].map((t) => [t._editorType, t]));
  constructor({
    uiManager: t,
    pageIndex: e,
    div: s,
    structTreeLayer: i,
    accessibilityManager: n,
    annotationLayer: r,
    drawLayer: a,
    textLayer: o,
    viewport: l,
    l10n: h
  }) {
    const d = [...re.#p.values()];
    if (!re._initialized) {
      re._initialized = !0;
      for (const u of d)
        u.initialize(h, t);
    }
    t.registerEditorTypes(d), this.#c = t, this.pageIndex = e, this.div = s, this.#t = n, this.#s = r, this.viewport = l, this.#d = o, this.drawLayer = a, this._structTree = i, this.#c.addLayer(this);
  }
  get isEmpty() {
    return this.#a.size === 0;
  }
  get isInvisible() {
    return this.isEmpty && this.#c.getMode() === X.NONE;
  }
  updateToolbar(t) {
    this.#c.updateToolbar(t);
  }
  updateMode(t = this.#c.getMode()) {
    switch (this.#w(), t) {
      case X.NONE:
        this.div.classList.toggle("nonEditing", !0), this.disableTextSelection(), this.togglePointerEvents(!1), this.toggleAnnotationLayerPointerEvents(!0), this.disableClick();
        return;
      case X.INK:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
        break;
      case X.HIGHLIGHT:
        this.enableTextSelection(), this.togglePointerEvents(!1), this.disableClick();
        break;
      default:
        this.disableTextSelection(), this.togglePointerEvents(!0), this.enableClick();
    }
    this.toggleAnnotationLayerPointerEvents(!1);
    const {
      classList: e
    } = this.div;
    if (e.toggle("nonEditing", !1), t === X.POPUP)
      e.toggle("commentEditing", !0);
    else {
      e.toggle("commentEditing", !1);
      for (const s of re.#p.values())
        e.toggle(`${s._type}Editing`, t === s._editorType);
    }
    this.div.hidden = !1;
  }
  hasTextLayer(t) {
    return t === this.#d?.div;
  }
  setEditingState(t) {
    this.#c.setEditingState(t);
  }
  addCommands(t) {
    this.#c.addCommands(t);
  }
  cleanUndoStack(t) {
    this.#c.cleanUndoStack(t);
  }
  toggleDrawing(t = !1) {
    this.div.classList.toggle("drawing", !t);
  }
  togglePointerEvents(t = !1) {
    this.div.classList.toggle("disabled", !t);
  }
  toggleAnnotationLayerPointerEvents(t = !1) {
    this.#s?.togglePointerEvents(t);
  }
  get #v() {
    return this.#a.size !== 0 ? this.#a.values() : this.#c.getEditors(this.pageIndex);
  }
  async enable() {
    this.#l = !0, this.div.tabIndex = 0, this.togglePointerEvents(!0), this.div.classList.toggle("nonEditing", !1), this.#g?.abort(), this.#g = null;
    const t = /* @__PURE__ */ new Set();
    for (const s of this.#v)
      s.enableEditing(), s.show(!0), s.annotationElementId && (this.#c.removeChangedExistingAnnotation(s), t.add(s.annotationElementId));
    const e = this.#s;
    if (e)
      for (const s of e.getEditableAnnotations()) {
        if (s.hide(), this.#c.isDeletedAnnotationElement(s.data.id) || t.has(s.data.id))
          continue;
        const i = await this.deserialize(s);
        i && (this.addOrRebuild(i), i.enableEditing());
      }
    this.#l = !1, this.#c._eventBus.dispatch("editorsrendered", {
      source: this,
      pageNumber: this.pageIndex + 1
    });
  }
  disable() {
    if (this.#o = !0, this.div.tabIndex = -1, this.togglePointerEvents(!1), this.div.classList.toggle("nonEditing", !0), this.#d && !this.#g) {
      this.#g = new AbortController();
      const i = this.#c.combinedSignal(this.#g);
      this.#d.div.addEventListener("pointerdown", (n) => {
        const {
          clientX: a,
          clientY: o,
          timeStamp: l
        } = n, h = this.#m;
        if (l - h > 500) {
          this.#m = l;
          return;
        }
        this.#m = -1;
        const {
          classList: d
        } = this.div;
        d.toggle("getElements", !0);
        const u = document.elementsFromPoint(a, o);
        if (d.toggle("getElements", !1), !this.div.contains(u[0]))
          return;
        let f;
        const p = new RegExp(`^${Ne}[0-9]+$`);
        for (const m of u)
          if (p.test(m.id)) {
            f = m.id;
            break;
          }
        if (!f)
          return;
        const g = this.#a.get(f);
        g?.annotationElementId === null && (St(n), g.dblclick(n));
      }, {
        signal: i,
        capture: !0
      });
    }
    const t = this.#s, e = [];
    if (t) {
      const i = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
      for (const r of this.#v) {
        if (r.disableEditing(), !r.annotationElementId) {
          e.push(r);
          continue;
        }
        if (r.serialize() !== null) {
          i.set(r.annotationElementId, r);
          continue;
        } else
          n.set(r.annotationElementId, r);
        this.getEditableAnnotation(r.annotationElementId)?.show(), r.remove();
      }
      for (const r of t.getEditableAnnotations()) {
        const {
          id: a
        } = r.data;
        if (this.#c.isDeletedAnnotationElement(a)) {
          r.updateEdited({
            deleted: !0
          });
          continue;
        }
        let o = n.get(a);
        if (o) {
          o.resetAnnotationElement(r), o.show(!1), r.show();
          continue;
        }
        o = i.get(a), o && (this.#c.addChangedExistingAnnotation(o), o.renderAnnotationElement(r) && o.show(!1)), r.show();
      }
    }
    this.#w(), this.isEmpty && (this.div.hidden = !0);
    const {
      classList: s
    } = this.div;
    for (const i of re.#p.values())
      s.remove(`${i._type}Editing`);
    this.disableTextSelection(), this.toggleAnnotationLayerPointerEvents(!0), t?.updateFakeAnnotations(e), this.#o = !1;
  }
  getEditableAnnotation(t) {
    return this.#s?.getEditableAnnotation(t) || null;
  }
  setActiveEditor(t) {
    this.#c.getActive() !== t && this.#c.setActiveEditor(t);
  }
  enableTextSelection() {
    if (this.div.tabIndex = -1, this.#d?.div && !this.#f) {
      this.#f = new AbortController();
      const t = this.#c.combinedSignal(this.#f);
      this.#d.div.addEventListener("pointerdown", this.#y.bind(this), {
        signal: t
      }), this.#d.div.classList.add("highlighting");
    }
  }
  disableTextSelection() {
    this.div.tabIndex = 0, this.#d?.div && this.#f && (this.#f.abort(), this.#f = null, this.#d.div.classList.remove("highlighting"));
  }
  #y(t) {
    this.#c.unselectAll();
    const {
      target: e
    } = t;
    if (e === this.#d.div || (e.getAttribute("role") === "img" || e.classList.contains("endOfContent") || e.classList.contains("textLayerImages") || e.classList.contains("textLayerImagePlaceholder")) && this.#d.div.contains(e)) {
      const {
        isMac: s
      } = at.platform;
      if (t.button !== 0 || t.ctrlKey && s)
        return;
      this.#c.showAllEditors("highlight", !0, !0), Wt.startDrawing(this, this.#c, this.#c.direction === "ltr", t), t.preventDefault();
    }
  }
  enableClick() {
    if (this.#i)
      return;
    this.#i = new AbortController();
    const t = this.#c.combinedSignal(this.#i);
    this.div.addEventListener("pointerdown", this.pointerdown.bind(this), {
      signal: t
    });
    const e = this.pointerup.bind(this);
    this.div.addEventListener("pointerup", e, {
      signal: t
    }), this.div.addEventListener("pointercancel", e, {
      signal: t
    });
  }
  disableClick() {
    this.#i?.abort(), this.#i = null;
  }
  attach(t) {
    this.#a.set(t.id, t);
    const {
      annotationElementId: e
    } = t;
    e && this.#c.isDeletedAnnotationElement(e) && this.#c.removeDeletedAnnotationElement(t);
  }
  detach(t) {
    this.#a.delete(t.id), this.#t?.removePointerInTextLayer(t.contentDiv), !this.#o && t.annotationElementId && this.#c.addDeletedAnnotationElement(t);
  }
  remove(t) {
    this.detach(t), this.#c.removeEditor(t), t.div.remove(), t.isAttachedToDOM = !1;
  }
  changeParent(t) {
    t.parent !== this && (t.parent && t.annotationElementId && (this.#c.addDeletedAnnotationElement(t), H.deleteAnnotationElement(t), t.annotationElementId = null), this.attach(t), t.parent?.detach(t), t.setParent(this), t.div && t.isAttachedToDOM && (t.div.remove(), this.div.append(t.div)));
  }
  add(t) {
    if (!(t.parent === this && t.isAttachedToDOM)) {
      if (this.changeParent(t), this.#c.addEditor(t), this.attach(t), !t.isAttachedToDOM) {
        const e = t.render();
        this.div.append(e), t.isAttachedToDOM = !0;
      }
      t.fixAndSetPosition(), t.onceAdded(!this.#l), this.#c.addToAnnotationStorage(t), t._reportTelemetry(t.telemetryInitialData);
    }
  }
  moveEditorInDOM(t) {
    if (!t.isAttachedToDOM)
      return;
    const {
      activeElement: e
    } = document;
    t.div.contains(e) && !this.#n && (t._focusEventsAllowed = !1, this.#n = setTimeout(() => {
      this.#n = null, t.div.contains(document.activeElement) ? t._focusEventsAllowed = !0 : (t.div.addEventListener("focusin", () => {
        t._focusEventsAllowed = !0;
      }, {
        once: !0,
        signal: this.#c._signal
      }), e.focus());
    }, 0)), t._structTreeParentId = this.#t?.moveElementInDOM(this.div, t.div, t.contentDiv, !0);
  }
  addOrRebuild(t) {
    t.needsToBeRebuilt() ? (t.parent ||= this, t.rebuild(), t.show()) : this.add(t);
  }
  addUndoableEditor(t) {
    const e = () => t._uiManager.rebuild(t), s = () => {
      t.remove();
    };
    this.addCommands({
      cmd: e,
      undo: s,
      mustExec: !1
    });
  }
  getEditorByUID(t) {
    for (const e of this.#a.values())
      if (e.uid === t)
        return e;
    return null;
  }
  get #b() {
    return re.#p.get(this.#c.getMode());
  }
  combinedSignal(t) {
    return this.#c.combinedSignal(t);
  }
  #A(t) {
    const e = this.#b;
    return e ? new e.prototype.constructor(t) : null;
  }
  canCreateNewEmptyEditor() {
    return this.#b?.canCreateNewEmptyEditor();
  }
  async pasteEditor(t, e) {
    this.updateToolbar(t), await this.#c.updateMode(t.mode);
    const {
      offsetX: s,
      offsetY: i
    } = this.#E(), n = this.#c.getId(), r = this.#A({
      parent: this,
      id: n,
      x: s,
      y: i,
      uiManager: this.#c,
      isCentered: !0,
      ...e
    });
    r && this.add(r);
  }
  async deserialize(t) {
    return await re.#p.get(t.annotationType ?? t.annotationEditorType)?.deserialize(t, this, this.#c) || null;
  }
  createAndAddNewEditor(t, e, s = {}) {
    const i = this.#c.getId(), n = this.#A({
      parent: this,
      id: i,
      x: t.offsetX,
      y: t.offsetY,
      uiManager: this.#c,
      isCentered: e,
      ...s
    });
    return n && this.add(n), n;
  }
  get boundingClientRect() {
    return this.div.getBoundingClientRect();
  }
  #E() {
    const {
      x: t,
      y: e,
      width: s,
      height: i
    } = this.boundingClientRect, n = Math.max(0, t), r = Math.max(0, e), a = Math.min(window.innerWidth, t + s), o = Math.min(window.innerHeight, e + i), l = (n + a) / 2 - t, h = (r + o) / 2 - e, [d, u] = this.viewport.rotation % 180 === 0 ? [l, h] : [h, l];
    return {
      offsetX: d,
      offsetY: u
    };
  }
  addNewEditor(t = {}) {
    this.createAndAddNewEditor(this.#E(), !0, t);
  }
  setSelected(t) {
    this.#c.setSelected(t);
  }
  toggleSelected(t) {
    this.#c.toggleSelected(t);
  }
  unselect(t) {
    this.#c.unselect(t);
  }
  pointerup(t) {
    const {
      isMac: e
    } = at.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div || !this.#r || (this.#r = !1, this.#b?.isDrawer && this.#b.supportMultipleDrawings))
      return;
    if (!this.#e) {
      this.#e = !0;
      return;
    }
    const s = this.#c.getMode();
    if (s === X.STAMP || s === X.POPUP || s === X.SIGNATURE) {
      this.#c.unselectAll();
      return;
    }
    this.createAndAddNewEditor(t, !1);
  }
  pointerdown(t) {
    if (this.#c.getMode() === X.HIGHLIGHT && this.enableTextSelection(), this.#r) {
      this.#r = !1;
      return;
    }
    const {
      isMac: e
    } = at.platform;
    if (t.button !== 0 || t.ctrlKey && e || t.target !== this.div)
      return;
    if (this.#r = !0, this.#b?.isDrawer) {
      this.startDrawingSession(t);
      return;
    }
    const s = this.#c.getActive();
    this.#e = !s || s.isEmpty();
  }
  startDrawingSession(t) {
    if (this.div.focus({
      preventScroll: !0
    }), this.#h) {
      this.#b.startDrawing(this, this.#c, !1, t);
      return;
    }
    this.#c.setCurrentDrawingSession(this), this.#h = new AbortController();
    const e = this.#c.combinedSignal(this.#h);
    this.div.addEventListener("blur", ({
      relatedTarget: s
    }) => {
      s && !this.div.contains(s) && (this.#u = null, this.commitOrRemove());
    }, {
      signal: e
    }), this.#b.startDrawing(this, this.#c, !1, t);
  }
  pause(t) {
    if (t) {
      const {
        activeElement: e
      } = document;
      this.div.contains(e) && (this.#u = e);
      return;
    }
    this.#u && setTimeout(() => {
      this.#u?.focus(), this.#u = null;
    }, 0);
  }
  endDrawingSession(t = !1) {
    return this.#h ? (this.#c.setCurrentDrawingSession(null), this.#h.abort(), this.#h = null, this.#u = null, this.#b.endDrawing(t)) : null;
  }
  findNewParent(t, e, s) {
    const i = this.#c.findParent(e, s);
    return i === null || i === this ? !1 : (i.changeParent(t), !0);
  }
  commitOrRemove() {
    return this.#h ? (this.endDrawingSession(), !0) : !1;
  }
  onScaleChanging() {
    this.#h && this.#b.onScaleChangingWhenDrawing(this);
  }
  destroy() {
    this.commitOrRemove(), this.#c.getActive()?.parent === this && (this.#c.commitOrRemove(), this.#c.setActiveEditor(null)), this.#n && (clearTimeout(this.#n), this.#n = null);
    for (const t of this.#a.values())
      this.#t?.removePointerInTextLayer(t.contentDiv), t.setParent(null), t.isAttachedToDOM = !1, t.div.remove();
    this.div = null, this.#a.clear(), this.#c.removeLayer(this);
  }
  #w() {
    for (const t of this.#a.values())
      t.isEmpty() && t.remove();
  }
  async render({
    viewport: t
  }) {
    this.viewport = t, Se(this.div, t);
    for (const e of this.#c.getEditors(this.pageIndex))
      this.add(e), e.rebuild();
    await this.#c.findClonesForPage(this), this.div.hidden = this.isEmpty, this.updateMode();
  }
  update({
    viewport: t
  }) {
    this.#c.commitOrRemove(), this.#w();
    const e = this.viewport.rotation, s = t.rotation;
    if (this.viewport = t, Se(this.div, {
      rotation: s
    }), e !== s)
      for (const i of this.#a.values())
        i.rotate(s);
  }
  get pageDimensions() {
    const {
      pageWidth: t,
      pageHeight: e
    } = this.viewport.rawDims;
    return [t, e];
  }
  get scale() {
    return this.#c.viewParameters.realScale;
  }
}
K(1806);
function po(c, t) {
  return c === t ? 0 : c.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}
function fs(c) {
  return c ? c.nodeType === Node.ELEMENT_NODE ? c.closest(".textLayer") : c.parentElement?.closest(".textLayer") || null : null;
}
function go(c, t, e, s) {
  if (c === e)
    return t <= s;
  const i = c.compareDocumentPosition(e);
  return i & Node.DOCUMENT_POSITION_FOLLOWING ? !0 : i & Node.DOCUMENT_POSITION_PRECEDING ? !1 : null;
}
function yn(c, t, e) {
  if (c.nodeType !== Node.ELEMENT_NODE || !c.classList.contains("textLayer") || t !== c.childNodes.length)
    return {
      container: c,
      offset: t
    };
  let s = c.lastChild;
  return s?.nodeType === Node.ELEMENT_NODE && s.classList.contains("endOfContent") && (s = s.previousSibling), !s || !e.contains(s) ? null : s.nodeType === Node.TEXT_NODE ? {
    container: s,
    offset: s.textContent.length
  } : {
    container: s,
    offset: s.childNodes.length
  };
}
class z {
  #t = null;
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #i = null;
  #n = null;
  #a = null;
  #r = /* @__PURE__ */ new Map();
  static #o = 0;
  static #l = 0;
  static #h = null;
  static #u = /* @__PURE__ */ new Set();
  static #d = !1;
  static #f = /* @__PURE__ */ new Set();
  static #g = /* @__PURE__ */ new WeakMap();
  constructor({
    filterFactory: t = null,
    pageColors: e = null,
    pageIndex: s,
    textLayer: i = null
  }) {
    if (this.pageIndex = s, this.#i = t, this.#n = e, i) {
      const n = z.#g.get(i);
      if (n?.selectionDiv && (n.selectionDiv.remove(), z.#u.delete(n.selectionDiv)), z.#g.set(i, {
        drawLayer: this
      }), z.#f.add(i), this.#s = i, this.#a = new MutationObserver((r) => {
        if (!(!this.#t || !this.#s?.isConnected || !z.#c())) {
          for (const {
            addedNodes: a
          } of r)
            for (const o of a)
              if (o.nodeType === Node.ELEMENT_NODE && o.classList.contains("endOfContent")) {
                z.#v();
                return;
              }
        }
      }), this.#a.observe(i, {
        childList: !0
      }), z.#h === null) {
        z.#h = new AbortController();
        const {
          signal: r
        } = z.#h;
        document.addEventListener("selectionchange", z.#v.bind(z), {
          signal: r
        }), document.addEventListener("pointerdown", () => {
          z.#d = !0;
        }, {
          signal: r
        }), document.addEventListener("pointerup", () => {
          z.#d = !1;
        }, {
          signal: r
        }), window.addEventListener("blur", () => {
          z.#d = !1;
        }, {
          signal: r
        });
      }
    }
  }
  setParent(t) {
    if (!this.#t) {
      this.#t = t, this.#s?.isConnected && z.#c() && z.#v();
      return;
    }
    if (this.#t !== t) {
      if (this.#e.size > 0)
        for (const e of this.#e.values())
          e.remove(), t.append(e);
      this.#t = t;
    }
  }
  static #m(t) {
    const e = this.#g.get(t);
    e?.selectionDiv && (e.selectionDiv.remove(), this.#u.delete(e.selectionDiv), e.selectionDiv = null, e.path = null);
  }
  static #c() {
    const t = document.getSelection();
    return !!t && !t.isCollapsed;
  }
  static #p() {
    return this.#f.keys().filter((t) => t.isConnected).toArray().sort(po);
  }
  static #v() {
    const t = document.getSelection();
    if (!t || t.isCollapsed) {
      for (const r of this.#u)
        r.remove();
      this.#u.clear();
      return;
    }
    const e = /* @__PURE__ */ new WeakMap(), s = this.#p(), i = [];
    for (let r = 0, a = t.rangeCount; r < a; r++) {
      const o = t.getRangeAt(r);
      if (o.collapsed)
        continue;
      let {
        startContainer: l,
        startOffset: h,
        endContainer: d,
        endOffset: u
      } = o, f = fs(l), p = fs(d);
      const g = f === null, m = p === null;
      if (this.#d && g !== m)
        return;
      if (t.rangeCount === 1) {
        const {
          anchorNode: b,
          anchorOffset: w,
          focusNode: A,
          focusOffset: S
        } = t, E = fs(b), T = fs(A), x = go(b, w, A, S);
        E && T && x !== null && (x ? (l = b, h = w, f = E, d = A, u = S, p = T) : (l = A, h = S, f = T, d = b, u = w, p = E));
      }
      const v = s.filter((b) => o.intersectsNode(b));
      if (v.length === 0)
        continue;
      let y = !1;
      if (f || (f = v[0], l = f, h = 0, y = !0), p || (p = v.at(-1), d = p, u = p.childNodes.length, y = !0), d.nodeType === Node.ELEMENT_NODE) {
        if (d.classList.contains("endOfContent")) {
          const b = d.previousSibling;
          if (!b)
            continue;
          d = b, u = b.nodeType === Node.TEXT_NODE ? b.textContent.length : b.childNodes.length;
        } else if (d.classList.contains("textLayer") && d.childNodes.length === u) {
          const b = yn(d, u, p);
          if (!b)
            continue;
          d = b.container, u = b.offset;
        }
      }
      if (l.nodeType === Node.ELEMENT_NODE) {
        const b = yn(l, h, f);
        if (!b)
          continue;
        l = b.container, h = b.offset;
      }
      if (f === p && !y && v.includes(f)) {
        i.push([o, f]);
        continue;
      }
      for (const b of v) {
        const w = b.firstChild;
        if (!w)
          continue;
        const A = document.createRange();
        if (b === f ? A.setStart(l, h) : A.setStartBefore(w), b === p)
          A.setEnd(d, u);
        else {
          const S = b.lastChild;
          if (!S)
            continue;
          if (S.nodeType === Node.ELEMENT_NODE && S.classList.contains("endOfContent")) {
            const E = S.previousSibling;
            if (!E)
              continue;
            A.setEndAfter(E);
          } else
            A.setEndAfter(S);
        }
        A.collapsed || i.push([A, b]);
      }
    }
    const n = new Set(i.map((r) => r[1]));
    for (const r of this.#f)
      n.has(r) || this.#m(r);
    for (const [r, a] of i) {
      const o = z.#g.get(a);
      if (!o)
        continue;
      let l = e.get(a);
      if (!l) {
        const p = a.getBoundingClientRect();
        l = (g, m, v, y) => ({
          x: (g - p.x) / p.width,
          y: (m - p.y) / p.height,
          width: v / p.width,
          height: y / p.height
        }), e.set(a, l);
      }
      const h = [];
      for (let {
        x: p,
        y: g,
        width: m,
        height: v
      } of r.getClientRects())
        m === 0 || v === 0 || ({
          x: p,
          y: g,
          width: m,
          height: v
        } = l(p, g, m, v), !(m === 1 && v === 1) && h.push(`M${p} ${g} h${m} v${v} h-${m} Z`));
      if (h.length === 0)
        continue;
      const d = o.drawLayer;
      let u = o.selectionDiv, f = o.path;
      if (!u) {
        const p = `clip_selection_${z.#l++}`;
        u = document.createElement("div"), u.className = "selection", u.style.clipPath = `url(#${p})`;
        const g = d.#i?.createSelectionStyle(d.#n);
        if (g)
          for (const [y, b] of Object.entries(g))
            u.style.setProperty(y, b);
        const m = z._svgFactory.create(1, 1, !0);
        m.setAttribute("aria-hidden", "true"), m.setAttribute("width", "100%"), m.setAttribute("height", "100%");
        const v = z._svgFactory.createElement("clipPath");
        v.setAttribute("id", p), v.setAttribute("clipPathUnits", "objectBoundingBox"), f = z._svgFactory.createElement("path"), v.append(f), m.append(v), u.append(m), o.path = f, o.selectionDiv = u;
      }
      d.#t && u.parentNode !== d.#t && (d.#t.append(u), this.#u.add(u)), f.setAttribute("d", h.join(" "));
    }
  }
  static get _svgFactory() {
    return j(this, "_svgFactory", new ws());
  }
  static #y(t, [e, s, i, n]) {
    const {
      style: r
    } = t;
    r.top = `${100 * s}%`, r.left = `${100 * e}%`, r.width = `${100 * i}%`, r.height = `${100 * n}%`;
  }
  #b() {
    const t = z._svgFactory.create(1, 1, !0);
    return this.#t.append(t), t.setAttribute("aria-hidden", "true"), t;
  }
  #A(t, e) {
    const s = z._svgFactory.createElement("clipPath");
    t.append(s);
    const i = `clip_${e}`;
    s.setAttribute("id", i), s.setAttribute("clipPathUnits", "objectBoundingBox");
    const n = z._svgFactory.createElement("use");
    return s.append(n), n.setAttribute("href", `#${e}`), n.classList.add("clip"), i;
  }
  #E(t, e) {
    for (const [s, i] of Object.entries(e))
      i === null ? t.removeAttribute(s) : t.setAttribute(s, i);
  }
  draw(t, e = !1, s = !1) {
    const i = z.#o++, n = this.#b(), r = z._svgFactory.createElement("defs");
    n.append(r);
    const a = z._svgFactory.createElement("path");
    r.append(a);
    const o = `path_${i}`;
    a.setAttribute("id", o), a.setAttribute("vector-effect", "non-scaling-stroke"), e && this.#r.set(i, a);
    const l = s ? this.#A(r, o) : null, h = z._svgFactory.createElement("use");
    return n.append(h), h.setAttribute("href", `#${o}`), this.updateProperties(n, t), this.#e.set(i, n), {
      id: i,
      clipPathId: `url(#${l})`
    };
  }
  drawOutline(t, e) {
    const s = z.#o++, i = this.#b(), n = z._svgFactory.createElement("defs");
    i.append(n);
    const r = z._svgFactory.createElement("path");
    n.append(r);
    const a = `path_${s}`;
    r.setAttribute("id", a), r.setAttribute("vector-effect", "non-scaling-stroke");
    let o;
    if (e) {
      const d = z._svgFactory.createElement("mask");
      n.append(d), o = `mask_${s}`, d.setAttribute("id", o), d.setAttribute("maskUnits", "objectBoundingBox");
      const u = z._svgFactory.createElement("rect");
      d.append(u), u.setAttribute("width", "1"), u.setAttribute("height", "1"), u.setAttribute("fill", "white");
      const f = z._svgFactory.createElement("use");
      d.append(f), f.setAttribute("href", `#${a}`), f.setAttribute("stroke", "none"), f.setAttribute("fill", "black"), f.setAttribute("fill-rule", "nonzero"), f.classList.add("mask");
    }
    const l = z._svgFactory.createElement("use");
    i.append(l), l.setAttribute("href", `#${a}`), o && l.setAttribute("mask", `url(#${o})`);
    const h = l.cloneNode();
    return i.append(h), l.classList.add("mainOutline"), h.classList.add("secondaryOutline"), this.updateProperties(i, t), this.#e.set(s, i), s;
  }
  finalizeDraw(t, e) {
    this.#r.delete(t), this.updateProperties(t, e);
  }
  updateProperties(t, e) {
    if (!e)
      return;
    const {
      root: s,
      bbox: i,
      rootClass: n,
      path: r
    } = e, a = typeof t == "number" ? this.#e.get(t) : t;
    if (a) {
      if (s && this.#E(a, s), i && z.#y(a, i), n) {
        const {
          classList: o
        } = a;
        for (const [l, h] of Object.entries(n))
          o.toggle(l, h);
      }
      if (r) {
        const l = a.firstElementChild.firstElementChild;
        this.#E(l, r);
      }
    }
  }
  updateParent(t, e) {
    if (e === this)
      return;
    const s = this.#e.get(t);
    s && (e.#t.append(s), this.#e.delete(t), e.#e.set(t, s));
  }
  remove(t) {
    this.#r.delete(t), this.#t !== null && (this.#e.get(t).remove(), this.#e.delete(t));
  }
  destroy() {
    this.#t = null;
    for (const t of this.#e.values())
      t.remove();
    this.#e.clear(), this.#r.clear(), this.#a?.disconnect(), this.#a = null, this.#s && (z.#g.get(this.#s)?.drawLayer === this && (z.#m(this.#s), z.#g.delete(this.#s), z.#f.delete(this.#s), z.#f.size === 0 && (z.#h?.abort(), z.#h = null, z.#d = !1)), this.#s = null);
  }
}
function ps(c) {
  return `${(c * 100).toFixed(2)}%`;
}
class Es {
  #t = [];
  #e = /* @__PURE__ */ new Map();
  #s = null;
  #i = 0;
  #n = 0;
  #a = 0;
  static #r = null;
  constructor(t, e, s, i) {
    this.#i = t, this.#t = e, this.#n = s.rawDims.pageWidth, this.#a = s.rawDims.pageHeight, this.#s = i;
  }
  render() {
    const t = document.createElement("div");
    t.className = "textLayerImages";
    for (let e = 0; e < this.#t.length; e += 6) {
      const s = this.#o(this.#t.subarray(e, e + 6));
      s && t.append(s);
    }
    return t.addEventListener("contextmenu", (e) => {
      if (!(e.target instanceof HTMLCanvasElement))
        return;
      const s = e.target, i = this.#e.get(s);
      if (!i)
        return;
      const n = Es.#r?.deref();
      if (n === s)
        return;
      n && (n.width = 0, n.height = 0), Es.#r = new WeakRef(s);
      const {
        inverseTransform: r,
        x1: a,
        y1: o,
        width: l,
        height: h
      } = i, d = this.#s(), u = Math.ceil(a * d.width), f = Math.ceil(o * d.height), p = Math.floor((a + l / this.#n) * d.width), g = Math.floor((o + h / this.#a) * d.height);
      s.width = p - u, s.height = g - f;
      const m = s.getContext("2d");
      m.setTransform(...r), m.translate(-u, -f), m.drawImage(d, 0, 0);
    }), t;
  }
  #o([t, e, s, i, n, r]) {
    const a = Math.hypot((n - t) * this.#n, (r - e) * this.#a), o = Math.hypot((s - t) * this.#n, (i - e) * this.#a);
    if (a < this.#i || o < this.#i)
      return null;
    const l = [(n - t) * this.#n / a, (r - e) * this.#a / a, (s - t) * this.#n / o, (i - e) * this.#a / o, 0, 0], h = N.inverseTransform(l), d = document.createElement("canvas");
    return d.className = "textLayerImagePlaceholder", d.width = 0, d.height = 0, Object.assign(d.style, {
      opacity: 0,
      position: "absolute",
      left: ps(t),
      top: ps(e),
      width: ps(a / this.#n),
      height: ps(o / this.#a),
      transformOrigin: "0% 0%",
      transform: `matrix(${l.join(",")})`
    }), this.#e.set(d, {
      inverseTransform: h,
      width: a,
      height: o,
      x1: t,
      y1: e
    }), d;
  }
}
globalThis._pdfjsTestingUtils = {
  HighlightOutliner: li
};
globalThis.pdfjsLib = {
  AbortException: ce,
  AnnotationEditorLayer: re,
  AnnotationEditorParamsType: q,
  AnnotationEditorType: X,
  AnnotationEditorUIManager: de,
  AnnotationLayer: xi,
  AnnotationMode: le,
  AnnotationType: pt,
  applyOpacity: Ar,
  build: $a,
  ColorPicker: $t,
  createValidAbsoluteUrl: bn,
  CSSConstants: br,
  DOMSVGFactory: ws,
  DrawLayer: z,
  FeatureTest: at,
  fetchData: ui,
  findContrastColor: Sr,
  getDocument: Ba,
  getFilenameFromUrl: gr,
  getPdfFilenameFromUrl: mr,
  getRGB: is,
  getRGBA: ss,
  getUuid: Sn,
  GlobalWorkerOptions: Ke,
  ImageKind: gs,
  InvalidPDFException: Zs,
  isDataScheme: Os,
  isPdfFile: pi,
  isValidExplicitDest: Vr,
  makeArr: Le,
  makeMap: di,
  makeObj: qs,
  makeSet: ur,
  MathClamp: ct,
  noContextMenu: Yt,
  normalizeUnicode: cr,
  OPS: se,
  OutputScale: Kt,
  PasswordException: Qs,
  PasswordResponses: ir,
  PDFDataRangeTransport: Hn,
  PDFDateString: ti,
  PDFWorker: qe,
  PermissionFlag: sr,
  PixelsPerInch: Fe,
  RenderingCancelledException: fi,
  renderRichText: En,
  ResponseException: bs,
  setLayerDimensions: Se,
  shadow: j,
  SignatureExtractor: Me,
  stopEvent: St,
  SupportedImageMimeTypes: ei,
  TextLayer: Lt,
  TextLayerImages: Es,
  TouchManager: Cn,
  updateUrlHash: An,
  Util: N,
  VerbosityLevel: Ts,
  version: ja,
  XfaLayer: wn
};
export {
  ce as AbortException,
  re as AnnotationEditorLayer,
  q as AnnotationEditorParamsType,
  X as AnnotationEditorType,
  de as AnnotationEditorUIManager,
  xi as AnnotationLayer,
  le as AnnotationMode,
  pt as AnnotationType,
  br as CSSConstants,
  $t as ColorPicker,
  ws as DOMSVGFactory,
  z as DrawLayer,
  at as FeatureTest,
  Ke as GlobalWorkerOptions,
  gs as ImageKind,
  Zs as InvalidPDFException,
  ct as MathClamp,
  se as OPS,
  Kt as OutputScale,
  Hn as PDFDataRangeTransport,
  ti as PDFDateString,
  qe as PDFWorker,
  Qs as PasswordException,
  ir as PasswordResponses,
  sr as PermissionFlag,
  Fe as PixelsPerInch,
  fi as RenderingCancelledException,
  bs as ResponseException,
  Me as SignatureExtractor,
  ei as SupportedImageMimeTypes,
  Lt as TextLayer,
  Es as TextLayerImages,
  Cn as TouchManager,
  N as Util,
  Ts as VerbosityLevel,
  wn as XfaLayer,
  Ar as applyOpacity,
  $a as build,
  bn as createValidAbsoluteUrl,
  ui as fetchData,
  Sr as findContrastColor,
  Ba as getDocument,
  gr as getFilenameFromUrl,
  mr as getPdfFilenameFromUrl,
  is as getRGB,
  ss as getRGBA,
  Sn as getUuid,
  Os as isDataScheme,
  pi as isPdfFile,
  Vr as isValidExplicitDest,
  Le as makeArr,
  di as makeMap,
  qs as makeObj,
  ur as makeSet,
  Yt as noContextMenu,
  cr as normalizeUnicode,
  En as renderRichText,
  Se as setLayerDimensions,
  j as shadow,
  St as stopEvent,
  An as updateUrlHash,
  ja as version
};
