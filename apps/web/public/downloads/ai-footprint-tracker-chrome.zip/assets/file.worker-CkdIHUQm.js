function ci(e) {
  const t = Object.values(e).filter((i) => typeof i == "number");
  return Object.entries(e).filter(([i, s]) => t.indexOf(+i) === -1).map(([i, s]) => s);
}
function fs(e, t = "|") {
  return e.map((n) => vr(n)).join(t);
}
function ui(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
class ma {
  constructor(t) {
    this._getter = t, this._value = void 0;
  }
  get value() {
    const t = this._getter;
    return t !== void 0 && (this._value = t(), this._getter = void 0), this._value;
  }
}
function kn(e) {
  return new ma(e);
}
function _a(e) {
  return e == null;
}
function Ei(e) {
  const t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
function ga(e, t) {
  const n = e / t, i = Math.round(n), s = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - i) < s ? 0 : n - i;
}
function Ae(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function zi(e) {
  const t = Object.getOwnPropertyDescriptor(e, "shape");
  return t?.get ? t.get.raw : t?.value;
}
function Oe(e) {
  return zi(e._zod.def) ?? e._zod.def.shape;
}
function hr(e, t, n) {
  Object.defineProperty(e, t, {
    get() {
      const i = n();
      return Ae(this, t, i), i;
    },
    enumerable: !0,
    configurable: !0
  });
}
function mr(e, t, n) {
  t in e ? Ae(e, t, n) : e[t] = n;
}
function Ye(e, t, n, i) {
  const s = Oe(t);
  for (const r of n) {
    const o = Object.getOwnPropertyDescriptor(s, r);
    o.enumerable && (o.get ? hr(e, r, () => {
      const a = t._zod.def.shape[r];
      return i ? i(a, r) : a;
    }) : mr(e, r, i ? i(o.value, r) : o.value));
  }
}
function va(e, t) {
  for (const n of Reflect.ownKeys(t)) {
    const i = Object.getOwnPropertyDescriptor(t, n);
    i.enumerable && (i.get ? hr(e, n, () => t[n]) : mr(e, n, i.value));
  }
}
function oe(...e) {
  const t = {};
  for (const n of e) {
    const i = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, i);
  }
  return Object.defineProperties({}, t);
}
function ba(e) {
  return JSON.stringify(e);
}
function ya(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const _r = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Zt(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
const wa = /* @__PURE__ */ kn(() => {
  if (le.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    const e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function pt(e) {
  if (Zt(e) === !1)
    return !1;
  const t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  const n = t.prototype;
  return !(Zt(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
function gr(e) {
  return pt(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
const xa = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function ht(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Be(e, t, n) {
  const i = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (i._zod.parent = e), i;
}
function I(e) {
  const t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: () => t };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: () => t.error } : t;
}
function vr(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function ka(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
const br = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, Sa = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function Ea(e, t) {
  const n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const r = {};
  return Ye(r, e, Sn(e, t)), Be(e, oe(n, { shape: r, checks: [] }));
}
function Sn(e, t) {
  const n = Oe(e), i = [];
  for (const s of Reflect.ownKeys(t)) {
    if (!Object.getOwnPropertyDescriptor(n, s)?.enumerable)
      throw new Error(`Unrecognized key: "${String(s)}"`);
    t[s] && i.push(s);
  }
  return i;
}
function za(e, t) {
  const n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const r = new Set(Sn(e, t)), o = {};
  return Ye(o, e, Reflect.ownKeys(Oe(e)).filter((a) => !r.has(a))), Be(e, oe(n, { shape: o, checks: [] }));
}
function Ia(e, t) {
  if (!pt(t))
    throw new Error("Invalid input to extend: expected a plain object");
  const n = e._zod.def.checks;
  if (n && n.length > 0) {
    const s = Oe(e);
    for (const r of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(s, r) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  return Be(e, oe(e._zod.def, { shape: yr(e, t) }));
}
function yr(e, t) {
  const n = {};
  return Ye(n, e, Reflect.ownKeys(Oe(e))), va(n, t), n;
}
function Ta(e, t) {
  if (!pt(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  return Be(e, oe(e._zod.def, { shape: yr(e, t) }));
}
function Oa(e, t) {
  if (!t?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  const n = {};
  Ye(n, e, Reflect.ownKeys(Oe(e))), Ye(n, t, Reflect.ownKeys(Oe(t)));
  const i = oe(e._zod.def, {
    shape: n,
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return Be(e, i);
}
function ps(e, t, n, i = "partial") {
  const r = t._zod.def.checks;
  if (r && r.length > 0)
    throw new Error(`.${i}() cannot be used on object schemas containing refinements`);
  const a = n ? new Set(Sn(t, n)) : void 0, u = {};
  return Ye(u, t, Reflect.ownKeys(Oe(t)), e && ((c, f) => a && !a.has(f) ? c : new e({ type: "optional", innerType: c }))), Be(t, oe(t._zod.def, { shape: u, checks: [] }));
}
function Aa(e, t, n) {
  const i = n ? new Set(Sn(t, n)) : void 0, s = {};
  return Ye(s, t, Reflect.ownKeys(Oe(t)), (r, o) => (
    // overwrite with non-optional
    i && !i.has(o) ? r : new e({ type: "nonoptional", innerType: r })
  )), Be(t, oe(t._zod.def, { shape: s }));
}
function me(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
function Na(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue === !1)
      return !0;
  return !1;
}
function Pe(e, t) {
  return t.map((n) => {
    var i;
    return (i = n).path ?? (i.path = []), n.path.unshift(e), n;
  });
}
function Ot(e) {
  return typeof e == "string" ? e : e?.message;
}
function hs(e) {
  const t = [];
  for (const n of e ?? []) {
    const i = n._zod.def;
    if (!/_(length|size)$|_equals$/.test(i.check))
      break;
    const s = i.maximum ?? i.length ?? i.size;
    s >= 0 && t.push([s, n]);
  }
  return t;
}
function li(e, t, n) {
  var i;
  for (let s = t; s < e.length; s++)
    (i = e[s]).schema ?? (i.schema = n);
}
function Le(e, t, n) {
  var i;
  const s = e.inst?._zod?.traits;
  s?.has("$ZodType") && (s.has("$ZodCheck") ? (i = e).schema ?? (i.schema = e.inst) : e.schema = e.inst);
  const r = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, o = e.message ? e.message : Ot(e.inst?._zod.def?.error?.(e)) ?? Ot(r?.(e)) ?? Ot(t?.error?.(e)) ?? Ot(n.customError?.(e)) ?? Ot(n.localeError?.(e)) ?? "Invalid input", a = {};
  for (const u of Object.keys(e))
    u === "inst" || u === "schema" || u === "continue" || u === "input" || u === "__proto__" || (a[u] = e[u]);
  return a.path ?? (a.path = []), a.message = o, t?.reportInput && (a.input = e.input), a;
}
const Ca = /[\uD800-\uDBFF]/;
function Ii(e) {
  const t = e.length;
  if (!Ca.test(e))
    return t;
  let n = t;
  for (let i = 0; i < t - 1; i++)
    (e.charCodeAt(i) & 64512) === 55296 && (e.charCodeAt(i + 1) & 64512) === 56320 && (n--, i++);
  return n;
}
function Ti(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function $a(e) {
  const t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      const n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
function Mt(...e) {
  const [t, n, i] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: i
  } : { ...t };
}
function Da(e, t) {
  for (const n in t) {
    const i = Object.getOwnPropertyDescriptor(t, n);
    i.get ? Object.defineProperty(e, n, { ...i, enumerable: !1 }) : Fa(e, n, i.value);
  }
}
function je(e, t, n, i = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: i, value: n }), n;
}
function wr(e, t, n) {
  return je(e, t, n, !1);
}
function xr(e, t) {
  for (const n in e) {
    const i = e[n];
    Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      get() {
        return je(this, n, i(this));
      },
      set(s) {
        je(this, n, s);
      }
    });
  }
  return t;
}
function Fa(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? n : je(this, t, n.bind(this));
    },
    set(i) {
      je(this, t, i);
    }
  });
}
function Ra(e, t) {
  const n = Object.getPrototypeOf(e);
  return t in n ? void 0 : n;
}
let jn, Re = !1;
const Pa = {
  configurable: !0,
  get() {
    Re = !0;
  }
};
function R(e, t, n) {
  const i = Object.getPrototypeOf(e._zod);
  if (t in i && jn !== e._zod) {
    jn = void 0;
    return;
  }
  jn = e._zod, Object.defineProperty(i, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, Pa);
      const s = Re;
      Re = !1;
      try {
        const r = n(this);
        return Re ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: r }), Re = Re || s, r;
      } catch (r) {
        throw delete this[t], Re = Re || s, r;
      }
    },
    set(s) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: s });
    }
  });
}
function Za(e, t, n, i) {
  const s = Ra(e, t);
  s && Object.defineProperty(s, t, {
    configurable: !0,
    get() {
      const r = { configurable: !0, writable: !0, enumerable: i, value: void 0 };
      return Object.defineProperty(this, t, r), r.value = n(this), Object.defineProperty(this, t, r), r.value;
    },
    set(r) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: i, value: r });
    }
  });
}
const Ma = "~constantCatch";
function La(e) {
  const t = () => e;
  return t[Ma] = !0, t;
}
var ms;
const Un = { value: void 0, enumerable: !1 };
let _s = "captureStackTrace" in Error ? Error : null;
function ja(e) {
  const t = _s;
  if (t) {
    const n = t.stackTraceLimit;
    if (typeof n == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return _s = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = n;
      }
    }
  }
  return new e();
}
function v(e, t, n, i) {
  const s = {};
  function r(m) {
    this.def = m, this.constr = l, this.traits = /* @__PURE__ */ new Set();
  }
  r.prototype = s;
  const o = n, a = o && /* @__PURE__ */ new WeakSet();
  function u(m, h) {
    if (m._zod) {
      if (m._zod.traits.has(e))
        return;
    } else {
      Un.value = new r(h);
      try {
        Object.defineProperty(m, "_zod", Un);
      } finally {
        Un.value = void 0;
      }
    }
    if (m._zod.traits.add(e), t(m, h), a) {
      const y = Object.getPrototypeOf(m), x = m._zod.constr.prototype;
      let k = y;
      for (; k && k !== x; )
        k = Object.getPrototypeOf(k);
      const N = k ?? y;
      a.has(N) || (a.add(N), Da(N, o));
    }
    const p = l.prototype;
    for (const y in p)
      Object.prototype.hasOwnProperty.call(p, y) && (y in m || (m[y] = p[y].bind(m)));
  }
  const c = i?.Parent ?? Object;
  class f extends c {
  }
  Object.defineProperty(f, "name", { value: e });
  function l(m) {
    const h = i?.Parent ? ja(f) : this;
    u(h, m);
    const p = h._zod.deferred;
    if (p) {
      for (const x of p)
        x();
      h._zod.deferred = void 0;
    }
    const y = globalThis.__zod_globalConfig?.postProcessor;
    return y && y(h), h;
  }
  return Object.defineProperty(l, "init", { value: u }), Object.defineProperty(l, Symbol.hasInstance, {
    value: (m) => i?.Parent && m instanceof i.Parent ? !0 : m?._zod?.traits?.has(e)
  }), Object.defineProperty(l, "name", { value: e }), l;
}
class Xe extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class kr extends Error {
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}
(ms = globalThis).__zod_globalConfig ?? (ms.__zod_globalConfig = {});
const le = globalThis.__zod_globalConfig;
function ve(e) {
  return e && Object.assign(le, e), le;
}
function Ua() {
  const e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, ui, 2)), e.message;
}
function Ba(e) {
  this._zod.message = e;
}
const qa = {
  get: Ua,
  set: Ba,
  enumerable: !0,
  configurable: !0
}, Bn = { value: void 0, enumerable: !1 }, gs = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), Ha = (e, t) => {
  e.name = "$ZodError", Bn.value = t, Object.defineProperty(e, "issues", Bn), Bn.value = void 0, Object.defineProperty(e, "message", qa);
  const n = Object.getPrototypeOf(e);
  gs.has(n) || (gs.add(n), Object.defineProperty(n, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      const i = () => this.message;
      return Object.defineProperty(this, "toString", { value: i, configurable: !0, writable: !0 }), i;
    },
    set(i) {
      Object.defineProperty(this, "toString", { value: i, configurable: !0, writable: !0 });
    }
  }));
}, Wa = v("$ZodError", Ha);
function Ka(e, t, n) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: n(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = n()), e[t];
}
function Va(e, t = (n) => n.message) {
  const n = {}, i = [];
  for (const s of e.issues)
    s.path.length > 0 ? Ka(n, s.path[0], () => []).push(t(s)) : i.push(t(s));
  return { formErrors: i, fieldErrors: n };
}
function Ja(e, t = (n) => n.message) {
  const n = { _errors: [] }, i = (s, r = []) => {
    for (const o of s.issues)
      if (o.code === "invalid_union" && o.errors.length)
        o.errors.map((a) => i({ issues: a }, [...r, ...o.path]));
      else if (o.code === "invalid_key")
        i({ issues: o.issues }, [...r, ...o.path]);
      else if (o.code === "invalid_element")
        i({ issues: o.issues }, [...r, ...o.path]);
      else {
        const a = [...r, ...o.path];
        if (a.length === 0)
          n._errors.push(t(o));
        else {
          let u = n, c = 0;
          for (; c < a.length; ) {
            const f = a[c], l = c === a.length - 1;
            if (f === "_errors") {
              l && u._errors.push(t(o)), c++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(u, f) || Object.defineProperty(u, f, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            const m = u[f];
            l && m._errors.push(t(o)), u = m, c++;
          }
        }
      }
  };
  return i(e), n;
}
function En(e, t) {
  return { callee: t?.callee ?? e, Err: t?.Err };
}
const Oi = (e) => {
  const t = (n, i, s, r) => {
    const o = s ? { ...s, async: !1 } : { async: !1 }, a = n._zod.run({ value: i, issues: [] }, o);
    if (a instanceof Promise)
      throw new Xe();
    if (a.issues.length) {
      const u = new (r?.Err ?? e)(a.issues.map((c) => Le(c, o, ve())));
      throw _r(u, r?.callee ?? t), u;
    }
    return a.value;
  };
  return t;
}, Ai = (e) => {
  const t = async (n, i, s, r) => {
    const o = s ? { ...s, async: !0 } : { async: !0 };
    let a = n._zod.run({ value: i, issues: [] }, o);
    if (a instanceof Promise && (a = await a), a.issues.length) {
      const u = new (r?.Err ?? e)(a.issues.map((c) => Le(c, o, ve())));
      throw _r(u, r?.callee ?? t), u;
    }
    return a.value;
  };
  return t;
}, Ni = (e) => (t, n, i) => {
  const s = i ? { ...i, async: !1 } : { async: !1 }, r = t._zod.run({ value: n, issues: [] }, s);
  if (r instanceof Promise)
    throw new Xe();
  return r.issues.length ? Sr(e, r.issues, s) : { success: !0, data: r.value };
};
function Sr(e, t, n) {
  let i;
  return {
    success: !1,
    get error() {
      return i || (i = new e(t.map((s) => Le(s, n, ve()))), t = void 0, n = void 0), i;
    },
    set error(s) {
      i = s, t = void 0, n = void 0;
    }
  };
}
const Ci = (e) => async (t, n, i) => {
  const s = i ? { ...i, async: !0 } : { async: !0 };
  let r = t._zod.run({ value: n, issues: [] }, s);
  return r instanceof Promise && (r = await r), r.issues.length ? Sr(e, r.issues, s) : { success: !0, data: r.value };
}, Xa = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), Ga = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), Ya = ((e, t, n) => {
  const i = e._zod.bag.validator;
  if (i !== void 0) {
    if (i(t) !== Xa)
      return !0;
    if (i.definite === !0 && n === void 0)
      return !1;
  }
  return Qa(e, t, n);
});
function Qa(e, t, n) {
  const i = n ? { ...n, async: !1, abortEarly: !0 } : { async: !1, abortEarly: !0 }, s = e._zod.bag.fallbackRun;
  let r;
  if (s ? (i[Ga] = !0, r = s({ value: t, issues: [] }, i)) : r = e._zod.run({ value: t, issues: [] }, i), r instanceof Promise)
    throw new Xe();
  return r.issues.length === 0;
}
const ec = async (e, t, n) => {
  const i = n ? { ...n, async: !0, abortEarly: !0 } : { async: !0, abortEarly: !0 };
  let s = e._zod.run({ value: t, issues: [] }, i);
  return s instanceof Promise && (s = await s), s.issues.length === 0;
}, tc = (e) => {
  const t = Oi(e), n = (i, s, r, o) => {
    const a = r ? { ...r, direction: "backward" } : { direction: "backward" };
    return t(i, s, a, En(n, o));
  };
  return n;
}, nc = (e) => {
  const t = Oi(e), n = (i, s, r, o) => t(i, s, r, En(n, o));
  return n;
}, ic = (e) => {
  const t = Ai(e), n = async (i, s, r, o) => {
    const a = r ? { ...r, direction: "backward" } : { direction: "backward" };
    return await t(i, s, a, En(n, o));
  };
  return n;
}, sc = (e) => {
  const t = Ai(e), n = async (i, s, r, o) => await t(i, s, r, En(n, o));
  return n;
}, rc = (e) => (t, n, i) => {
  const s = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Ni(e)(t, n, s);
}, oc = (e) => (t, n, i) => Ni(e)(t, n, i), ac = (e) => async (t, n, i) => {
  const s = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Ci(e)(t, n, s);
}, cc = (e) => async (t, n, i) => Ci(e)(t, n, i), uc = /^[cC][0-9a-z]{6,}$/, lc = /^[0-9a-z]+$/, dc = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, fc = /^[0-9a-vA-V]{20}$/, pc = /^[A-Za-z0-9]{27}$/, hc = /^[a-zA-Z0-9_-]{21}$/;
function mc(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
const _c = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, gc = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, vs = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, vc = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, bc = "^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function yc() {
  return new RegExp(bc, "u");
}
const wc = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, xc = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, kc = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, Sc = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, Ec = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, zc = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/, Ic = /^https?$/, Tc = /^\+[1-9]\d{6,14}$/, Er = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Oc(e) {
  return new RegExp(`^${e}$`);
}
const Ac = /* @__PURE__ */ Oc(Er);
function di(e) {
  const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function Nc(e) {
  return new RegExp(`^${di(e)}$`);
}
function Cc(e) {
  const t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${di({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, i = e.local ? `${n}|${di({ precision: e.precision })}` : n;
  return new RegExp(`^${Er}T(?:${i})$`);
}
const $c = /^[\s\S]{0,}$/, Dc = /^-?\d+$/, $i = /^-?\d+(?:\.\d+)?$/, Fc = /^(?:true|false)$/i, Rc = /^null$/i, Pc = /^[^A-Z]*$/, Zc = /^[^a-z]*$/, ie = /* @__PURE__ */ v("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), Di = (e) => {
  const t = e.value;
  return !_a(t) && t.length !== void 0;
}, gn = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, zr = /* @__PURE__ */ v("$ZodCheckLessThan", (e, t) => {
  ie.init(e, t);
  const n = gn[typeof t.value];
  e._zod.check = (i) => {
    (t.inclusive ? i.value <= t.value : i.value < t.value) || i.issues.push({
      origin: gn[typeof i.value] ?? n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Ir = /* @__PURE__ */ v("$ZodCheckGreaterThan", (e, t) => {
  ie.init(e, t);
  const n = gn[typeof t.value];
  e._zod.check = (i) => {
    (t.inclusive ? i.value >= t.value : i.value > t.value) || i.issues.push({
      origin: gn[typeof i.value] ?? n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Mc = /* @__PURE__ */ v("$ZodCheckMultipleOf", (e, t) => {
  ie.init(e, t), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && n.value % t.value === BigInt(0)
    ) : ga(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Lc = /* @__PURE__ */ v("$ZodCheckNumberFormat", (e, t) => {
  ie.init(e, t), t.format = t.format || "float64";
  const n = t.format?.includes("int"), i = n ? "int" : "number", [s, r] = br[t.format];
  e._zod.check = (o) => {
    const a = o.value;
    if (n) {
      if (!Number.isInteger(a)) {
        o.issues.push({
          expected: i,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: a,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(a)) {
        a > 0 ? o.issues.push({
          input: a,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        }) : o.issues.push({
          input: a,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    a < s && o.issues.push({
      origin: "number",
      input: a,
      code: "too_small",
      minimum: s,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), a > r && o.issues.push({
      origin: "number",
      input: a,
      code: "too_big",
      maximum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), jc = /* @__PURE__ */ v("$ZodCheckMaxLength", (e, t) => {
  var n;
  ie.init(e, t), (n = e._zod.def).when ?? (n.when = Di), e._zod.check = (i) => {
    const s = i.value, r = s.length;
    if ((typeof s == "string" && r > t.maximum ? Ii(s) : r) <= t.maximum)
      return;
    const a = Ti(s);
    i.issues.push({
      origin: a,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: s,
      inst: e,
      continue: !t.abort
    });
  };
}), Uc = /* @__PURE__ */ v("$ZodCheckMinLength", (e, t) => {
  var n;
  ie.init(e, t), (n = e._zod.def).when ?? (n.when = Di), e._zod.check = (i) => {
    const s = i.value, r = s.length;
    if ((typeof s == "string" && r >= t.minimum && r < t.minimum * 2 ? Ii(s) : r) >= t.minimum)
      return;
    const a = Ti(s);
    i.issues.push({
      origin: a,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: s,
      inst: e,
      continue: !t.abort
    });
  };
}), Bc = /* @__PURE__ */ v("$ZodCheckLengthEquals", (e, t) => {
  var n;
  ie.init(e, t), (n = e._zod.def).when ?? (n.when = Di), e._zod.check = (i) => {
    const s = i.value, r = s.length, o = typeof s == "string" && r >= t.length && r <= t.length * 2 ? Ii(s) : r;
    if (o === t.length)
      return;
    const a = Ti(s), u = o > t.length;
    i.issues.push({
      origin: a,
      ...u ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), zn = /* @__PURE__ */ v("$ZodCheckStringFormat", (e, t) => {
  var n, i;
  ie.init(e, t), t.pattern ? (n = e._zod).check ?? (n.check = (s) => {
    t.pattern.lastIndex = 0, !t.pattern.test(s.value) && s.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: s.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (i = e._zod).check ?? (i.check = () => {
  });
}), qc = /* @__PURE__ */ v("$ZodCheckRegex", (e, t) => {
  zn.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), Hc = /* @__PURE__ */ v("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = Pc), zn.init(e, t);
}), Wc = /* @__PURE__ */ v("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = Zc), zn.init(e, t);
}), Kc = /* @__PURE__ */ v("$ZodCheckIncludes", (e, t) => {
  ie.init(e, t);
  const n = ht(t.includes), i = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
  t.pattern = i, e._zod.check = (s) => {
    s.value.includes(t.includes, t.position) || s.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: s.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Vc = /* @__PURE__ */ v("$ZodCheckStartsWith", (e, t) => {
  ie.init(e, t);
  const n = new RegExp(`^${ht(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.check = (i) => {
    i.value.startsWith(t.prefix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Jc = /* @__PURE__ */ v("$ZodCheckEndsWith", (e, t) => {
  ie.init(e, t);
  const n = new RegExp(`.*${ht(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.check = (i) => {
    i.value.endsWith(t.suffix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Xc = /* @__PURE__ */ v("$ZodCheckOverwrite", (e, t) => {
  ie.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});
class Gc {
  constructor(t = [], n = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = n;
  }
  // the compiler catches a child's throw and keeps writing into this doc, so the indent has to unwind with it
  indented(t) {
    this.indent += 1;
    try {
      t(this);
    } finally {
      this.indent -= 1;
    }
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    const i = t.split(`
`).filter((o) => o), s = Math.min(...i.map((o) => o.length - o.trimStart().length)), r = i.map((o) => o.slice(s)).map((o) => " ".repeat(this.indent * 2) + o);
    for (const o of r)
      this.content.push(o);
  }
  compile() {
    const t = Function, n = this?.content ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${n.join(`
`)}
};`)(...Object.values(this.closed));
  }
}
const Yc = {
  major: 4,
  minor: 6,
  patch: 7
}, M = /* @__PURE__ */ v("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Yc;
  const i = e._zod.def.checks, s = e._zod.traits.has("$ZodCheck") ? [e, ...i ?? []] : i?.length ? [...i] : [];
  for (const r of s)
    for (const o of r._zod.onattach)
      o(e);
  if (s.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    const r = (a, u, c) => {
      if (a.memo)
        return a;
      let f = me(a), l;
      for (const m of u) {
        if (m._zod.def.when) {
          if (Na(a) || !m._zod.def.when(a))
            continue;
        } else if (f)
          continue;
        const h = a.issues.length, p = m._zod.check(a);
        if (p instanceof Promise && c?.async === !1)
          throw new Xe();
        if (l || p instanceof Promise)
          l = (l ?? Promise.resolve()).then(async () => {
            await p, a.issues.length !== h && (li(a.issues, h, e), f || (f = me(a, h)));
          });
        else {
          if (a.issues.length === h)
            continue;
          li(a.issues, h, e), f || (f = me(a, h));
        }
      }
      return l ? l.then(() => a) : a;
    }, o = (a, u, c) => {
      if (me(a))
        return a.aborted = !0, a;
      const f = r(u, s, c);
      if (f instanceof Promise) {
        if (c.async === !1)
          throw new Xe();
        return f.then((l) => e._zod.parse(l, c));
      }
      return e._zod.parse(f, c);
    };
    e._zod.run = (a, u) => {
      if (u.skipChecks)
        return e._zod.parse(a, u);
      if (u.direction === "backward") {
        const f = e._zod.parse({ value: a.value, issues: [] }, { ...u, skipChecks: !0 });
        return f instanceof Promise ? f.then((l) => o(l, a, u)) : o(f, a, u);
      }
      const c = e._zod.parse(a, u);
      if (c instanceof Promise) {
        if (u.async === !1)
          throw new Xe();
        return c.then((f) => r(f, s, u));
      }
      return r(c, s, u);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return wr(this, "~standard", Or(this));
  },
  set "~standard"(e) {
    je(this, "~standard", e);
  }
}), Tr = (e, t) => e.issues.length ? { issues: e.issues.map((n) => Le(n, t, ve())) } : { value: e.value };
async function Qc(e, t) {
  const n = { async: !0 };
  return Tr(await e._zod.run({ value: t, issues: [] }, n), n);
}
function Or(e) {
  return {
    validate: (t) => {
      const n = { async: !1 };
      try {
        const i = e._zod.run({ value: t, issues: [] }, n);
        if (!(i instanceof Promise))
          return Tr(i, n);
      } catch {
      }
      return Qc(e, t);
    },
    vendor: "zod",
    version: 1
  };
}
const Fi = /* @__PURE__ */ v("$ZodString", (e, t) => {
  M.init(e, t), e._zod.pattern = t.pattern ?? $c, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), q = /* @__PURE__ */ v("$ZodStringFormat", (e, t) => {
  zn.init(e, t), Fi.init(e, t);
}), eu = /* @__PURE__ */ v("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = gc), q.init(e, t);
}), tu = /* @__PURE__ */ v("$ZodUUID", (e, t) => {
  if (t.version) {
    const i = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (i === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = vs(i));
  } else
    t.pattern ?? (t.pattern = vs());
  q.init(e, t);
}), nu = /* @__PURE__ */ v("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = vc), q.init(e, t);
}), Ar = 1, vn = 2;
function Nr(e) {
  try {
    return typeof URL < "u" && typeof URL.canParse == "function" ? URL.canParse(e) : (new URL(e), !0);
  } catch {
    return !1;
  }
}
function iu(e, t) {
  return !("normalize" in t) && !("hostname" in t) && !("protocol" in t) ? Nr(e) || vn : su(e, t);
}
function su(e, t) {
  if (!t.normalize && t.protocol?.source === Ic.source && !/^https?:\/\//i.test(e))
    return Ar;
  try {
    if (typeof URL < "u") {
      const n = URL;
      if (typeof n.parse == "function")
        return n.parse(e) ?? vn;
    }
    return new URL(e);
  } catch {
    return vn;
  }
}
const ru = /[\t\n\r]/g;
function bs(e) {
  return e.replace(ru, "");
}
function ou(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
function au(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
const cu = /* @__PURE__ */ v("$ZodURL", (e, t) => {
  q.init(e, t), e._zod.check = (n) => {
    try {
      const i = n.value.trim(), s = iu(i, t);
      if (s === Ar) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (s === vn) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (s === !0) {
        n.value = bs(i);
        return;
      }
      t.hostname && !ou(s, t.hostname) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !au(s, t.protocol) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), n.value = t.normalize ? s.href : bs(i);
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), uu = /* @__PURE__ */ v("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = yc()), q.init(e, t);
}), lu = /* @__PURE__ */ v("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? hc : mc(t.length)), q.init(e, t);
}), du = /* @__PURE__ */ v("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = uc), q.init(e, t);
}), fu = /* @__PURE__ */ v("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = lc), q.init(e, t);
}), pu = /* @__PURE__ */ v("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = dc), q.init(e, t);
}), hu = /* @__PURE__ */ v("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = fc), q.init(e, t);
}), mu = /* @__PURE__ */ v("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = pc), q.init(e, t);
}), _u = /* @__PURE__ */ v("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Cc(t)), q.init(e, t);
}), gu = /* @__PURE__ */ v("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Ac), q.init(e, t);
}), vu = /* @__PURE__ */ v("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Nc(t)), q.init(e, t);
}), bu = /* @__PURE__ */ v("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = _c), q.init(e, t);
}), yu = /* @__PURE__ */ v("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = wc), q.init(e, t);
}), wu = /^[0-9a-fA-F:.]+$/;
function Cr(e) {
  return wu.test(e) ? Nr(`http://[${e}]`) : !1;
}
const xu = /* @__PURE__ */ v("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = xc), q.init(e, t), e._zod.check = (n) => {
    Cr(n.value) || n.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), ku = /* @__PURE__ */ v("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = kc), q.init(e, t);
});
function Su(e) {
  const t = e.split("/");
  if (t.length !== 2)
    return !1;
  const [n, i] = t;
  if (!i)
    return !1;
  const s = Number(i);
  return `${s}` !== i || s < 0 || s > 128 ? !1 : Cr(n);
}
const Eu = /* @__PURE__ */ v("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = Sc), q.init(e, t), e._zod.check = (n) => {
    Su(n.value) || n.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function $r(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
const Dr = /^[0-9a-zA-Z+/]*={0,2}$/, zu = /* @__PURE__ */ v("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Dr), q.init(e, t), e._zod.check = (n) => {
    $r(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ri = /^[A-Za-z0-9_-]*$/;
function Iu(e) {
  if (!Ri.test(e))
    return !1;
  const t = e.replace(/[-_]/g, (i) => i === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return $r(n);
}
const Tu = /* @__PURE__ */ v("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = Ri), q.init(e, t), e._zod.check = (n) => {
    Iu(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ou = /* @__PURE__ */ v("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Tc), q.init(e, t);
});
function Au(e, t = null) {
  try {
    const n = e.split(".");
    if (n.length !== 3)
      return !1;
    const [i] = n;
    if (!i)
      return !1;
    const s = JSON.parse(atob(i));
    return !("typ" in s && s?.typ !== "JWT" || !s.alg || t && (!("alg" in s) || s.alg !== t));
  } catch {
    return !1;
  }
}
const Nu = /* @__PURE__ */ v("$ZodJWT", (e, t) => {
  q.init(e, t), e._zod.check = (n) => {
    Au(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Fr = /* @__PURE__ */ v("$ZodNumber", (e, t) => {
  M.init(e, t), e._zod.pattern = $i, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    const s = n.value;
    if (typeof s == "number" && !Number.isNaN(s) && Number.isFinite(s))
      return n;
    const r = typeof s == "number" ? Number.isNaN(s) ? "NaN" : Number.isFinite(s) ? void 0 : String(s) : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: s,
      inst: e,
      ...r ? { received: r } : {}
    }), n;
  };
}), Cu = /* @__PURE__ */ v("$ZodNumberFormat", (e, t) => {
  Lc.init(e, t), Fr.init(e, t);
}), $u = /* @__PURE__ */ v("$ZodBoolean", (e, t) => {
  M.init(e, t), e._zod.pattern = Fc, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    const s = n.value;
    return typeof s == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: s,
      inst: e
    }), n;
  };
}), Du = /* @__PURE__ */ v("$ZodNull", (e, t) => {
  M.init(e, t), e._zod.pattern = Rc, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, i) => {
    const s = n.value;
    return s === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: s,
      inst: e
    }), n;
  };
}), Fu = /* @__PURE__ */ v("$ZodUnknown", (e, t) => {
  M.init(e, t), e._zod.parse = (n) => n;
}), Ru = /* @__PURE__ */ v("$ZodNever", (e, t) => {
  M.init(e, t), e._zod.parse = (n, i) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
});
function Pu(e, t) {
  const n = hs(e._zod.def.checks);
  if (!n.length)
    return;
  const i = Math.min(...n.map((r) => r[0])), s = e._zod.parse;
  e._zod.parse = (r, o) => {
    const a = t(r.value);
    if (a > i && !o?.skipChecks && o?.direction !== "backward") {
      for (const [u, c] of hs(e._zod.def.checks))
        if (a > u && c._zod.def.when(r)) {
          const f = r.issues.length;
          return c._zod.check(r), r.issues[f].continue = !1, li(r.issues, f, e), r;
        }
    }
    return s(r, o);
  };
}
const Zu = (e) => Array.isArray(e) ? e.length : -1;
function ys(e, t, n) {
  e.issues.length && t.issues.push(...Pe(n, e.issues)), t.value[n] = e.value;
}
const Mu = /* @__PURE__ */ v("$ZodArray", (e, t) => {
  M.init(e, t);
  const n = le.memoizer;
  n?.attach(e), e._zod.parse = (i, s) => {
    const r = i.value;
    if (!Array.isArray(r))
      return i.issues.push({
        expected: "array",
        code: "invalid_type",
        input: r,
        inst: e
      }), i;
    i.value = n ? n.alloc(e, i, Array(r.length), s) : Array(r.length);
    const o = [], a = s?.abortEarly;
    for (let u = 0; u < r.length; u++) {
      const c = r[u], f = t.element._zod.run({
        value: c,
        issues: []
      }, s);
      if (f instanceof Promise)
        o.push(f.then((l) => ys(l, i, u)));
      else if (ys(f, i, u), a && f.issues.length !== 0 && me(f))
        break;
    }
    return o.length ? Promise.all(o).then(() => i) : i;
  }, Pu(e, Zu);
});
function bn(e, t, n, i, s, r) {
  const o = n in i, a = r === "optional";
  if (!(!o && a && s === "optional")) {
    if (e.issues.length) {
      if (s !== void 0 && a && !o)
        return;
      t.issues.push(...Pe(n, e.issues));
    }
    if (!o && s === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [n]
      });
      return;
    }
    e.value === void 0 ? (o || s === "defaulted" && !a) && (t.value[n] = void 0) : t.value[n] = e.value;
  }
}
const Lu = [];
function Rr(e) {
  const t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), i = n.length ? n : Lu, s = i.length ? [...t, ...i] : t;
  for (const o of s)
    if (!e.shape?.[o]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(o)}": expected a Zod schema`);
  const r = ka(e.shape);
  return {
    ...e,
    allKeys: s,
    symbolKeys: i,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(r)
  };
}
function Pr(e, t, n, i, s, r, o) {
  const a = [], u = s.keySet, c = s.catchall._zod, f = c.def.type, l = c.optin, m = c.optout;
  let h = 0;
  for (const p in t) {
    if (o && n.issues.length !== h) {
      if (me(n, h))
        break;
      h = n.issues.length;
    }
    if (u.has(p))
      continue;
    if (p === "__proto__") {
      f === "never" && a.push(p);
      continue;
    }
    if (f === "never") {
      a.push(p);
      continue;
    }
    const y = c.run({ value: t[p], issues: [] }, i);
    y instanceof Promise ? e.push(y.then((x) => bn(x, n, p, t, l, m))) : bn(y, n, p, t, l, m);
  }
  return a.length && n.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: r,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => n) : n;
}
const ju = /* @__PURE__ */ v("$ZodObject", (e, t) => {
  M.init(e, t);
  const n = Object.getOwnPropertyDescriptor(t, "shape"), i = n?.get ? n.get.raw : t.shape ?? {};
  if (i) {
    const c = () => {
      const f = { ...i };
      return Object.defineProperty(t, "shape", { value: f }), c.raw = f, f;
    };
    c.raw = i, Object.defineProperty(t, "shape", { get: c });
  }
  const s = kn(() => Rr(t));
  R(e, "propValues", (c) => {
    const f = c.def.shape, l = {};
    for (const m in f) {
      const h = f[m]._zod;
      if (h.values) {
        Object.prototype.hasOwnProperty.call(l, m) || Ae(l, m, /* @__PURE__ */ new Set());
        for (const p of h.values)
          l[m].add(p);
        h.optin !== void 0 && l[m].add(void 0);
      }
    }
    return l;
  });
  const r = Zt, o = t.catchall;
  let a;
  const u = le.memoizer;
  u?.attach(e), e._zod.parse = (c, f) => {
    a ?? (a = s.value);
    const l = c.value;
    if (!r(l))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: l,
        inst: e
      }), c;
    c.value = u ? u.alloc(e, c, {}, f) : {};
    const m = [], h = a.shape, p = f?.abortEarly;
    let y = c.issues.length;
    for (const x of a.allKeys) {
      if (p && c.issues.length !== y) {
        if (me(c, y))
          break;
        y = c.issues.length;
      }
      if (x === "__proto__")
        continue;
      const k = h[x], N = k._zod.optin, L = k._zod.optout, se = k._zod.run({ value: l[x], issues: [] }, f);
      se instanceof Promise ? m.push(se.then((Z) => bn(Z, c, x, l, N, L))) : bn(se, c, x, l, N, L);
    }
    return o ? Pr(m, l, c, f, s.value, e, p === !0) : m.length ? Promise.all(m).then(() => c) : c;
  };
}), Uu = /* @__PURE__ */ v("$ZodObjectJIT", (e, t) => {
  ju.init(e, t);
  const n = e._zod.parse, i = kn(() => Rr(t)), s = le.memoizer, r = (h) => {
    const p = i.value, y = p.symbolKeys, x = new Gc(["payload", "ctx"], { shape: h, inst: e, memo: s, syms: y }), k = (Z) => `shape[${Z}]._zod.run({ value: input[${Z}], issues: [] }, ctx)`, N = (Z, F) => `
          let ${Z}_ab = false;
          for (let i = 0; i < ${Z}.issues.length; i++) {
            const iss = ${Z}.issues[i];
            iss.path = iss.path ? [${F}, ...iss.path] : [${F}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${Z}_ab = true;
          }
          if (${Z}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
    x.write("const input = payload.value;");
    const L = /* @__PURE__ */ Object.create(null);
    let se = 0;
    for (const Z of p.allKeys)
      L[Z] = `key_${se++}`;
    x.write(s ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (const Z of p.allKeys) {
      if (Z === "__proto__")
        continue;
      const F = L[Z], V = typeof Z == "symbol" ? `syms[${y.indexOf(Z)}]` : ba(Z), Ce = `${V} in input`, be = h[Z], Ee = be?._zod?.optin, J = Ee !== void 0, nt = be?._zod?.optout === "optional";
      if (x.write(`const ${F} = ${k(V)};`), J && nt) {
        const wt = Ee === "optional" ? `${F}_present` : `${F}.value !== undefined || ${F}_present`;
        x.write(`
        const ${F}_present = ${Ce};
        if (!${F}.issues.length || ${F}_present) {
          if (${F}.issues.length) {${N(F, V)}
          }

          if (${wt}) {
            newResult[${V}] = ${F}.value;
          }
        }

      `);
      } else J ? (x.write(`
        if (${F}.issues.length) {${N(F, V)}
        }
      `), Ee === "defaulted" ? x.write(`newResult[${V}] = ${F}.value;`) : x.write(`
        if (${F}.value !== undefined || ${Ce}) {
          newResult[${V}] = ${F}.value;
        }
      `)) : x.write(`
        const ${F}_present = ${Ce};
        if (${F}.issues.length) {${N(F, V)}
        }
        if (!${F}_present && !${F}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${V}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${F}_present) {
          newResult[${V}] = ${F}.value;
        }

      `);
    }
    return x.write("payload.value = newResult;"), x.write("return payload;"), x.compile();
  };
  let o;
  const a = Zt, u = !le.jitless, f = u && wa.value, l = t.catchall;
  let m;
  e._zod.parse = (h, p) => {
    m ?? (m = i.value);
    const y = h.value;
    return a(y) ? u && f && p?.async === !1 && p.jitless !== !0 ? (o || (o = r(t.shape)), h = o(h, p), l ? Pr([], y, h, p, m, e, p?.abortEarly === !0) : h) : n(h, p) : (h.issues.push({
      expected: "object",
      code: "invalid_type",
      input: y,
      inst: e
    }), h);
  };
});
function ws(e, t, n, i) {
  for (const r of e)
    if (r.issues.length === 0)
      return t.value = r.value, t;
  const s = e.filter((r) => !me(r));
  return s.length === 1 ? (t.value = s[0].value, s[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((r) => r.issues.map((o) => Le(o, i, ve())))
  }), t);
}
const Zr = /* @__PURE__ */ v("$ZodUnion", (e, t) => {
  M.init(e, t), R(e, "optin", (i) => i.def.options.some((s) => s._zod.optin === "defaulted") ? "defaulted" : i.def.options.some((s) => s._zod.optin !== void 0) ? "optional" : void 0), R(e, "optout", (i) => i.def.options.some((s) => s._zod.optout === "optional") ? "optional" : void 0), R(e, "values", (i) => {
    if (i.def.options.every((s) => s._zod.values))
      return new Set(i.def.options.flatMap((s) => Array.from(s._zod.values)));
  }), R(e, "pattern", (i) => {
    if (i.def.options.every((s) => s._zod.pattern)) {
      const s = i.def.options.map((r) => r._zod.pattern);
      return new RegExp(`^(${s.map((r) => Ei(r.source)).join("|")})$`);
    }
  });
  const n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (i, s) => {
    if (n)
      return n(i, s);
    let r = !1;
    const o = [];
    for (const a of t.options) {
      const u = a._zod.run({
        value: i.value,
        issues: []
      }, s);
      if (u instanceof Promise)
        o.push(u), r = !0;
      else {
        if (u.issues.length === 0)
          return u;
        o.push(u);
      }
    }
    return r ? Promise.all(o).then((a) => ws(a, i, e, s)) : ws(o, i, e, s);
  };
});
function Bu(e) {
  const t = /* @__PURE__ */ new Map();
  for (const n of e.options) {
    const i = n._zod.propValues?.[e.discriminator];
    if (!i || i.size === 0)
      throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(n)}"`);
    for (const s of i)
      if (t.has(s)) {
        if (s !== void 0)
          throw new Error(`Duplicate discriminator value "${String(s)}"`);
        t.set(s, null);
      } else
        t.set(s, n);
  }
  return t;
}
const qu = /* @__PURE__ */ v("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, Zr.init(e, t);
  const n = e._zod.parse;
  R(e, "propValues", (s) => {
    const r = {};
    let o = 0;
    for (const a of s.def.options) {
      const u = a._zod.propValues;
      if (!u || Object.keys(u).length === 0)
        throw new Error(`Invalid discriminated union option at index "${s.def.options.indexOf(a)}"`);
      u[s.def.discriminator]?.has(void 0) && o++;
      for (const [c, f] of Object.entries(u)) {
        Object.prototype.hasOwnProperty.call(r, c) || Ae(r, c, /* @__PURE__ */ new Set());
        for (const l of f)
          r[c].add(l);
      }
    }
    return !s.def.unionFallback && o > 1 && r[s.def.discriminator]?.delete(void 0), r;
  }), t.options.forEach((s, r) => {
    const o = zi(s._zod.def);
    if (o && !Object.prototype.hasOwnProperty.call(o, t.discriminator))
      throw new Error(`Invalid discriminated union option at index "${r}"`);
  });
  const i = kn(() => Bu(t));
  e._zod.parse = (s, r) => {
    const o = s.value;
    if (!Zt(o))
      return s.issues.push({
        code: "invalid_type",
        expected: "object",
        input: o,
        inst: e
      }), s;
    const a = o?.[t.discriminator], u = i.value.get(a);
    return u && (a !== void 0 || r.direction !== "backward") ? u._zod.run(s, r) : t.unionFallback || r.direction === "backward" ? n(s, r) : (s.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(i.value.keys()).filter((c) => i.value.get(c) !== null),
      input: o,
      path: [t.discriminator],
      inst: e
    }), s);
  };
}), Hu = /* @__PURE__ */ v("$ZodIntersection", (e, t) => {
  M.init(e, t), e._zod.parse = (n, i) => {
    const s = n.value, r = t.left._zod.run({ value: s, issues: [] }, i), o = t.right._zod.run({ value: s, issues: [] }, i);
    return r instanceof Promise || o instanceof Promise ? Promise.all([r, o]).then(([u, c]) => xs(n, u, c)) : xs(n, r, o);
  };
});
function fi(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (pt(e) && pt(t)) {
    const n = Object.keys(t), i = Object.keys(e).filter((r) => n.indexOf(r) !== -1), s = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(s, "__proto__") && delete s.__proto__;
    for (const r of i) {
      if (r === "__proto__")
        continue;
      const o = fi(e[r], t[r]);
      if (!o.valid)
        return {
          valid: !1,
          mergeErrorPath: [r, ...o.mergeErrorPath]
        };
      s[r] = o.data;
    }
    return { valid: !0, data: s };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    const n = [];
    for (let i = 0; i < e.length; i++) {
      const s = e[i], r = t[i], o = fi(s, r);
      if (!o.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...o.mergeErrorPath]
        };
      n.push(o.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function xs(e, t, n) {
  const i = /* @__PURE__ */ new Map();
  let s;
  const r = /* @__PURE__ */ new Map(), o = (c, f) => {
    let l;
    if (c.code === "unrecognized_keys" && !c.path?.length)
      s ?? (s = c), l = c.keys;
    else if (c.code === "invalid_key" && c.origin === "record" && c.path?.length === 1) {
      const m = String(c.path[0]);
      r.has(m) || r.set(m, c), l = [m];
    } else
      return !1;
    for (const m of l)
      i.has(m) || i.set(m, {}), i.get(m)[f] = !0;
    return !0;
  };
  for (const c of t.issues)
    o(c, "l") || e.issues.push(c);
  for (const c of n.issues)
    o(c, "r") || e.issues.push(c);
  const a = [...i].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (a.length) {
    const c = s ? a.filter((f) => s.keys.includes(f)) : [];
    c.length && e.issues.push({ ...s, keys: c });
    for (const f of a)
      !c.includes(f) && r.has(f) && e.issues.push(r.get(f));
  }
  const u = fi(t.value, n.value);
  if (!u.valid) {
    if (me(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(u.mergeErrorPath)}`);
  }
  return e.value = u.data, e;
}
const Wu = /* @__PURE__ */ v("$ZodTuple", (e, t) => {
  M.init(e, t);
  const n = t.items, i = le.memoizer;
  i?.attach(e), e._zod.parse = (s, r) => {
    const o = s.value;
    if (!Array.isArray(o))
      return s.issues.push({
        input: o,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), s;
    s.value = i ? i.alloc(e, s, [], r) : [];
    const a = [], u = ks(n, "optin"), c = ks(n, "optout");
    if (!t.rest) {
      if (o.length < u)
        return s.issues.push({
          code: "too_small",
          minimum: u,
          inclusive: !0,
          input: o,
          inst: e,
          origin: "array"
        }), s;
      o.length > n.length && s.issues.push({
        code: "too_big",
        maximum: n.length,
        inclusive: !0,
        input: o,
        inst: e,
        origin: "array"
      });
    }
    const f = new Array(n.length), l = t.rest ? r?.abortEarly : void 0;
    let m = !1;
    for (let h = 0; h < n.length; h++) {
      const p = n[h]._zod.run({ value: o[h], issues: [] }, r);
      p instanceof Promise ? a.push(p.then((y) => {
        f[h] = y;
      })) : (f[h] = p, l && !m && p.issues.length && (m = me(p)));
    }
    if (t.rest && !m) {
      let h = n.length - 1;
      const p = o.slice(n.length);
      let y = s.issues.length;
      for (const x of p) {
        if (l && s.issues.length !== y) {
          if (me(s, y))
            break;
          y = s.issues.length;
        }
        h++;
        const k = t.rest._zod.run({ value: x, issues: [] }, r);
        k instanceof Promise ? a.push(k.then((N) => Ss(N, s, h))) : Ss(k, s, h);
      }
    }
    return a.length ? Promise.all(a).then(() => Es(f, s, n, o, c)) : Es(f, s, n, o, c);
  };
});
function ks(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional"))
      return n + 1;
  return 0;
}
function Ss(e, t, n) {
  e.issues.length && t.issues.push(...Pe(n, e.issues)), t.value[n] = e.value;
}
function Es(e, t, n, i, s) {
  for (let r = 0; r < n.length; r++) {
    const o = e[r], a = r < i.length;
    if (!a && r >= s && n[r]._zod.optin === "optional") {
      t.value.length = r;
      break;
    }
    if (o.issues.length) {
      if (!a && r >= s) {
        t.value.length = r;
        break;
      }
      t.issues.push(...Pe(r, o.issues));
    }
    t.value[r] = o.value;
  }
  for (let r = t.value.length - 1; r >= i.length && (n[r]._zod.optout === "optional" && t.value[r] === void 0); r--)
    t.value.length = r;
  return t;
}
const Ku = /* @__PURE__ */ v("$ZodRecord", (e, t) => {
  M.init(e, t);
  const n = le.memoizer;
  n?.attach(e), e._zod.parse = (i, s) => {
    const r = i.value;
    if (!pt(r))
      return i.issues.push({
        expected: "record",
        code: "invalid_type",
        input: r,
        inst: e
      }), i;
    const o = [], a = t.keyType._zod.values;
    if (a && !t.partial) {
      i.value = n ? n.alloc(e, i, {}, s) : {};
      const u = /* @__PURE__ */ new Set();
      for (const f of a)
        if (typeof f == "string" || typeof f == "number" || typeof f == "symbol") {
          if (u.add(typeof f == "number" ? f.toString() : f), f === "__proto__")
            continue;
          const l = t.keyType._zod.run({ value: f, issues: [] }, s);
          if (l instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (l.issues.length) {
            i.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: l.issues.map((p) => Le(p, s, ve())),
              input: f,
              path: [f],
              inst: e
            });
            continue;
          }
          const m = l.value;
          if (m === "__proto__")
            continue;
          const h = t.valueType._zod.run({ value: r[f], issues: [] }, s);
          h instanceof Promise ? o.push(h.then((p) => {
            p.issues.length && i.issues.push(...Pe(f, p.issues)), i.value[m] = p.value;
          })) : (h.issues.length && i.issues.push(...Pe(f, h.issues)), i.value[m] = h.value);
        }
      let c;
      for (const f in r)
        if (!u.has(f))
          if (t.mode === "loose") {
            if (f === "__proto__")
              continue;
            i.value[f] = r[f];
          } else
            c = c ?? [], c.push(f);
      c && c.length > 0 && i.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: c,
        continue: !0
      });
    } else {
      i.value = n ? n.alloc(e, i, {}, s) : {};
      let u;
      for (const c of Reflect.ownKeys(r)) {
        if (c === "__proto__" || !Object.prototype.propertyIsEnumerable.call(r, c))
          continue;
        let f = t.keyType._zod.run({ value: c, issues: [] }, s);
        if (f instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && $i.test(c) && f.issues.length) {
          const p = t.keyType._zod.run({ value: Number(c), issues: [] }, s);
          if (p instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          p.issues.length === 0 && (f = p);
        }
        if (f.issues.length) {
          t.mode === "loose" ? i.value[c] = r[c] : a ? (u = u ?? [], u.push(c)) : i.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: f.issues.map((p) => Le(p, s, ve())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        const m = f.value;
        if (m === "__proto__")
          continue;
        const h = t.valueType._zod.run({ value: r[c], issues: [] }, s);
        h instanceof Promise ? o.push(h.then((p) => {
          p.issues.length && i.issues.push(...Pe(c, p.issues)), i.value[m] = p.value;
        })) : (h.issues.length && i.issues.push(...Pe(c, h.issues)), i.value[m] = h.value);
      }
      u && u.length > 0 && i.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: u,
        continue: !0
      });
    }
    return o.length ? Promise.all(o).then(() => i) : i;
  };
}), Vu = /* @__PURE__ */ v("$ZodEnum", (e, t) => {
  M.init(e, t);
  const n = ci(t.entries), i = new Set(n);
  e._zod.values = i, R(e, "pattern", (s) => {
    const r = ci(s.def.entries).filter((o) => xa.has(typeof o));
    return new RegExp(r.length ? `^(${r.map((o) => ht(o.toString())).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (s, r) => {
    const o = s.value;
    return i.has(o) || s.issues.push({
      code: "invalid_value",
      values: n,
      input: o,
      inst: e
    }), s;
  };
}), Ju = /* @__PURE__ */ v("$ZodLiteral", (e, t) => {
  M.init(e, t);
  const n = new Set(t.values);
  e._zod.values = n, R(e, "pattern", (i) => {
    const s = i.def.values;
    return new RegExp(s.length ? `^(${s.map((r) => typeof r == "string" ? ht(r) : r ? ht(r.toString()) : String(r)).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (i, s) => {
    const r = i.value;
    return n.has(r) || i.issues.push({
      code: "invalid_value",
      values: t.values,
      input: r,
      inst: e
    }), i;
  };
}), Xu = /* @__PURE__ */ v("$ZodTransform", (e, t) => {
  M.init(e, t), e._zod.optin = "optional", le.memoizer?.guard(e), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new kr(e.constructor.name);
    const s = t.transform(n.value, n);
    if (i.async)
      return (s instanceof Promise ? s : Promise.resolve(s)).then((o) => (n.value = o, n));
    if (s instanceof Promise)
      throw new Xe();
    return n.value = s, n;
  };
});
function zs(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
const Mr = /* @__PURE__ */ v("$ZodOptional", (e, t) => {
  M.init(e, t), R(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", R(e, "values", (n) => {
    const i = n.def.innerType._zod.values;
    return i ? /* @__PURE__ */ new Set([...i, void 0]) : void 0;
  }), R(e, "pattern", (n) => {
    const i = n.def.innerType._zod.pattern;
    return i ? new RegExp(`^(${Ei(i.source)})?$`) : void 0;
  }), e._zod.parse = (n, i) => {
    if (n.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return n;
      const s = t.innerType._zod.run({ value: n.value, issues: [] }, i);
      return s instanceof Promise ? s.then((r) => zs(n, r)) : zs(n, s);
    }
    return t.innerType._zod.run(n, i);
  };
}), Gu = /* @__PURE__ */ v("$ZodExactOptional", (e, t) => {
  Mr.init(e, t), R(e, "values", (n) => n.def.innerType._zod.values), R(e, "pattern", (n) => n.def.innerType._zod.pattern), e._zod.parse = (n, i) => t.innerType._zod.run(n, i);
}), Yu = /* @__PURE__ */ v("$ZodNullable", (e, t) => {
  M.init(e, t), R(e, "optin", (n) => n.def.innerType._zod.optin), R(e, "optout", (n) => n.def.innerType._zod.optout), R(e, "pattern", (n) => {
    const i = n.def.innerType._zod.pattern;
    return i ? new RegExp(`^(${Ei(i.source)}|null)$`) : void 0;
  }), R(e, "values", (n) => n.def.innerType._zod.values ? /* @__PURE__ */ new Set([...n.def.innerType._zod.values, null]) : void 0), e._zod.parse = (n, i) => n.value === null ? n : t.innerType._zod.run(n, i);
}), Qu = /* @__PURE__ */ v("$ZodDefault", (e, t) => {
  M.init(e, t), e._zod.optin = "defaulted", R(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    const s = t.innerType._zod.run(n, i);
    return s instanceof Promise ? s.then((r) => Is(r, t)) : Is(s, t);
  };
});
function Is(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
const el = /* @__PURE__ */ v("$ZodPrefault", (e, t) => {
  M.init(e, t), e._zod.optin = "defaulted", R(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => (i.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, i));
}), tl = /* @__PURE__ */ v("$ZodNonOptional", (e, t) => {
  M.init(e, t), R(e, "values", (n) => {
    const i = n.def.innerType._zod.values;
    return i ? new Set([...i].filter((s) => s !== void 0)) : void 0;
  }), e._zod.parse = (n, i) => {
    const s = t.innerType._zod.run(n, i);
    return s instanceof Promise ? s.then((r) => Ts(r, e)) : Ts(s, e);
  };
});
function Ts(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
function Os(e, t, n, i) {
  return t.issues.length ? (e.value = n.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((s) => Le(s, i, ve()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
const nl = /* @__PURE__ */ v("$ZodCatch", (e, t) => {
  M.init(e, t), R(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), R(e, "optout", (n) => n.def.innerType._zod.optout), R(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    const s = t.innerType._zod.run({ value: n.value, issues: [] }, i);
    return s instanceof Promise ? s.then((r) => Os(n, r, t, i)) : Os(n, s, t, i);
  };
}), il = /* @__PURE__ */ v("$ZodPipe", (e, t) => {
  M.init(e, t), R(e, "values", (n) => n.def.in._zod.values), R(e, "optin", (n) => n.def.in._zod.optin), R(e, "optout", (n) => n.def.out._zod.optout), R(e, "propValues", (n) => n.def.in._zod.propValues), e._zod.parse = (n, i) => {
    if (i.direction === "backward") {
      const r = t.out._zod.run(n, i);
      return r instanceof Promise ? r.then((o) => sn(o, t.in, i)) : sn(r, t.in, i);
    }
    const s = t.in._zod.run(n, i);
    return s instanceof Promise ? s.then((r) => sn(r, t.out, i)) : sn(s, t.out, i);
  };
});
function sn(e, t, n) {
  return e.issues.some((i) => i.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
const sl = /* @__PURE__ */ v("$ZodReadonly", (e, t) => {
  M.init(e, t), R(e, "propValues", (n) => n.def.innerType._zod.propValues), R(e, "values", (n) => n.def.innerType._zod.values), R(e, "optin", (n) => n.def.innerType?._zod?.optin), R(e, "optout", (n) => n.def.innerType?._zod?.optout), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    const s = t.innerType._zod.run(n, i);
    return s instanceof Promise ? s.then(As) : As(s);
  };
});
function As(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
const rl = /* @__PURE__ */ v("$ZodCustom", (e, t) => {
  ie.init(e, t), M.init(e, t), e._zod.parse = (n, i) => n, e._zod.check = (n) => {
    const i = n.value, s = t.fn(i);
    if (s instanceof Promise)
      return s.then((r) => Ns(r, n, i, e));
    Ns(s, n, i, e);
  };
});
function Ns(e, t, n, i) {
  if (!e) {
    const s = {
      code: "custom",
      input: n,
      inst: i,
      // incorporates params.error into issue reporting
      path: [...i._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !i._zod.def.abort
      // params: inst._zod.def.params,
    };
    i._zod.def.params && (s.params = i._zod.def.params), t.issues.push(Mt(s));
  }
}
class ol extends Error {
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}
const pi = "~memo", Cs = [];
function Lr(e) {
  return e !== null && typeof e == "object";
}
function qn(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
const jr = /* @__PURE__ */ new WeakMap(), Ct = 0, pn = 1, Ft = 2;
function hn(e, t, n) {
  const i = jr.get(e);
  if (i !== void 0)
    return i ? Ft : Ct;
  if (t.has(e))
    return Ft;
  t.add(e);
  let s = Ct;
  const r = (f) => {
    if (s !== Ft && f?._zod) {
      const l = hn(f, t);
      l > s && (s = l);
    }
  }, o = (f, l) => {
    let m = Ct;
    for (const h of Reflect.ownKeys(f)) {
      const p = Object.getOwnPropertyDescriptor(f, h);
      if (!p.enumerable)
        continue;
      const y = p.get ? pn : p.value?._zod ? hn(p.value, t) : Ct;
      y > m && (m = y);
    }
    return m;
  }, a = (f) => {
    f > s && (s = f);
  }, u = e._zod.def;
  switch (u.type) {
    case "object": {
      const f = zi(u);
      a(f ? o(f) : pn), r(u.catchall);
      break;
    }
    case "array":
      r(u.element);
      break;
    case "tuple":
      for (const f of u.items)
        r(f);
      r(u.rest);
      break;
    case "record":
    case "map":
      r(u.keyType), r(u.valueType);
      break;
    case "set":
      r(u.valueType);
      break;
    case "union":
      for (const f of u.options)
        r(f);
      break;
    case "intersection":
      r(u.left), r(u.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      r(u.innerType);
      break;
    case "pipe":
      r(u.in), r(u.out);
      break;
    case "function":
      r(u.input), r(u.output);
      break;
    // `$ZodLazy` caches its inner on the def, so a resolved edge is followed exactly
    case "lazy": {
      const f = u._cachedInner ?? void 0;
      a(f ? hn(f, t) : pn);
      break;
    }
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (const f in u) {
        const l = Object.getOwnPropertyDescriptor(u, f);
        if (!l || l.get)
          continue;
        const m = l.value;
        if (!(!m || typeof m != "object")) {
          if (m._zod)
            r(m);
          else if (Array.isArray(m))
            for (const h of m)
              r(h);
        }
      }
  }
  return t.delete(e), al(e, s);
}
function al(e, t) {
  return t !== pn && jr.set(e, t === Ft), t;
}
function cl(e, t) {
  let n = e.buckets.get(t);
  return n || (n = /* @__PURE__ */ new WeakMap(), e.buckets.set(t, n)), n;
}
let rn;
const on = [], ul = {
  alloc(e, t, n) {
    const i = rn;
    if (!i)
      return n;
    rn = void 0;
    const s = { value: n, issues: null };
    return i.set(t.value, s), on.push(s), n;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const n = e._zod.parse, i = (s, r) => {
        if (r.direction !== "backward" && dl(r, s.value))
          throw new ol();
        return n(s, r);
      };
      e._zod.parse = i, e._zod.run === n && (e._zod.run = i);
    });
  },
  attach(e) {
    var t;
    let n, i = !1, s, r;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const o = e._zod.parse, a = (u, c) => {
        if (n === void 0) {
          const k = hn(e, /* @__PURE__ */ new Set());
          if (k === Ct)
            return e._zod.parse = o, e._zod.run === a && (e._zod.run = o), o(u, c);
          k === Ft || i ? n = !0 : i = !0;
        }
        const f = u.value;
        if (!Lr(f))
          return o(u, c);
        let l = c[pi];
        l || (l = { buckets: /* @__PURE__ */ new WeakMap(), backEdges: void 0 }, c[pi] = l);
        let m;
        s === c ? m = r : (m = cl(l, e), s = c, r = m);
        const h = m.get(f);
        if (h)
          return u.value = h.value, h.issues ? h.issues.length && u.issues.push(...qn(h.issues)) : (u.memo = !0, l.backEdges ?? (l.backEdges = /* @__PURE__ */ new WeakSet()), l.backEdges.add(h.value)), u;
        rn = m;
        const p = on.length, y = o(u, c);
        rn = void 0;
        const x = on.length > p ? on.pop() : void 0;
        return y instanceof Promise ? y.then((k) => (x && (x.issues = k.issues.length ? qn(k.issues) : Cs), k)) : (x && (x.issues = y.issues.length ? qn(y.issues) : Cs), y);
      };
      e._zod.parse = a, e._zod.run === o && (e._zod.run = a);
    });
  }
};
function ll() {
  return ul;
}
function dl(e, t) {
  const n = e[pi]?.backEdges;
  return n !== void 0 && Lr(t) && n.has(t);
}
const fl = () => {
  const e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  const n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    currency_code: "currency code",
    credit_card: "credit card number",
    iban: "IBAN",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function s(r, o) {
    return r === "number" && typeof o == "number" && !Number.isFinite(o) ? String(o) : i[r] ?? r;
  }
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        const o = s(r.expected), a = $a(r.input), u = s(a, r.input);
        return `Invalid input: expected ${o}, received ${u}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${vr(r.values[0])}` : `Invalid option: expected one of ${fs(r.values, "|")}`;
      case "too_big": {
        const o = r.exact ? "exactly " : r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Too big: expected ${r.origin ?? "value"} to have ${o}${r.maximum.toString()} ${a.unit ?? "elements"}` : `Too big: expected ${r.origin ?? "value"} to be ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        const o = r.exact ? "exactly " : r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Too small: expected ${r.origin} to have ${o}${r.minimum.toString()} ${a.unit}` : `Too small: expected ${r.origin} to be ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        const o = r;
        return o.format === "starts_with" ? `Invalid string: must start with "${o.prefix}"` : o.format === "ends_with" ? `Invalid string: must end with "${o.suffix}"` : o.format === "includes" ? `Invalid string: must include "${o.includes}"` : o.format === "regex" ? `Invalid string: must match pattern ${o.pattern}` : `Invalid ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${r.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${r.keys.length > 1 ? "s" : ""}: ${fs(r.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${r.origin}`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `Invalid discriminator value. Expected ${r.options.map((a) => `'${a}'`).join(" | ")}` : r.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${r.origin}`;
      default:
        return "Invalid input";
    }
  };
};
function pl() {
  return {
    localeError: fl()
  };
}
var $s;
class hl {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    const i = n[0];
    return this._map.set(t, i), i && typeof i == "object" && "id" in i && this._idmap.set(i.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    const n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    const n = t._zod.parent;
    if (n) {
      const i = { ...this.get(n) ?? {} };
      delete i.id;
      const s = { ...i, ...this._map.get(t) };
      return Object.keys(s).length ? s : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
}
function ml() {
  return new hl();
}
($s = globalThis).__zod_globalRegistry ?? ($s.__zod_globalRegistry = ml());
const $t = globalThis.__zod_globalRegistry;
function Ur(e) {
  return e.checks && (e.checks = [...e.checks]), e;
}
// @__NO_SIDE_EFFECTS__
function _l(e, t) {
  return new e(Ur({ type: "string", ...I(t) }));
}
// @__NO_SIDE_EFFECTS__
function gl(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function vl(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Br(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function bl(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function yl(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function wl(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function qr(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function xl(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function kl(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Sl(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function El(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function zl(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Il(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Tl(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ol(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Al(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Nl(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Cl(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function $l(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Dl(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Fl(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Rl(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Pl(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Hr(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Zl(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ml(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ll(e, t) {
  return new e(Ur({ type: "number", checks: [], ...I(t) }));
}
// @__NO_SIDE_EFFECTS__
function jl(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ul(e, t) {
  return new e({
    type: "boolean",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Bl(e, t) {
  return new e({
    type: "null",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function ql(e) {
  return new e({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function Hl(e, t) {
  return new e({
    type: "never",
    ...I(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ds(e, t) {
  return new zr({
    check: "less_than",
    ...I(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Hn(e, t) {
  return new zr({
    check: "less_than",
    ...I(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function Fs(e, t) {
  return new Ir({
    check: "greater_than",
    ...I(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Wn(e, t) {
  return new Ir({
    check: "greater_than",
    ...I(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function Rs(e, t) {
  return new Mc({
    check: "multiple_of",
    ...I(t),
    value: e
  });
}
// @__NO_SIDE_EFFECTS__
function Wr(e, t) {
  return new jc({
    check: "max_length",
    ...I(t),
    maximum: e
  });
}
// @__NO_SIDE_EFFECTS__
function yn(e, t) {
  return new Uc({
    check: "min_length",
    ...I(t),
    minimum: e
  });
}
// @__NO_SIDE_EFFECTS__
function Kr(e, t) {
  return new Bc({
    check: "length_equals",
    ...I(t),
    length: e
  });
}
// @__NO_SIDE_EFFECTS__
function Wl(e, t) {
  return new qc({
    check: "string_format",
    format: "regex",
    ...I(t),
    pattern: e
  });
}
// @__NO_SIDE_EFFECTS__
function Kl(e) {
  return new Hc({
    check: "string_format",
    format: "lowercase",
    ...I(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Vl(e) {
  return new Wc({
    check: "string_format",
    format: "uppercase",
    ...I(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Jl(e, t) {
  return new Kc({
    check: "string_format",
    format: "includes",
    ...I(t),
    includes: e
  });
}
// @__NO_SIDE_EFFECTS__
function Xl(e, t) {
  return new Vc({
    check: "string_format",
    format: "starts_with",
    ...I(t),
    prefix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Gl(e, t) {
  return new Jc({
    check: "string_format",
    format: "ends_with",
    ...I(t),
    suffix: e
  });
}
// @__NO_SIDE_EFFECTS__
function vt(e) {
  return new Xc({
    check: "overwrite",
    tx: e
  });
}
// @__NO_SIDE_EFFECTS__
function Yl(e) {
  return /* @__PURE__ */ vt((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function Ql() {
  return /* @__PURE__ */ vt((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function ed() {
  return /* @__PURE__ */ vt((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function td() {
  return /* @__PURE__ */ vt((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function nd() {
  return /* @__PURE__ */ vt((e) => ya(e));
}
// @__NO_SIDE_EFFECTS__
function id(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...I(n)
  });
}
// @__NO_SIDE_EFFECTS__
function sd(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...I(n)
  });
}
// @__NO_SIDE_EFFECTS__
function rd(e, t) {
  const n = /* @__PURE__ */ od((i) => (i.addIssue = (s) => {
    if (typeof s == "string")
      i.issues.push(Mt(s, i.value, n._zod.def));
    else {
      const r = s;
      r.fatal && (r.continue = !1), r.code ?? (r.code = "custom"), "input" in r || (r.input = i.value), r.inst ?? (r.inst = n), r.continue ?? (r.continue = !n._zod.def.abort), i.issues.push(Mt(r));
    }
  }, e(i.value, i)), t);
  return n;
}
// @__NO_SIDE_EFFECTS__
function od(e, t) {
  const n = new ie({
    check: "custom",
    ...I(t)
  });
  return n._zod.check = e, n;
}
function Rt(e, ...t) {
  for (const n of t)
    for (const i of Reflect.ownKeys(n))
      Object.prototype.propertyIsEnumerable.call(n, i) && Ae(e, i, n[i]);
  return e;
}
function Vr(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? $t,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
function Ue(e, t, n, i, s) {
  const r = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: i.path, message: s }) : t.unrepresentable;
  if (r === "any")
    return !1;
  if (r === void 0 || r === "throw")
    throw new Error(s);
  return Object.assign(n, r), !0;
}
function K(e, t, n = { path: [], schemaPath: [] }) {
  var i;
  const s = e._zod.def, r = t.seen.get(e);
  if (r)
    return r.count++, n.schemaPath.includes(e) && (r.cycle = n.path), r.schema;
  const o = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, o), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  const a = e._zod.toJSONSchema?.();
  if (a)
    o.schema = a;
  else {
    const f = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, o.schema, f);
    else {
      const m = o.schema, h = t.processors[s.type];
      if (!h)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${s.type}`);
      h(e, t, m, f);
    }
    const l = e._zod.parent;
    l && (o.ref || (o.ref = l), K(l, t, f), t.seen.get(l).isParent = !0);
  }
  const u = t.metadataRegistry.get(e);
  return u && Rt(o.schema, u), t.io === "input" && ee(e) && (delete o.schema.examples, delete o.schema.default), t.io === "input" && "_prefault" in o.schema && ((i = o.schema).default ?? (i.default = o.schema._prefault)), delete o.schema._prefault, t.seen.get(e).schema;
}
function Ps(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function Jr(e, t) {
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  const i = /* @__PURE__ */ new Map();
  for (const o of e.seen.entries()) {
    const a = e.metadataRegistry.get(o[0])?.id;
    if (a) {
      const u = i.get(a);
      if (u && u !== o[0])
        throw new Error(`Duplicate schema id "${a}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      i.set(a, o[0]);
    }
  }
  const s = (o) => {
    const a = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      const l = e.external.registry.get(o[0])?.id, m = e.external.uri ?? ((p) => p);
      if (l)
        return { ref: m(l) };
      const h = o[1].defId ?? o[1].schema.id ?? `schema${e.counter++}`;
      return o[1].defId = h, { defId: h, ref: `${m("__shared")}#/${a}/${Ps(h)}` };
    }
    const u = "#", c = `${u}/${a}/`;
    if (o[1] === n && !o[1].schema.id)
      return { ref: u };
    const f = o[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: f, ref: c + Ps(f) };
  }, r = (o) => {
    if (o[1].schema.$ref)
      return;
    const a = o[1], { ref: u, defId: c } = s(o);
    a.def = { ...a.schema }, c && (a.defId = c);
    const f = a.schema;
    for (const l in f)
      delete f[l];
    f.$ref = u;
  };
  if (e.cycles === "throw")
    for (const o of e.seen.entries()) {
      const a = o[1];
      if (a.cycle)
        throw new Error(`Cycle detected: #/${a.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const o of e.seen.entries()) {
    const a = o[1];
    if (t === o[0]) {
      r(o);
      continue;
    }
    if (e.external) {
      const c = e.external.registry.get(o[0])?.id;
      if (t !== o[0] && c) {
        r(o);
        continue;
      }
    }
    if (e.metadataRegistry.get(o[0])?.id) {
      r(o);
      continue;
    }
    if (a.cycle) {
      r(o);
      continue;
    }
    a.count > 1 && e.reused === "ref" && r(o);
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
function Xr(e) {
  const t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  const n = [];
  for (const i of t) {
    if (!i || typeof i != "object")
      return;
    Xr(i);
    const s = Object.keys(i);
    if (s.length !== 1 || s[0] !== "type")
      return;
    const r = i.type;
    for (const o of Array.isArray(r) ? r : [r]) {
      if (typeof o != "string")
        return;
      n.includes(o) || n.push(o);
    }
  }
  delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
const Gr = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), Zs = ["oneOf", "anyOf"];
function Ms(e) {
  const t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
function hi(e) {
  const t = [];
  for (const r of e) {
    if (typeof r != "object" || r.type !== "object")
      return null;
    for (const o in r)
      if (!Gr.has(o))
        return null;
    t.push(r);
  }
  const n = {}, i = /* @__PURE__ */ new Set();
  for (const r of t) {
    for (const o in r.properties) {
      if (Object.prototype.hasOwnProperty.call(n, o))
        continue;
      const a = [];
      for (const c of t) {
        const f = c.properties?.[o] ?? Ms(c);
        f != null && (a.some((l) => JSON.stringify(l) === JSON.stringify(f)) || a.push(f));
      }
      const u = a.length === 1 ? a[0] : hi(a) ?? { allOf: a };
      Ae(n, o, u);
    }
    for (const o of r.required ?? [])
      i.add(o);
  }
  const s = { type: "object", properties: n };
  if (i.size && (s.required = [...i]), t.every((r) => r.additionalProperties === !1))
    s.additionalProperties = !1;
  else {
    const r = [];
    for (const o of t) {
      const a = Ms(o);
      a && !r.some((u) => JSON.stringify(u) === JSON.stringify(a)) && r.push(a);
    }
    r.length === 1 ? s.additionalProperties = r[0] : r.length > 1 && (s.additionalProperties = { allOf: r });
  }
  return s;
}
function ad(e) {
  const t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (const s of Gr)
    if (s in e)
      return;
  const n = t.filter((s) => Zs.some((r) => Array.isArray(s[r])));
  let i = null;
  if (!n.length)
    i = hi(t);
  else {
    const s = n[0], r = Zs.find((u) => Array.isArray(s[u]));
    if (Object.keys(s).length !== 1)
      return;
    const o = t.filter((u) => u !== s), a = s[r].map((u) => hi([...o, u]));
    if (a.some((u) => !u))
      return;
    i = { [r]: a };
  }
  i && (delete e.allOf, Rt(e, i));
}
function Yr(e, t) {
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const i = (a) => {
    const u = e.seen.get(a);
    if (u.ref === null)
      return;
    const c = u.def ?? u.schema, f = { ...c }, l = u.ref;
    if (u.ref = null, l) {
      i(l);
      const h = e.seen.get(l), p = h.schema;
      if (p.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (c.allOf = c.allOf ?? [], c.allOf.push(p)) : Rt(c, p), Rt(c, f), a._zod.parent === l)
        for (const x in c)
          x === "$ref" || x === "allOf" || x in f || delete c[x];
      if (p.$ref && h.def)
        for (const x in c)
          x === "$ref" || x === "allOf" || x in h.def && JSON.stringify(c[x]) === JSON.stringify(h.def[x]) && delete c[x];
    }
    const m = a._zod.parent;
    if (m && m !== l) {
      i(m);
      const h = e.seen.get(m);
      if (h?.schema.$ref && (c.$ref = h.schema.$ref, h.def))
        for (const p in c)
          p === "$ref" || p === "allOf" || p in h.def && JSON.stringify(c[p]) === JSON.stringify(h.def[p]) && delete c[p];
    }
    e.override({
      zodSchema: a,
      jsonSchema: c,
      path: u.path ?? []
    });
  };
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (const a of [...e.seen.entries()].reverse())
      i(a[0]);
    if (e.target !== "openapi-3.0")
      for (const a of e.seen.entries())
        Xr(a[1].def ?? a[1].schema);
    for (const a of e.deferred)
      a();
    if (e.intersections.length) {
      const a = /* @__PURE__ */ new Map();
      for (const u of e.seen.values())
        for (const c of [u.schema, u.def]) {
          const f = c?.allOf;
          if (!Array.isArray(f))
            continue;
          const l = a.get(f);
          l ? l.push(c) : a.set(f, [c]);
        }
      for (const u of e.intersections)
        for (const c of a.get(u) ?? [])
          ad(c);
    }
  }
  const s = {};
  if (e.target === "draft-2020-12" ? s.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? s.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? s.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    const a = e.external.registry.get(t)?.id;
    if (!a)
      throw new Error("Schema is missing an `id` property");
    s.$id = e.external.uri(a);
  }
  Rt(s, n.defId ? n.schema : n.def ?? n.schema);
  const r = e.metadataRegistry.get(t)?.id;
  r !== void 0 && s.id === r && delete s.id;
  const o = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (const a of e.seen.entries()) {
      const u = a[1];
      u.def && u.defId && (u.def.id === u.defId && delete u.def.id, Ae(o, u.defId, u.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(o).length > 0 && (e.target === "draft-2020-12" ? s.$defs = o : s.definitions = o);
  try {
    const a = JSON.parse(JSON.stringify(s));
    return Object.defineProperty(a, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: wn(t, "input", e.processors),
          output: wn(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), a;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function ee(e, t) {
  const n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  const i = e._zod.def;
  if (i.type === "transform")
    return !0;
  if (i.type === "array")
    return ee(i.element, n);
  if (i.type === "set")
    return ee(i.valueType, n);
  if (i.type === "lazy")
    return ee(i.getter(), n);
  if (i.type === "promise" || i.type === "optional" || i.type === "nonoptional" || i.type === "nullable" || i.type === "readonly" || i.type === "default" || i.type === "prefault" || i.type === "catch")
    return ee(i.innerType, n);
  if (i.type === "intersection")
    return ee(i.left, n) || ee(i.right, n);
  if (i.type === "record" || i.type === "map")
    return ee(i.keyType, n) || ee(i.valueType, n);
  if (i.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : ee(i.in, n) || ee(i.out, n);
  if (i.type === "object") {
    for (const s in i.shape)
      if (ee(i.shape[s], n))
        return !0;
    return !1;
  }
  if (i.type === "union") {
    for (const s of i.options)
      if (ee(s, n))
        return !0;
    return !1;
  }
  if (i.type === "tuple") {
    for (const s of i.items)
      if (ee(s, n))
        return !0;
    return !!(i.rest && ee(i.rest, n));
  }
  return !1;
}
const cd = (e, t = {}) => (n) => {
  const i = Vr({ ...n, processors: t });
  return K(e, i), Jr(i, e), Yr(i, e);
}, wn = (e, t, n = {}) => (i) => {
  const { libraryOptions: s, target: r } = i ?? {}, o = Vr({ ...s ?? {}, target: r, io: t, processors: n });
  return K(e, o), Jr(o, e), Yr(o, e);
}, mt = (e, t, n) => {
  (e[t] === void 0 || n > e[t]) && (e[t] = n);
}, _t = (e, t, n) => {
  (e[t] === void 0 || n < e[t]) && (e[t] = n);
}, Ls = (e, t) => {
  mt(e, "minimum", t), _t(e, "maximum", t);
}, Qr = (e, t) => {
  e.multipleOf ?? (e.multipleOf = []), e.multipleOf.includes(t) || e.multipleOf.push(t);
}, eo = (e, t) => {
  e.patterns ?? (e.patterns = /* @__PURE__ */ new Set()), e.patterns.add(t);
}, to = (e, t) => {
  e.mime = e.mime ? e.mime.filter((n) => t.includes(n)) : [...t];
}, no = (e, t) => {
  e.format = t, t.includes("int") && (e.isInt = !0);
}, js = (e, t) => mt(e, "minimum", t.minimum), Us = (e, t) => _t(e, "maximum", t.maximum), Bs = (e) => (t, n) => {
  no(t, n.format);
  const [i, s] = e[n.format];
  mt(t, "minimum", i), _t(t, "maximum", s);
}, ud = {
  greater_than: (e, t) => mt(e, t.inclusive ? "minimum" : "exclusiveMinimum", t.value),
  less_than: (e, t) => _t(e, t.inclusive ? "maximum" : "exclusiveMaximum", t.value),
  multiple_of: (e, t) => Qr(e, t.value),
  number_format: Bs(br),
  bigint_format: Bs(Sa),
  min_length: js,
  max_length: Us,
  length_equals: (e, t) => Ls(e, t.length),
  min_size: js,
  max_size: Us,
  size_equals: (e, t) => Ls(e, t.size),
  string_format: (e, t) => {
    no(e, t.format), t.pattern && eo(e, t.pattern), (t.format === "base64" || t.format === "base64url") && (e.contentEncoding = t.format), (t.local || t.precision === -1) && (e.laxFormat = !0);
  },
  mime_type: (e, t) => to(e, t.mime)
};
function ue(e) {
  const t = {}, n = e._zod.def, i = e._zod.traits.has("$ZodCheck") ? [e, ...n.checks ?? []] : n.checks ?? [];
  for (const r of i)
    ud[r._zod.def.check]?.(t, r._zod.def);
  const s = e._zod.bag;
  s.minimum !== void 0 && mt(t, "minimum", s.minimum), s.exclusiveMinimum !== void 0 && mt(t, "exclusiveMinimum", s.exclusiveMinimum), s.maximum !== void 0 && _t(t, "maximum", s.maximum), s.exclusiveMaximum !== void 0 && _t(t, "exclusiveMaximum", s.exclusiveMaximum), s.multipleOf !== void 0 && Qr(t, s.multipleOf), s.format !== void 0 && (t.format ?? (t.format = s.format), s.format.includes("int") && (t.isInt = !0)), s.mime && to(t, s.mime);
  for (const r of s.patterns ?? [])
    eo(t, r);
  return t;
}
const ld = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, dd = /* @__PURE__ */ new Map([
  [Dr, Ec],
  [Ri, zc]
]), io = (e) => dd.get(e) ?? e, fd = (e, t, n, i) => {
  const s = n;
  s.type = "string";
  const { minimum: r, maximum: o, format: a, patterns: u, contentEncoding: c, laxFormat: f } = ue(e);
  if (typeof r == "number" && (s.minLength = r), typeof o == "number" && (s.maxLength = o), a && (s.format = ld[a] ?? a, s.format === "" && delete s.format, (a === "time" || f) && delete s.format), c && (s.contentEncoding = c), u && u.size > 0) {
    const l = [...u].map(io);
    l.length === 1 ? s.pattern = l[0].source : l.length > 1 && (s.allOf = [
      ...l.map((m) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: m.source
      }))
    ]);
  }
}, pd = (e, t, n, i) => {
  const s = n, { minimum: r, maximum: o, multipleOf: a, exclusiveMaximum: u, exclusiveMinimum: c, isInt: f } = ue(e);
  s.type = f ? "integer" : "number";
  const l = typeof c == "number" && c >= (r ?? Number.NEGATIVE_INFINITY), m = typeof u == "number" && u <= (o ?? Number.POSITIVE_INFINITY), h = t.target === "draft-04" || t.target === "openapi-3.0";
  if (l ? h ? (s.minimum = c, s.exclusiveMinimum = !0) : s.exclusiveMinimum = c : typeof r == "number" && (s.minimum = r), m ? h ? (s.maximum = u, s.exclusiveMaximum = !0) : s.exclusiveMaximum = u : typeof o == "number" && (s.maximum = o), a) {
    const p = /* @__PURE__ */ new Set();
    for (const k of a)
      Number.isFinite(k) && k !== 0 ? p.add(Math.abs(k)) : Ue(e, t, s, i, `A multipleOf divisor of ${k} cannot be represented in JSON Schema`);
    const [y, ...x] = p;
    y !== void 0 && (s.multipleOf = y), x.length && (s.allOf = [...s.allOf ?? [], ...x.map((k) => ({ multipleOf: k }))]);
  }
}, hd = (e, t, n, i) => {
  n.type = "boolean";
}, md = (e, t, n, i) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, _d = (e, t, n, i) => {
  n.not = {};
}, gd = (e, t, n, i) => {
}, vd = (e, t, n, i) => {
  const s = e._zod.def, r = ci(s.entries);
  if (r.length === 0) {
    n.not = {};
    return;
  }
  r.every((o) => typeof o == "number") && (n.type = "number"), r.every((o) => typeof o == "string") && (n.type = "string"), n.enum = r;
}, bd = (e, t, n, i) => {
  const s = e._zod.def;
  if (s.values.length === 0) {
    n.not = {};
    return;
  }
  const r = [];
  for (const o of s.values)
    if (o === void 0) {
      if (Ue(e, t, n, i, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof o == "bigint") {
      if (Ue(e, t, n, i, "BigInt literals cannot be represented in JSON Schema"))
        return;
      r.push(Number(o));
    } else
      r.push(o);
  if (r.length !== 0) if (r.length === 1) {
    const o = r[0];
    n.type = o === null ? "null" : typeof o, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [o] : n.const = o;
  } else
    r.every((o) => typeof o == "number") && (n.type = "number"), r.every((o) => typeof o == "string") && (n.type = "string"), r.every((o) => typeof o == "boolean") && (n.type = "boolean"), r.every((o) => o === null) && (n.type = "null"), n.enum = r;
}, yd = (e, t, n, i) => {
  Ue(e, t, n, i, "Custom types cannot be represented in JSON Schema");
}, wd = (e, t, n, i) => {
  Ue(e, t, n, i, "Transforms cannot be represented in JSON Schema");
}, xd = (e, t, n, i) => {
  const s = n, r = e._zod.def, { minimum: o, maximum: a } = ue(e);
  typeof o == "number" && (s.minItems = o), typeof a == "number" && (s.maxItems = a), s.type = "array", s.items = K(r.element, t, {
    ...i,
    path: [...i.path, "items"]
  });
};
function Lt(e) {
  const t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? Lt(t.out) : t.type === "catch" ? Lt(t.innerType) : e._zod.optin;
}
const kd = (e, t, n, i) => {
  const s = n, r = e._zod.def, o = r.shape;
  if (Object.getOwnPropertySymbols(o).length && Ue(e, t, s, i, "Symbol keys cannot be represented in JSON Schema"))
    return;
  s.type = "object", s.properties = {};
  for (const c in o)
    Ae(s.properties, c, K(o[c], t, {
      ...i,
      path: [...i.path, "properties", c]
    }));
  const u = [];
  for (const c of Object.keys(o)) {
    const f = r.shape[c];
    (t.io === "input" ? Lt(f) === void 0 : f._zod.optout === void 0) && u.push(c);
  }
  u.length > 0 && (s.required = u), r.catchall?._zod.def.type === "never" ? s.additionalProperties = !1 : r.catchall ? r.catchall && (s.additionalProperties = K(r.catchall, t, {
    ...i,
    path: [...i.path, "additionalProperties"]
  })) : t.io === "output" && (s.additionalProperties = !1);
}, Sd = (e, t, n, i) => {
  const s = e._zod.def, r = s.inclusive === !1, o = s.options.map((a, u) => K(a, t, {
    ...i,
    path: [...i.path, r ? "oneOf" : "anyOf", u]
  }));
  r ? n.oneOf = o : n.anyOf = o;
}, Ed = (e, t, n, i) => {
  const s = e._zod.def, r = K(s.left, t, {
    ...i,
    path: [...i.path, "allOf", 0]
  }), o = K(s.right, t, {
    ...i,
    path: [...i.path, "allOf", 1]
  }), a = (c) => "allOf" in c && Object.keys(c).length === 1, u = [
    ...a(r) ? r.allOf : [r],
    ...a(o) ? o.allOf : [o]
  ];
  n.allOf = u, t.intersections.push(u);
}, zd = (e, t, n, i) => {
  const s = n, r = e._zod.def;
  s.type = "array";
  const o = t.target === "draft-2020-12" ? "prefixItems" : "items", a = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", u = r.items.map((y, x) => K(y, t, {
    ...i,
    path: [...i.path, o, x]
  })), c = r.rest ? K(r.rest, t, {
    ...i,
    path: [...i.path, a, ...t.target === "openapi-3.0" ? [r.items.length] : []]
  }) : null;
  let f = r.items.length;
  for (; f > 0; ) {
    const y = r.items[f - 1];
    if (!(t.io === "input" ? Lt(y) !== void 0 : y._zod.optout === "optional"))
      break;
    f--;
  }
  const l = r.items.length, m = !r.rest;
  t.target === "draft-2020-12" ? (s.prefixItems = u, m ? s.items = !1 : c && (s.items = c), f > 0 && (s.minItems = f), m && (s.maxItems = l)) : t.target === "openapi-3.0" ? (s.items = {
    anyOf: u
  }, c && s.items.anyOf.push(c), f > 0 && (s.minItems = f), m && (s.maxItems = l)) : (s.items = u, m ? s.additionalItems = !1 : c && (s.additionalItems = c), f > 0 && (s.minItems = f), m && (s.maxItems = l));
  const { minimum: h, maximum: p } = ue(e);
  typeof h == "number" && (s.minItems = h), typeof p == "number" && (s.maxItems = p);
};
function mi(e, t, n) {
  if (t.$ref) {
    if (n.has(t))
      return t;
    n.add(t);
    const p = e.get(t)?.def;
    if (!p)
      return t;
    const y = mi(e, p, n);
    return y === p ? t : y;
  }
  for (const p of ["anyOf", "oneOf"]) {
    const y = t[p];
    if (!Array.isArray(y))
      continue;
    const x = y.map((k) => mi(e, k, n));
    x.some((k, N) => k !== y[N]) && (t = { ...t, [p]: x });
  }
  const i = Array.isArray(t.type) ? t.type : [t.type], s = !i.includes("string") && i.some((p) => p === "number" || p === "integer"), r = t.enum ?? (t.const !== void 0 ? [t.const] : void 0);
  if (!s && !r?.some((p) => typeof p == "number"))
    return t;
  const { minimum: o, maximum: a, exclusiveMinimum: u, exclusiveMaximum: c, multipleOf: f, format: l, id: m, ...h } = t;
  return h.enum ? h.enum = h.enum.map((p) => typeof p == "number" ? String(p) : p) : typeof h.const == "number" && (h.const = String(h.const)), s && (h.type = "string", r || (h.pattern = (i.includes("number") ? $i : Dc).source)), h;
}
const _i = /* @__PURE__ */ new WeakMap();
function Id(e) {
  const t = /* @__PURE__ */ new Map();
  for (const i of e.seen.values())
    i.def && !t.has(i.schema) && t.set(i.schema, i);
  const n = /* @__PURE__ */ new Map();
  for (const i of _i.get(e) ?? []) {
    const s = e.seen.get(i), r = (s?.def ?? s?.schema)?.propertyNames;
    if (!r || r === !0 || n.has(r))
      continue;
    const o = mi(t, r, /* @__PURE__ */ new Set());
    o !== r && n.set(r, o);
  }
  if (n.size)
    for (const i of e.seen.values())
      for (const s of [i.schema, i.def]) {
        const r = s && n.get(s.propertyNames);
        r && (s.propertyNames = r);
      }
}
const Td = (e, t, n, i) => {
  const s = n, r = e._zod.def;
  s.type = "object";
  const o = r.keyType, a = ue(o).patterns;
  if (r.mode === "loose" && a && a.size > 0) {
    const f = K(r.valueType, t, {
      ...i,
      path: [...i.path, "patternProperties", "*"]
    });
    s.patternProperties = {};
    for (const l of a)
      Ae(s.patternProperties, io(l).source, f);
  } else {
    if (t.target === "draft-07" || t.target === "draft-2020-12") {
      s.propertyNames = K(r.keyType, t, {
        ...i,
        path: [...i.path, "propertyNames"]
      });
      let f = _i.get(t);
      f || (f = [], _i.set(t, f), t.deferred.push(() => Id(t))), f.push(e);
    }
    s.additionalProperties = K(r.valueType, t, {
      ...i,
      path: [...i.path, "additionalProperties"]
    });
  }
  const u = o._zod.values, c = t.io === "input" && Lt(r.valueType) !== void 0;
  if (u && !r.partial && !c) {
    const f = [...u].filter((l) => typeof l == "string" || typeof l == "number");
    f.length > 0 && (s.required = f.map(String));
  }
}, Od = (e, t, n, i) => {
  const s = e._zod.def, r = K(s.innerType, t, i), o = t.seen.get(e);
  t.target === "openapi-3.0" ? (o.ref = s.innerType, n.nullable = !0) : n.anyOf = [r, { type: "null" }];
}, Ad = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
}, Pi = /* @__PURE__ */ Symbol();
function so(e, t, n, i, s) {
  let r = !1;
  const o = JSON.stringify(e, (a, u) => typeof u != "bigint" ? u : (r = !0, null));
  return r ? (Ue(t, n, i, s, "BigInt defaults cannot be represented in JSON Schema"), Pi) : JSON.parse(o);
}
const Nd = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
  const o = so(s.defaultValue, e, t, n, i);
  o !== Pi && (n.default = o);
}, Cd = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  if (r.ref = s.innerType, t.io !== "input")
    return;
  const o = so(s.defaultValue, e, t, n, i);
  o !== Pi && (n._prefault = o);
}, $d = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
  let o;
  try {
    o = s.catchValue(void 0);
  } catch {
    Ue(e, t, n, i, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  n.default = o;
}, Dd = (e, t, n, i) => {
  const s = e._zod.def, r = s.in._zod.traits.has("$ZodTransform"), o = t.io === "input" ? r ? s.out : s.in : s.out;
  K(o, t, i);
  const a = t.seen.get(e);
  a.ref = o;
}, Fd = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType, n.readOnly = !0;
}, ro = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
}, qs = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function an(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    get() {
      const i = n(this);
      return Object.defineProperty(this, t, { value: i, configurable: !0, writable: !0 }), i;
    },
    set(i) {
      Object.defineProperty(this, t, { value: i, configurable: !0, writable: !0 });
    }
  });
}
const Rd = (e, t) => {
  Wa.init(e, t), e.name = "ZodError";
  const n = Object.getPrototypeOf(e);
  qs.has(n) || (qs.add(n), an(n, "format", (i) => (s) => Ja(i, s)), an(n, "flatten", (i) => (s) => Va(i, s)), an(n, "addIssue", (i) => (s) => {
    i.issues.push(s), i.message = JSON.stringify(i.issues, ui, 2);
  }), an(n, "addIssues", (i) => (s) => {
    i.issues.push(...s), i.message = JSON.stringify(i.issues, ui, 2);
  }), Object.defineProperty(n, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, de = /* @__PURE__ */ v("ZodError", Rd, void 0, {
  Parent: Error
}), Pd = /* @__PURE__ */ Oi(de), Zd = /* @__PURE__ */ Ai(de), Md = /* @__PURE__ */ Ni(de), Ld = /* @__PURE__ */ Ci(de), jd = /* @__PURE__ */ tc(de), Ud = /* @__PURE__ */ nc(de), Bd = /* @__PURE__ */ ic(de), qd = /* @__PURE__ */ sc(de), Hd = /* @__PURE__ */ rc(de), Wd = /* @__PURE__ */ oc(de), Kd = /* @__PURE__ */ ac(de), Vd = /* @__PURE__ */ cc(de);
function Jd() {
  le.localeError || ve(pl());
}
function Bt() {
  le.memoizer || ve({ memoizer: ll() });
}
const B = /* @__PURE__ */ v("ZodType", (e, t) => (Jd(), M.init(e, t), e.def = t, e.type = t.type, e), {
  check(...e) {
    const t = this.def;
    return this.clone(oe(t, {
      checks: [
        ...t.checks ?? [],
        ...e.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, t) {
    return Be(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  refine(e, t) {
    return this.check(Hf(e, t));
  },
  superRefine(e, t) {
    return this.check(Wf(e, t));
  },
  overwrite(e) {
    return this.check(/* @__PURE__ */ vt(e));
  },
  optional() {
    return Vs(this);
  },
  exactOptional() {
    return Cf(this);
  },
  nullable() {
    return Js(this);
  },
  nullish() {
    return Vs(Js(this));
  },
  nonoptional(e) {
    return Zf(this, e);
  },
  array() {
    return A(this);
  },
  or(e) {
    return Ne([this, e]);
  },
  and(e) {
    return If(this, e);
  },
  transform(e) {
    return Xs(this, Nf(e));
  },
  default(e) {
    return Ff(this, e);
  },
  prefault(e) {
    return Pf(this, e);
  },
  catch(e) {
    return Lf(this, e);
  },
  pipe(e) {
    return Xs(this, e);
  },
  readonly() {
    return Bf(this);
  },
  describe(e) {
    const t = this.clone();
    return $t.add(t, { description: e }), t;
  },
  meta(...e) {
    if (e.length === 0)
      return $t.get(this);
    const t = this.clone();
    return $t.add(t, e[0]), t;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return wr(this, "~standard", {
      ...Or(this),
      jsonSchema: {
        input: wn(this, "input"),
        output: wn(this, "output")
      }
    });
  },
  set "~standard"(e) {
    je(this, "~standard", e);
  },
  parse: function e(t, n) {
    return Pd(this, t, n, { callee: e });
  },
  parseAsync: async function e(t, n) {
    return await Zd(this, t, n, { callee: e });
  },
  safeParse(e, t) {
    return Md(this, e, t);
  },
  async safeParseAsync(e, t) {
    return Ld(this, e, t);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    je(this, "spa", e);
  },
  validate(e, t) {
    return Ya(this, e, t);
  },
  validateAsync(e, t) {
    return ec(this, e, t);
  },
  encode: function e(t, n) {
    return jd(this, t, n, { callee: e });
  },
  decode: function e(t, n) {
    return Ud(this, t, n, { callee: e });
  },
  encodeAsync: async function e(t, n) {
    return await Bd(this, t, n, { callee: e });
  },
  decodeAsync: async function e(t, n) {
    return await qd(this, t, n, { callee: e });
  },
  safeEncode(e, t) {
    return Hd(this, e, t);
  },
  safeDecode(e, t) {
    return Wd(this, e, t);
  },
  async safeEncodeAsync(e, t) {
    return Kd(this, e, t);
  },
  async safeDecodeAsync(e, t) {
    return Vd(this, e, t);
  },
  toJSONSchema(e) {
    return cd(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return $t.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), oo = /* @__PURE__ */ v(
  "_ZodString",
  (e, t) => {
    Fi.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => fd(e, n, i);
  },
  /* @__PURE__ */ xr({
    format: (e) => ue(e).format ?? null,
    minLength: (e) => ue(e).minimum ?? null,
    maxLength: (e) => ue(e).maximum ?? null
  }, {
    regex(...e) {
      return this.check(/* @__PURE__ */ Wl(...e));
    },
    includes(...e) {
      return this.check(/* @__PURE__ */ Jl(...e));
    },
    startsWith(...e) {
      return this.check(/* @__PURE__ */ Xl(...e));
    },
    endsWith(...e) {
      return this.check(/* @__PURE__ */ Gl(...e));
    },
    min(...e) {
      return this.check(/* @__PURE__ */ yn(...e));
    },
    max(...e) {
      return this.check(/* @__PURE__ */ Wr(...e));
    },
    length(...e) {
      return this.check(/* @__PURE__ */ Kr(...e));
    },
    nonempty(...e) {
      return this.check(/* @__PURE__ */ yn(1, ...e));
    },
    lowercase(e) {
      return this.check(/* @__PURE__ */ Kl(e));
    },
    uppercase(e) {
      return this.check(/* @__PURE__ */ Vl(e));
    },
    trim() {
      return this.check(/* @__PURE__ */ Ql());
    },
    normalize(...e) {
      return this.check(/* @__PURE__ */ Yl(...e));
    },
    toLowerCase() {
      return this.check(/* @__PURE__ */ ed());
    },
    toUpperCase() {
      return this.check(/* @__PURE__ */ td());
    },
    slugify() {
      return this.check(/* @__PURE__ */ nd());
    }
  })
), Xd = /* @__PURE__ */ v("ZodString", (e, t) => {
  Fi.init(e, t), oo.init(e, t);
}, {
  email(e) {
    return this.check(/* @__PURE__ */ gl(ef, e));
  },
  url(e) {
    return this.check(/* @__PURE__ */ qr(co, e));
  },
  jwt(e) {
    return this.check(/* @__PURE__ */ Rl(gf, e));
  },
  emoji(e) {
    return this.check(/* @__PURE__ */ xl(nf, e));
  },
  guid(e) {
    return this.check(/* @__PURE__ */ vl(tf, e));
  },
  uuid(e) {
    return this.check(/* @__PURE__ */ Br(Dt, e));
  },
  uuidv4(e) {
    return this.check(/* @__PURE__ */ bl(Dt, e));
  },
  uuidv6(e) {
    return this.check(/* @__PURE__ */ yl(Dt, e));
  },
  uuidv7(e) {
    return this.check(/* @__PURE__ */ wl(Dt, e));
  },
  nanoid(e) {
    return this.check(/* @__PURE__ */ kl(sf, e));
  },
  cuid(e) {
    return this.check(/* @__PURE__ */ Sl(rf, e));
  },
  cuid2(e) {
    return this.check(/* @__PURE__ */ El(of, e));
  },
  ulid(e) {
    return this.check(/* @__PURE__ */ zl(af, e));
  },
  base64(e) {
    return this.check(/* @__PURE__ */ $l(hf, e));
  },
  base64url(e) {
    return this.check(/* @__PURE__ */ Dl(mf, e));
  },
  xid(e) {
    return this.check(/* @__PURE__ */ Il(cf, e));
  },
  ksuid(e) {
    return this.check(/* @__PURE__ */ Tl(uf, e));
  },
  ipv4(e) {
    return this.check(/* @__PURE__ */ Ol(lf, e));
  },
  ipv6(e) {
    return this.check(/* @__PURE__ */ Al(df, e));
  },
  cidrv4(e) {
    return this.check(/* @__PURE__ */ Nl(ff, e));
  },
  cidrv6(e) {
    return this.check(/* @__PURE__ */ Cl(pf, e));
  },
  e164(e) {
    return this.check(/* @__PURE__ */ Fl(_f, e));
  },
  datetime(e) {
    return this.check(/* @__PURE__ */ Pl(Gd, e));
  },
  date(e) {
    return this.check(/* @__PURE__ */ Hr(ao, e));
  },
  time(e) {
    return this.check(/* @__PURE__ */ Zl(Yd, e));
  },
  duration(e) {
    return this.check(/* @__PURE__ */ Ml(Qd, e));
  }
});
function S(e) {
  return /* @__PURE__ */ _l(Xd, e);
}
const H = /* @__PURE__ */ v("ZodStringFormat", (e, t) => {
  q.init(e, t), oo.init(e, t);
}), Gd = /* @__PURE__ */ v("ZodISODateTime", (e, t) => {
  _u.init(e, t), H.init(e, t);
}), ao = /* @__PURE__ */ v("ZodISODate", (e, t) => {
  gu.init(e, t), H.init(e, t);
}), Yd = /* @__PURE__ */ v("ZodISOTime", (e, t) => {
  vu.init(e, t), H.init(e, t);
}), Qd = /* @__PURE__ */ v("ZodISODuration", (e, t) => {
  bu.init(e, t), H.init(e, t);
}), ef = /* @__PURE__ */ v("ZodEmail", (e, t) => {
  nu.init(e, t), H.init(e, t);
}), tf = /* @__PURE__ */ v("ZodGUID", (e, t) => {
  eu.init(e, t), H.init(e, t);
}), Dt = /* @__PURE__ */ v("ZodUUID", (e, t) => {
  tu.init(e, t), H.init(e, t);
});
function Qe(e) {
  return /* @__PURE__ */ Br(Dt, e);
}
const co = /* @__PURE__ */ v("ZodURL", (e, t) => {
  cu.init(e, t), H.init(e, t);
});
function Ge(e) {
  return /* @__PURE__ */ qr(co, e);
}
const nf = /* @__PURE__ */ v("ZodEmoji", (e, t) => {
  uu.init(e, t), H.init(e, t);
}), sf = /* @__PURE__ */ v("ZodNanoID", (e, t) => {
  lu.init(e, t), H.init(e, t);
}), rf = /* @__PURE__ */ v("ZodCUID", (e, t) => {
  du.init(e, t), H.init(e, t);
}), of = /* @__PURE__ */ v("ZodCUID2", (e, t) => {
  fu.init(e, t), H.init(e, t);
}), af = /* @__PURE__ */ v("ZodULID", (e, t) => {
  pu.init(e, t), H.init(e, t);
}), cf = /* @__PURE__ */ v("ZodXID", (e, t) => {
  hu.init(e, t), H.init(e, t);
}), uf = /* @__PURE__ */ v("ZodKSUID", (e, t) => {
  mu.init(e, t), H.init(e, t);
}), lf = /* @__PURE__ */ v("ZodIPv4", (e, t) => {
  yu.init(e, t), H.init(e, t);
}), df = /* @__PURE__ */ v("ZodIPv6", (e, t) => {
  xu.init(e, t), H.init(e, t);
}), ff = /* @__PURE__ */ v("ZodCIDRv4", (e, t) => {
  ku.init(e, t), H.init(e, t);
}), pf = /* @__PURE__ */ v("ZodCIDRv6", (e, t) => {
  Eu.init(e, t), H.init(e, t);
}), hf = /* @__PURE__ */ v("ZodBase64", (e, t) => {
  zu.init(e, t), H.init(e, t);
}), mf = /* @__PURE__ */ v("ZodBase64URL", (e, t) => {
  Tu.init(e, t), H.init(e, t);
}), _f = /* @__PURE__ */ v("ZodE164", (e, t) => {
  Ou.init(e, t), H.init(e, t);
}), gf = /* @__PURE__ */ v("ZodJWT", (e, t) => {
  Nu.init(e, t), H.init(e, t);
}), uo = /* @__PURE__ */ v(
  "ZodNumber",
  (e, t) => {
    Fr.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => pd(e, n, i, s), e.isFinite = !0;
  },
  /* @__PURE__ */ xr({
    minValue: (e) => {
      const { minimum: t, exclusiveMinimum: n } = ue(e);
      return Math.max(t ?? Number.NEGATIVE_INFINITY, n ?? Number.NEGATIVE_INFINITY);
    },
    maxValue: (e) => {
      const { maximum: t, exclusiveMaximum: n } = ue(e);
      return Math.min(t ?? Number.POSITIVE_INFINITY, n ?? Number.POSITIVE_INFINITY);
    },
    isInt: (e) => {
      const { isInt: t, multipleOf: n } = ue(e);
      return !!t || !!n?.some(Number.isSafeInteger);
    },
    format: (e) => ue(e).format ?? null
  }, {
    gt(e, t) {
      return this.check(/* @__PURE__ */ Fs(e, t));
    },
    gte(e, t) {
      return this.check(/* @__PURE__ */ Wn(e, t));
    },
    min(e, t) {
      return this.check(/* @__PURE__ */ Wn(e, t));
    },
    lt(e, t) {
      return this.check(/* @__PURE__ */ Ds(e, t));
    },
    lte(e, t) {
      return this.check(/* @__PURE__ */ Hn(e, t));
    },
    max(e, t) {
      return this.check(/* @__PURE__ */ Hn(e, t));
    },
    int(e) {
      return this.check(Hs(e));
    },
    safe(e) {
      return this.check(Hs(e));
    },
    positive(e) {
      return this.check(/* @__PURE__ */ Fs(0, e));
    },
    nonnegative(e) {
      return this.check(/* @__PURE__ */ Wn(0, e));
    },
    negative(e) {
      return this.check(/* @__PURE__ */ Ds(0, e));
    },
    nonpositive(e) {
      return this.check(/* @__PURE__ */ Hn(0, e));
    },
    multipleOf(e, t) {
      return this.check(/* @__PURE__ */ Rs(e, t));
    },
    step(e, t) {
      return this.check(/* @__PURE__ */ Rs(e, t));
    },
    finite() {
      return this;
    }
  })
);
function D(e) {
  return /* @__PURE__ */ Ll(uo, e);
}
const vf = /* @__PURE__ */ v("ZodNumberFormat", (e, t) => {
  Cu.init(e, t), uo.init(e, t);
});
function Hs(e) {
  return /* @__PURE__ */ jl(vf, e);
}
const bf = /* @__PURE__ */ v("ZodBoolean", (e, t) => {
  $u.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => hd(e, n, i);
});
function Te(e) {
  return /* @__PURE__ */ Ul(bf, e);
}
const yf = /* @__PURE__ */ v("ZodNull", (e, t) => {
  Du.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => md(e, n, i);
});
function gi(e) {
  return /* @__PURE__ */ Bl(yf, e);
}
const wf = /* @__PURE__ */ v("ZodUnknown", (e, t) => {
  Fu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => gd();
});
function Ws() {
  return /* @__PURE__ */ ql(wf);
}
const xf = /* @__PURE__ */ v("ZodNever", (e, t) => {
  Ru.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => _d(e, n, i);
});
function lo(e) {
  return /* @__PURE__ */ Hl(xf, e);
}
const kf = /* @__PURE__ */ v("ZodArray", (e, t) => {
  Bt(), Mu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => xd(e, n, i, s), e.element = t.element;
}, {
  min(e, t) {
    return this.check(/* @__PURE__ */ yn(e, t));
  },
  nonempty(e) {
    return this.check(/* @__PURE__ */ yn(1, e));
  },
  max(e, t) {
    return this.check(/* @__PURE__ */ Wr(e, t));
  },
  length(e, t) {
    return this.check(/* @__PURE__ */ Kr(e, t));
  },
  unwrap() {
    return this.element;
  }
});
function A(e, t) {
  return /* @__PURE__ */ id(kf, e, t);
}
const Sf = /* @__PURE__ */ v("ZodObject", (e, t) => {
  Bt(), Uu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => kd(e, n, i, s), Za(e, "shape", (n) => n._zod.def.shape, !1);
}, {
  keyof() {
    return b(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone(oe(this._zod.def, { catchall: e }));
  },
  passthrough() {
    return this.clone(oe(this._zod.def, { catchall: Ws() }));
  },
  loose() {
    return this.clone(oe(this._zod.def, { catchall: Ws() }));
  },
  strict() {
    return this.clone(oe(this._zod.def, { catchall: lo() }));
  },
  strip() {
    return this.clone(oe(this._zod.def, { catchall: void 0 }));
  },
  extend(e) {
    return Ia(this, e);
  },
  safeExtend(e) {
    return Ta(this, e);
  },
  merge(e) {
    return Oa(this, e);
  },
  pick(e) {
    return Ea(this, e);
  },
  omit(e) {
    return za(this, e);
  },
  partial(...e) {
    return ps(Zi, this, e[0]);
  },
  exactPartial(...e) {
    return ps(po, this, e[0], "exactPartial");
  },
  required(...e) {
    return Aa(ho, this, e[0]);
  }
});
function w(e, t) {
  return new Sf({
    type: "object",
    shape: e,
    catchall: lo(),
    ...I(t)
  });
}
const fo = /* @__PURE__ */ v("ZodUnion", (e, t) => {
  Zr.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Sd(e, n, i, s), e.options = t.options;
});
function Ne(e, t) {
  return new fo({
    type: "union",
    options: e,
    ...I(t)
  });
}
const Ef = /* @__PURE__ */ v("ZodDiscriminatedUnion", (e, t) => {
  fo.init(e, t), qu.init(e, t);
});
function bt(e, t, n) {
  return new Ef({
    type: "union",
    options: t,
    discriminator: e,
    ...I(n)
  });
}
const zf = /* @__PURE__ */ v("ZodIntersection", (e, t) => {
  Hu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Ed(e, n, i, s);
});
function If(e, t) {
  return new zf({
    type: "intersection",
    left: e,
    right: t
  });
}
const Tf = /* @__PURE__ */ v("ZodTuple", (e, t) => {
  Bt(), Wu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => zd(e, n, i, s);
}, {
  rest(e) {
    return this.clone({
      ...this._zod.def,
      rest: e
    });
  },
  partial() {
    const e = this._zod.def;
    if (e.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...e,
      items: e.items.map((t) => new Zi({ type: "optional", innerType: t }))
    });
  }
});
function Ks(e, t, n) {
  const i = t instanceof M, s = i ? n : t, r = i ? t : null;
  return new Tf({
    type: "tuple",
    items: e,
    rest: r,
    ...I(s)
  });
}
const vi = /* @__PURE__ */ v("ZodRecord", (e, t) => {
  Bt(), Ku.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Td(e, n, i, s), e.keyType = t.keyType, e.valueType = t.valueType;
});
function ke(e, t, n) {
  return !t || !t._zod ? new vi({
    type: "record",
    keyType: S(),
    valueType: e,
    ...I(t)
  }) : new vi({
    type: "record",
    keyType: e,
    valueType: t,
    ...I(n)
  });
}
function Ze(e, t, n) {
  return new vi({
    type: "record",
    keyType: e,
    valueType: t,
    ...I(n),
    partial: !0
  });
}
const bi = /* @__PURE__ */ v("ZodEnum", (e, t) => {
  Vu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (i, s, r) => vd(e, i, s), e.enum = t.entries, e.options = [...e._zod.values];
  const n = new Set(Object.keys(t.entries));
  e.extract = (i, s) => {
    const r = {};
    for (const o of i)
      if (n.has(o))
        r[o] = t.entries[o];
      else
        throw new Error(`Key ${o} not found in enum`);
    return new bi({
      ...t,
      checks: [],
      ...I(s),
      entries: r
    });
  }, e.exclude = (i, s) => {
    const r = { ...t.entries };
    for (const o of i)
      if (n.has(o))
        delete r[o];
      else
        throw new Error(`Key ${o} not found in enum`);
    return new bi({
      ...t,
      checks: [],
      ...I(s),
      entries: r
    });
  };
});
function b(e, t) {
  const n = Array.isArray(e) ? Object.fromEntries(e.map((i) => [i, i])) : e;
  return new bi({
    type: "enum",
    entries: n,
    ...I(t)
  });
}
const Of = /* @__PURE__ */ v("ZodLiteral", (e, t) => {
  Ju.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => bd(e, n, i, s), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function E(e, t) {
  return new Of({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...I(t)
  });
}
const Af = /* @__PURE__ */ v("ZodTransform", (e, t) => {
  Bt(), Xu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => wd(e, n, i, s), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new kr(e.constructor.name);
    n.addIssue = (r) => {
      if (typeof r == "string")
        n.issues.push(Mt(r, n.value, t));
      else {
        const o = r;
        o.fatal && (o.continue = !1), o.code ?? (o.code = "custom"), "input" in o || (o.input = n.value), o.inst ?? (o.inst = e), n.issues.push(Mt(o));
      }
    };
    const s = t.transform(n.value, n);
    return s instanceof Promise ? s.then((r) => (n.value = r, n)) : (n.value = s, n);
  };
});
function Nf(e) {
  return new Af({
    type: "transform",
    transform: e
  });
}
const Zi = /* @__PURE__ */ v("ZodOptional", (e, t) => {
  Mr.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => ro(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Vs(e) {
  return new Zi({
    type: "optional",
    innerType: e
  });
}
const po = /* @__PURE__ */ v("ZodExactOptional", (e, t) => {
  Gu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => ro(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Cf(e) {
  return new po({
    type: "optional",
    innerType: e
  });
}
const $f = /* @__PURE__ */ v("ZodNullable", (e, t) => {
  Yu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Od(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Js(e) {
  return new $f({
    type: "nullable",
    innerType: e
  });
}
const Df = /* @__PURE__ */ v("ZodDefault", (e, t) => {
  Qu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Nd(e, n, i, s), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Ff(e, t) {
  return new Df({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : gr(t);
    }
  });
}
const Rf = /* @__PURE__ */ v("ZodPrefault", (e, t) => {
  el.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Cd(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Pf(e, t) {
  return new Rf({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : gr(t);
    }
  });
}
const ho = /* @__PURE__ */ v("ZodNonOptional", (e, t) => {
  tl.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Ad(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Zf(e, t) {
  return new ho({
    type: "nonoptional",
    innerType: e,
    ...I(t)
  });
}
const Mf = /* @__PURE__ */ v("ZodCatch", (e, t) => {
  nl.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => $d(e, n, i, s), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Lf(e, t) {
  return new Mf({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : La(t)
  });
}
const jf = /* @__PURE__ */ v("ZodPipe", (e, t) => {
  il.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Dd(e, n, i, s), e.in = t.in, e.out = t.out;
});
function Xs(e, t) {
  return new jf({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
const Uf = /* @__PURE__ */ v("ZodReadonly", (e, t) => {
  sl.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Fd(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Bf(e) {
  return new Uf({
    type: "readonly",
    innerType: e
  });
}
const qf = /* @__PURE__ */ v("ZodCustom", (e, t) => {
  rl.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => yd(e, n, i, s);
});
function Hf(e, t = {}) {
  return /* @__PURE__ */ sd(qf, e, t);
}
function Wf(e, t) {
  return /* @__PURE__ */ rd(e, t);
}
function In(e) {
  return /* @__PURE__ */ Hr(ao, e);
}
ve({ jitless: !0 });
const C = S().regex(/^(0|[1-9][0-9]{0,18})$/).refine(
  (e) => /^(0|[1-9][0-9]{0,18})$/.test(e) && BigInt(e) <= 9223372036854775807n,
  "Counter overflow"
), Tn = S().regex(/^(0|[1-9][0-9]*)(\.[0-9]{1,18})?$/).refine((e) => e.replace(".", "").length <= 38, "Decimal overflow"), _e = S().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/).refine(
  (e) => !Number.isNaN(Date.parse(e)) && new Date(e).toISOString() === e,
  "Invalid calendar instant"
), O = S().regex(/^[0-9a-f]{64}$/), j = S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/), Mi = S().max(96).regex(/^-?(0|[1-9][0-9]*)(\.[0-9]+)?(e[+-]?[0-9]{1,3})?$/).refine((e) => Number.isFinite(Number(e)), "Nonfinite quantity").refine(
  (e) => Number(e) !== 0 || /^-?0(\.0+)?(e[+-]?[0-9]{1,3})?$/.test(e),
  "Quantity underflow"
), Se = Mi.refine(
  (e) => Number(e) >= 0 && !Object.is(Number(e), -0),
  "Negative quantity"
), xn = b(["original", "ecologits"]), On = b([
  "build_default",
  "original",
  "ecologits"
]), yi = D().int().min(1).max(2147483647), lt = S().regex(/^[a-z][a-z0-9_-]{0,63}$/), mo = S().regex(/^[A-Za-z0-9][A-Za-z0-9._:/@+\-]{0,191}$/), qt = w({
  provider: lt,
  model_name: mo,
  workload: b(["text", "video"])
}), Li = w({
  strategy: E("original_engine")
}), ji = w({
  strategy: E("unavailable")
}), _o = w({
  strategy: E("upstream_provider_flagship"),
  profile: qt
}), Kf = bt("strategy", [
  _o,
  Li,
  ji
]), Vf = b([
  "nearest_record",
  "family_benchmark",
  "model_not_named",
  "model_not_in_library",
  // The highest version of the same family in the catalog, for a version not listed yet.
  "model_family_stand_in",
  // The highest version of the same variant (GPT Pro, Gemini Pro Image) for a variant not listed.
  "model_variant_stand_in",
  // The highest model of the same kind and vendor when the catalog has no record of the variant.
  "model_kind_stand_in"
]), Jf = bt("strategy", [
  w({
    strategy: E("upstream_profile"),
    profile: qt,
    basis: Vf
  }),
  Li,
  ji
]), go = w({
  policy_version: j,
  review_date: In(),
  provider_defaults: ke(lt, Kf),
  model_overrides: ke(j, Jf),
  /** A site without an identified provider may name one explicit benchmark profile. */
  unknown_provider: bt("strategy", [
    _o,
    Li,
    ji
  ])
}).superRefine((e, t) => {
  (Object.keys(e.provider_defaults).length > 64 || Object.keys(e.model_overrides).length > 4096) && t.addIssue({
    code: "custom",
    message: "Policy exceeds its entry limit"
  });
  for (const [n, i] of Object.entries(
    e.provider_defaults
  ))
    i.strategy === "upstream_provider_flagship" && i.profile.provider !== n && t.addIssue({
      code: "custom",
      message: "A provider flagship must belong to that provider",
      path: ["provider_defaults", n]
    });
}), Xf = w({
  schema_version: E("1.0.0"),
  review_date: In(),
  mapping_basis: E("consumer_to_api_assumption"),
  source: Ge(),
  bindings: ke(j, qt).refine(
    (e) => Object.keys(e).length <= 4096,
    "Too many mappings"
  )
}), cn = b([
  "chatgpt",
  "claude",
  "gemini",
  "perplexity",
  "notebooklm"
]), Ie = S().regex(/^(0|[1-9][0-9]{0,6})(\.[0-9]{1,9})?$/).refine((e) => Number(e) > 0, "Coefficient must be positive"), Gs = Ne([
  Ie,
  w({ min: Ie, max: Ie }).refine(
    (e) => Number(e.min) <= Number(e.max),
    "Range minimum exceeds its maximum"
  )
]), Gf = w({
  factor: Ie,
  tokenizer_profile_id: E("o200k-base-4.0.0-reference"),
  measured_on: In(),
  source: Ge()
}), Ys = w({
  width: D().int().min(1).max(65536),
  height: D().int().min(1).max(65536),
  duration_seconds: Ie,
  with_audio: Te()
}), Yf = w({
  schema_version: E("1.0.0"),
  review_date: In(),
  image: w({
    method_id: j,
    it_energy_wh_per_image: Ie,
    source: Ge(),
    model_providers: ke(j, lt),
    site_providers: Ze(cn, lt)
  }),
  speech: w({
    method_id: j,
    profile: qt,
    tokens_per_second: ke(lt, Ie),
    characters_per_second: Ie,
    site_providers: Ze(cn, lt),
    source: Ge()
  }),
  video: w({
    method_id: j,
    // The registry model that stands in when the page shows a video but names no model.
    site_models: Ze(cn, j),
    site_defaults: Ze(cn, Ys),
    model_defaults: ke(mo, Ys),
    source: Ge()
  }),
  overview: w({
    method_id: j,
    seconds_per_illustration: Ie
  }),
  // A model served away from its catalog provider's data centres takes the grid and, when
  // given, the PUE and WUE of where it runs. Factors replace the provider's for that model only.
  environment_overrides: ke(
    j,
    w({
      electricity_mix_zone: S().regex(/^[A-Z]{3}$/),
      datacenter_pue: Gs.optional(),
      datacenter_wue: Gs.optional()
    }).refine(
      (e) => e.datacenter_pue === void 0 || Number(
        typeof e.datacenter_pue == "string" ? e.datacenter_pue : e.datacenter_pue.min
      ) >= 1,
      "PUE cannot be below 1"
    )
  ),
  // Optional, so method definitions saved before 15 October 2026 stay readable: a method
  // without it estimates Claude text from the tokenizer's count unchanged.
  claude_token_factor: Gf.optional()
}), Qf = w({
  catalog_schema: j,
  catalog_sha256: O,
  converter_version: j,
  core_sha256: O,
  core_version: j,
  requested_git_commit: S().regex(/^[a-f0-9]{40}$/),
  source_artifact_sha256: O,
  upstream_version: j
});
w({
  schema_version: E("1.0.0"),
  engine_id: E("ecologits"),
  core: Qf,
  mappings: Xf,
  fallback: go,
  media: Yf,
  product_policy: E("operational-only-output-1"),
  latency_policy: E("observed-live-then-history-then-modeled-1"),
  environment_policy: E("upstream-provider-default-assumed"),
  water_total_policy: E("upstream-wcf-1"),
  original_fallback: w({
    method_id: j,
    method_hash: O
  })
});
w({
  schema_version: E("1.0.0"),
  default_engine: xn,
  // Keep historical research configurations readable after retiring the Original engine.
  available_engines: Ne([
    Ks([E("ecologits")]),
    Ks([E("original"), E("ecologits")])
  ]),
  ecologits_fallback: go
});
w({
  schema_version: E("1.0.0"),
  preference: On,
  selection_revision: yi,
  updated_at: _e
});
const jt = w({
  engine_id: xn,
  implementation_version: j,
  method_id: j,
  method_hash: O,
  source_version: j.nullable(),
  source_commit: S().regex(/^[a-f0-9]{40}$/).nullable(),
  catalog_hash: O.nullable(),
  profile_policy_hash: O,
  environment_policy_hash: O,
  product_scope: E("operational-only")
}), ep = w({
  observed_request_id: Qe(),
  canonical_request_id: Qe(),
  relation_hash: O
}), tp = w({
  message_key: O,
  observation_hash: O
}), np = bt("family", [
  w({
    family: E("live"),
    request_id: Qe(),
    request_revision: yi,
    request_hash: O,
    attempt_id: Qe(),
    attempt_revision: yi,
    attempt_hash: O,
    canonical_request_binding: ep.optional(),
    history_binding: tp.optional()
  }),
  w({
    family: E("history"),
    message_key: O,
    observation_hash: O
  })
]), ce = S().regex(/^[0-9]+(\.[0-9]+)?$/).refine((e) => Number(e) > 0 && Number(e) < 1e9), un = S().regex(/^(0|[1-9][0-9]*)(\.[0-9]+)?$/).refine((e) => Number(e) < 1e9).nullable(), Ui = w({
  publisher: S(),
  title: S(),
  url: Ge(),
  section: S(),
  source_revision: S(),
  license: S(),
  access_date: S(),
  activity_period: S().nullable(),
  factor_data_period: S().nullable(),
  publication_date: S().nullable(),
  software_snapshot: S(),
  review_date: S(),
  unknown_period_reason: S(),
  population: S(),
  statistic: b(["scenario_example", "measured_configuration"])
}), vo = w({
  id: S(),
  pue: un,
  carbon: un,
  carbon_gas: b(["CO2", "CO2e"]),
  carbon_boundary: b(["generation", "lifecycle", "unknown"]),
  carbon_accounting: b(["location", "market"]),
  gases: A(S()),
  gwp: S().nullable(),
  direct_water: un,
  direct_denominator: b(["it", "facility"]),
  upstream_water: un,
  water_kind: E("consumption"),
  direct_water_source: b(["freshwater", "all_source", "unknown"]),
  upstream_water_source: b(["freshwater", "all_source", "unknown"]),
  common_water_scope: b(["freshwater_consumption", "all_source_consumption"]).nullable(),
  upstream_exclusions: A(S()),
  provenance: Ui
}).refine((e) => e.pue === null || Number(e.pue) >= 1, "PUE below 1");
w({
  schema_version: E("1.0.0"),
  method_id: S().regex(/^[a-z0-9.-]+$/),
  equation_id: b(["ecologits-output-v1", "test-linear-v1"]),
  runtime_selection_allowed: E(!0),
  validation_state: E("unvalidated_reference"),
  reviewer: S().min(1),
  review_date: S(),
  release_validation: E("pending"),
  coefficients: w({
    energyAlpha: ce,
    energyBeta: S().regex(/^-[0-9]+\.[0-9]+$/),
    energyGamma: ce,
    latencyAlpha: ce,
    latencyBeta: ce,
    latencyGamma: ce
  }),
  settings: w({
    gpuMemoryGb: ce,
    precisionBits: E("16"),
    batchSize: ce,
    memoryMultiplier: ce,
    hostPowerKw: ce,
    serverGpuCount: ce
  }),
  profiles: A(
    w({
      id: S(),
      model: S(),
      activeBillions: ce,
      totalBillions: ce,
      architecture_source: Ge()
    })
  ).min(1).max(1e3),
  scenario: vo,
  provenance: Ui,
  missing_components: A(S())
});
const bo = [
  "capture_hook_missing",
  "protocol_unsupported",
  "composer_anchor_missing",
  "capture_limit_exceeded",
  "model_unverified",
  "tokenizer_unavailable",
  "storage_write_failed",
  "ledger_integrity_failed",
  "auth_reconnect_required",
  "enrollment_revoked",
  "sync_delayed",
  "payload_rejected",
  "revision_conflict",
  "request_identity_ambiguous",
  "dependency_missing",
  "clock_skew",
  "estimate_pending",
  "estimate_unavailable",
  "method_update_invalid",
  "aggregate_inconsistent",
  "ip_unresolved",
  "ip_history_expired",
  "retention_expired",
  "deletion_in_progress",
  "policy_unavailable",
  "guidance_budget_unavailable",
  "host_interference_detected",
  "conversation_identity_local_only",
  "cross_device_dedup_unverified",
  "hidden_reasoning_unobserved",
  "context_unobserved",
  "cache_semantics_unknown",
  "tool_work_unobserved",
  "media_processing_unobserved",
  "media_metadata_limit_exceeded",
  "image_dimensions_unknown",
  "image_settings_unknown",
  "image_execution_incomplete",
  "tokenizer_mapping_unverified",
  "observed_text_only",
  "not_applicable",
  "provider_usage_unavailable",
  "malformed_frame",
  "unsupported_operation",
  "conflicting_duplicate_identity",
  "capture_body_missing",
  "buffer_overflow",
  "stale_tokenizer_response",
  "tokenizer_timeout",
  "unknown_model",
  "profile_absent",
  "no_comparable_profile",
  "input_length_not_modelled",
  "unvalidated_reference",
  "factor_unavailable",
  "factor_incompatible",
  "method_unsupported",
  "partial_capture",
  "history_only",
  "historical_timing_conflict",
  "unknown_terminal_state",
  "media_direction_unknown",
  "provider_selection_unverified",
  "reasoning_overlap_unknown",
  "record_erased",
  // Tracking accuracy rules of 30 Sep to 4 Oct 2026. Each names what Details explains.
  "reasoning_summary_only",
  "research_work_unobserved",
  "side_calls_unobserved",
  "unknown_event_observed",
  "model_not_in_library",
  "model_not_named",
  "model_stand_in",
  "component_unavailable",
  "media_default_assumed",
  "speech_length_estimated",
  "file_size_estimated",
  "content_not_opened",
  "environment_override",
  // A saved row no live capture can produce (NotebookLM Studio); never an unresolved match.
  "no_live_request"
], yt = b(bo), ip = (e) => e / 2 ** 32 | 0, sp = (e) => e >>> 0;
function rp(e, t, n, i) {
  const s = ip(n), r = sp(n);
  e.setUint32(t, i ? r : s, i), e.setUint32(t + 4, i ? s : r, i);
}
function Qs(e) {
  return e instanceof Uint8Array || ArrayBuffer.isView(e) && e.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in e && e.BYTES_PER_ELEMENT === 1;
}
const op = (e) => e ? `"${e}" ` : "";
function Bi(e, t, n = "") {
  if (Qs(e) && t === void 0)
    return e;
  const i = Qs(e), s = "", r = i ? `length=${e.length}` : `type=${typeof e}`, o = op(n) + "expected Uint8Array" + s + ", got " + r;
  throw i ? new RangeError(o) : new TypeError(o);
}
const ap = (e, t) => {
  if (e === null || typeof e != "object" || Array.isArray(e))
    throw new TypeError((t === "object" ? "" : `"${t}" `) + "expected object, got type=" + typeof e);
}, er = (e, t) => {
  ap(e, t);
  const n = Object.getPrototypeOf(e);
  if (n !== Object.prototype && n !== null)
    throw new TypeError(`"${t}" expected plain object`);
  if (Object.hasOwn(e, "__proto__"))
    throw new TypeError(`"${t}.__proto__" is not allowed`);
};
function tr(e, t = !0) {
  if (e.destroyed)
    throw new Error("hash was destroyed");
  if (t && e.finished)
    throw new Error("digest() was already called");
}
function cp(e, t) {
  Bi(e, void 0, "output");
  const n = t.outputLen;
  if (!(e.length >= n))
    throw new RangeError('"output" expected length >= ' + n);
}
function nr(...e) {
  for (let t = 0; t < e.length; t++)
    e[t].fill(0);
}
function Kn(e) {
  return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function xe(e, t) {
  return e << 32 - t | e >>> t;
}
const up = /* @ts-ignore */ typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function", lp = /* @__PURE__ */ Array.from({ length: 256 }, (e, t) => t.toString(16).padStart(2, "0"));
function dp(e) {
  if (Bi(e), up)
    return e.toHex();
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += lp[e[n]];
  return t;
}
function fp(e, t, n = "opts") {
  return er(e, "defaults"), t !== void 0 && er(t, n), Object.assign(/* @__PURE__ */ Object.create(null), e, t);
}
function pp(e, t = {}) {
  if (typeof e != "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof e);
  t = fp({}, t, "info");
  const n = (s, r) => e(r).update(s).digest(), i = e(void 0);
  return n.outputLen = i.outputLen, n.blockLen = i.blockLen, n.canXOF = i.canXOF, n.create = (s) => e(s), Object.assign(n, t), Object.freeze(n);
}
const hp = (e) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, e])
});
function mp(e, t, n) {
  return e & t ^ ~e & n;
}
function _p(e, t, n) {
  return e & t ^ e & n ^ t & n;
}
class gp {
  blockLen;
  outputLen;
  canXOF = !1;
  padOffset;
  isLE;
  // For partial updates less than block size
  buffer;
  view;
  finished = !1;
  length = 0;
  pos = 0;
  destroyed = !1;
  constructor(t, n, i, s) {
    this.blockLen = t, this.outputLen = n, this.padOffset = i, this.isLE = s, this.buffer = new Uint8Array(t), this.view = Kn(this.buffer);
  }
  update(t) {
    tr(this), Bi(t);
    const { view: n, buffer: i, blockLen: s } = this, r = t.length;
    let o = !1;
    for (let a = 0; a < r; ) {
      const u = Math.min(s - this.pos, r - a);
      if (u === s) {
        const c = Kn(t);
        for (; s <= r - a; a += s)
          this.process(c, a);
        o = !0;
        continue;
      }
      i.set(a === 0 && u === r ? t : t.subarray(a, a + u), this.pos), this.pos += u, a += u, this.pos === s && (this.process(n, 0), this.pos = 0, o = !0);
    }
    return this.length += t.length, o && this.roundClean(), this;
  }
  digestInto(t) {
    tr(this), cp(t, this), this.finished = !0;
    const { buffer: n, view: i, blockLen: s, isLE: r } = this;
    let { pos: o } = this;
    n[o++] = 128, n.fill(0, o), this.padOffset > s - o && (this.process(i, 0), n.fill(0)), rp(i, s - 8, this.length * 8, r), this.process(i, 0), this.roundClean();
    const a = t === n ? i : Kn(t), u = this.outputLen, c = u / 4, f = this.get();
    if (u % 4 || c > f.length)
      throw new Error("invalid outputLen");
    for (let l = 0; l < c; l++)
      a.setUint32(4 * l, f[l], r);
  }
  digest() {
    const { buffer: t, outputLen: n } = this;
    this.digestInto(t);
    const i = t.slice(0, n);
    return this.destroy(), i;
  }
  _cloneIntoMeta(t) {
    const { buffer: n, length: i, finished: s, destroyed: r, pos: o } = this;
    return t.destroyed = r, t.finished = s, t.length = i, t.pos = o, o && t.buffer.set(n), t;
  }
  clone() {
    return this._cloneInto();
  }
}
const vp = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]), bp = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), De = /* @__PURE__ */ new Uint32Array(64);
class yp extends gp {
  // We cannot use array here since array allows indexing by variable
  // which means optimizer/compiler cannot use registers.
  // Numeric initializers matter: starting the fields as `undefined` changes
  // V8's field representation and makes sha256 3x slower (measured).
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(t, n) {
    super(64, t, 8, !1), this.A = n[0] | 0, this.B = n[1] | 0, this.C = n[2] | 0, this.D = n[3] | 0, this.E = n[4] | 0, this.F = n[5] | 0, this.G = n[6] | 0, this.H = n[7] | 0;
  }
  get() {
    const { A: t, B: n, C: i, D: s, E: r, F: o, G: a, H: u } = this;
    return [t, n, i, s, r, o, a, u];
  }
  // prettier-ignore
  set(t, n, i, s, r, o, a, u) {
    this.A = t | 0, this.B = n | 0, this.C = i | 0, this.D = s | 0, this.E = r | 0, this.F = o | 0, this.G = a | 0, this.H = u | 0;
  }
  _cloneInto(t) {
    return (t ||= new this.constructor()).set(...this.get()), this._cloneIntoMeta(t);
  }
  process(t, n) {
    for (let l = 0; l < 16; l++, n += 4)
      De[l] = t.getUint32(n, !1);
    for (let l = 16; l < 64; l++) {
      const m = De[l - 15], h = De[l - 2], p = xe(m, 7) ^ xe(m, 18) ^ m >>> 3, y = xe(h, 17) ^ xe(h, 19) ^ h >>> 10;
      De[l] = y + De[l - 7] + p + De[l - 16] | 0;
    }
    let { A: i, B: s, C: r, D: o, E: a, F: u, G: c, H: f } = this;
    for (let l = 0; l < 64; l++) {
      const m = xe(a, 6) ^ xe(a, 11) ^ xe(a, 25), h = f + m + mp(a, u, c) + bp[l] + De[l] | 0, y = (xe(i, 2) ^ xe(i, 13) ^ xe(i, 22)) + _p(i, s, r) | 0;
      f = c, c = u, u = a, a = o + h | 0, o = r, r = s, s = i, i = h + y | 0;
    }
    i = i + this.A | 0, s = s + this.B | 0, r = r + this.C | 0, o = o + this.D | 0, a = a + this.E | 0, u = u + this.F | 0, c = c + this.G | 0, f = f + this.H | 0, this.set(i, s, r, o, a, u, c, f);
  }
  roundClean() {
    nr(De);
  }
  destroy() {
    this.destroyed = !0, this.set(0, 0, 0, 0, 0, 0, 0, 0), nr(this.buffer);
  }
}
class wp extends yp {
  constructor() {
    super(32, vp);
  }
}
const xp = /* @__PURE__ */ pp(
  () => new wp(),
  /* @__PURE__ */ hp(1)
);
function et(e, t = 0) {
  if (t > 16) throw new Error("payload_rejected");
  if (e === null || typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isSafeInteger(e))
    return JSON.stringify(e);
  if (Array.isArray(e))
    return "[" + e.map((n) => et(n, t + 1)).join(",") + "]";
  if (typeof e == "object" && Object.getPrototypeOf(e) === Object.prototype)
    return "{" + Object.keys(e).sort().map(
      (n) => JSON.stringify(n) + ":" + et(e[n], t + 1)
    ).join(",") + "}";
  throw new Error("payload_rejected");
}
function gt(e) {
  return dp(xp(new TextEncoder().encode(et(e))));
}
const yo = Ne([
  yt,
  b([
    "provider_unknown",
    "model_override",
    "provider_policy",
    "unknown_provider_policy",
    "model_provider_conflict",
    "unsupported_workload",
    "numeric_domain_unsupported",
    "model_proxy",
    "original_engine_fallback",
    "provider_environment_assumed",
    "source_error",
    "source_warning",
    "cancelled",
    "stale_estimation_result",
    "original_method_missing"
  ])
]), An = A(yo).max(96);
function wo(e, t, n) {
  return n === "original_fallback" ? e === "ecologits" && t === "original" : n === "legacy_reference" ? e === "original" && t === "original" : ["direct_mapping", "model_override", "provider_flagship"].includes(
    n
  ) ? e === "ecologits" && t === "ecologits" : n === "unavailable" && e === t;
}
const kp = Ne([
  Se,
  w({
    min: Se,
    max: Se
  }).refine(
    (e) => Number(e.min) <= Number(e.max),
    "Reversed impact interval"
  )
]);
function Ht(e, t, n) {
  return w({
    type: E(e),
    name: E(t),
    unit: E(n),
    value: kp
  });
}
const ir = Ht("energy", "Energy", "kWh"), Vn = Ht("GWP", "Global Warming Potential", "kgCO2eq"), Jn = Ht("ADPe", "Abiotic Depletion Potential (elements)", "kgSbeq"), Xn = Ht("PE", "Primary Energy", "MJ"), sr = Ht("WCF", "Water Consumption Footprint", "L"), rr = w({
  code: S().regex(/^[a-z][a-z0-9_-]{0,127}$/),
  message: S().max(1024)
}), xo = w({
  energy: ir.nullable(),
  gwp: Vn.nullable(),
  adpe: Jn.nullable(),
  pe: Xn.nullable(),
  wcf: sr.nullable(),
  usage: w({
    type: E("usage"),
    name: E("Usage"),
    energy: ir,
    gwp: Vn,
    adpe: Jn,
    pe: Xn,
    wcf: sr
  }).nullable(),
  embodied: w({
    type: E("embodied"),
    name: E("Embodied"),
    gwp: Vn,
    adpe: Jn,
    pe: Xn
  }).nullable(),
  warnings: A(rr).min(1).max(64).nullable(),
  errors: A(rr).min(1).max(64).nullable()
}).superRefine((e, t) => {
  const n = [
    e.energy,
    e.gwp,
    e.adpe,
    e.pe,
    e.wcf,
    e.usage,
    e.embodied
  ];
  (e.errors === null ? n.some((i) => i === null) : n.some((i) => i !== null)) && t.addIssue({
    code: "custom",
    message: "Inconsistent upstream outcome"
  });
}), At = w({
  value: Tn.nullable(),
  unit: b(["kWh", "gCO2e", "gCO2", "L"]),
  status: b(["partial_estimate", "unavailable"]),
  scope: S(),
  scenario_low: gi(),
  scenario_high: gi(),
  reasons: A(S())
}), ko = w({
  profile_selection: b(["reference_only", "unavailable"]),
  reference_only: E(!0),
  selected_profile_id: S().nullable(),
  cohort_id: S(),
  cohort_hash: O,
  eligible_candidate_count: D().int().nonnegative(),
  result_scope: E("gpu_associated_reference"),
  starting_energy_boundary: E("gpu"),
  gpu_kwh: Tn.nullable(),
  generated_image_count: C.nullable(),
  known_settings: w({
    width: D().nullable().optional(),
    height: D().nullable().optional(),
    steps: D().nullable().optional(),
    precision: S().optional(),
    kind: S().optional()
  }),
  reasons: A(S())
}), Sp = w({
  schema_version: E("1.0.0"),
  attempt_id: Qe(),
  observation_revision: D().int().min(1),
  observation_hash: O,
  method_id: j,
  method_hash: O,
  view: b(["original", "recalculated"]),
  original_method_hash: O.nullable(),
  observed_model_key: S().nullable(),
  model_evidence: S(),
  profile_selection: b([
    "matched_profile",
    "highest_comparable",
    "reference_only",
    "unavailable"
  ]),
  selected_profile_id: S().nullable(),
  cohort_id: S(),
  cohort_hash: O,
  eligible_candidate_count: D().int().nonnegative(),
  eligibility_signature: O,
  environment_scenario_id: S(),
  factor_provenance_status: S(),
  starting_energy_boundary: E("it"),
  result_scope: E("modeled_text_component"),
  reference_only: Te(),
  validation_state: E("unvalidated_reference"),
  known_settings: ke(S(), S()),
  assumed_settings: ke(S(), S()),
  selection_reason: S(),
  included_components: A(S()),
  missing_components: A(S()),
  reasons: A(S()),
  metrics: w({
    energy: At,
    carbon: At,
    water_direct: At,
    water_upstream: At,
    water_total: At
  }),
  image_references: A(ko),
  provenance: Ui,
  environment_provenance: vo
}), So = w({
  quantity: b([
    "energy",
    "carbon",
    "water_direct",
    "water_upstream",
    "water_total"
  ]),
  value: Tn.nullable(),
  unit: S(),
  scope: E("historical_visible_response"),
  method_id: j,
  method_hash: O,
  status: b(["partial_estimate", "unavailable"]),
  validation_state: E("unvalidated_reference"),
  profile_selection: b(["highest_comparable", "unavailable"]),
  selected_profile_id: S().nullable(),
  reasons: A(S()),
  missing_components: A(S()),
  known_message_count: C,
  unknown_message_count: C
}), Ep = A(So).max(5).refine(
  (e) => (e.length === 0 || e.length === 5) && new Set(e.map((t) => t.quantity)).size === e.length,
  "Incomplete historical result"
), Nt = w({
  value: Se.nullable(),
  unit: b(["kWh", "gCO2e", "gCO2", "L"]),
  status: b(["partial_estimate", "unavailable"]),
  scope: b([
    "modeled_text_component",
    "historical_visible_response",
    "modeled_video_component",
    "modeled_image_component",
    "modeled_speech_component"
  ]),
  phase: E("usage"),
  scenario_low: Se.nullable(),
  scenario_high: Se.nullable(),
  interval_kind: b(["upstream_approximation", "scenario"]).nullable(),
  value_kind: b(["scalar", "midpoint", "unavailable"]),
  reasons: An
}).superRefine((e, t) => {
  const n = e.value === null, i = e.scenario_low !== null && e.scenario_high !== null;
  (n !== (e.status === "unavailable") || n !== (e.value_kind === "unavailable")) && t.addIssue({
    code: "custom",
    message: "Metric availability contradicts value"
  }), (i !== (e.value_kind === "midpoint") || i !== (e.interval_kind !== null) || e.scenario_low === null != (e.scenario_high === null)) && t.addIssue({
    code: "custom",
    message: "Incomplete interval metadata"
  }), i && (Number(e.scenario_low) > Number(e.value) || Number(e.value) > Number(e.scenario_high)) && t.addIssue({
    code: "custom",
    message: "Display value outside interval"
  });
});
b(["minimum", "midpoint", "maximum"]);
const Eo = w({
  energy: Nt,
  carbon: Nt,
  water_direct: Nt,
  water_upstream: Nt,
  water_total: Nt
}).superRefine((e, t) => {
  (e.energy.unit !== "kWh" || !["gCO2e", "gCO2"].includes(e.carbon.unit) || [e.water_direct, e.water_upstream, e.water_total].some(
    (n) => n.unit !== "L"
  )) && t.addIssue({
    code: "custom",
    message: "Metric has incompatible units"
  });
}), zo = "3.0.0", zp = [
  "exact_record",
  "nearest_record",
  "family_benchmark",
  "model_not_named",
  "model_not_in_library",
  "model_family_stand_in",
  "model_variant_stand_in",
  "model_kind_stand_in"
], Ip = b(zp), Io = w({
  kind: b([
    "legacy_reference",
    "direct_mapping",
    "model_override",
    "provider_flagship",
    "original_fallback",
    "unavailable"
  ]),
  observed_model_id: j.nullable(),
  profile: qt.nullable(),
  reason: yo.nullable(),
  basis: Ip.nullable()
}), Gn = Se.nullable(), Tp = w({
  output_tokens: C.nullable(),
  latency_seconds: Gn,
  latency_basis: b(["measured", "history", "research_task", "modeled"]).nullable(),
  environment_provider: S().regex(/^[a-z][a-z0-9_-]{0,63}$/).nullable(),
  electricity_mix_zone: S().regex(/^[A-Z]{3}$/).nullable(),
  units: C.nullable(),
  width: D().int().min(1).max(65536).nullable(),
  height: D().int().min(1).max(65536).nullable(),
  duration_seconds: Gn,
  with_audio: Te().nullable(),
  audio_seconds: Gn,
  defaults_applied: A(b(["resolution", "duration", "audio", "length", "model"])).max(5)
}), Op = w({
  component_id: S().regex(/^[a-z][a-z_]{0,31}_[0-9]{1,3}$/),
  kind: b(["text", "image", "video", "speech"]),
  role: b([
    "main",
    "side_calls",
    "research",
    "storyboard",
    "generated_image",
    "generated_video",
    "generated_speech",
    "overview_illustrations",
    "overview_narration"
  ]),
  method_id: j,
  selection: Io.nullable(),
  inputs: Tp,
  raw: xo.nullable(),
  status: b(["estimated", "unavailable"]),
  metrics: Eo,
  reasons: An
}).superRefine((e, t) => {
  Object.values(e.metrics).some(
    (i) => i.value !== null
  ) !== (e.status === "estimated") && t.addIssue({
    code: "custom",
    message: "Component status contradicts its metrics"
  }), e.selection !== null && ["direct_mapping", "model_override", "provider_flagship"].includes(
    e.selection.kind
  ) !== (e.selection.profile !== null) && t.addIssue({
    code: "custom",
    message: "Component selection profile mismatch"
  }), e.raw?.errors && e.status === "estimated" && t.addIssue({
    code: "custom",
    message: "Component estimate carries upstream errors"
  });
}), Ap = w({
  schema_version: E(zo),
  source: np,
  input_hash: O,
  auxiliary_method_hashes: w({
    image_reference: O
  }),
  requested_method: jt,
  effective_method: jt,
  execution_origin: b(["local", "organization"]),
  view: b(["original", "recalculated"]),
  original_method_hash: O.nullable(),
  selection: Io,
  components: A(Op).max(96),
  raw: bt("engine_id", [
    w({
      engine_id: E("original"),
      result: Ne([
        Sp,
        Ep
      ])
    }),
    w({
      engine_id: E("ecologits"),
      result: xo
    })
  ]).nullable(),
  status: b(["estimated", "unavailable"]),
  metrics: Eo,
  image_references: A(ko).max(100),
  reasons: An,
  missing_components: A(S().regex(/^[a-z][a-z0-9_]{0,127}$/)).max(64),
  validation_state: E("unvalidated_reference"),
  comparability: w({
    energy_boundary: E("facility"),
    carbon_boundary: b(["generation", "lifecycle", "unknown"]),
    carbon_accounting: b(["location", "market"]),
    water_kind: E("consumption"),
    direct_water_source: b(["freshwater", "all_source", "unknown"]),
    upstream_water_source: b(["freshwater", "all_source", "unknown"]),
    common_water_scope: b(["freshwater_consumption", "all_source_consumption"]).nullable(),
    tokenizer_profile_id: j.nullable()
  })
}).superRefine((e, t) => {
  e.requested_method.engine_id === e.effective_method.engine_id && gt(e.requested_method) !== gt(e.effective_method) && t.addIssue({
    code: "custom",
    message: "The same engine must retain its complete method identity"
  }), e.input_hash !== Cp(e) && t.addIssue({
    code: "custom",
    message: "Calculation input hash mismatch"
  }), e.image_references.some(
    (r) => r.cohort_hash !== e.auxiliary_method_hashes.image_reference
  ) && t.addIssue({
    code: "custom",
    message: "Independent image method mismatch"
  }), wo(
    e.requested_method.engine_id,
    e.effective_method.engine_id,
    e.selection.kind
  ) || t.addIssue({
    code: "custom",
    message: "Selection misattributes its engine"
  }), ["direct_mapping", "model_override", "provider_flagship"].includes(
    e.selection.kind
  ) !== (e.selection.profile !== null) && t.addIssue({
    code: "custom",
    message: "Selection profile mismatch"
  }), e.raw !== null && e.raw.engine_id !== e.effective_method.engine_id && t.addIssue({
    code: "custom",
    message: "Raw output engine mismatch"
  });
  const n = e.reasons.includes("original_method_missing");
  n && (e.view !== "recalculated" || e.source.family !== "live" || e.original_method_hash !== null) && t.addIssue({
    code: "custom",
    message: "Missing original lineage is only valid for an explicitly unrecorded live calculation"
  }), e.view === "recalculated" && e.original_method_hash === null && !n && t.addIssue({
    code: "custom",
    message: "Recalculation requires original lineage"
  }), e.status === "unavailable" && Object.values(e.metrics).some((r) => r.value !== null) && t.addIssue({
    code: "custom",
    message: "Unavailable result has a successful metric"
  });
  const i = e.components.some(
    (r) => r.status === "estimated"
  );
  e.status === "estimated" && (e.raw === null && !i || Object.values(e.metrics).every(
    (r) => r.value === null
  ) || e.raw?.engine_id === "ecologits" && e.raw.result.errors !== null && !i) && t.addIssue({
    code: "custom",
    message: "Estimated result lacks numerical evidence"
  }), (i || e.effective_method.engine_id === "ecologits") && !Np(e.metrics, e.components) && t.addIssue({
    code: "custom",
    message: "Top-level metrics must equal the sum of the estimated components"
  }), e.effective_method.engine_id === "original" && e.components.length > 0 && t.addIssue({
    code: "custom",
    message: "The original method has no components"
  }), new Set(e.components.map((r) => r.component_id)).size !== e.components.length && t.addIssue({
    code: "custom",
    message: "Duplicate component identity"
  });
  const s = e.components.filter(
    (r) => r.role === "main"
  );
  if (e.effective_method.engine_id === "ecologits" && (s.length > 1 || et(e.raw) !== et(
    s[0]?.raw ? { engine_id: "ecologits", result: s[0].raw } : null
  )) && t.addIssue({
    code: "custom",
    message: "Raw output must be the main component's raw output"
  }), e.requested_method.engine_id !== e.effective_method.engine_id && !(e.requested_method.engine_id === "ecologits" && e.effective_method.engine_id === "original" && e.selection.kind === "original_fallback") && t.addIssue({
    code: "custom",
    message: "Unsupported engine substitution"
  }), e.raw?.engine_id === "original") {
    const r = e.raw.result;
    Array.isArray(r) ? (e.source.family !== "history" || r.some(
      (o) => o.method_hash !== e.effective_method.method_hash || o.method_id !== e.effective_method.method_id
    ) || r.length === 0 && e.status === "estimated") && t.addIssue({
      code: "custom",
      message: "Original historical result binding mismatch"
    }) : (e.source.family !== "live" || r.observation_hash !== e.source.attempt_hash || r.observation_revision !== e.source.attempt_revision || r.attempt_id !== e.source.attempt_id || r.method_hash !== e.effective_method.method_hash || r.method_id !== e.effective_method.method_id || r.observed_model_key !== e.selection.observed_model_id) && t.addIssue({
      code: "custom",
      message: "Original live result binding mismatch"
    });
  }
});
function ln(e, t) {
  if (e === null) return !1;
  const n = Number(e);
  return Math.abs(n - t) <= 1e-9 * Math.max(Math.abs(n), Math.abs(t));
}
function Np(e, t) {
  const n = t.filter(
    (i) => i.status === "estimated"
  );
  return Object.keys(e).every((i) => {
    const s = n.map((u) => u.metrics[i]).filter((u) => u.value !== null), r = e[i];
    if (!s.length) return r.value === null;
    if (r.value_kind === "scalar")
      return !s.some((u) => u.value_kind === "midpoint") && ln(
        r.value,
        s.reduce((u, c) => u + Number(c.value), 0)
      );
    const o = s.reduce(
      (u, c) => u + Number(c.scenario_low ?? c.value),
      0
    ), a = s.reduce(
      (u, c) => u + Number(c.scenario_high ?? c.value),
      0
    );
    return r.value_kind === "midpoint" && ln(r.scenario_low, o) && ln(r.scenario_high, a) && ln(r.value, (o + a) / 2);
  });
}
function Cp(e) {
  return gt({
    schema_version: zo,
    source: e.source,
    requested_method_hash: e.requested_method.method_hash,
    effective_method_hash: e.effective_method.method_hash,
    selection: e.selection,
    auxiliary_method_hashes: e.auxiliary_method_hashes
  });
}
const $p = w({
  ...So.shape,
  value: Se.nullable(),
  unit: b(["kWh", "gCO2e", "gCO2", "L"]),
  phase: E("usage"),
  scenario_low: Se.nullable(),
  scenario_high: Se.nullable(),
  interval_kind: b(["upstream_approximation", "scenario"]).nullable(),
  value_kind: b(["scalar", "midpoint", "midpoint_sum", "unavailable"]),
  profile_selection: b([
    "legacy_reference",
    "direct_mapping",
    "model_override",
    "provider_flagship",
    "original_fallback",
    "unavailable"
  ]),
  selected_profile_id: S().max(320).regex(/^[A-Za-z0-9][A-Za-z0-9._:/@+\-]*$/).nullable(),
  reasons: An,
  requested_method: jt,
  effective_method: jt,
  comparability: Ap.shape.comparability
}).superRefine((e, t) => {
  const n = (r) => t.addIssue({ code: "custom", message: r });
  e.requested_method.engine_id === e.effective_method.engine_id && gt(e.requested_method) !== gt(e.effective_method) && n(
    "The same historical engine must retain its complete method identity"
  ), wo(
    e.requested_method.engine_id,
    e.effective_method.engine_id,
    e.profile_selection
  ) || n("Historical selection misattributes its engine"), (e.method_id !== e.requested_method.method_id || e.method_hash !== e.requested_method.method_hash) && n("Historical method binding mismatch"), (e.value === null != (e.status === "unavailable") || e.value === null != (e.value_kind === "unavailable")) && n("Historical availability mismatch"), (e.profile_selection === "unavailable" && e.selected_profile_id !== null || e.value !== null && e.selected_profile_id === null) && n("Historical profile mismatch");
  const i = e.scenario_low !== null && e.scenario_high !== null, s = e.value_kind === "midpoint" || e.value_kind === "midpoint_sum";
  (e.scenario_low === null != (e.scenario_high === null) || e.value_kind === "midpoint" && (!i || e.interval_kind === null) || e.value_kind === "midpoint_sum" && e.interval_kind !== null || !s && (i || e.interval_kind !== null)) && n("Historical interval metadata mismatch"), i && (Number(e.scenario_low) > Number(e.value) || Number(e.value) > Number(e.scenario_high)) && n("Historical value outside interval"), (e.quantity === "energy" ? e.unit !== "kWh" : e.quantity === "carbon" ? !["gCO2e", "gCO2"].includes(e.unit) : e.unit !== "L") && n("Historical quantity unit mismatch"), e.requested_method.engine_id !== e.effective_method.engine_id && !(e.requested_method.engine_id === "ecologits" && e.effective_method.engine_id === "original" && e.profile_selection === "original_fallback") && n("Historical engine substitution mismatch");
}), Dp = [
  "chatgpt-latest",
  "chatgpt-gpt-5-6-sol",
  "chatgpt-gpt-5-5",
  "chatgpt-gpt-5-6-luna",
  "chatgpt-gpt-5-6-sol-pro",
  "chatgpt-gpt-6-pro",
  "chatgpt-reasoning-effort",
  "chatgpt-pro-option",
  "chatgpt-think",
  "chatgpt-images-2-5",
  "chatgpt-images-thinking",
  "chatgpt-gpt-live-1",
  "chatgpt-gpt-live-1-mini",
  "chatgpt-voice-live",
  "chatgpt-voice-advanced",
  "chatgpt-voice-standard",
  "chatgpt-gpt-6-2-sol",
  "chatgpt-gpt-6-2-astra",
  "chatgpt-gpt-6-1-terra",
  "chatgpt-gpt-6-2-sol-pro",
  "chatgpt-gpt-6-2-astra-pro",
  "chatgpt-gpt-6-1-terra-pro",
  "chatgpt-gpt-6-1-sol",
  "chatgpt-gpt-6-sol",
  "chatgpt-gpt-6-luna",
  "chatgpt-gpt-6-astra",
  "chatgpt-gpt-6-1-sol-pro",
  "chatgpt-gpt-6-sol-pro",
  "chatgpt-gpt-6-luna-pro",
  "chatgpt-gpt-5-6-luna-pro",
  "chatgpt-gpt-5-6-terra-pro",
  "chatgpt-gpt-5-6-terra",
  "chatgpt-gpt-5-5-pro",
  "chatgpt-gpt-5-5-mini",
  "chatgpt-gpt-5-4",
  "chatgpt-gpt-5-4-pro",
  "chatgpt-gpt-5-4-mini",
  "chatgpt-gpt-5-3-mini",
  "chatgpt-gpt-5-2",
  "chatgpt-gpt-5-2-pro",
  "chatgpt-gpt-5-1",
  "chatgpt-gpt-5",
  "chatgpt-gpt-5-mini",
  "chatgpt-gpt-5-pro",
  "chatgpt-gpt-4-1",
  "chatgpt-gpt-4-1-mini",
  "chatgpt-gpt-4o",
  "chatgpt-gpt-4o-mini",
  "chatgpt-gpt-4",
  "chatgpt-gpt-3-5",
  "chatgpt-o4-mini",
  "chatgpt-o3",
  "chatgpt-o3-pro",
  "chatgpt-o3-mini",
  "chatgpt-o1",
  "chatgpt-voice-bidi",
  "chatgpt-deep-research",
  "chatgpt-agent",
  "chatgpt-unlisted",
  "chatgpt-gpt-sol-unlisted",
  "chatgpt-gpt-astra-unlisted",
  "chatgpt-gpt-luna-unlisted",
  "chatgpt-gpt-terra-unlisted",
  "chatgpt-gpt-pro-unlisted",
  "chatgpt-gpt-mini-unlisted",
  "chatgpt-gpt-nano-unlisted",
  "chatgpt-gpt-codex-unlisted",
  "chatgpt-gpt-sol-pro-unlisted",
  "chatgpt-gpt-astra-pro-unlisted",
  "chatgpt-gpt-luna-pro-unlisted",
  "chatgpt-gpt-terra-pro-unlisted",
  "claude-fable-5-2",
  "claude-fable-5-1",
  "claude-opus-5",
  "claude-sonnet-5",
  "claude-haiku-5-5",
  "claude-haiku-4-5",
  "claude-fable-5",
  "claude-opus-4-8",
  "claude-opus-4-7",
  "claude-opus-4-6",
  "claude-opus-3",
  "claude-sonnet-4-6",
  "claude-effort",
  "claude-thinking",
  "claude-opus-5-5",
  "claude-sonnet-5-5",
  "claude-opus-4-5",
  "claude-sonnet-4-5",
  "claude-opus-4-1",
  "claude-opus-4",
  "claude-sonnet-4",
  "claude-sonnet-3-7",
  "claude-sonnet-3-5",
  "claude-haiku-3-5",
  "claude-haiku-3",
  "claude-unlisted",
  "claude-haiku-unlisted",
  "claude-sonnet-unlisted",
  "claude-opus-unlisted",
  "claude-fable-unlisted",
  "claude-small-unlisted",
  "gemini-3-6-flash",
  "gemini-3-6-thinking",
  "gemini-3-1-pro",
  "gemini-public-flash-lite",
  "gemini-public-flash",
  "gemini-public-pro",
  "gemini-thinking-level",
  "gemini-deep-think",
  "gemini-deep-research",
  "gemini-nano-banana-2-lite",
  "gemini-nano-banana-2",
  "gemini-nano-banana-pro",
  "gemini-omni",
  "gemini-lyria",
  "gemini-4-hydrogen",
  "gemini-4-neon",
  "gemini-3-8-flash",
  "gemini-3-7-flash",
  "gemini-3-5-flash",
  "gemini-3-5-flash-lite",
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-2-5-flash",
  "gemini-2-5-flash-lite",
  "gemini-2-5-pro",
  "gemini-nano-banana",
  "gemini-omni-video",
  "gemini-unnamed",
  "gemini-unlisted",
  "gemini-flash-unlisted",
  "gemini-flash-lite-unlisted",
  "gemini-pro-unlisted",
  "gemini-pro-image-unlisted",
  "gemini-flash-image-unlisted",
  "gemini-image-unlisted",
  "perplexity-best",
  "perplexity-sonar-2",
  "perplexity-gpt-5-6-terra",
  "perplexity-gpt-5-6-sol",
  "perplexity-gemini-3-8-flash",
  "perplexity-claude-sonnet-5",
  "perplexity-claude-opus-5",
  "perplexity-kimi-k3",
  "perplexity-glm-5-3",
  "perplexity-grok-4-6",
  "perplexity-nemotron-3-ultra",
  "perplexity-gemini-3-7-flash",
  "perplexity-thinking",
  "perplexity-search",
  "perplexity-deep-research",
  "perplexity-learn",
  "perplexity-council",
  "perplexity-computer",
  "perplexity-comet",
  "perplexity-image-default",
  "perplexity-gpt-image-1",
  "perplexity-nano-banana",
  "perplexity-nano-banana-pro",
  "perplexity-seedream-4-5",
  "perplexity-veo-3-1",
  "perplexity-gpt-6-2-sol",
  "perplexity-gpt-6-2-astra",
  "perplexity-gpt-6-2-sol-pro",
  "perplexity-gpt-6-2-astra-pro",
  "perplexity-gemini-4-argon",
  "perplexity-gemini-4-carbon",
  "perplexity-gemini-4-hydrogen",
  "perplexity-gemini-4-neon",
  "perplexity-claude-fable-5-2",
  "perplexity-gpt-6-1-sol",
  "perplexity-gpt-6-sol",
  "perplexity-gpt-6-astra",
  "perplexity-gpt-6-1-sol-pro",
  "perplexity-gpt-6-sol-pro",
  "perplexity-gpt-6-astra-pro",
  "perplexity-gpt-5-6-sol-pro",
  "perplexity-gpt-5-6-terra-pro",
  "perplexity-gpt-5-5",
  "perplexity-gpt-5-4",
  "perplexity-gpt-5-2",
  "perplexity-gpt-5-2-pro",
  "perplexity-gpt-5-1",
  "perplexity-gpt-5",
  "perplexity-gpt-5-mini",
  "perplexity-gpt-5-nano",
  "perplexity-gpt-5-pro",
  "perplexity-gpt-4-1",
  "perplexity-gpt-4o",
  "perplexity-o4-mini",
  "perplexity-o3-pro",
  "perplexity-claude-fable-5-1",
  "perplexity-claude-opus-5-5",
  "perplexity-claude-sonnet-5-5",
  "perplexity-claude-opus-4-8",
  "perplexity-claude-opus-4-7",
  "perplexity-claude-opus-4-6",
  "perplexity-claude-opus-4-5",
  "perplexity-claude-opus-4-1",
  "perplexity-claude-opus-4",
  "perplexity-claude-sonnet-4-6",
  "perplexity-claude-sonnet-4-5",
  "perplexity-claude-sonnet-4",
  "perplexity-claude-haiku-4-5",
  "perplexity-gemini-3-5-flash",
  "perplexity-gemini-3-1-pro",
  "perplexity-gemini-3-flash",
  "perplexity-gemini-3-pro",
  "perplexity-gemini-2-5-pro",
  "perplexity-glm-5-2",
  "perplexity-deepseek",
  "perplexity-qwen",
  "perplexity-kimi",
  "perplexity-grok",
  "perplexity-nemotron",
  "perplexity-agentic-research",
  "perplexity-create-files",
  "perplexity-study",
  "perplexity-nano-banana-2",
  "perplexity-veo-3-1-fast",
  "perplexity-veo-3-0",
  "perplexity-veo-3-0-fast",
  "perplexity-sora-2-pro",
  "perplexity-video-unlisted",
  "perplexity-unlisted",
  "perplexity-unlisted-anthropic",
  "perplexity-unlisted-google",
  "perplexity-claude-haiku-unlisted",
  "perplexity-claude-sonnet-unlisted",
  "perplexity-claude-opus-unlisted",
  "perplexity-claude-fable-unlisted",
  "perplexity-gpt-sol-unlisted",
  "perplexity-gpt-astra-unlisted",
  "perplexity-gpt-luna-unlisted",
  "perplexity-gpt-terra-unlisted",
  "perplexity-gemini-flash-unlisted",
  "perplexity-gemini-flash-lite-unlisted",
  "perplexity-gemini-pro-unlisted",
  "perplexity-claude-small-unlisted",
  "perplexity-gpt-pro-unlisted",
  "perplexity-gpt-mini-unlisted",
  "perplexity-gpt-nano-unlisted",
  "perplexity-gpt-codex-unlisted",
  "perplexity-gpt-sol-pro-unlisted",
  "perplexity-gpt-astra-pro-unlisted",
  "perplexity-gpt-luna-pro-unlisted",
  "perplexity-gpt-terra-pro-unlisted",
  "perplexity-gemini-pro-image-unlisted",
  "perplexity-gemini-flash-image-unlisted",
  "perplexity-gemini-image-unlisted",
  "notebooklm-default",
  "notebooklm-image"
], Fp = w({
  namespace: S().min(1).max(256),
  mode: b(["personal", "company"]),
  era: S().max(256).nullable()
});
w({
  preference: On,
  expectedRevision: D().int().min(1).max(2147483647).nullable()
});
w({
  schema_version: E("1.0.0"),
  scope: Fp,
  scopeToken: S().min(1).max(256),
  preference: On.nullable(),
  selectionRevision: D().int().min(1).max(2147483647).nullable(),
  buildDefault: xn,
  effectiveEngine: xn.nullable(),
  method: jt.nullable(),
  local: w({
    status: b(["idle", "running", "complete", "pending", "failed"]),
    jobId: S().max(128).nullable(),
    processed: D().int().nonnegative(),
    unavailable: D().int().nonnegative(),
    pending: D().int().nonnegative()
  }),
  organization: w({
    status: b([
      "personal",
      "current",
      "pending",
      "unavailable",
      "invalidated"
    ]),
    reason: b([
      "sync_delayed",
      "method_unsupported",
      "deletion_changed",
      "auth_reconnect_required",
      "policy_unavailable"
    ]).nullable()
  }),
  reason: b([
    "invalid_preference",
    "engine_unavailable",
    "selection_conflict",
    "storage_write_failed",
    "estimate_unavailable",
    "policy_unavailable"
  ]).nullable()
});
const Rp = w({
  preference: On,
  selection_revision: D().int().min(1).max(2147483647),
  method_id: j,
  method_hash: O,
  operation_id: Qe()
});
w({
  selection: Rp.extend({
    selection_generation: D().int().min(1),
    job_id: O,
    updated_at: _e
  }).nullable(),
  compatibility: w({
    status: b(["supported", "pending"]),
    reason: b([
      "method_unsupported",
      "method_hash_mismatch",
      "engine_mismatch",
      "engine_unavailable"
    ]).nullable()
  }).nullable(),
  recalculation: Ne([
    w({
      job_id: O,
      status: E("invalidated"),
      completed_at: gi(),
      error_code: E("deletion_changed")
    }),
    w({
      job_id: O,
      method_id: j,
      calculation_view: E("recalculated"),
      status: b([
        "pending",
        "completed",
        "failed",
        "invalidated",
        "superseded"
      ]),
      processed_estimates: D().int().nonnegative(),
      created_at: _e,
      completed_at: _e.nullable(),
      error_code: S().regex(/^[a-z][a-z0-9_]{0,127}$/).nullable(),
      requires_advance: E(!1),
      selection_revision: D().int().min(1),
      selection_generation: D().int().min(1)
    })
  ]).nullable()
}).superRefine((e, t) => {
  (e.selection === null ? e.compatibility !== null || e.recalculation !== null : e.compatibility === null || e.recalculation === null) && t.addIssue({
    code: "custom",
    message: "Incomplete organization selection"
  }), e.selection && e.recalculation && (e.selection.job_id !== e.recalculation.job_id || "method_id" in e.recalculation && (e.recalculation.method_id !== e.selection.method_id || e.recalculation.selection_revision !== e.selection.selection_revision || e.recalculation.selection_generation !== e.selection.selection_generation)) && t.addIssue({
    code: "custom",
    message: "Organization selection binding mismatch"
  });
});
const qi = O.nullable(), Wt = "3.0.0", Nn = A(yt).max(32).refine((e) => new Set(e).size === e.length, "Duplicate reasons"), To = E("0.1.0"), Pp = [
  "chatgpt",
  "claude",
  "gemini",
  "perplexity",
  "notebooklm"
], Hi = b(Pp), tt = b(Dp).nullable(), Cn = b([
  "response_field",
  "request_field",
  "ui_selection",
  "unknown"
]), Ut = Qe(), Oo = D().int().min(1).max(2147483647), Zp = [
  "o200k-base-4.0.0-reference",
  "cl100k-base-4.0.0-reference",
  "observed-text-v1",
  // Uploaded image tokens from each vendor's published rule (A7), not a text tokenizer.
  "vendor-image-rules-1"
], Kt = b(Zp).nullable(), Mp = [
  "browser_request",
  "chatgpt_history",
  "claude_history",
  "perplexity_history",
  "gemini_history",
  "cowork_history",
  "notebooklm_history"
], Lp = Object.freeze({
  browser_request: ["request"],
  chatgpt_history: ["provider_message", "research_task"],
  claude_history: ["content_blocks", "research_task"],
  perplexity_history: ["workflow"],
  gemini_history: ["research_task"],
  cowork_history: ["provider_message"],
  notebooklm_history: ["provider_message"]
}), Wi = w({
  duration_seconds: Mi.refine((e) => {
    const t = Number(e);
    if (!(t > 0 && t <= 86400)) return !1;
    const n = /^(0|[1-9][0-9]*)(?:\.([0-9]+))?(?:e([+-]?[0-9]{1,3}))?$/.exec(e);
    if (!n) return !1;
    const i = BigInt(n[1] + (n[2] ?? "")), s = Number(n[3] ?? 0) - (n[2]?.length ?? 0);
    return s >= 0 ? i * 10n ** BigInt(s) <= 86400n : i <= 86400n * 10n ** BigInt(-s);
  }, "Timing duration must be greater than zero and at most one day"),
  source: b(Mp),
  scope: b([
    "request",
    "provider_message",
    "content_blocks",
    "workflow",
    "research_task"
  ]),
  completeness: b(["complete_for_scope", "partial", "unknown"]),
  profile_version: E("timing-observation-1")
}).superRefine((e, t) => {
  Lp[e.source].includes(e.scope) || t.addIssue({
    code: "custom",
    path: ["scope"],
    message: "Timing source and scope do not match"
  });
});
function jp(e) {
  return e === "claude" ? ["claude_history", "cowork_history"] : [`${e}_history`];
}
const ge = w({
  value: C.nullable(),
  evidence: b([
    "provider_reported",
    "official_tokenizer",
    "calibrated_estimate",
    "heuristic_estimate",
    "unknown",
    "not_applicable"
  ]),
  scope: b([
    "provider_request",
    "observed_text",
    "reconstructed_context",
    "provider_defined_subset"
  ]),
  completeness: b(["complete_for_scope", "partial", "unknown"]),
  profile_id: Kt,
  reason: yt.nullable()
}).superRefine((e, t) => {
  (e.evidence === "unknown" || e.evidence === "not_applicable") && (e.value !== null || e.reason === null) && t.addIssue({
    code: "custom",
    message: "Unknown or inapplicable measurements require null and a reason"
  }), e.value === null && e.reason === null && t.addIssue({
    code: "custom",
    message: "Missing quantity requires a reason"
  }), e.value !== null && e.evidence === "calibrated_estimate" && t.addIssue({
    code: "custom",
    message: "No calibrated tokenizer profiles are approved"
  });
}), Up = [
  "new_input_text",
  "logical_input_total",
  "input_uncached",
  "input_cache_read",
  "input_cache_write",
  "answer_output",
  "visible_thinking",
  "reported_reasoning",
  "output_total",
  "tool_input",
  "intermediate_output",
  "tool_output",
  "image_input_tokens",
  "image_output_tokens"
], Ki = [
  "answer_output",
  "visible_thinking",
  "tool_input",
  "intermediate_output"
], Bp = [
  ...Ki,
  "reported_reasoning",
  "tool_output",
  "image_input_tokens"
], or = [
  "visible_thinking",
  "tool_input",
  "intermediate_output",
  "tool_output"
], qp = w(
  Object.fromEntries(
    Up.map((e) => [e, ge])
  )
);
function Ao(e = "provider_usage_unavailable") {
  return {
    value: null,
    evidence: "unknown",
    scope: "observed_text",
    completeness: "unknown",
    profile_id: null,
    reason: e
  };
}
function Hp(e) {
  const t = Ki.map((a) => e[a]), n = t.filter((a) => a.value !== null), i = t.filter(
    (a) => a.value === null && a.evidence !== "not_applicable"
  );
  if (!n.length)
    return Ao(
      i[0]?.reason ?? e.answer_output.reason ?? "estimate_unavailable"
    );
  const s = new Set(n.map((a) => a.profile_id)), r = new Set(n.map((a) => a.evidence)), o = i.length > 0 || n.some(
    (a) => a.completeness !== "complete_for_scope"
  ) || s.size > 1 || r.size > 1;
  return {
    value: n.reduce((a, u) => a + BigInt(u.value), 0n).toString(),
    evidence: r.size === 1 ? [...r][0] : "heuristic_estimate",
    scope: "observed_text",
    completeness: o ? "partial" : "complete_for_scope",
    profile_id: s.size === 1 ? [...s][0] : null,
    reason: o ? i[0]?.reason ?? n.find(
      (a) => a.completeness !== "complete_for_scope"
    )?.reason ?? "partial_capture" : n[0].reason ?? null
  };
}
const No = (e, t) => et(e) === et(Hp(t)), Me = D().int().min(1).max(65536).nullable(), Vi = w({
  width: Me,
  height: Me,
  steps: D().int().min(1).max(1e4).nullable(),
  precision: b(["bfloat16", "float16", "float32", "unknown"]),
  architecture: b(["diffusion", "autoregressive", "unknown"])
}), Co = {
  width: Me,
  height: Me,
  dimension_source: b([
    "original",
    "provider_resized",
    "thumbnail_only",
    "unknown"
  ])
}, $o = b([
  "text_to_image",
  "image_edit",
  "inpaint",
  "upscale",
  "unknown"
]), Wp = b([
  "requested",
  "generating",
  "completed",
  "cancelled",
  "failed",
  "interrupted_unconfirmed"
]), Kp = w({
  count: C,
  origin: b(["new_upload", "retained_context", "unknown_origin"]),
  ...Co,
  detail: b(["low", "high", "auto", "unknown"]),
  token_profile_id: Kt,
  tokens: ge
}), Vp = w({
  operation_key: O,
  kind: $o,
  requested_count: C.nullable(),
  settings: Vi
}), Jp = w({
  operation_key: O,
  kind: $o,
  requested_count: C.nullable(),
  returned_count: C.nullable(),
  state: Wp,
  execution_evidence: b([
    "none",
    "provider_started",
    "content_observed",
    "usage_reported"
  ]),
  settings: Vi,
  model_id: tt,
  model_evidence: Cn
}), Xp = w({
  operation_key: O,
  count: C,
  ...Co,
  settings: Vi
}), Gp = w({
  input_images: A(Kp).max(100),
  requested_operations: A(Vp).max(100),
  coverage_reasons: Nn
}).refine(
  (e) => e.input_images.length + e.requested_operations.length <= 100,
  "Media entry limit"
).refine(
  (e) => new Set(e.requested_operations.map((t) => t.operation_key)).size === e.requested_operations.length,
  "Duplicate operation"
), Yp = w({
  image_operations: A(Jp).max(100),
  generated_images: A(Xp).max(100),
  coverage_reasons: Nn
}).superRefine((e, t) => {
  e.image_operations.length + e.generated_images.length > 100 && t.addIssue({ code: "custom", message: "Media entry limit" }), new Set(e.image_operations.map((n) => n.operation_key)).size !== e.image_operations.length && t.addIssue({ code: "custom", message: "Duplicate operation" });
  for (const n of e.generated_images)
    e.image_operations.some((i) => i.operation_key === n.operation_key) || t.addIssue({
      code: "custom",
      message: "Generated image requires operation"
    });
  for (const n of e.image_operations) {
    const i = e.generated_images.filter(
      (s) => s.operation_key === n.operation_key
    );
    n.returned_count !== null && C.safeParse(n.returned_count).success && i.every((s) => C.safeParse(s.count).success) && i.reduce((r, o) => r + BigInt(o.count), 0n) > BigInt(n.returned_count) && t.addIssue({
      code: "custom",
      message: "Grouped outputs exceed returned count"
    });
  }
}), Yn = Mi.refine((e) => {
  const t = Number(e);
  return t > 0 && t <= 86400;
}, "Media length must be greater than zero and at most one day"), Qp = w({
  role: b(["side_calls", "research", "storyboard"]),
  model_id: tt,
  model_evidence: Cn,
  tokens: ge,
  timing: Wi.nullable()
}), eh = bt("kind", [
  w({
    kind: E("image"),
    model_id: tt,
    count: C,
    width: Me,
    height: Me,
    // A stopped or failed job counts as one image only when generation visibly started.
    outcome: b(["returned", "started_not_returned"])
  }),
  w({
    kind: E("video"),
    model_id: tt,
    width: Me,
    height: Me,
    duration_seconds: Yn.nullable(),
    with_audio: Te().nullable()
  }),
  w({
    kind: E("speech"),
    length_basis: b(["audio_frames", "stored_length", "characters"]),
    seconds: Yn.nullable(),
    characters: C.nullable()
  }),
  w({
    kind: E("video_overview"),
    duration_seconds: Yn
  })
]), Do = w({
  text_components: A(Qp).max(16),
  media: A(eh).max(64)
}).superRefine((e, t) => {
  for (const [n, i] of e.media.entries())
    i.kind === "speech" && (i.length_basis === "characters" ? i.characters === null || i.characters === "0" || i.seconds !== null : i.seconds === null || i.characters !== null) && t.addIssue({
      code: "custom",
      path: ["media", n],
      message: "Speech length must match its basis"
    }), i.kind === "image" && (i.count === "0" || i.outcome === "started_not_returned" && i.count !== "1") && t.addIssue({
      code: "custom",
      path: ["media", n],
      message: "Image entries need a positive count; a started job is one image"
    });
}), th = [
  "local-file-text-utf8-pdfjs6.3.289-opc-v1",
  "observed-inline-file-text-v1"
], Fo = b(th), Ro = [
  "provider_processing",
  "ocr",
  "image_encoding",
  "retrieval_selection",
  "layout_and_drawing_text",
  "rendered_visibility",
  "formula_recalculation",
  "external_font_mapping"
], Po = b(Ro), nh = w({
  ...ge.shape,
  scope: E("extracted_file_text"),
  evidence: b(["heuristic_estimate", "unknown"])
}).superRefine((e, t) => {
  e.value === null && (e.reason === null || e.evidence !== "unknown" || e.completeness !== "unknown") && t.addIssue({
    code: "custom",
    message: "Missing file text requires unknown evidence and a reason"
  }), e.value !== null && (e.evidence !== "heuristic_estimate" || e.profile_id === null || e.completeness === "unknown" || e.reason === null) && t.addIssue({
    code: "custom",
    message: "Known file text requires an approved profile and scoped evidence"
  });
}), Ji = w({
  component_id: S().regex(
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/
  ),
  origin: b(["new_upload", "retained_context", "unknown_origin"]),
  extraction_profile_id: Fo,
  page_count: D().int().min(0).max(200).nullable(),
  tokens: nh,
  missing: A(Po).min(1).max(Ro.length).refine(
    (e) => new Set(e).size === e.length && e.includes("provider_processing"),
    "Local extraction does not establish provider processing"
  )
}), ih = w({
  schema_version: E(Wt),
  kind: E("request"),
  request_id: Ut,
  revision: Oo,
  conversation_key: O,
  key_version: E("1"),
  provider_request_key: O.nullable(),
  site: Hi,
  adapter_version: To,
  // `read_aloud` is speech made from a reply already shown (ChatGPT, G1) and
  // `notebook_guide` a NotebookLM guide the page asks for itself (W9).
  // Neither has a prompt: they add energy, never a request (see countsAsRequest).
  action: b([
    "send",
    "regenerate",
    "continue",
    "edit_and_send",
    "read_aloud",
    "notebook_guide"
  ]),
  dispatched_at: _e,
  ended_at: _e.nullable(),
  state: b([
    "dispatched",
    "generating",
    "completed",
    "cancelled",
    "failed",
    "interrupted_unconfirmed"
  ]),
  model_id: tt,
  model_evidence: Cn,
  features: A(
    b([
      "text",
      "thinking",
      "search",
      "document",
      "image_input",
      "image_generation",
      "image_edit",
      "audio",
      "video",
      "other_tool"
    ])
  ).max(10).refine((e) => new Set(e).size === e.length),
  observed_search_operations: C.nullable(),
  documents: w({
    extracted_text: A(Ji).max(100).nullable(),
    upload_count: C.nullable(),
    types: A(
      b([
        "text_pdf",
        "scanned_pdf",
        "text",
        "office",
        "other",
        "unknown"
      ])
    ).max(6).refine((e) => new Set(e).size === e.length),
    processing: b([
      "observed_text",
      "opaque",
      "mixed",
      "none",
      "unknown"
    ])
  }),
  media: Gp,
  coverage_reasons: Nn,
  policy_version: S().regex(/^(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})$/),
  company_dedup_key: qi
}).superRefine((e, t) => {
  e.coverage_reasons.includes("historical_timing_conflict") && t.addIssue({
    code: "custom",
    message: "Historical timing conflicts require a historical response"
  }), e.coverage_reasons.includes("no_live_request") && t.addIssue({
    code: "custom",
    message: "Only saved history rows can lack a live request"
  }), e.company_dedup_key !== null && t.addIssue({
    code: "custom",
    path: ["company_dedup_key"],
    message: "The company key travels beside the record"
  }), e.ended_at !== null && e.ended_at < e.dispatched_at && t.addIssue({ code: "custom", message: "End precedes dispatch" }), e.action === "read_aloud" && (e.site !== "chatgpt" || e.features.length !== 1 || e.features[0] !== "audio" || e.documents.upload_count !== null && e.documents.upload_count !== "0" || e.documents.types.length > 0 || e.documents.extracted_text !== null || !["none", "unknown"].includes(e.documents.processing) || e.media.input_images.length > 0 || e.media.requested_operations.length > 0 || e.observed_search_operations !== null && e.observed_search_operations !== "0") && t.addIssue({
    code: "custom",
    message: "Read aloud is ChatGPT audio only"
  }), e.action === "notebook_guide" && (e.site !== "notebooklm" || e.features.length !== 1 || e.features[0] !== "text" || e.documents.upload_count !== null && e.documents.upload_count !== "0" || e.documents.types.length > 0 || e.documents.extracted_text !== null || !["none", "unknown"].includes(e.documents.processing) || e.media.input_images.length > 0 || e.media.requested_operations.length > 0 || e.observed_search_operations !== null && e.observed_search_operations !== "0") && t.addIssue({
    code: "custom",
    message: "A notebook guide is NotebookLM text only"
  });
  const n = e.documents.extracted_text ?? [];
  new Set(n.map((i) => i.component_id)).size !== n.length && t.addIssue({
    code: "custom",
    message: "Duplicate file component identity"
  }), e.documents.upload_count !== null && C.safeParse(e.documents.upload_count).success && BigInt(n.filter((i) => i.origin === "new_upload").length) > BigInt(e.documents.upload_count) && t.addIssue({
    code: "custom",
    message: "New file components exceed observed uploads"
  }), n.length + e.media.input_images.length + e.media.requested_operations.length > 100 && t.addIssue({
    code: "custom",
    message: "Combined media metadata limit exceeded"
  });
}), sh = w({
  schema_version: E(Wt),
  kind: E("attempt"),
  attempt_id: Ut,
  request_id: Ut,
  revision: Oo,
  provider_attempt_key: O.nullable(),
  key_version: E("1"),
  started_at: _e,
  ended_at: _e.nullable(),
  state: b([
    "dispatch_only",
    "generating",
    "completed",
    "cancelled",
    "failed",
    "interrupted_unconfirmed"
  ]),
  execution_evidence: b([
    "none",
    "provider_started",
    "content_observed",
    "usage_reported"
  ]),
  model_id: tt,
  model_evidence: Cn,
  tokens: qp,
  timing: Wi.nullable(),
  media: Yp,
  generation: Do,
  coverage_reasons: Nn,
  tokenizer_profile_id: Kt,
  tokenizer_asset_hash: O.nullable(),
  proposed_method_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/).nullable(),
  company_dedup_key: qi
}).refine(
  (e) => !e.coverage_reasons.includes("historical_timing_conflict"),
  "Historical timing conflicts require a historical response"
).refine(
  (e) => !e.coverage_reasons.includes("no_live_request"),
  "Only saved history rows can lack a live request"
).refine(
  (e) => e.company_dedup_key === null,
  "The company key travels beside the record"
).refine(
  (e) => No(e.tokens.output_total, e.tokens) || e.tokens.output_total.evidence === "provider_reported" && e.tokens.output_total.scope === "provider_request" && e.tokens.output_total.value !== null,
  "Output total must equal its parts unless the provider reports it for the request"
).refine(
  (e) => e.ended_at === null || e.ended_at >= e.started_at,
  "End precedes start"
).refine(
  (e) => e.timing === null || e.timing.source === "browser_request",
  "Live attempts require browser timing"
).refine(
  (e) => e.timing?.completeness !== "complete_for_scope" || e.state === "completed",
  "Complete live timing requires a completed attempt"
), rh = Ne([
  ih,
  sh
]), oh = w({
  kind: b(["request", "attempt"]),
  record_id: Ut,
  company_dedup_key: O
});
w({
  schema_version: E(Wt),
  batch_id: Ut,
  sent_at: _e,
  client_version: To,
  deletion_epoch: D().int().min(0).max(Number.MAX_SAFE_INTEGER),
  records: A(rh).min(1).max(100),
  // Left out when no record has a key, so a server without company keys accepts it.
  company_dedup_keys: A(oh).max(100).optional()
}).superRefine((e, t) => {
  if (!e.company_dedup_keys) return;
  const n = new Set(
    e.records.map(
      (s) => s.kind === "request" ? `request:${s.request_id}` : `attempt:${s.attempt_id}`
    )
  ), i = e.company_dedup_keys.map((s) => `${s.kind}:${s.record_id}`);
  (new Set(i).size !== i.length || i.some((s) => !n.has(s))) && t.addIssue({
    code: "custom",
    path: ["company_dedup_keys"],
    message: "Each company key names one record of the batch"
  });
});
const ar = {
  historical_timing_conflict: [
    "Historical timing is uncertain. Valid message and token counts are retained.",
    "No action is required. Estimates use valid live timing when available, otherwise modeled timing."
  ],
  storage_write_failed: [
    "This activity could not be saved.",
    "Check browser storage and retry. Keep this tab open while recording recovers."
  ],
  ledger_integrity_failed: [
    "Some saved records need repair.",
    "Open tracking details. Affected totals remain unavailable until the records reconcile."
  ],
  tokenizer_unavailable: [
    "The request was recorded, but text counting failed.",
    "Reload the extension to restart its local counting worker."
  ],
  tokenizer_mapping_unverified: [
    "This text count uses an approximate model mapping.",
    "Read the counting scope in Details."
  ],
  sync_delayed: [
    "Saved activity is waiting to sync.",
    "Check the company connection; pending records will retry automatically."
  ],
  auth_reconnect_required: [
    "Your company connection needs renewal.",
    "Open Company and connect again with your work email."
  ],
  protocol_unsupported: [
    "This provider response is not supported by the current parser.",
    "Update the extension. Independently recorded activity remains available."
  ],
  estimate_unavailable: [
    "Resources are unavailable for part of this activity.",
    "Read the missing components in Details."
  ],
  method_update_invalid: [
    "The calculation update could not be verified.",
    "Keep the current valid method and contact the deployment operator."
  ],
  revision_conflict: [
    "Two versions of this record conflict.",
    "Keep the record in the reconciliation queue; do not create a replacement identity."
  ],
  capture_limit_exceeded: [
    "The measurement limit was reached. Your AI request continues.",
    "The recorded subtotal remains partial; review its coverage in Details."
  ],
  retention_expired: [
    "These company records are outside the retention period.",
    "Remove the expired local records after applying the server receipt."
  ],
  host_interference_detected: [
    "On-page measurement has stopped to preserve the AI tool.",
    "Reload the page and inspect the extension diagnostic."
  ],
  factor_incompatible: [
    "The available environmental factors cover different scopes.",
    "Show the supported components separately."
  ],
  payload_rejected: [
    "This numerical record does not match the accepted contract.",
    "Keep it quarantined and update the extension before retrying."
  ]
};
Object.freeze(
  Object.fromEntries(
    bo.map((e) => [
      e,
      Object.freeze({
        code: e,
        retryable: [
          "sync_delayed",
          "dependency_missing",
          "estimate_pending",
          "tokenizer_timeout",
          "storage_write_failed"
        ].includes(e),
        safe_message: ar[e]?.[0] ?? "This component has limited or unavailable coverage.",
        safe_action: ar[e]?.[1] ?? "Open Details for the affected scope and its recorded reason."
      })
    ])
  )
);
const Zo = Wt, ah = S().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3,6}Z$/).refine((e) => {
  const t = e.replace(/(\.\d{3})\d*Z$/, "$1Z");
  return Number.isFinite(Date.parse(t)) && new Date(t).toISOString() === t;
}, "Invalid history date"), ch = w(
  Object.fromEntries(
    Bp.map((e) => [e, ge])
  )
);
function uh(e, t) {
  return e.evidence === "provider_reported" ? t === "response" && e.scope === "provider_request" && e.value !== null : e.scope === "observed_text" && (e.value === null ? e.evidence === "unknown" : e.evidence === "heuristic_estimate" && e.profile_id !== null);
}
function lh(e, t, n) {
  return n === "prompt" ? [...Ki, "reported_reasoning", "tool_output"].every((i) => t[i].evidence === "not_applicable") : t.image_input_tokens.evidence !== "not_applicable" ? !1 : e.evidence === "provider_reported" ? !0 : No(e, t);
}
const dh = w({
  schema_version: E(Zo),
  kind: E("history_message"),
  message_key: O,
  role: b(["prompt", "response"]),
  conversation_key: O,
  key_version: E("1"),
  site: Hi,
  parent_key: O.nullable(),
  prompt_key: O.nullable(),
  provider_request_key: O.nullable(),
  provider_attempt_key: O.nullable(),
  occurred_at: ah.nullable(),
  date_basis: b([
    "message_created",
    "entry_created",
    "turn_created",
    "unknown"
  ]),
  observed_at: _e,
  proposed_method_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/),
  proposed_method_hash: O,
  model_id: tt,
  tokens: ge,
  parts: ch.nullable(),
  generation: Do,
  inline_file_text: A(Ji.omit({ component_id: !0 })).max(16).nullable(),
  timing: Wi.nullable(),
  text_complete: Te(),
  coverage_reasons: A(yt).max(33).refine(
    (e) => new Set(e).size === e.length && (e.length <= 32 || e.includes("historical_timing_conflict")),
    "Historical timing conflict reserves one additional reason slot"
  ),
  company_dedup_key: qi
}).superRefine((e, t) => {
  e.company_dedup_key !== null && t.addIssue({
    code: "custom",
    path: ["company_dedup_key"],
    message: "The company key travels beside the message"
  }), e.coverage_reasons.includes("no_live_request") && e.site !== "notebooklm" && t.addIssue({
    code: "custom",
    path: ["coverage_reasons"],
    message: "Only NotebookLM Studio rows lack a live request"
  }), e.coverage_reasons.includes("historical_timing_conflict") && (e.role !== "response" || e.timing !== null) && t.addIssue({
    code: "custom",
    path: ["timing"],
    message: "Conflicting historical response timing must be unavailable"
  }), e.timing !== null && (e.role !== "response" || !jp(e.site).includes(e.timing.source) || e.timing.completeness === "complete_for_scope" && !e.text_complete) && t.addIssue({
    code: "custom",
    path: ["timing"],
    message: "Historical timing must match the response provider"
  }), (e.occurred_at === null != (e.date_basis === "unknown") || !uh(e.tokens, e.role) || e.role === "prompt" && e.provider_attempt_key !== null) && t.addIssue({
    code: "custom",
    message: "Invalid historical text evidence"
  }), (e.role === "response" && e.parts === null || e.parts !== null && !lh(e.tokens, e.parts, e.role)) && t.addIssue({
    code: "custom",
    path: ["parts"],
    message: "Historical parts do not match the recorded total"
  }), e.role === "prompt" && (e.generation.text_components.length || e.generation.media.length) && t.addIssue({
    code: "custom",
    path: ["generation"],
    message: "Prompts carry no generated output"
  });
});
w({
  schema_version: E(Zo),
  site: Hi,
  conversation_key: O,
  observed_at: _e,
  deletion_epoch: D().int().min(0).max(Number.MAX_SAFE_INTEGER),
  messages: A(dh).max(100),
  branch_scope: b(["selected_branch", "loaded_messages", "unknown"]),
  selected_leaf_key: O.nullable(),
  branch_message_keys: A(O).max(100).nullable(),
  root_message_key: O.nullable(),
  first_request_verified: Te(),
  has_earlier: Te().nullable(),
  has_later: Te().nullable(),
  // Company keys of the page's messages, beside them as in a usage batch (W11). Left out
  // when no message has one.
  company_dedup_keys: A(
    w({
      message_key: O,
      company_dedup_key: O
    })
  ).max(100).optional(),
  // Message keys of the member's saved Claude messages that this page's exact rows replace,
  // once, so the server stops counting their text estimate. Keyed hashes like message_key,
  // never ids or text. Left out when empty; a published browser never sends it.
  replaced_message_keys: A(O).max(200).optional(),
  // Claude's exact input for the turn of an exact reply of this page (owner decision of 23 Nov
  // 2026, package EC): new input, input written to the cache and input read from it, as
  // Claude reports them. The server counts that input once for the turn, as the browser
  // does: the reply's tool results and the prompt it answers add none of their own. Left
  // out when empty; the published 0.1.0 never sends it.
  exact_inputs: A(
    w({
      message_key: O,
      new: C,
      cache_write: C,
      cache_read: C
    })
  ).max(100).optional()
}).superRefine((e, t) => {
  if (e.exact_inputs) {
    const n = new Map(e.messages.map((s) => [s.message_key, s])), i = e.exact_inputs.map((s) => s.message_key);
    (e.site !== "claude" || new Set(i).size !== i.length || i.some((s) => {
      const r = n.get(s);
      return !r || r.role !== "response" || r.prompt_key === null || r.tokens.evidence !== "provider_reported";
    })) && t.addIssue({
      code: "custom",
      path: ["exact_inputs"],
      message: "Exact input names Claude replies of this page that carry Claude's own count, each once"
    });
  }
  if (e.replaced_message_keys) {
    const n = new Set(e.messages.map((s) => s.message_key)), i = e.replaced_message_keys;
    (e.site !== "claude" || new Set(i).size !== i.length || i.some((s) => n.has(s))) && t.addIssue({
      code: "custom",
      path: ["replaced_message_keys"],
      message: "Replaced keys name other saved Claude messages, each once"
    });
  }
  if ((new Set(e.messages.map((n) => n.message_key)).size !== e.messages.length || e.messages.some(
    (n) => n.site !== e.site || n.conversation_key !== e.conversation_key
  ) || e.first_request_verified && e.root_message_key === null || e.branch_message_keys !== null && new Set(e.branch_message_keys).size !== e.branch_message_keys.length) && t.addIssue({ code: "custom", message: "Inconsistent history page" }), e.company_dedup_keys) {
    const n = new Set(e.messages.map((s) => s.message_key)), i = e.company_dedup_keys.map((s) => s.message_key);
    (new Set(i).size !== i.length || i.some((s) => !n.has(s))) && t.addIssue({
      code: "custom",
      path: ["company_dedup_keys"],
      message: "Each company key names one message of the page"
    });
  }
});
const fh = 2097152, ph = 262144, Qn = D().int().min(0).max(fh);
w({
  units: Qn,
  fileUnits: A(D().int().min(0).max(ph)).max(16).nullable(),
  // Lengths and counts of the reply's other text parts and other-model text, so a
  // message whose reasoning or tool input changed is counted again.
  partUnits: Ze(b(or), Qn),
  partTokens: Ze(b(or), ge),
  componentUnits: A(Qn.nullable()).max(16),
  componentTokens: A(ge.nullable()).max(16),
  implementationId: S().min(1).max(128),
  profileId: S().min(1).max(128),
  assetHash: S().min(1).max(256),
  tokens: ge,
  inlineFileComponents: A(Ji.omit({ component_id: !0 })).max(16).nullable(),
  // The tokens of each text or code file Perplexity Computer created in the reply, by a
  // keyed hash of the file's id, and whether they were counted from its content or its
  // size (14 Oct 2026). Kept so a reopened chat neither downloads nor counts it again.
  computerFiles: ke(
    S().regex(/^[0-9a-f]{64}$/),
    w({
      tokens: C,
      basis: b(["content", "size"])
    })
  ).refine((e) => Object.keys(e).length <= 64).optional()
});
const hh = [
  "total",
  "tool_output",
  "image_input_tokens",
  "other_models"
], mh = w({
  quantity: E("extracted_file_text"),
  scope: E("extracted_file_text"),
  unit: E("tokens"),
  additive: E(!1),
  value: C.nullable(),
  measurement_group: w({
    origin: b(["new_upload", "retained_context", "unknown_origin"]),
    extraction_profile_id: Fo,
    evidence: b(["heuristic_estimate", "unknown"]),
    profile_id: Kt
  }),
  applicable_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  contributing_component_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  unknown_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  partial_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  unvalidated_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  reason_counts: Ze(
    yt,
    D().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
  ),
  missing_counts: Ze(
    Po,
    D().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
  )
});
function _h(e, t) {
  if ([
    "observed_prompt_count",
    "observed_response_count",
    "prompt_count",
    "response_count",
    "dated_message_count",
    "undated_message_count",
    "calculated_message_count",
    "uncalculated_message_count",
    "matched_live_message_count",
    "unresolved_overlap_message_count",
    "conflicting_message_count"
  ].some((a) => !C.safeParse(e[a]).success))
    return;
  const i = (a) => BigInt(e[a]), s = i("observed_prompt_count") + i("observed_response_count"), r = i("calculated_message_count") + i("uncalculated_message_count"), o = i("prompt_count") + i("response_count") - r;
  (s !== i("dated_message_count") + i("undated_message_count") || s !== r + i("matched_live_message_count") + i("conflicting_message_count") || o < 0n || o > i("response_count") || // Rows no live capture can produce (no_live_request) contribute without waiting for a
  // live match, so only the other contributing rows are unresolved.
  i("unresolved_overlap_message_count") > r) && t.addIssue({
    code: "custom",
    message: "Inconsistent historical coverage"
  });
  for (const a of e.resources)
    (a.value === null != (a.status === "unavailable") || !("requested_method" in a) && a.profile_selection === "unavailable" != (a.selected_profile_id === null)) && t.addIssue({
      code: "custom",
      message: "Inconsistent historical assessment"
    });
}
const gh = A(
  Ne([
    w({
      quantity: b([
        "energy",
        "carbon",
        "water_direct",
        "water_upstream",
        "water_total"
      ]),
      value: Tn.nullable(),
      unit: b(["kWh", "gCO2e", "gCO2", "L"]),
      scope: E("historical_visible_response"),
      method_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/),
      method_hash: O,
      status: b(["partial_estimate", "unavailable"]),
      validation_state: E("unvalidated_reference"),
      profile_selection: b(["highest_comparable", "unavailable"]),
      selected_profile_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,159}$/).nullable(),
      reasons: A(yt).max(32),
      missing_components: A(S().regex(/^[a-z0-9_]{1,100}$/)).max(32),
      known_message_count: C,
      unknown_message_count: C
    }),
    $p
  ])
).max(160);
w({
  schema_version: E(Wt),
  scope: E("loaded_history"),
  status: b(["available", "empty", "unavailable"]),
  observed_prompt_count: C,
  observed_response_count: C,
  prompt_count: C,
  response_count: C,
  dated_message_count: C,
  undated_message_count: C,
  calculated_message_count: C,
  uncalculated_message_count: C,
  matched_live_message_count: C,
  unresolved_overlap_message_count: C,
  conflicting_message_count: C,
  first_request_verified: Te(),
  branch_scope: b(["selected_branch", "loaded_messages", "unknown"]),
  provider_history_complete: E(!1),
  tokens: A(
    w({
      role: b(["prompt", "response"]),
      part: b(hh),
      profile_id: Kt,
      evidence: b(["heuristic_estimate", "provider_reported", "unknown"]),
      value: C.nullable(),
      known_message_count: C,
      unknown_message_count: C
    })
  ).max(128),
  file_text: A(mh).max(256),
  file_text_coverage: w({
    observed_message_count: C,
    unknown_message_count: C,
    scope: E("extracted_file_text"),
    additive: E(!1)
  }),
  resources: gh
}).superRefine(_h);
const Mo = "gpt-tokenizer-4.0.0", Xi = "o200k-base-4.0.0-reference", wi = Object.freeze({
  jobId: 128,
  modelId: 256,
  fieldTextUnits: 2097152,
  fieldTextBytes: 8 * 1024 * 1024,
  inlineFileTextUnits: 262144,
  // Six text fields, up to 16 inline files and up to 16 other-model components.
  fields: 38,
  pendingJobs: 16,
  timeoutMs: 2e4
}), vh = new TextEncoder();
function bh(e, t) {
  const n = Object.keys(e).sort(), i = [...t].sort();
  return n.length === i.length && n.every((s, r) => s === i[r]);
}
function yh(e, t) {
  return typeof e == "string" && e.length > 0 && e.length <= wi.jobId && !/[\u0000-\u001f\u007f]/.test(e) && Number.isSafeInteger(t) && Number(t) >= 1;
}
function ei(e, t) {
  return {
    jobId: e.jobId,
    revision: e.revision,
    measurement: Ao(t),
    assetHash: null,
    profileId: null,
    encoding: null,
    modelExactness: "unverified",
    status: "unavailable"
  };
}
function Lo(e, t) {
  const n = e.profiles.filter(
    (i) => i.profileId === t
  );
  return n.length === 1 ? n[0] : null;
}
function wh(e, t, n) {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const i = e;
  if (!bh(i, [
    "assetHash",
    "encoding",
    "jobId",
    "measurement",
    "modelExactness",
    "profileId",
    "revision",
    "status"
  ]) || i.jobId !== t.jobId || i.revision !== t.revision || i.modelExactness !== "unverified")
    return !1;
  const s = ge.safeParse(i.measurement);
  return i.status === "counted" ? !s.success || s.data.value === null || !/^(0|[1-9][0-9]*)$/.test(s.data.value) || BigInt(s.data.value) > BigInt(vh.encode(t.text).byteLength) || t.text.length > 0 && BigInt(s.data.value) === 0n ? !1 : i.assetHash === n.assetHash && i.profileId === n.profileId && i.encoding === n.encoding && s.data.evidence === "heuristic_estimate" && s.data.scope === "observed_text" && s.data.completeness === "complete_for_scope" && s.data.profile_id === n.profileId && s.data.reason === "tokenizer_mapping_unverified" : i.status === "unavailable" && s.success && s.data.value === null && s.data.evidence === "unknown" && s.data.scope === "observed_text" && s.data.completeness === "unknown" && s.data.profile_id === null && (s.data.reason === "tokenizer_unavailable" || s.data.reason === "capture_limit_exceeded") && i.assetHash === null && i.profileId === null && i.encoding === null;
}
const xh = "4.0.0", kh = { o200k_base: { profile_id: "o200k-base-4.0.0-reference", asset_hash: "4cd35a52f4ece645422670151ccbdbd6afd2bcb47b83efd13e47e5d8942aecb4" }, cl100k_base: { profile_id: "cl100k-base-4.0.0-reference", asset_hash: "b56372fb0b95dbd370f9de6f44b6c15006a8a36980fbc6c0568a0108971aea45" } };
var Gi = {
  version: xh,
  profiles: kh
};
const xi = Object.freeze({
  "o200k-base-4.0.0-reference": "o200k_base",
  "cl100k-base-4.0.0-reference": "cl100k_base"
}), jo = Object.freeze({
  id: Mo,
  profiles: Object.freeze(
    Object.entries(xi).map(
      ([e, t]) => Object.freeze({
        profileId: e,
        encoding: t,
        assetHash: Gi.profiles[t].asset_hash
      })
    )
  )
}), ti = (e) => typeof e == "string" && /^[a-z0-9][a-z0-9._-]{0,127}$/.test(e), ni = (e, t) => Object.keys(e).sort().join(",") === t.sort().join(","), mn = () => {
  throw new Error("tokenizer_manifest_invalid");
};
function Sh(e) {
  (!e || typeof e != "object" || Array.isArray(e) || !ti(e.id) || !Array.isArray(e.profiles) || e.profiles.length < 1 || e.profiles.length > 16 || !ni(e, ["id", "profiles"]) && !ni(e, ["id", "profiles", "count"]) || "count" in e && typeof e.count != "function") && mn();
  const t = e.profiles.map((n) => ((!n || typeof n != "object" || Array.isArray(n) || !ni(n, ["profileId", "encoding", "assetHash"]) || !ti(n.profileId) || !ti(n.encoding) || typeof n.assetHash != "string" || !/^[a-f0-9]{64}$/.test(n.assetHash) || !ge.safeParse({
    value: "0",
    evidence: "heuristic_estimate",
    scope: "observed_text",
    completeness: "complete_for_scope",
    profile_id: n.profileId,
    reason: "tokenizer_mapping_unverified"
  }).success) && mn(), Object.freeze({
    profileId: n.profileId,
    encoding: n.encoding,
    assetHash: n.assetHash
  })));
  return new Set(t.map((n) => n.profileId)).size !== t.length && mn(), Object.freeze({ id: e.id, profiles: Object.freeze(t) });
}
function Eh(e, t) {
  const n = Sh(e);
  return Lo(n, t) || mn(), Object.freeze({
    selection: Object.freeze({ implementationId: n.id, profileId: t }),
    manifest: n
  });
}
Eh(
  jo,
  Xi
);
const dn = { maxDimension: 65535, budget: null }, re = (e, t) => ({ kind: "openai_patches", ...e, multiplier: t }), Ve = (e, t) => ({
  kind: "openai_tiles",
  base: e,
  tile: t
}), zh = Object.freeze({
  "gpt-6-astra": re(dn, 120),
  "gpt-5-6-sol": re(dn, 120),
  "gpt-5-6-terra": re(dn, 120),
  "gpt-5-6-luna": re(dn, 120),
  // Auto is original detail: up to 10,000 patches and 6,000 pixels.
  "gpt-5-5": re({ maxDimension: 6e3, budget: 1e4 }, 120),
  // Auto is high detail: up to 2,500 patches and 2,048 pixels.
  "gpt-5-4": re({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-4-mini": re({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-4-nano": re({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-2": re({ maxDimension: 2048, budget: 6144 }, 120),
  "gpt-4-1-mini": re({ maxDimension: 2048, budget: 6144 }, 162),
  // Retired patch models have a published multiplier but no sizing row; they use the
  // sizing of the other patch models of their generation.
  "gpt-5-mini": re({ maxDimension: 2048, budget: 6144 }, 120),
  "gpt-5-nano": re({ maxDimension: 2048, budget: 6144 }, 150),
  "o4-mini": re({ maxDimension: 2048, budget: 6144 }, 172),
  "gpt-5-1": Ve(70, 140),
  "gpt-5": Ve(70, 140),
  "gpt-4o": Ve(85, 170),
  "gpt-4-1": Ve(85, 170),
  "gpt-4o-mini": Ve(2833, 5667),
  o1: Ve(75, 150),
  o3: Ve(75, 150)
});
zh["gpt-6-astra"];
const cr = /* @__PURE__ */ new Map(), Ih = new TextEncoder();
function Th(e, t) {
  if (gt(e) !== t)
    throw new Error("tokenizer_unavailable");
}
async function Oh(e) {
  let t = cr.get(e);
  return t || (t = (async () => {
    const [n, i] = e === "o200k_base" ? await Promise.all([
      import("./o200k_base-CvUU9Zmb.js"),
      import("./o200k_base-BYTgCC8K.js")
    ]) : await Promise.all([
      import("./cl100k_base-BhiXU_Ff.js"),
      import("./cl100k_base-MCg9hpJE.js")
    ]);
    return Th(i.default, Gi.profiles[e].asset_hash), n.setMergeCacheSize(0), n;
  })(), cr.set(e, t)), t;
}
async function Ah(e) {
  if (e.text.length > wi.fieldTextBytes || Ih.encode(e.text).byteLength > wi.fieldTextBytes)
    return ei(e, "capture_limit_exceeded");
  const t = e.profileId ?? Xi;
  if (!(t in xi))
    return ei(e, "tokenizer_unavailable");
  const n = xi[t];
  try {
    const s = (await Oh(n)).countTokens(e.text, { disallowedSpecial: /* @__PURE__ */ new Set() });
    return {
      jobId: e.jobId,
      revision: e.revision,
      measurement: {
        value: String(s),
        evidence: "heuristic_estimate",
        scope: "observed_text",
        completeness: "complete_for_scope",
        profile_id: t,
        reason: "tokenizer_mapping_unverified"
      },
      assetHash: Gi.profiles[n].asset_hash,
      profileId: t,
      encoding: n,
      modelExactness: "unverified",
      status: "counted"
    };
  } catch {
    return ei(e, "tokenizer_unavailable");
  }
}
const Yi = Object.freeze({
  ...jo,
  count: Ah
});
new TextEncoder();
async function Nh(e, t = Yi) {
  if (!e || typeof e != "object" || typeof e.text != "string" || e.modelId !== null && typeof e.modelId != "string" || !yh(e.jobId, e.revision) || e.profileId !== void 0 && typeof e.profileId != "string")
    throw new Error("payload_rejected");
  return t.count(e);
}
var te = Uint8Array, dt = Uint16Array, Ch = Int32Array, Uo = new te([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), Bo = new te([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), $h = new te([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), qo = function(e, t) {
  for (var n = new dt(31), i = 0; i < 31; ++i)
    n[i] = t += 1 << e[i - 1];
  for (var s = new Ch(n[30]), i = 1; i < 30; ++i)
    for (var r = n[i]; r < n[i + 1]; ++r)
      s[r] = r - n[i] << 5 | i;
  return { b: n, r: s };
}, Ho = qo(Uo, 2), Wo = Ho.b, Dh = Ho.r;
Wo[28] = 258, Dh[258] = 28;
var Fh = qo(Bo, 0), Rh = Fh.b, ki = new dt(32768);
for (var U = 0; U < 32768; ++U) {
  var Fe = (U & 43690) >> 1 | (U & 21845) << 1;
  Fe = (Fe & 52428) >> 2 | (Fe & 13107) << 2, Fe = (Fe & 61680) >> 4 | (Fe & 3855) << 4, ki[U] = ((Fe & 65280) >> 8 | (Fe & 255) << 8) >> 1;
}
var Pt = (function(e, t, n) {
  for (var i = e.length, s = 0, r = new dt(t); s < i; ++s)
    e[s] && ++r[e[s] - 1];
  var o = new dt(t);
  for (s = 1; s < t; ++s)
    o[s] = o[s - 1] + r[s - 1] << 1;
  var a;
  if (n) {
    a = new dt(1 << t);
    var u = 15 - t;
    for (s = 0; s < i; ++s)
      if (e[s])
        for (var c = s << 4 | e[s], f = t - e[s], l = o[e[s] - 1]++ << f, m = l | (1 << f) - 1; l <= m; ++l)
          a[ki[l] >> u] = c;
  } else
    for (a = new dt(i), s = 0; s < i; ++s)
      e[s] && (a[s] = ki[o[e[s] - 1]++] >> 15 - e[s]);
  return a;
}), Vt = new te(288);
for (var U = 0; U < 144; ++U)
  Vt[U] = 8;
for (var U = 144; U < 256; ++U)
  Vt[U] = 9;
for (var U = 256; U < 280; ++U)
  Vt[U] = 7;
for (var U = 280; U < 288; ++U)
  Vt[U] = 8;
var Ko = new te(32);
for (var U = 0; U < 32; ++U)
  Ko[U] = 5;
var Ph = /* @__PURE__ */ Pt(Vt, 9, 1), Zh = /* @__PURE__ */ Pt(Ko, 5, 1), ii = function(e) {
  for (var t = e[0], n = 1; n < e.length; ++n)
    e[n] > t && (t = e[n]);
  return t;
}, pe = function(e, t, n) {
  var i = t / 8 | 0;
  return (e[i] | e[i + 1] << 8) >> (t & 7) & n;
}, si = function(e, t) {
  var n = t / 8 | 0;
  return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, Mh = function(e) {
  return (e + 7) / 8 | 0;
}, _n = function(e, t, n) {
  return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new te(e.subarray(t, n));
}, Lh = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
], he = function(e, t, n) {
  var i = new Error(t || Lh[e]);
  if (i.code = e, Error.captureStackTrace && Error.captureStackTrace(i, he), !n)
    throw i;
  return i;
}, jh = function(e, t, n, i) {
  var s = e.length, r = 0;
  if (!s || t.f && !t.l)
    return n || new te(0);
  var o = !n, a = o || t.i != 2, u = t.i;
  o && (n = new te(s * 3));
  var c = function(Yt) {
    var Qt = n.length;
    if (Yt > Qt) {
      var Et = new te(Math.max(Qt * 2, Yt));
      Et.set(n), n = Et;
    }
  }, f = t.f || 0, l = t.p || 0, m = t.b || 0, h = t.l, p = t.d, y = t.m, x = t.n, k = s * 8;
  do {
    if (!h) {
      f = pe(e, l, 1);
      var N = pe(e, l + 1, 3);
      if (l += 3, N)
        if (N == 1)
          h = Ph, p = Zh, y = 9, x = 5;
        else if (N == 2) {
          var F = pe(e, l, 31) + 257, V = pe(e, l + 10, 15) + 4, Ce = F + pe(e, l + 5, 31) + 1;
          l += 14;
          for (var be = new te(Ce), Ee = new te(19), J = 0; J < V; ++J)
            Ee[$h[J]] = pe(e, l + J * 3, 7);
          l += V * 3;
          for (var nt = ii(Ee), wt = (1 << nt) - 1, $n = Pt(Ee, nt, 1), J = 0; J < Ce; ) {
            var Jt = $n[pe(e, l, wt)];
            l += Jt & 15;
            var L = Jt >> 4;
            if (L < 16)
              be[J++] = L;
            else {
              var W = 0, ze = 0;
              for (L == 16 ? (ze = 3 + pe(e, l, 3), l += 2, W = be[J - 1]) : L == 17 ? (ze = 3 + pe(e, l, 7), l += 3) : L == 18 && (ze = 11 + pe(e, l, 127), l += 7); ze--; )
                be[J++] = W;
            }
          }
          var it = be.subarray(0, F), ye = be.subarray(F);
          y = ii(it), x = ii(ye), h = Pt(it, y, 1), p = Pt(ye, x, 1);
        } else
          he(1);
      else {
        var L = Mh(l) + 4, se = e[L - 4] | e[L - 3] << 8, Z = L + se;
        if (Z > s) {
          u && he(0);
          break;
        }
        a && c(m + se), n.set(e.subarray(L, Z), m), t.b = m += se, t.p = l = Z * 8, t.f = f;
        continue;
      }
      if (l > k) {
        u && he(0);
        break;
      }
    }
    a && c(m + 131072);
    for (var xt = (1 << y) - 1, Dn = (1 << x) - 1, kt = l; ; kt = l) {
      var W = h[si(e, l) & xt], we = W >> 4;
      if (l += W & 15, l > k) {
        u && he(0);
        break;
      }
      if (W || he(2), we < 256)
        n[m++] = we;
      else if (we == 256) {
        kt = l, h = null;
        break;
      } else {
        var Xt = we - 254;
        if (we > 264) {
          var J = we - 257, qe = Uo[J];
          Xt = pe(e, l, (1 << qe) - 1) + Wo[J], l += qe;
        }
        var St = p[si(e, l) & Dn], st = St >> 4;
        St || he(3), l += St & 15;
        var ye = Rh[st];
        if (st > 3) {
          var qe = Bo[st];
          ye += si(e, l) & (1 << qe) - 1, l += qe;
        }
        if (l > k) {
          u && he(0);
          break;
        }
        a && c(m + 131072);
        var rt = m + Xt;
        if (m < ye) {
          var He = r - ye, Gt = Math.min(ye, rt);
          for (He + m < 0 && he(3); m < Gt; ++m)
            n[m] = i[He + m];
        }
        for (; m < rt; ++m)
          n[m] = n[m - ye];
      }
    }
    t.l = h, t.p = kt, t.b = m, t.f = f, h && (f = 1, t.m = y, t.d = p, t.n = x);
  } while (!f);
  return m != n.length && o ? _n(n, 0, m) : n.subarray(0, m);
}, Uh = /* @__PURE__ */ new te(0), Bh = /* @__PURE__ */ (function() {
  function e(t, n) {
    typeof t == "function" && (n = t, t = {}), this.ondata = n;
    var i = t && t.dictionary && t.dictionary.subarray(-32768);
    this.s = { i: 0, b: i ? i.length : 0 }, this.o = new te(32768), this.p = new te(0), i && this.o.set(i);
  }
  return e.prototype.e = function(t) {
    if (this.ondata || he(5), this.d && he(4), !this.p.length)
      this.p = t;
    else if (t.length) {
      var n = new te(this.p.length + t.length);
      n.set(this.p), n.set(t, this.p.length), this.p = n;
    }
  }, e.prototype.c = function(t) {
    this.s.i = +(this.d = t || !1);
    var n = this.s.b, i = jh(this.p, this.s, this.o);
    this.ondata(_n(i, n, this.s.b), this.d), this.o = _n(i, this.s.b - 32768), this.s.b = this.o.length, this.p = _n(this.p, this.s.p / 8 | 0), this.s.p &= 7;
  }, e.prototype.push = function(t, n) {
    this.e(t), this.c(n);
  }, e;
})(), qh = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), Hh = 0;
try {
  qh.decode(Uh, { stream: !0 }), Hh = 1;
} catch {
}
var Je = {}, ri = {}, ur;
function Wh() {
  return ur || (ur = 1, (function(e) {
    Object.defineProperty(e, "__esModule", { value: !0 }), e.CHAR = `	
\r -\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}`, e.S = ` 	\r
`, e.NAME_START_CHAR = ":A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}", e.NAME_CHAR = "-" + e.NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040", e.CHAR_RE = new RegExp("^[" + e.CHAR + "]$", "u"), e.S_RE = new RegExp("^[" + e.S + "]+$", "u"), e.NAME_START_CHAR_RE = new RegExp("^[" + e.NAME_START_CHAR + "]$", "u"), e.NAME_CHAR_RE = new RegExp("^[" + e.NAME_CHAR + "]$", "u"), e.NAME_RE = new RegExp("^[" + e.NAME_START_CHAR + "][" + e.NAME_CHAR + "]*$", "u"), e.NMTOKEN_RE = new RegExp("^[" + e.NAME_CHAR + "]+$", "u");
    var t = 9, n = 10, i = 13, s = 32;
    e.S_LIST = [s, n, i, t];
    function r(c) {
      return c >= s && c <= 55295 || c === n || c === i || c === t || c >= 57344 && c <= 65533 || c >= 65536 && c <= 1114111;
    }
    e.isChar = r;
    function o(c) {
      return c === s || c === n || c === i || c === t;
    }
    e.isS = o;
    function a(c) {
      return c >= 65 && c <= 90 || c >= 97 && c <= 122 || c === 58 || c === 95 || c === 8204 || c === 8205 || c >= 192 && c <= 214 || c >= 216 && c <= 246 || c >= 248 && c <= 767 || c >= 880 && c <= 893 || c >= 895 && c <= 8191 || c >= 8304 && c <= 8591 || c >= 11264 && c <= 12271 || c >= 12289 && c <= 55295 || c >= 63744 && c <= 64975 || c >= 65008 && c <= 65533 || c >= 65536 && c <= 983039;
    }
    e.isNameStartChar = a;
    function u(c) {
      return a(c) || c >= 48 && c <= 57 || c === 45 || c === 46 || c === 183 || c >= 768 && c <= 879 || c >= 8255 && c <= 8256;
    }
    e.isNameChar = u;
  })(ri)), ri;
}
var oi = {}, lr;
function Kh() {
  return lr || (lr = 1, (function(e) {
    Object.defineProperty(e, "__esModule", { value: !0 }), e.CHAR = "-\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}", e.RESTRICTED_CHAR = "-\b\v\f-\x7F-\x84\x86-\x9F", e.S = ` 	\r
`, e.NAME_START_CHAR = ":A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}", e.NAME_CHAR = "-" + e.NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040", e.CHAR_RE = new RegExp("^[" + e.CHAR + "]$", "u"), e.RESTRICTED_CHAR_RE = new RegExp("^[" + e.RESTRICTED_CHAR + "]$", "u"), e.S_RE = new RegExp("^[" + e.S + "]+$", "u"), e.NAME_START_CHAR_RE = new RegExp("^[" + e.NAME_START_CHAR + "]$", "u"), e.NAME_CHAR_RE = new RegExp("^[" + e.NAME_CHAR + "]$", "u"), e.NAME_RE = new RegExp("^[" + e.NAME_START_CHAR + "][" + e.NAME_CHAR + "]*$", "u"), e.NMTOKEN_RE = new RegExp("^[" + e.NAME_CHAR + "]+$", "u");
    var t = 9, n = 10, i = 13, s = 32;
    e.S_LIST = [s, n, i, t];
    function r(l) {
      return l >= 1 && l <= 55295 || l >= 57344 && l <= 65533 || l >= 65536 && l <= 1114111;
    }
    e.isChar = r;
    function o(l) {
      return l >= 1 && l <= 8 || l === 11 || l === 12 || l >= 14 && l <= 31 || l >= 127 && l <= 132 || l >= 134 && l <= 159;
    }
    e.isRestrictedChar = o;
    function a(l) {
      return l === 9 || l === 10 || l === 13 || l > 31 && l < 127 || l === 133 || l > 159 && l <= 55295 || l >= 57344 && l <= 65533 || l >= 65536 && l <= 1114111;
    }
    e.isCharAndNotRestricted = a;
    function u(l) {
      return l === s || l === n || l === i || l === t;
    }
    e.isS = u;
    function c(l) {
      return l >= 65 && l <= 90 || l >= 97 && l <= 122 || l === 58 || l === 95 || l === 8204 || l === 8205 || l >= 192 && l <= 214 || l >= 216 && l <= 246 || l >= 248 && l <= 767 || l >= 880 && l <= 893 || l >= 895 && l <= 8191 || l >= 8304 && l <= 8591 || l >= 11264 && l <= 12271 || l >= 12289 && l <= 55295 || l >= 63744 && l <= 64975 || l >= 65008 && l <= 65533 || l >= 65536 && l <= 983039;
    }
    e.isNameStartChar = c;
    function f(l) {
      return c(l) || l >= 48 && l <= 57 || l === 45 || l === 46 || l === 183 || l >= 768 && l <= 879 || l >= 8255 && l <= 8256;
    }
    e.isNameChar = f;
  })(oi)), oi;
}
var ai = {}, dr;
function Vh() {
  return dr || (dr = 1, (function(e) {
    Object.defineProperty(e, "__esModule", { value: !0 }), e.NC_NAME_START_CHAR = "A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}", e.NC_NAME_CHAR = "-" + e.NC_NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040", e.NC_NAME_START_CHAR_RE = new RegExp("^[" + e.NC_NAME_START_CHAR + "]$", "u"), e.NC_NAME_CHAR_RE = new RegExp("^[" + e.NC_NAME_CHAR + "]$", "u"), e.NC_NAME_RE = new RegExp("^[" + e.NC_NAME_START_CHAR + "][" + e.NC_NAME_CHAR + "]*$", "u");
    function t(i) {
      return i >= 65 && i <= 90 || i === 95 || i >= 97 && i <= 122 || i >= 192 && i <= 214 || i >= 216 && i <= 246 || i >= 248 && i <= 767 || i >= 880 && i <= 893 || i >= 895 && i <= 8191 || i >= 8204 && i <= 8205 || i >= 8304 && i <= 8591 || i >= 11264 && i <= 12271 || i >= 12289 && i <= 55295 || i >= 63744 && i <= 64975 || i >= 65008 && i <= 65533 || i >= 65536 && i <= 983039;
    }
    e.isNCNameStartChar = t;
    function n(i) {
      return t(i) || i === 45 || i === 46 || i >= 48 && i <= 57 || i === 183 || i >= 768 && i <= 879 || i >= 8255 && i <= 8256;
    }
    e.isNCNameChar = n;
  })(ai)), ai;
}
var fr;
function Jh() {
  if (fr) return Je;
  fr = 1, Object.defineProperty(Je, "__esModule", { value: !0 }), Je.SaxesParser = Je.EVENTS = void 0;
  const e = Wh(), t = Kh(), n = Vh();
  var i = e.isS, s = e.isChar, r = e.isNameStartChar, o = e.isNameChar, a = e.S_LIST, u = e.NAME_RE, c = t.isChar, f = n.isNCNameStartChar, l = n.isNCNameChar, m = n.NC_NAME_RE;
  const h = "http://www.w3.org/XML/1998/namespace", p = "http://www.w3.org/2000/xmlns/", y = {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment
    __proto__: null,
    xml: h,
    xmlns: p
  }, x = {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment
    __proto__: null,
    amp: "&",
    gt: ">",
    lt: "<",
    quot: '"',
    apos: "'"
  }, k = -1, N = -2, L = 0, se = 1, Z = 2, F = 3, V = 4, Ce = 5, be = 6, Ee = 7, J = 8, nt = 9, wt = 10, $n = 11, Jt = 12, W = 13, ze = 14, it = 15, ye = 16, xt = 17, Dn = 18, kt = 19, we = 20, Xt = 21, qe = 22, St = 23, st = 24, rt = 25, He = 26, Gt = 27, Yt = 28, Qt = 29, Et = 30, Yo = 31, Qo = 32, We = 33, ea = 34, Fn = 35, zt = 36, Rn = 37, ta = 38, Qi = 39, es = 40, na = 41, ts = 42, ia = 43, sa = 44, Pn = 9, fe = 10, Zn = 13, ns = 32, is = 33, ss = 34, It = 38, rs = 39, en = 45, tn = 47, ra = 59, $e = 60, ot = 61, X = 62, G = 63, os = 91, at = 93, as = 133, cs = 8232, nn = (Q) => Q === ss || Q === rs, us = [ss, rs], oa = [...us, os, X], aa = [...us, $e, at], ca = [ot, G, ...a], ua = [...a, X, It, $e];
  function Mn(Q, d, _) {
    switch (d) {
      case "xml":
        _ !== h && Q.fail(`xml prefix must be bound to ${h}.`);
        break;
      case "xmlns":
        _ !== p && Q.fail(`xmlns prefix must be bound to ${p}.`);
        break;
    }
    switch (_) {
      case p:
        Q.fail(d === "" ? `the default namespace may not be set to ${_}.` : `may not assign a prefix (even "xmlns") to the URI ${p}.`);
        break;
      case h:
        switch (d) {
          case "xml":
            break;
          case "":
            Q.fail(`the default namespace may not be set to ${_}.`);
            break;
          default:
            Q.fail("may not assign the xml namespace to another prefix.");
        }
        break;
    }
  }
  function la(Q, d) {
    for (const _ of Object.keys(d))
      Mn(Q, _, d[_]);
  }
  const da = (Q) => m.test(Q), fa = (Q) => u.test(Q), Ke = 0, ls = 1, Ln = 2;
  Je.EVENTS = [
    "xmldecl",
    "text",
    "processinginstruction",
    "doctype",
    "comment",
    "opentagstart",
    "attribute",
    "opentag",
    "closetag",
    "cdata",
    "error",
    "end",
    "ready"
  ];
  const ds = {
    xmldecl: "xmldeclHandler",
    text: "textHandler",
    processinginstruction: "piHandler",
    doctype: "doctypeHandler",
    comment: "commentHandler",
    opentagstart: "openTagStartHandler",
    attribute: "attributeHandler",
    opentag: "openTagHandler",
    closetag: "closeTagHandler",
    cdata: "cdataHandler",
    error: "errorHandler",
    end: "endHandler",
    ready: "readyHandler"
  };
  class pa {
    /**
     * @param opt The parser options.
     */
    constructor(d) {
      this.opt = d ?? {}, this.fragmentOpt = !!this.opt.fragment;
      const _ = this.xmlnsOpt = !!this.opt.xmlns;
      if (this.trackPosition = this.opt.position !== !1, this.fileName = this.opt.fileName, _) {
        this.nameStartCheck = f, this.nameCheck = l, this.isName = da, this.processAttribs = this.processAttribsNS, this.pushAttrib = this.pushAttribNS, this.ns = Object.assign({ __proto__: null }, y);
        const g = this.opt.additionalNamespaces;
        g != null && (la(this, g), Object.assign(this.ns, g));
      } else
        this.nameStartCheck = r, this.nameCheck = o, this.isName = fa, this.processAttribs = this.processAttribsPlain, this.pushAttrib = this.pushAttribPlain;
      this.stateTable = [
        /* eslint-disable @typescript-eslint/unbound-method */
        this.sBegin,
        this.sBeginWhitespace,
        this.sDoctype,
        this.sDoctypeQuote,
        this.sDTD,
        this.sDTDQuoted,
        this.sDTDOpenWaka,
        this.sDTDOpenWakaBang,
        this.sDTDComment,
        this.sDTDCommentEnding,
        this.sDTDCommentEnded,
        this.sDTDPI,
        this.sDTDPIEnding,
        this.sText,
        this.sEntity,
        this.sOpenWaka,
        this.sOpenWakaBang,
        this.sComment,
        this.sCommentEnding,
        this.sCommentEnded,
        this.sCData,
        this.sCDataEnding,
        this.sCDataEnding2,
        this.sPIFirstChar,
        this.sPIRest,
        this.sPIBody,
        this.sPIEnding,
        this.sXMLDeclNameStart,
        this.sXMLDeclName,
        this.sXMLDeclEq,
        this.sXMLDeclValueStart,
        this.sXMLDeclValue,
        this.sXMLDeclSeparator,
        this.sXMLDeclEnding,
        this.sOpenTag,
        this.sOpenTagSlash,
        this.sAttrib,
        this.sAttribName,
        this.sAttribNameSawWhite,
        this.sAttribValue,
        this.sAttribValueQuoted,
        this.sAttribValueClosed,
        this.sAttribValueUnquoted,
        this.sCloseTag,
        this.sCloseTagSawWhite
        /* eslint-enable @typescript-eslint/unbound-method */
      ], this._init();
    }
    /**
     * Indicates whether or not the parser is closed. If ``true``, wait for
     * the ``ready`` event to write again.
     */
    get closed() {
      return this._closed;
    }
    _init() {
      var d;
      this.openWakaBang = "", this.text = "", this.name = "", this.piTarget = "", this.entity = "", this.q = null, this.tags = [], this.tag = null, this.topNS = null, this.chunk = "", this.chunkPosition = 0, this.i = 0, this.prevI = 0, this.carriedFromPrevious = void 0, this.forbiddenState = Ke, this.attribList = [];
      const { fragmentOpt: _ } = this;
      this.state = _ ? W : L, this.reportedTextBeforeRoot = this.reportedTextAfterRoot = this.closedRoot = this.sawRoot = _, this.xmlDeclPossible = !_, this.xmlDeclExpects = ["version"], this.entityReturnState = void 0;
      let { defaultXMLVersion: g } = this.opt;
      if (g === void 0) {
        if (this.opt.forceXMLVersion === !0)
          throw new Error("forceXMLVersion set but defaultXMLVersion is not set");
        g = "1.0";
      }
      this.setXMLVersion(g), this.positionAtNewLine = 0, this.doctype = !1, this._closed = !1, this.xmlDecl = {
        version: void 0,
        encoding: void 0,
        standalone: void 0
      }, this.line = 1, this.column = 0, this.ENTITIES = Object.create(x), (d = this.readyHandler) === null || d === void 0 || d.call(this);
    }
    /**
     * The stream position the parser is currently looking at. This field is
     * zero-based.
     *
     * This field is not based on counting Unicode characters but is to be
     * interpreted as a plain index into a JavaScript string.
     */
    get position() {
      return this.chunkPosition + this.i;
    }
    /**
     * The column number of the next character to be read by the parser.  *
     * This field is zero-based. (The first column in a line is 0.)
     *
     * This field reports the index at which the next character would be in the
     * line if the line were represented as a JavaScript string.  Note that this
     * *can* be different to a count based on the number of *Unicode characters*
     * due to how JavaScript handles astral plane characters.
     *
     * See [[column]] for a number that corresponds to a count of Unicode
     * characters.
     */
    get columnIndex() {
      return this.position - this.positionAtNewLine;
    }
    /**
     * Set an event listener on an event. The parser supports one handler per
     * event type. If you try to set an event handler over an existing handler,
     * the old handler is silently overwritten.
     *
     * @param name The event to listen to.
     *
     * @param handler The handler to set.
     */
    on(d, _) {
      this[ds[d]] = _;
    }
    /**
     * Unset an event handler.
     *
     * @parma name The event to stop listening to.
     */
    off(d) {
      this[ds[d]] = void 0;
    }
    /**
     * Make an error object. The error object will have a message that contains
     * the ``fileName`` option passed at the creation of the parser. If position
     * tracking was turned on, it will also have line and column number
     * information.
     *
     * @param message The message describing the error to report.
     *
     * @returns An error object with a properly formatted message.
     */
    makeError(d) {
      var _;
      let g = (_ = this.fileName) !== null && _ !== void 0 ? _ : "";
      return this.trackPosition && (g.length > 0 && (g += ":"), g += `${this.line}:${this.column}`), g.length > 0 && (g += ": "), new Error(g + d);
    }
    /**
     * Report a parsing error. This method is made public so that client code may
     * check for issues that are outside the scope of this project and can report
     * errors.
     *
     * @param message The error to report.
     *
     * @returns this
     */
    fail(d) {
      const _ = this.makeError(d), g = this.errorHandler;
      if (g === void 0)
        throw _;
      return g(_), this;
    }
    /**
     * Write a XML data to the parser.
     *
     * @param chunk The XML data to write.
     *
     * @returns this
     */
    // We do need object for the type here. Yes, it often causes problems
    // but not in this case.
    write(d) {
      if (this.closed)
        return this.fail("cannot write after close; assign an onready handler.");
      let _ = !1;
      d === null ? (_ = !0, d = "") : typeof d == "object" && (d = d.toString()), this.carriedFromPrevious !== void 0 && (d = `${this.carriedFromPrevious}${d}`, this.carriedFromPrevious = void 0);
      let g = d.length;
      const z = d.charCodeAt(g - 1);
      !_ && // A trailing CR or surrogate must be carried over to the next
      // chunk.
      (z === Zn || z >= 55296 && z <= 56319) && (this.carriedFromPrevious = d[g - 1], g--, d = d.slice(0, g));
      const { stateTable: $ } = this;
      for (this.chunk = d, this.i = 0; this.i < g; )
        $[this.state].call(this);
      return this.chunkPosition += g, _ ? this.end() : this;
    }
    /**
     * Close the current stream. Perform final well-formedness checks and reset
     * the parser tstate.
     *
     * @returns this
     */
    close() {
      return this.write(null);
    }
    /**
     * Get a single code point out of the current chunk. This updates the current
     * position if we do position tracking.
     *
     * This is the algorithm to use for XML 1.0.
     *
     * @returns The character read.
     */
    getCode10() {
      const { chunk: d, i: _ } = this;
      if (this.prevI = _, this.i = _ + 1, _ >= d.length)
        return k;
      const g = d.charCodeAt(_);
      if (this.column++, g < 55296) {
        if (g >= ns || g === Pn)
          return g;
        switch (g) {
          case fe:
            return this.line++, this.column = 0, this.positionAtNewLine = this.position, fe;
          case Zn:
            return d.charCodeAt(_ + 1) === fe && (this.i = _ + 2), this.line++, this.column = 0, this.positionAtNewLine = this.position, N;
          default:
            return this.fail("disallowed character."), g;
        }
      }
      if (g > 56319)
        return g >= 57344 && g <= 65533 || this.fail("disallowed character."), g;
      const z = 65536 + (g - 55296) * 1024 + (d.charCodeAt(_ + 1) - 56320);
      return this.i = _ + 2, z > 1114111 && this.fail("disallowed character."), z;
    }
    /**
     * Get a single code point out of the current chunk. This updates the current
     * position if we do position tracking.
     *
     * This is the algorithm to use for XML 1.1.
     *
     * @returns {number} The character read.
     */
    getCode11() {
      const { chunk: d, i: _ } = this;
      if (this.prevI = _, this.i = _ + 1, _ >= d.length)
        return k;
      const g = d.charCodeAt(_);
      if (this.column++, g < 55296) {
        if (g > 31 && g < 127 || g > 159 && g !== cs || g === Pn)
          return g;
        switch (g) {
          case fe:
            return this.line++, this.column = 0, this.positionAtNewLine = this.position, fe;
          case Zn: {
            const $ = d.charCodeAt(_ + 1);
            ($ === fe || $ === as) && (this.i = _ + 2);
          }
          /* yes, fall through */
          case as:
          // 0x85
          case cs:
            return this.line++, this.column = 0, this.positionAtNewLine = this.position, N;
          default:
            return this.fail("disallowed character."), g;
        }
      }
      if (g > 56319)
        return g >= 57344 && g <= 65533 || this.fail("disallowed character."), g;
      const z = 65536 + (g - 55296) * 1024 + (d.charCodeAt(_ + 1) - 56320);
      return this.i = _ + 2, z > 1114111 && this.fail("disallowed character."), z;
    }
    /**
     * Like ``getCode`` but with the return value normalized so that ``NL`` is
     * returned for ``NL_LIKE``.
     */
    getCodeNorm() {
      const d = this.getCode();
      return d === N ? fe : d;
    }
    unget() {
      this.i = this.prevI, this.column--;
    }
    /**
     * Capture characters into a buffer until encountering one of a set of
     * characters.
     *
     * @param chars An array of codepoints. Encountering a character in the array
     * ends the capture. (``chars`` may safely contain ``NL``.)
     *
     * @return The character code that made the capture end, or ``EOC`` if we hit
     * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
     * instead.
     */
    captureTo(d) {
      let { i: _ } = this;
      const { chunk: g } = this;
      for (; ; ) {
        const z = this.getCode(), $ = z === N, P = $ ? fe : z;
        if (P === k || d.includes(P))
          return this.text += g.slice(_, this.prevI), P;
        $ && (this.text += `${g.slice(_, this.prevI)}
`, _ = this.i);
      }
    }
    /**
     * Capture characters into a buffer until encountering a character.
     *
     * @param char The codepoint that ends the capture. **NOTE ``char`` MAY NOT
     * CONTAIN ``NL``.** Passing ``NL`` will result in buggy behavior.
     *
     * @return ``true`` if we ran into the character. Otherwise, we ran into the
     * end of the current chunk.
     */
    captureToChar(d) {
      let { i: _ } = this;
      const { chunk: g } = this;
      for (; ; ) {
        let z = this.getCode();
        switch (z) {
          case N:
            this.text += `${g.slice(_, this.prevI)}
`, _ = this.i, z = fe;
            break;
          case k:
            return this.text += g.slice(_), !1;
        }
        if (z === d)
          return this.text += g.slice(_, this.prevI), !0;
      }
    }
    /**
     * Capture characters that satisfy ``isNameChar`` into the ``name`` field of
     * this parser.
     *
     * @return The character code that made the test fail, or ``EOC`` if we hit
     * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
     * instead.
     */
    captureNameChars() {
      const { chunk: d, i: _ } = this;
      for (; ; ) {
        const g = this.getCode();
        if (g === k)
          return this.name += d.slice(_), k;
        if (!o(g))
          return this.name += d.slice(_, this.prevI), g === N ? fe : g;
      }
    }
    /**
     * Skip white spaces.
     *
     * @return The character that ended the skip, or ``EOC`` if we hit
     * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
     * instead.
     */
    skipSpaces() {
      for (; ; ) {
        const d = this.getCodeNorm();
        if (d === k || !i(d))
          return d;
      }
    }
    setXMLVersion(d) {
      this.currentXMLVersion = d, d === "1.0" ? (this.isChar = s, this.getCode = this.getCode10) : (this.isChar = c, this.getCode = this.getCode11);
    }
    // STATE ENGINE METHODS
    // This needs to be a state separate from S_BEGIN_WHITESPACE because we want
    // to be sure never to come back to this state later.
    sBegin() {
      this.chunk.charCodeAt(0) === 65279 && (this.i++, this.column++), this.state = se;
    }
    sBeginWhitespace() {
      const d = this.i, _ = this.skipSpaces();
      switch (this.prevI !== d && (this.xmlDeclPossible = !1), _) {
        case $e:
          if (this.state = it, this.text.length !== 0)
            throw new Error("no-empty text at start");
          break;
        case k:
          break;
        default:
          this.unget(), this.state = W, this.xmlDeclPossible = !1;
      }
    }
    sDoctype() {
      var d;
      const _ = this.captureTo(oa);
      switch (_) {
        case X: {
          (d = this.doctypeHandler) === null || d === void 0 || d.call(this, this.text), this.text = "", this.state = W, this.doctype = !0;
          break;
        }
        case k:
          break;
        default:
          this.text += String.fromCodePoint(_), _ === os ? this.state = V : nn(_) && (this.state = F, this.q = _);
      }
    }
    sDoctypeQuote() {
      const d = this.q;
      this.captureToChar(d) && (this.text += String.fromCodePoint(d), this.q = null, this.state = Z);
    }
    sDTD() {
      const d = this.captureTo(aa);
      d !== k && (this.text += String.fromCodePoint(d), d === at ? this.state = Z : d === $e ? this.state = be : nn(d) && (this.state = Ce, this.q = d));
    }
    sDTDQuoted() {
      const d = this.q;
      this.captureToChar(d) && (this.text += String.fromCodePoint(d), this.state = V, this.q = null);
    }
    sDTDOpenWaka() {
      const d = this.getCodeNorm();
      switch (this.text += String.fromCodePoint(d), d) {
        case is:
          this.state = Ee, this.openWakaBang = "";
          break;
        case G:
          this.state = $n;
          break;
        default:
          this.state = V;
      }
    }
    sDTDOpenWakaBang() {
      const d = String.fromCodePoint(this.getCodeNorm()), _ = this.openWakaBang += d;
      this.text += d, _ !== "-" && (this.state = _ === "--" ? J : V, this.openWakaBang = "");
    }
    sDTDComment() {
      this.captureToChar(en) && (this.text += "-", this.state = nt);
    }
    sDTDCommentEnding() {
      const d = this.getCodeNorm();
      this.text += String.fromCodePoint(d), this.state = d === en ? wt : J;
    }
    sDTDCommentEnded() {
      const d = this.getCodeNorm();
      this.text += String.fromCodePoint(d), d === X ? this.state = V : (this.fail("malformed comment."), this.state = J);
    }
    sDTDPI() {
      this.captureToChar(G) && (this.text += "?", this.state = Jt);
    }
    sDTDPIEnding() {
      const d = this.getCodeNorm();
      this.text += String.fromCodePoint(d), d === X && (this.state = V);
    }
    sText() {
      this.tags.length !== 0 ? this.handleTextInRoot() : this.handleTextOutsideRoot();
    }
    sEntity() {
      let { i: d } = this;
      const { chunk: _ } = this;
      e:
        for (; ; )
          switch (this.getCode()) {
            case N:
              this.entity += `${_.slice(d, this.prevI)}
`, d = this.i;
              break;
            case ra: {
              const { entityReturnState: g } = this, z = this.entity + _.slice(d, this.prevI);
              this.state = g;
              let $;
              z === "" ? (this.fail("empty entity name."), $ = "&;") : ($ = this.parseEntity(z), this.entity = ""), (g !== W || this.textHandler !== void 0) && (this.text += $);
              break e;
            }
            case k:
              this.entity += _.slice(d);
              break e;
          }
    }
    sOpenWaka() {
      const d = this.getCode();
      if (r(d))
        this.state = ea, this.unget(), this.xmlDeclPossible = !1;
      else
        switch (d) {
          case tn:
            this.state = ia, this.xmlDeclPossible = !1;
            break;
          case is:
            this.state = ye, this.openWakaBang = "", this.xmlDeclPossible = !1;
            break;
          case G:
            this.state = St;
            break;
          default:
            this.fail("disallowed character in tag name"), this.state = W, this.xmlDeclPossible = !1;
        }
    }
    sOpenWakaBang() {
      switch (this.openWakaBang += String.fromCodePoint(this.getCodeNorm()), this.openWakaBang) {
        case "[CDATA[":
          !this.sawRoot && !this.reportedTextBeforeRoot && (this.fail("text data outside of root node."), this.reportedTextBeforeRoot = !0), this.closedRoot && !this.reportedTextAfterRoot && (this.fail("text data outside of root node."), this.reportedTextAfterRoot = !0), this.state = we, this.openWakaBang = "";
          break;
        case "--":
          this.state = xt, this.openWakaBang = "";
          break;
        case "DOCTYPE":
          this.state = Z, (this.doctype || this.sawRoot) && this.fail("inappropriately located doctype declaration."), this.openWakaBang = "";
          break;
        default:
          this.openWakaBang.length >= 7 && this.fail("incorrect syntax.");
      }
    }
    sComment() {
      this.captureToChar(en) && (this.state = Dn);
    }
    sCommentEnding() {
      var d;
      const _ = this.getCodeNorm();
      _ === en ? (this.state = kt, (d = this.commentHandler) === null || d === void 0 || d.call(this, this.text), this.text = "") : (this.text += `-${String.fromCodePoint(_)}`, this.state = xt);
    }
    sCommentEnded() {
      const d = this.getCodeNorm();
      d !== X ? (this.fail("malformed comment."), this.text += `--${String.fromCodePoint(d)}`, this.state = xt) : this.state = W;
    }
    sCData() {
      this.captureToChar(at) && (this.state = Xt);
    }
    sCDataEnding() {
      const d = this.getCodeNorm();
      d === at ? this.state = qe : (this.text += `]${String.fromCodePoint(d)}`, this.state = we);
    }
    sCDataEnding2() {
      var d;
      const _ = this.getCodeNorm();
      switch (_) {
        case X: {
          (d = this.cdataHandler) === null || d === void 0 || d.call(this, this.text), this.text = "", this.state = W;
          break;
        }
        case at:
          this.text += "]";
          break;
        default:
          this.text += `]]${String.fromCodePoint(_)}`, this.state = we;
      }
    }
    // We need this separate state to check the first character fo the pi target
    // with this.nameStartCheck which allows less characters than this.nameCheck.
    sPIFirstChar() {
      const d = this.getCodeNorm();
      this.nameStartCheck(d) ? (this.piTarget += String.fromCodePoint(d), this.state = st) : d === G || i(d) ? (this.fail("processing instruction without a target."), this.state = d === G ? He : rt) : (this.fail("disallowed character in processing instruction name."), this.piTarget += String.fromCodePoint(d), this.state = st);
    }
    sPIRest() {
      const { chunk: d, i: _ } = this;
      for (; ; ) {
        const g = this.getCodeNorm();
        if (g === k) {
          this.piTarget += d.slice(_);
          return;
        }
        if (!this.nameCheck(g)) {
          this.piTarget += d.slice(_, this.prevI);
          const z = g === G;
          z || i(g) ? this.piTarget === "xml" ? (this.xmlDeclPossible || this.fail("an XML declaration must be at the start of the document."), this.state = z ? We : Gt) : this.state = z ? He : rt : (this.fail("disallowed character in processing instruction name."), this.piTarget += String.fromCodePoint(g));
          break;
        }
      }
    }
    sPIBody() {
      if (this.text.length === 0) {
        const d = this.getCodeNorm();
        d === G ? this.state = He : i(d) || (this.text = String.fromCodePoint(d));
      } else this.captureToChar(G) && (this.state = He);
    }
    sPIEnding() {
      var d;
      const _ = this.getCodeNorm();
      if (_ === X) {
        const { piTarget: g } = this;
        g.toLowerCase() === "xml" && this.fail("the XML declaration must appear at the start of the document."), (d = this.piHandler) === null || d === void 0 || d.call(this, {
          target: g,
          body: this.text
        }), this.piTarget = this.text = "", this.state = W;
      } else _ === G ? this.text += "?" : (this.text += `?${String.fromCodePoint(_)}`, this.state = rt);
      this.xmlDeclPossible = !1;
    }
    sXMLDeclNameStart() {
      const d = this.skipSpaces();
      if (d === G) {
        this.state = We;
        return;
      }
      d !== k && (this.state = Yt, this.name = String.fromCodePoint(d));
    }
    sXMLDeclName() {
      const d = this.captureTo(ca);
      if (d === G) {
        this.state = We, this.name += this.text, this.text = "", this.fail("XML declaration is incomplete.");
        return;
      }
      if (i(d) || d === ot) {
        if (this.name += this.text, this.text = "", !this.xmlDeclExpects.includes(this.name))
          switch (this.name.length) {
            case 0:
              this.fail("did not expect any more name/value pairs.");
              break;
            case 1:
              this.fail(`expected the name ${this.xmlDeclExpects[0]}.`);
              break;
            default:
              this.fail(`expected one of ${this.xmlDeclExpects.join(", ")}`);
          }
        this.state = d === ot ? Et : Qt;
      }
    }
    sXMLDeclEq() {
      const d = this.getCodeNorm();
      if (d === G) {
        this.state = We, this.fail("XML declaration is incomplete.");
        return;
      }
      i(d) || (d !== ot && this.fail("value required."), this.state = Et);
    }
    sXMLDeclValueStart() {
      const d = this.getCodeNorm();
      if (d === G) {
        this.state = We, this.fail("XML declaration is incomplete.");
        return;
      }
      i(d) || (nn(d) ? this.q = d : (this.fail("value must be quoted."), this.q = ns), this.state = Yo);
    }
    sXMLDeclValue() {
      const d = this.captureTo([this.q, G]);
      if (d === G) {
        this.state = We, this.text = "", this.fail("XML declaration is incomplete.");
        return;
      }
      if (d === k)
        return;
      const _ = this.text;
      switch (this.text = "", this.name) {
        case "version": {
          this.xmlDeclExpects = ["encoding", "standalone"];
          const g = _;
          this.xmlDecl.version = g, /^1\.[0-9]+$/.test(g) ? this.opt.forceXMLVersion || this.setXMLVersion(g) : this.fail("version number must match /^1\\.[0-9]+$/.");
          break;
        }
        case "encoding":
          /^[A-Za-z][A-Za-z0-9._-]*$/.test(_) || this.fail("encoding value must match 	/^[A-Za-z0-9][A-Za-z0-9._-]*$/."), this.xmlDeclExpects = ["standalone"], this.xmlDecl.encoding = _;
          break;
        case "standalone":
          _ !== "yes" && _ !== "no" && this.fail('standalone value must match "yes" or "no".'), this.xmlDeclExpects = [], this.xmlDecl.standalone = _;
          break;
      }
      this.name = "", this.state = Qo;
    }
    sXMLDeclSeparator() {
      const d = this.getCodeNorm();
      if (d === G) {
        this.state = We;
        return;
      }
      i(d) || (this.fail("whitespace required."), this.unget()), this.state = Gt;
    }
    sXMLDeclEnding() {
      var d;
      this.getCodeNorm() === X ? (this.piTarget !== "xml" ? this.fail("processing instructions are not allowed before root.") : this.name !== "version" && this.xmlDeclExpects.includes("version") && this.fail("XML declaration must contain a version."), (d = this.xmldeclHandler) === null || d === void 0 || d.call(this, this.xmlDecl), this.name = "", this.piTarget = this.text = "", this.state = W) : this.fail("The character ? is disallowed anywhere in XML declarations."), this.xmlDeclPossible = !1;
    }
    sOpenTag() {
      var d;
      const _ = this.captureNameChars();
      if (_ === k)
        return;
      const g = this.tag = {
        name: this.name,
        attributes: /* @__PURE__ */ Object.create(null)
      };
      switch (this.name = "", this.xmlnsOpt && (this.topNS = g.ns = /* @__PURE__ */ Object.create(null)), (d = this.openTagStartHandler) === null || d === void 0 || d.call(this, g), this.sawRoot = !0, !this.fragmentOpt && this.closedRoot && this.fail("documents may contain only one root."), _) {
        case X:
          this.openTag();
          break;
        case tn:
          this.state = Fn;
          break;
        default:
          i(_) || this.fail("disallowed character in tag name."), this.state = zt;
      }
    }
    sOpenTagSlash() {
      this.getCode() === X ? this.openSelfClosingTag() : (this.fail("forward-slash in opening tag not followed by >."), this.state = zt);
    }
    sAttrib() {
      const d = this.skipSpaces();
      d !== k && (r(d) ? (this.unget(), this.state = Rn) : d === X ? this.openTag() : d === tn ? this.state = Fn : this.fail("disallowed character in attribute name."));
    }
    sAttribName() {
      const d = this.captureNameChars();
      d === ot ? this.state = Qi : i(d) ? this.state = ta : d === X ? (this.fail("attribute without value."), this.pushAttrib(this.name, this.name), this.name = this.text = "", this.openTag()) : d !== k && this.fail("disallowed character in attribute name.");
    }
    sAttribNameSawWhite() {
      const d = this.skipSpaces();
      switch (d) {
        case k:
          return;
        case ot:
          this.state = Qi;
          break;
        default:
          this.fail("attribute without value."), this.text = "", this.name = "", d === X ? this.openTag() : r(d) ? (this.unget(), this.state = Rn) : (this.fail("disallowed character in attribute name."), this.state = zt);
      }
    }
    sAttribValue() {
      const d = this.getCodeNorm();
      nn(d) ? (this.q = d, this.state = es) : i(d) || (this.fail("unquoted attribute value."), this.state = ts, this.unget());
    }
    sAttribValueQuoted() {
      const { q: d, chunk: _ } = this;
      let { i: g } = this;
      for (; ; )
        switch (this.getCode()) {
          case d:
            this.pushAttrib(this.name, this.text + _.slice(g, this.prevI)), this.name = this.text = "", this.q = null, this.state = na;
            return;
          case It:
            this.text += _.slice(g, this.prevI), this.state = ze, this.entityReturnState = es;
            return;
          case fe:
          case N:
          case Pn:
            this.text += `${_.slice(g, this.prevI)} `, g = this.i;
            break;
          case $e:
            this.text += _.slice(g, this.prevI), this.fail("disallowed character.");
            return;
          case k:
            this.text += _.slice(g);
            return;
        }
    }
    sAttribValueClosed() {
      const d = this.getCodeNorm();
      i(d) ? this.state = zt : d === X ? this.openTag() : d === tn ? this.state = Fn : r(d) ? (this.fail("no whitespace between attributes."), this.unget(), this.state = Rn) : this.fail("disallowed character in attribute name.");
    }
    sAttribValueUnquoted() {
      const d = this.captureTo(ua);
      switch (d) {
        case It:
          this.state = ze, this.entityReturnState = ts;
          break;
        case $e:
          this.fail("disallowed character.");
          break;
        case k:
          break;
        default:
          this.text.includes("]]>") && this.fail('the string "]]>" is disallowed in char data.'), this.pushAttrib(this.name, this.text), this.name = this.text = "", d === X ? this.openTag() : this.state = zt;
      }
    }
    sCloseTag() {
      const d = this.captureNameChars();
      d === X ? this.closeTag() : i(d) ? this.state = sa : d !== k && this.fail("disallowed character in closing tag.");
    }
    sCloseTagSawWhite() {
      switch (this.skipSpaces()) {
        case X:
          this.closeTag();
          break;
        case k:
          break;
        default:
          this.fail("disallowed character in closing tag.");
      }
    }
    // END OF STATE ENGINE METHODS
    handleTextInRoot() {
      let { i: d, forbiddenState: _ } = this;
      const { chunk: g, textHandler: z } = this;
      e:
        for (; ; )
          switch (this.getCode()) {
            case $e: {
              if (this.state = it, z !== void 0) {
                const { text: $ } = this, P = g.slice(d, this.prevI);
                $.length !== 0 ? (z($ + P), this.text = "") : P.length !== 0 && z(P);
              }
              _ = Ke;
              break e;
            }
            case It:
              this.state = ze, this.entityReturnState = W, z !== void 0 && (this.text += g.slice(d, this.prevI)), _ = Ke;
              break e;
            case at:
              switch (_) {
                case Ke:
                  _ = ls;
                  break;
                case ls:
                  _ = Ln;
                  break;
                case Ln:
                  break;
                default:
                  throw new Error("impossible state");
              }
              break;
            case X:
              _ === Ln && this.fail('the string "]]>" is disallowed in char data.'), _ = Ke;
              break;
            case N:
              z !== void 0 && (this.text += `${g.slice(d, this.prevI)}
`), d = this.i, _ = Ke;
              break;
            case k:
              z !== void 0 && (this.text += g.slice(d));
              break e;
            default:
              _ = Ke;
          }
      this.forbiddenState = _;
    }
    handleTextOutsideRoot() {
      let { i: d } = this;
      const { chunk: _, textHandler: g } = this;
      let z = !1;
      e:
        for (; ; ) {
          const $ = this.getCode();
          switch ($) {
            case $e: {
              if (this.state = it, g !== void 0) {
                const { text: P } = this, Y = _.slice(d, this.prevI);
                P.length !== 0 ? (g(P + Y), this.text = "") : Y.length !== 0 && g(Y);
              }
              break e;
            }
            case It:
              this.state = ze, this.entityReturnState = W, g !== void 0 && (this.text += _.slice(d, this.prevI)), z = !0;
              break e;
            case N:
              g !== void 0 && (this.text += `${_.slice(d, this.prevI)}
`), d = this.i;
              break;
            case k:
              g !== void 0 && (this.text += _.slice(d));
              break e;
            default:
              i($) || (z = !0);
          }
        }
      z && (!this.sawRoot && !this.reportedTextBeforeRoot && (this.fail("text data outside of root node."), this.reportedTextBeforeRoot = !0), this.closedRoot && !this.reportedTextAfterRoot && (this.fail("text data outside of root node."), this.reportedTextAfterRoot = !0));
    }
    pushAttribNS(d, _) {
      var g;
      const { prefix: z, local: $ } = this.qname(d), P = { name: d, prefix: z, local: $, value: _ };
      if (this.attribList.push(P), (g = this.attributeHandler) === null || g === void 0 || g.call(this, P), z === "xmlns") {
        const Y = _.trim();
        this.currentXMLVersion === "1.0" && Y === "" && this.fail("invalid attempt to undefine prefix in XML 1.0"), this.topNS[$] = Y, Mn(this, $, Y);
      } else if (d === "xmlns") {
        const Y = _.trim();
        this.topNS[""] = Y, Mn(this, "", Y);
      }
    }
    pushAttribPlain(d, _) {
      var g;
      const z = { name: d, value: _ };
      this.attribList.push(z), (g = this.attributeHandler) === null || g === void 0 || g.call(this, z);
    }
    /**
     * End parsing. This performs final well-formedness checks and resets the
     * parser to a clean state.
     *
     * @returns this
     */
    end() {
      var d, _;
      this.sawRoot || this.fail("document must contain a root element.");
      const { tags: g } = this;
      for (; g.length > 0; ) {
        const $ = g.pop();
        this.fail(`unclosed tag: ${$.name}`);
      }
      this.state !== L && this.state !== W && this.fail("unexpected end.");
      const { text: z } = this;
      return z.length !== 0 && ((d = this.textHandler) === null || d === void 0 || d.call(this, z), this.text = ""), this._closed = !0, (_ = this.endHandler) === null || _ === void 0 || _.call(this), this._init(), this;
    }
    /**
     * Resolve a namespace prefix.
     *
     * @param prefix The prefix to resolve.
     *
     * @returns The namespace URI or ``undefined`` if the prefix is not defined.
     */
    resolve(d) {
      var _, g;
      let z = this.topNS[d];
      if (z !== void 0)
        return z;
      const { tags: $ } = this;
      for (let P = $.length - 1; P >= 0; P--)
        if (z = $[P].ns[d], z !== void 0)
          return z;
      return z = this.ns[d], z !== void 0 ? z : (g = (_ = this.opt).resolvePrefix) === null || g === void 0 ? void 0 : g.call(_, d);
    }
    /**
     * Parse a qname into its prefix and local name parts.
     *
     * @param name The name to parse
     *
     * @returns
     */
    qname(d) {
      const _ = d.indexOf(":");
      if (_ === -1)
        return { prefix: "", local: d };
      const g = d.slice(_ + 1), z = d.slice(0, _);
      return (z === "" || g === "" || g.includes(":")) && this.fail(`malformed name: ${d}.`), { prefix: z, local: g };
    }
    processAttribsNS() {
      var d;
      const { attribList: _ } = this, g = this.tag;
      {
        const { prefix: P, local: Y } = this.qname(g.name);
        g.prefix = P, g.local = Y;
        const ct = g.uri = (d = this.resolve(P)) !== null && d !== void 0 ? d : "";
        P !== "" && (P === "xmlns" && this.fail('tags may not have "xmlns" as prefix.'), ct === "" && (this.fail(`unbound namespace prefix: ${JSON.stringify(P)}.`), g.uri = P));
      }
      if (_.length === 0)
        return;
      const { attributes: z } = g, $ = /* @__PURE__ */ new Set();
      for (const P of _) {
        const { name: Y, prefix: ct, local: ha } = P;
        let ut, Tt;
        ct === "" ? (ut = Y === "xmlns" ? p : "", Tt = Y) : (ut = this.resolve(ct), ut === void 0 && (this.fail(`unbound namespace prefix: ${JSON.stringify(ct)}.`), ut = ct), Tt = `{${ut}}${ha}`), $.has(Tt) && this.fail(`duplicate attribute: ${Tt}.`), $.add(Tt), P.uri = ut, z[Y] = P;
      }
      this.attribList = [];
    }
    processAttribsPlain() {
      const { attribList: d } = this, _ = this.tag.attributes;
      for (const { name: g, value: z } of d)
        _[g] !== void 0 && this.fail(`duplicate attribute: ${g}.`), _[g] = z;
      this.attribList = [];
    }
    /**
     * Handle a complete open tag. This parser code calls this once it has seen
     * the whole tag. This method checks for well-formeness and then emits
     * ``onopentag``.
     */
    openTag() {
      var d;
      this.processAttribs();
      const { tags: _ } = this, g = this.tag;
      g.isSelfClosing = !1, (d = this.openTagHandler) === null || d === void 0 || d.call(this, g), _.push(g), this.state = W, this.name = "";
    }
    /**
     * Handle a complete self-closing tag. This parser code calls this once it has
     * seen the whole tag. This method checks for well-formeness and then emits
     * ``onopentag`` and ``onclosetag``.
     */
    openSelfClosingTag() {
      var d, _, g;
      this.processAttribs();
      const { tags: z } = this, $ = this.tag;
      $.isSelfClosing = !0, (d = this.openTagHandler) === null || d === void 0 || d.call(this, $), (_ = this.closeTagHandler) === null || _ === void 0 || _.call(this, $), (this.tag = (g = z[z.length - 1]) !== null && g !== void 0 ? g : null) === null && (this.closedRoot = !0), this.state = W, this.name = "";
    }
    /**
     * Handle a complete close tag. This parser code calls this once it has seen
     * the whole tag. This method checks for well-formeness and then emits
     * ``onclosetag``.
     */
    closeTag() {
      const { tags: d, name: _ } = this;
      if (this.state = W, this.name = "", _ === "") {
        this.fail("weird empty close tag."), this.text += "</>";
        return;
      }
      const g = this.closeTagHandler;
      let z = d.length;
      for (; z-- > 0; ) {
        const $ = this.tag = d.pop();
        if (this.topNS = $.ns, g?.($), $.name === _)
          break;
        this.fail("unexpected close tag.");
      }
      z === 0 ? this.closedRoot = !0 : z < 0 && (this.fail(`unmatched closing tag: ${_}.`), this.text += `</${_}>`);
    }
    /**
     * Resolves an entity. Makes any necessary well-formedness checks.
     *
     * @param entity The entity to resolve.
     *
     * @returns The parsed entity.
     */
    parseEntity(d) {
      if (d[0] !== "#") {
        const g = this.ENTITIES[d];
        return g !== void 0 ? g : (this.fail(this.isName(d) ? "undefined entity." : "disallowed character in entity name."), `&${d};`);
      }
      let _ = NaN;
      return d[1] === "x" && /^#x[0-9a-f]+$/i.test(d) ? _ = parseInt(d.slice(2), 16) : /^#[0-9]+$/.test(d) && (_ = parseInt(d.slice(1), 10)), this.isChar(_) ? String.fromCodePoint(_) : (this.fail("malformed character entity."), `&${d};`);
    }
  }
  return Je.SaxesParser = pa, Je;
}
var Xh = Jh();
const ne = Object.freeze({
  inputBytes: 25 * 1024 * 1024,
  textBytes: 8 * 1024 * 1024,
  pages: 200,
  zipEntries: 512,
  zipExpandedBytes: 32 * 1024 * 1024,
  zipEntryBytes: 8 * 1024 * 1024,
  zipRatio: 200,
  xmlDepth: 128,
  cells: 5e4,
  sheets: 64,
  timeoutMs: 3e4
});
class T extends Error {
  constructor(t) {
    super(t), this.code = t;
  }
  code;
}
const Vo = "local-file-text-utf8-pdfjs6.3.289-opc-v1";
function Gh(e, t = {
  implementationId: Mo,
  profileId: Xi
}) {
  return {
    implementationId: e.tokenizerImplementationId ?? t.implementationId,
    profileId: e.tokenizerProfileId ?? t.profileId
  };
}
function Jo(e) {
  if (!e || typeof e != "object") throw new T("invalid_job");
  const t = e;
  if (![
    "bytes,jobId,kind,revision",
    "bytes,jobId,kind,revision,tokenizerImplementationId,tokenizerProfileId"
  ].includes(Object.keys(t).sort().join(",")) || typeof t.jobId != "string" || !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(t.jobId) || !Number.isSafeInteger(t.revision) || t.revision < 1 || !["text", "pdf", "docx", "xlsx", "pptx"].includes(t.kind) || !(t.bytes instanceof ArrayBuffer) || t.tokenizerImplementationId !== void 0 && (typeof t.tokenizerImplementationId != "string" || !/^[a-z0-9][a-z0-9._-]{0,127}$/.test(t.tokenizerImplementationId)) || t.tokenizerProfileId !== void 0 && (typeof t.tokenizerProfileId != "string" || !/^[a-z0-9][a-z0-9._-]{0,127}$/.test(t.tokenizerProfileId)))
    throw new T("invalid_job");
  if (t.bytes.byteLength > ne.inputBytes)
    throw new T("input_limit");
}
function Xo(e, t) {
  return {
    jobId: e.jobId,
    revision: e.revision,
    kind: e.kind,
    status: t === "cancelled" ? "cancelled" : "unavailable",
    reason: t,
    inputBytes: e.bytes?.byteLength ?? 0,
    extractedTextBytes: null,
    pages: null,
    textParts: null,
    tokens: null,
    scope: "extracted_file_text",
    tokenizerProfile: null,
    tokenizerAssetHash: null,
    evidence: "unknown",
    modelExactness: "unverified",
    extractionProfile: Vo,
    coverage: "unavailable",
    missing: [
      "provider_processing",
      "ocr",
      "image_encoding",
      "retrieval_selection"
    ],
    association: "unassociated",
    telemetryAllowed: !1
  };
}
function ae(e) {
  if (e?.aborted) throw new T("cancelled");
}
class Yh {
  pieces = [];
  size = 0;
  append(t) {
    if (this.size += new TextEncoder().encode(t).byteLength, this.size > ne.textBytes) throw new T("text_limit");
    this.pieces.push(t);
  }
  finish() {
    return this.pieces.join("");
  }
}
const Qh = new Uint32Array(256).map((e, t) => {
  for (let n = 0; n < 8; n++) t = t & 1 ? 3988292384 ^ t >>> 1 : t >>> 1;
  return t >>> 0;
}), pr = (e) => {
  try {
    return new TextDecoder("utf-8", { fatal: !0 }).decode(e);
  } catch {
    throw new T("invalid_utf8");
  }
};
function Go(e) {
  if (e[0] === 208 && e[1] === 207)
    throw new T("unsupported_file");
  const t = new DataView(e.buffer, e.byteOffset, e.byteLength);
  let n = -1;
  for (let f = e.length - 22; f >= Math.max(0, e.length - 65557); f--)
    if (t.getUint32(f, !0) === 101010256 && f + 22 + t.getUint16(f + 20, !0) === e.length) {
      n = f;
      break;
    }
  if (n < 0) throw new T("truncated_file");
  const i = t.getUint16(n + 10, !0), s = t.getUint32(n + 16, !0), r = t.getUint32(n + 12, !0);
  if (i > ne.zipEntries || i === 65535 || s === 4294967295 || r === 4294967295)
    throw new T("zip_limit");
  if (t.getUint16(n + 4, !0) || t.getUint16(n + 6, !0) || t.getUint16(n + 8, !0) !== i || s + r !== n)
    throw new T("unsupported_file");
  const o = [], a = /* @__PURE__ */ new Set();
  let u = s, c = 0;
  for (let f = 0; f < i; f++) {
    if (u + 46 > n || t.getUint32(u, !0) !== 33639248)
      throw new T("malformed_file");
    const l = t.getUint16(u + 28, !0), m = t.getUint16(u + 30, !0), h = t.getUint16(u + 32, !0);
    if (u + 46 + l + m + h > n)
      throw new T("truncated_file");
    const p = {
      name: pr(e.subarray(u + 46, u + 46 + l)),
      flags: t.getUint16(u + 8, !0),
      method: t.getUint16(u + 10, !0),
      crc: t.getUint32(u + 16, !0),
      size: t.getUint32(u + 20, !0),
      expanded: t.getUint32(u + 24, !0),
      offset: t.getUint32(u + 42, !0)
    };
    if (p.flags & 1) throw new T("encrypted_file");
    if (![0, 8].includes(p.method))
      throw new T("unsupported_file");
    if (!p.name || /[\\\x00-\x1f:]/.test(p.name) || p.name.startsWith("/") || p.name.split("/").includes("..") || a.has(p.name))
      throw new T("malformed_file");
    if (/vbaproject|vbaData|activex/i.test(p.name))
      throw new T("macros_unsupported");
    if (a.add(p.name), c += p.expanded, p.expanded > ne.zipEntryBytes || c > ne.zipExpandedBytes || p.expanded > Math.max(1, p.size) * ne.zipRatio)
      throw new T("zip_limit");
    if (p.offset + 30 > s || t.getUint32(p.offset, !0) !== 67324752 || t.getUint16(p.offset + 6, !0) !== p.flags || t.getUint16(p.offset + 8, !0) !== p.method)
      throw new T("malformed_file");
    const y = t.getUint16(p.offset + 26, !0), x = t.getUint16(p.offset + 28, !0);
    if (pr(
      e.subarray(p.offset + 30, p.offset + 30 + y)
    ) !== p.name)
      throw new T("malformed_file");
    if (p.offset += 30 + y + x, p.offset + p.size > s)
      throw new T("truncated_file");
    o.push(p), u += 46 + l + m + h;
  }
  if (u !== n) throw new T("malformed_file");
  return o;
}
async function ft(e, t, n) {
  let i = 0, s = 4294967295;
  const r = new TextDecoder("utf-8", { fatal: !0 }), o = [];
  function a(f, l) {
    if (i += f.length, i > t.expanded || i > ne.zipEntryBytes)
      throw new T("zip_limit");
    for (const m of f)
      s = s >>> 8 ^ Qh[(s ^ m) & 255];
    try {
      o.push(r.decode(f, { stream: !l }));
    } catch {
      throw new T("invalid_utf8");
    }
  }
  const u = e.subarray(t.offset, t.offset + t.size), c = t.method === 8 ? new Bh(a) : null;
  for (let f = 0; f < u.length || f === 0; f += 1024) {
    ae(n);
    const l = u.subarray(f, f + 1024), m = f + 1024 >= u.length;
    c ? c.push(l, m) : a(l, m), f % 32768 === 0 && await new Promise((h) => setTimeout(h, 0));
  }
  if (i !== t.expanded || (s ^ 4294967295) >>> 0 !== t.crc)
    throw new T("malformed_file");
  return o.join("");
}
function Si() {
  const e = new Xh.SaxesParser({ xmlns: !0, position: !1 });
  return e.on("doctype", () => {
    throw new T("unsafe_xml");
  }), e.on("error", () => {
    throw new T("malformed_file");
  }), e;
}
async function em(e, t, n) {
  const i = Go(e), s = i.find(
    (c) => c.name === "[Content_Types].xml"
  );
  if (!s || !i.some((c) => c.name === "word/document.xml"))
    throw new T("unsupported_file");
  let r = !1, o = 0;
  const a = Si();
  if (a.on("opentag", (c) => {
    if (++o > ne.xmlDepth) throw new T("zip_limit");
    const f = c.attributes.ContentType?.value;
    if (f?.includes("macroEnabled"))
      throw new T("macros_unsupported");
    c.attributes.PartName?.value === "/word/document.xml" && f === "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml" && (r = !0);
  }), a.on("closetag", () => {
    o--;
  }), a.write(await ft(e, s, n)).close(), !r) throw new T("unsupported_file");
  const u = i.filter(
    (c) => /^word\/(document|header\d+|footer\d+|footnotes|endnotes)\.xml$/.test(
      c.name
    )
  ).sort(
    (c, f) => c.name === "word/document.xml" ? -1 : f.name === "word/document.xml" ? 1 : c.name.localeCompare(f.name, "en")
  );
  for (const c of u) {
    ae(n);
    const f = await ft(e, c, n), l = Si();
    let m = 0, h = 0, p = 0;
    const y = [];
    l.on("opentag", (k) => {
      if (++m > ne.xmlDepth) throw new T("zip_limit");
      if ([
        "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
        "http://purl.oclc.org/ooxml/wordprocessingml/main"
      ].includes(k.uri)) {
        if (k.local === "r" && y.push({ depth: m, hidden: !1 }), k.local === "vanish" && y.length) {
          const L = Object.values(k.attributes).find(
            (se) => se.local === "val"
          )?.value;
          ["0", "false", "off"].includes(L ?? "true") || (y[y.length - 1].hidden = !0);
        }
        ["del", "moveFrom"].includes(k.local) && !p && (p = m), k.local === "t" && !p && (h = m), ["tab", "br", "cr"].includes(k.local) && !p && !y.at(-1)?.hidden && t.append(k.local === "tab" ? "	" : `
`);
      }
    });
    const x = (k) => {
      h && !p && !y.at(-1)?.hidden && t.append(k);
    };
    l.on("text", x), l.on("cdata", x), l.on("closetag", (k) => {
      m === h && (h = 0), m === p && (p = 0), k.local === "p" && !p && t.append(`
`), y.at(-1)?.depth === m && y.pop(), m--;
    });
    for (let k = 0; k < f.length; k += 16384)
      ae(n), l.write(f.slice(k, k + 16384)), await new Promise((N) => setTimeout(N, 0));
    l.close(), t.append(`
`);
  }
  return u.length;
}
async function tm(e, t, n, i) {
  if (!new TextDecoder("latin1").decode(e.subarray(0, 8)).startsWith("%PDF-")) throw new T("unsupported_file");
  const r = new TextDecoder("latin1").decode(
    e.subarray(Math.max(0, e.length - 1024))
  );
  if (!/%%EOF\s*$/.test(r)) throw new T("truncated_file");
  const o = await import("./pdf-BL_IY-hq.js");
  ae(n);
  const a = i ? new Worker(i, { type: "module" }) : null, u = a ? o.PDFWorker.create({ port: a, verbosity: 0 }) : void 0;
  let c = !1;
  class f {
    async fetch() {
      throw c = !0, new Error("external_document_resources_disabled");
    }
  }
  const l = o.getDocument({
    data: e,
    worker: u,
    verbosity: 0,
    stopAtErrors: !0,
    enableXfa: !1,
    disableFontFace: !0,
    useSystemFonts: !1,
    useWorkerFetch: !1,
    useWasm: !1,
    isOffscreenCanvasSupported: !1,
    isImageDecoderSupported: !1,
    maxImageSize: 0,
    disableAutoFetch: !0,
    disableStream: !0,
    disableRange: !0,
    BinaryDataFactory: f
  }), m = () => {
    l.destroy().catch(() => {
    });
  };
  n?.addEventListener("abort", m, { once: !0 });
  try {
    const h = await l.promise;
    if (ae(n), await h.getPermissions() !== null)
      throw new T("encrypted_file");
    if (h.numPages > ne.pages)
      throw new T("page_limit");
    for (let p = 1; p <= h.numPages; p++) {
      ae(n);
      const y = await h.getPage(p), x = y.streamTextContent({ disableNormalization: !0 }).getReader();
      try {
        for (; ; ) {
          ae(n);
          const { value: k, done: N } = await x.read();
          if (N) break;
          for (const L of k.items)
            "str" in L && (t.append(L.str), L.hasEOL && t.append(`
`));
        }
      } finally {
        await x.cancel().catch(() => {
        }), y.cleanup();
      }
      t.append(`
`);
    }
    if (!t.finish().trim()) throw new T("no_extractable_text");
    return { pages: h.numPages, externalFontMapping: c };
  } catch (h) {
    throw ae(n), h instanceof T ? h : h && typeof h == "object" && "name" in h && h.name === "PasswordException" ? new T("encrypted_file") : new T("malformed_file");
  } finally {
    n?.removeEventListener("abort", m), await l.destroy().catch(() => {
    }), u?.destroy(), a?.terminate();
  }
}
async function fn(e, t, n) {
  const i = Si();
  let s = 0;
  i.on("opentag", (r) => {
    if (++s > ne.xmlDepth) throw new T("zip_limit");
    t.open?.(r);
  }), i.on("text", (r) => t.text?.(r)), i.on("cdata", (r) => t.text?.(r)), i.on("closetag", (r) => {
    t.close?.(r), s--;
  });
  for (let r = 0; r < e.length; r += 16384)
    ae(n), i.write(e.slice(r, r + 16384)), await new Promise((o) => setTimeout(o, 0));
  i.close();
}
async function nm(e, t, n, i) {
  const s = Go(e), r = s.find((h) => h.name === "[Content_Types].xml"), o = t === "xlsx" ? "xl/workbook.xml" : "ppt/presentation.xml";
  if (!r || !s.some((h) => h.name === o))
    throw new T("unsupported_file");
  const a = t === "xlsx" ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml" : "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml";
  let u = !1;
  if (await fn(
    await ft(e, r, i),
    {
      open(h) {
        const p = h.attributes.ContentType?.value;
        if (p?.includes("macroEnabled"))
          throw new T("macros_unsupported");
        h.attributes.PartName?.value === "/" + o && p === a && (u = !0);
      }
    },
    i
  ), !u) throw new T("unsupported_file");
  if (t === "pptx") {
    const h = s.filter((p) => /^ppt\/slides\/slide\d+\.xml$/.test(p.name)).sort((p, y) => p.name.localeCompare(y.name, "en", { numeric: !0 }));
    if (!h.length) throw new T("no_extractable_text");
    if (h.length > ne.pages) throw new T("page_limit");
    for (const p of h) {
      let y = !1;
      await fn(
        await ft(e, p, i),
        {
          open(x) {
            y = x.local === "t" && [
              "http://schemas.openxmlformats.org/drawingml/2006/main",
              "http://purl.oclc.org/ooxml/drawingml/main"
            ].includes(x.uri);
          },
          text(x) {
            y && n.append(x);
          },
          close(x) {
            x.local === "t" && (y = !1), x.local === "p" && n.append(`
`);
          }
        },
        i
      ), n.append(`
`);
    }
    return h.length;
  }
  const c = [], f = s.find((h) => h.name === "xl/sharedStrings.xml");
  if (f) {
    let h = "", p = !1, y = !1;
    await fn(
      await ft(e, f, i),
      {
        open(x) {
          x.local === "si" && (h = ""), x.local === "rPh" && (y = !0), x.local === "t" && (p = !0);
        },
        text(x) {
          p && !y && (h += x);
        },
        close(x) {
          if (x.local === "t" && (p = !1), x.local === "rPh" && (y = !1), x.local === "si") {
            if (c.length >= ne.cells)
              throw new T("zip_limit");
            c.push(h);
          }
        }
      },
      i
    );
  }
  const l = s.filter((h) => /^xl\/worksheets\/sheet\d+\.xml$/.test(h.name)).sort((h, p) => h.name.localeCompare(p.name, "en", { numeric: !0 }));
  if (!l.length) throw new T("no_extractable_text");
  if (l.length > ne.sheets) throw new T("page_limit");
  let m = 0;
  for (const h of l) {
    let p = !1, y = !1, x = "", k = "";
    await fn(
      await ft(e, h, i),
      {
        open(N) {
          if (N.local === "c") {
            if (++m > ne.cells) throw new T("zip_limit");
            p = !0, x = N.attributes.t?.value ?? "n", k = "";
          }
          p && (N.local === "v" || x === "inlineStr" && N.local === "t") && (y = !0);
        },
        text(N) {
          y && (k += N);
        },
        close(N) {
          if ((N.local === "v" || N.local === "t") && (y = !1), N.local === "c") {
            if (x === "s") {
              if (!/^[0-9]{1,6}$/.test(k) || Number(k) >= c.length)
                throw new T("malformed_file");
              k = c[Number(k)];
            }
            n.append(k + "	"), p = !1;
          }
          N.local === "row" && n.append(`
`);
        }
      },
      i
    ), n.append(`
`);
  }
  return l.length;
}
async function im(e, t = {}) {
  Jo(e);
  const n = e.bytes.byteLength;
  try {
    ae(t.signal);
    const i = new Uint8Array(e.bytes), s = new Yh();
    let r = null, o = 1, a = !1;
    if (e.kind === "text") {
      const p = new TextDecoder("utf-8", { fatal: !0 });
      for (let y = 0; y < i.length || y === 0; y += 16384) {
        ae(t.signal);
        try {
          s.append(
            p.decode(i.subarray(y, y + 16384), {
              stream: y + 16384 < i.length
            })
          );
        } catch (x) {
          throw x instanceof T ? x : new T("invalid_utf8");
        }
        await new Promise((x) => setTimeout(x, 0));
      }
    } else if (e.kind === "docx")
      o = await em(i, s, t.signal);
    else if (e.kind === "xlsx" || e.kind === "pptx")
      o = await nm(i, e.kind, s, t.signal), e.kind === "pptx" && (r = o);
    else {
      const p = await tm(
        i,
        s,
        t.signal,
        t.pdfWorkerSrc
      );
      r = p.pages, o = p.pages, a = p.externalFontMapping;
    }
    ae(t.signal);
    const u = s.finish();
    if (e.kind !== "text" && !u.trim())
      throw new T("no_extractable_text");
    const c = t.tokenizer ?? Yi, f = Gh(e), l = Lo(c, f.profileId);
    if (c.id !== f.implementationId || !l)
      throw new T("tokenizer_unavailable");
    const m = {
      text: u,
      jobId: e.jobId,
      revision: e.revision,
      modelId: null,
      profileId: f.profileId
    }, h = await Nh(m, c);
    if (ae(t.signal), h.status !== "counted" || !wh(h, m, l))
      throw new T("tokenizer_unavailable");
    return {
      jobId: e.jobId,
      revision: e.revision,
      kind: e.kind,
      status: "counted",
      reason: null,
      inputBytes: n,
      extractedTextBytes: s.size,
      pages: r,
      textParts: o,
      tokens: h.measurement.value,
      scope: "extracted_file_text",
      tokenizerProfile: h.profileId,
      tokenizerAssetHash: h.assetHash,
      evidence: "heuristic_estimate",
      modelExactness: "unverified",
      extractionProfile: Vo,
      coverage: "complete_for_extraction_profile",
      missing: [
        "provider_processing",
        "ocr",
        "image_encoding",
        "retrieval_selection",
        ...e.kind !== "text" ? ["layout_and_drawing_text", "rendered_visibility"] : [],
        ...e.kind === "xlsx" ? ["formula_recalculation"] : [],
        ...a ? ["external_font_mapping"] : []
      ],
      association: "unassociated",
      telemetryAllowed: !1
    };
  } catch (i) {
    return {
      ...Xo(
        e,
        i instanceof T ? i.code : "malformed_file"
      ),
      inputBytes: n
    };
  }
}
var sm = "/assets/pdf-worker-BKUmZ-vi.js";
const rm = Yi;
class om {
  constructor(t, n = rm, i = sm) {
    this.post = t, this.tokenizer = n, this.pdfSource = i;
  }
  post;
  tokenizer;
  pdfSource;
  active = null;
  disposed = !1;
  async receive(t) {
    if (this.disposed) return;
    if (t && typeof t == "object" && "cancel" in t) {
      const r = t, o = Object.keys(r).sort().join(",");
      (o === "cancel" || o === "cancel,revision") && typeof r.cancel == "string" && (r.revision === void 0 || Number.isSafeInteger(r.revision) && r.revision === this.active?.job.revision) && this.active && r.cancel === this.active.job.jobId && this.active.abort.abort();
      return;
    }
    const n = t;
    try {
      Jo(n);
    } catch {
      return;
    }
    if (this.active) {
      this.post(Xo(n, "busy"));
      return;
    }
    const i = new AbortController(), s = { job: n, abort: i };
    this.active = s;
    try {
      const r = await im(n, {
        signal: i.signal,
        pdfWorkerSrc: this.pdfSource,
        tokenizer: this.tokenizer
      });
      !this.disposed && this.active === s && this.post(r);
    } finally {
      this.active === s && (this.active = null);
    }
  }
  dispose() {
    this.disposed = !0, this.active?.abort.abort();
  }
}
const am = new om((e) => self.postMessage(e));
self.onmessage = (e) => am.receive(e.data);
