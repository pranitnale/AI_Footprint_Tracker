import{c as E,i as I,B as N}from"./types-DugsohS3.js";const _=N,t=E(_,I);export{t as P};
