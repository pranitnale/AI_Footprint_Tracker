import { G as e } from "./GptEncoding-BiZOMHiF.js";
import { A as h, D as A, E as G, a as x, F as I, b as T, c as _, H as u, d as F, e as L, f as M, g as b, h as k, i as O, j as P, I as z, k as D, l as R } from "./GptEncoding-BiZOMHiF.js";
import a from "./o200k_base-BYTgCC8K.js";
const o = e.getEncodingApi("o200k_base", () => a), { decode: t, decodeAsyncGenerator: s, decodeGenerator: i, encode: m, encodeGenerator: d, isWithinTokenLimit: c, countTokens: E, encodeChat: f, encodeChatGenerator: C, vocabularySize: p, setMergeCacheSize: y, clearMergeCache: H, estimateCost: S } = o;
export {
  h as ALL_SPECIAL_TOKENS,
  A as DEFAULT_MERGE_CACHE_SIZE,
  G as EndOfPrompt,
  x as EndOfText,
  I as FimMiddle,
  T as FimPrefix,
  _ as FimSuffix,
  u as HarmonyCall,
  F as HarmonyChannel,
  L as HarmonyConstrain,
  M as HarmonyEnd,
  b as HarmonyMessage,
  k as HarmonyReturn,
  O as HarmonyStart,
  P as HarmonyStartOfText,
  z as ImEnd,
  D as ImSep,
  R as ImStart,
  H as clearMergeCache,
  E as countTokens,
  t as decode,
  s as decodeAsyncGenerator,
  i as decodeGenerator,
  o as default,
  m as encode,
  f as encodeChat,
  C as encodeChatGenerator,
  d as encodeGenerator,
  S as estimateCost,
  c as isWithinTokenLimit,
  y as setMergeCacheSize,
  p as vocabularySize
};
