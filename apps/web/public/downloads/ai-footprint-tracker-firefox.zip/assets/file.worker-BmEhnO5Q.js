function ai(e) {
  const t = Object.values(e).filter((i) => typeof i == "number");
  return Object.entries(e).filter(([i, s]) => t.indexOf(+i) === -1).map(([i, s]) => s);
}
function ls(e, t = "|") {
  return e.map((n) => _r(n)).join(t);
}
function ci(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
class fa {
  constructor(t) {
    this._getter = t, this._value = void 0;
  }
  get value() {
    const t = this._getter;
    return t !== void 0 && (this._value = t(), this._getter = void 0), this._value;
  }
}
function xn(e) {
  return new fa(e);
}
function pa(e) {
  return e == null;
}
function ki(e) {
  const t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
function ha(e, t) {
  const n = e / t, i = Math.round(n), s = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - i) < s ? 0 : n - i;
}
function Oe(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function Si(e) {
  const t = Object.getOwnPropertyDescriptor(e, "shape");
  return t?.get ? t.get.raw : t?.value;
}
function Te(e) {
  return Si(e._zod.def) ?? e._zod.def.shape;
}
function fr(e, t, n) {
  Object.defineProperty(e, t, {
    get() {
      const i = n();
      return Oe(this, t, i), i;
    },
    enumerable: !0,
    configurable: !0
  });
}
function pr(e, t, n) {
  t in e ? Oe(e, t, n) : e[t] = n;
}
function Ye(e, t, n, i) {
  const s = Te(t);
  for (const r of n) {
    const o = Object.getOwnPropertyDescriptor(s, r);
    o.enumerable && (o.get ? fr(e, r, () => {
      const a = t._zod.def.shape[r];
      return i ? i(a, r) : a;
    }) : pr(e, r, i ? i(o.value, r) : o.value));
  }
}
function ma(e, t) {
  for (const n of Reflect.ownKeys(t)) {
    const i = Object.getOwnPropertyDescriptor(t, n);
    i.enumerable && (i.get ? fr(e, n, () => t[n]) : pr(e, n, i.value));
  }
}
function oe(...e) {
  const t = {};
  for (const n of e) {
    const i = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, i);
  }
  return Object.defineProperties({}, t);
}
function _a(e) {
  return JSON.stringify(e);
}
function ga(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const hr = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Zt(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
const va = /* @__PURE__ */ xn(() => {
  if (le.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    const e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function pt(e) {
  if (Zt(e) === !1)
    return !1;
  const t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  const n = t.prototype;
  return !(Zt(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
function mr(e) {
  return pt(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
const ba = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function ht(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Be(e, t, n) {
  const i = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (i._zod.parent = e), i;
}
function z(e) {
  const t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: () => t };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: () => t.error } : t;
}
function _r(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function ya(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
const gr = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, wa = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function xa(e, t) {
  const n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const r = {};
  return Ye(r, e, kn(e, t)), Be(e, oe(n, { shape: r, checks: [] }));
}
function kn(e, t) {
  const n = Te(e), i = [];
  for (const s of Reflect.ownKeys(t)) {
    if (!Object.getOwnPropertyDescriptor(n, s)?.enumerable)
      throw new Error(`Unrecognized key: "${String(s)}"`);
    t[s] && i.push(s);
  }
  return i;
}
function ka(e, t) {
  const n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const r = new Set(kn(e, t)), o = {};
  return Ye(o, e, Reflect.ownKeys(Te(e)).filter((a) => !r.has(a))), Be(e, oe(n, { shape: o, checks: [] }));
}
function Sa(e, t) {
  if (!pt(t))
    throw new Error("Invalid input to extend: expected a plain object");
  const n = e._zod.def.checks;
  if (n && n.length > 0) {
    const s = Te(e);
    for (const r of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(s, r) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  return Be(e, oe(e._zod.def, { shape: vr(e, t) }));
}
function vr(e, t) {
  const n = {};
  return Ye(n, e, Reflect.ownKeys(Te(e))), ma(n, t), n;
}
function Ea(e, t) {
  if (!pt(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  return Be(e, oe(e._zod.def, { shape: vr(e, t) }));
}
function Ia(e, t) {
  if (!t?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  const n = {};
  Ye(n, e, Reflect.ownKeys(Te(e))), Ye(n, t, Reflect.ownKeys(Te(t)));
  const i = oe(e._zod.def, {
    shape: n,
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return Be(e, i);
}
function ds(e, t, n, i = "partial") {
  const r = t._zod.def.checks;
  if (r && r.length > 0)
    throw new Error(`.${i}() cannot be used on object schemas containing refinements`);
  const a = n ? new Set(kn(t, n)) : void 0, l = {};
  return Ye(l, t, Reflect.ownKeys(Te(t)), e && ((c, f) => a && !a.has(f) ? c : new e({ type: "optional", innerType: c }))), Be(t, oe(t._zod.def, { shape: l, checks: [] }));
}
function za(e, t, n) {
  const i = n ? new Set(kn(t, n)) : void 0, s = {};
  return Ye(s, t, Reflect.ownKeys(Te(t)), (r, o) => (
    // overwrite with non-optional
    i && !i.has(o) ? r : new e({ type: "nonoptional", innerType: r })
  )), Be(t, oe(t._zod.def, { shape: s }));
}
function me(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
function Ta(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue === !1)
      return !0;
  return !1;
}
function Re(e, t) {
  return t.map((n) => {
    var i;
    return (i = n).path ?? (i.path = []), n.path.unshift(e), n;
  });
}
function Ot(e) {
  return typeof e == "string" ? e : e?.message;
}
function fs(e, t, n) {
  var i;
  for (let s = t; s < e.length; s++)
    (i = e[s]).schema ?? (i.schema = n);
}
function je(e, t, n) {
  var i;
  const s = e.inst?._zod?.traits;
  s?.has("$ZodType") && (s.has("$ZodCheck") ? (i = e).schema ?? (i.schema = e.inst) : e.schema = e.inst);
  const r = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, o = e.message ? e.message : Ot(e.inst?._zod.def?.error?.(e)) ?? Ot(r?.(e)) ?? Ot(t?.error?.(e)) ?? Ot(n.customError?.(e)) ?? Ot(n.localeError?.(e)) ?? "Invalid input", a = {};
  for (const l of Object.keys(e))
    l === "inst" || l === "schema" || l === "continue" || l === "input" || l === "__proto__" || (a[l] = e[l]);
  return a.path ?? (a.path = []), a.message = o, t?.reportInput && (a.input = e.input), a;
}
const Oa = /[\uD800-\uDBFF]/;
function Ei(e) {
  const t = e.length;
  if (!Oa.test(e))
    return t;
  let n = t;
  for (let i = 0; i < t - 1; i++)
    (e.charCodeAt(i) & 64512) === 55296 && (e.charCodeAt(i + 1) & 64512) === 56320 && (n--, i++);
  return n;
}
function Ii(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function Aa(e) {
  const t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      const n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
function Mt(...e) {
  const [t, n, i] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: i
  } : { ...t };
}
function Na(e, t) {
  for (const n in t) {
    const i = Object.getOwnPropertyDescriptor(t, n);
    i.get ? Object.defineProperty(e, n, { ...i, enumerable: !1 }) : ps(e, n, i.value);
  }
  for (const n of Object.getOwnPropertySymbols(t))
    ps(e, n, t[n]);
}
function Le(e, t, n, i = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: i, value: n }), n;
}
function br(e, t, n) {
  return Le(e, t, n, !1);
}
function yr(e, t) {
  for (const n in e) {
    const i = e[n];
    Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      get() {
        return Le(this, n, i(this));
      },
      set(s) {
        Le(this, n, s);
      }
    });
  }
  return t;
}
function ps(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? n : Le(this, t, n.bind(this));
    },
    set(i) {
      Le(this, t, i);
    }
  });
}
function Ca(e, t) {
  const n = Object.getPrototypeOf(e);
  return t in n ? void 0 : n;
}
let jn, Pe = !1;
const $a = {
  configurable: !0,
  get() {
    Pe = !0;
  }
};
function F(e, t, n) {
  const i = Object.getPrototypeOf(e._zod);
  if (t in i && jn !== e._zod) {
    jn = void 0;
    return;
  }
  jn = e._zod, Object.defineProperty(i, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, $a);
      const s = Pe;
      Pe = !1;
      try {
        const r = n(this);
        return Pe ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: r }), Pe = Pe || s, r;
      } catch (r) {
        throw delete this[t], Pe = Pe || s, r;
      }
    },
    set(s) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: s });
    }
  });
}
function Da(e, t, n, i) {
  const s = Ca(e, t);
  s && Object.defineProperty(s, t, {
    configurable: !0,
    get() {
      const r = { configurable: !0, writable: !0, enumerable: i, value: void 0 };
      return Object.defineProperty(this, t, r), r.value = n(this), Object.defineProperty(this, t, r), r.value;
    },
    set(r) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: i, value: r });
    }
  });
}
const Fa = "~constantCatch";
function Pa(e) {
  const t = () => e;
  return t[Fa] = !0, t;
}
var hs;
const Ln = { value: void 0, enumerable: !1 };
let ms = "captureStackTrace" in Error ? Error : null;
function Ra(e) {
  const t = ms;
  if (t) {
    const n = t.stackTraceLimit;
    if (typeof n == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return ms = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = n;
      }
    }
  }
  return new e();
}
function v(e, t, n, i) {
  const s = {};
  function r(m) {
    this.def = m, this.constr = u, this.traits = /* @__PURE__ */ new Set();
  }
  r.prototype = s;
  const o = n, a = o && /* @__PURE__ */ new WeakSet();
  function l(m, h) {
    if (!m._zod) {
      Ln.value = new r(h);
      try {
        Object.defineProperty(m, "_zod", Ln);
      } finally {
        Ln.value = void 0;
      }
    }
    if (m._zod.traits.has(e))
      return;
    if (m._zod.traits.add(e), t(m, h), a) {
      const y = Object.getPrototypeOf(m), x = m._zod.constr.prototype;
      let k = y;
      for (; k && k !== x; )
        k = Object.getPrototypeOf(k);
      const N = k ?? y;
      a.has(N) || (a.add(N), Na(N, o));
    }
    const p = u.prototype;
    for (const y in p)
      Object.prototype.hasOwnProperty.call(p, y) && (y in m || (m[y] = p[y].bind(m)));
  }
  const c = i?.Parent ?? Object;
  class f extends c {
  }
  Object.defineProperty(f, "name", { value: e });
  function u(m) {
    const h = i?.Parent ? Ra(f) : this;
    l(h, m);
    const p = h._zod.deferred;
    if (p) {
      for (const x of p)
        x();
      h._zod.deferred = void 0;
    }
    const y = globalThis.__zod_globalConfig?.postProcessor;
    return y && y(h), h;
  }
  return Object.defineProperty(u, "init", { value: l }), Object.defineProperty(u, Symbol.hasInstance, {
    value: (m) => i?.Parent && m instanceof i.Parent ? !0 : m?._zod?.traits?.has(e)
  }), Object.defineProperty(u, "name", { value: e }), u;
}
class Xe extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class wr extends Error {
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}
(hs = globalThis).__zod_globalConfig ?? (hs.__zod_globalConfig = {});
const le = globalThis.__zod_globalConfig;
function ve(e) {
  return e && Object.assign(le, e), le;
}
function Za() {
  const e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, ci, 2)), e.message;
}
function Ma(e) {
  this._zod.message = e;
}
const ja = {
  get: Za,
  set: Ma,
  enumerable: !0,
  configurable: !0
}, Un = { value: void 0, enumerable: !1 }, _s = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), La = (e, t) => {
  e.name = "$ZodError", Un.value = t, Object.defineProperty(e, "issues", Un), Un.value = void 0, Object.defineProperty(e, "message", ja);
  const n = Object.getPrototypeOf(e);
  _s.has(n) || (_s.add(n), Object.defineProperty(n, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      const i = () => this.message;
      return Object.defineProperty(this, "toString", { value: i, configurable: !0, writable: !0 }), i;
    },
    set(i) {
      Object.defineProperty(this, "toString", { value: i, configurable: !0, writable: !0 });
    }
  }));
}, Ua = v("$ZodError", La);
function Ba(e, t, n) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: n(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = n()), e[t];
}
function qa(e, t = (n) => n.message) {
  const n = {}, i = [];
  for (const s of e.issues)
    s.path.length > 0 ? Ba(n, s.path[0], () => []).push(t(s)) : i.push(t(s));
  return { formErrors: i, fieldErrors: n };
}
function Ha(e, t = (n) => n.message) {
  const n = { _errors: [] }, i = (s, r = []) => {
    for (const o of s.issues)
      if (o.code === "invalid_union" && o.errors.length)
        o.errors.map((a) => i({ issues: a }, [...r, ...o.path]));
      else if (o.code === "invalid_key")
        i({ issues: o.issues }, [...r, ...o.path]);
      else if (o.code === "invalid_element")
        i({ issues: o.issues }, [...r, ...o.path]);
      else {
        const a = [...r, ...o.path];
        if (a.length === 0)
          n._errors.push(t(o));
        else {
          let l = n, c = 0;
          for (; c < a.length; ) {
            const f = a[c], u = c === a.length - 1;
            if (f === "_errors") {
              u && l._errors.push(t(o)), c++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(l, f) || Object.defineProperty(l, f, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            const m = l[f];
            u && m._errors.push(t(o)), l = m, c++;
          }
        }
      }
  };
  return i(e), n;
}
function Sn(e, t) {
  return { callee: t?.callee ?? e, Err: t?.Err };
}
const zi = (e) => {
  const t = (n, i, s, r) => {
    const o = s ? { ...s, async: !1 } : { async: !1 }, a = n._zod.run({ value: i, issues: [] }, o);
    if (a instanceof Promise)
      throw new Xe();
    if (a.issues.length) {
      const l = new (r?.Err ?? e)(a.issues.map((c) => je(c, o, ve())));
      throw hr(l, r?.callee ?? t), l;
    }
    return a.value;
  };
  return t;
}, Ti = (e) => {
  const t = async (n, i, s, r) => {
    const o = s ? { ...s, async: !0 } : { async: !0 };
    let a = n._zod.run({ value: i, issues: [] }, o);
    if (a instanceof Promise && (a = await a), a.issues.length) {
      const l = new (r?.Err ?? e)(a.issues.map((c) => je(c, o, ve())));
      throw hr(l, r?.callee ?? t), l;
    }
    return a.value;
  };
  return t;
}, Oi = (e) => (t, n, i) => {
  const s = i ? { ...i, async: !1 } : { async: !1 }, r = t._zod.run({ value: n, issues: [] }, s);
  if (r instanceof Promise)
    throw new Xe();
  return r.issues.length ? xr(e, r.issues, s) : { success: !0, data: r.value };
};
function xr(e, t, n) {
  let i;
  return {
    success: !1,
    get error() {
      return i || (i = new e(t.map((s) => je(s, n, ve()))), t = void 0, n = void 0), i;
    },
    set error(s) {
      i = s, t = void 0, n = void 0;
    }
  };
}
const Ai = (e) => async (t, n, i) => {
  const s = i ? { ...i, async: !0 } : { async: !0 };
  let r = t._zod.run({ value: n, issues: [] }, s);
  return r instanceof Promise && (r = await r), r.issues.length ? xr(e, r.issues, s) : { success: !0, data: r.value };
}, Wa = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), Ka = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), Va = ((e, t, n) => {
  const i = e._zod.bag.validator;
  if (i !== void 0) {
    if (i(t) !== Wa)
      return !0;
    if (i.definite === !0 && n === void 0)
      return !1;
  }
  return Ja(e, t, n);
});
function Ja(e, t, n) {
  const i = n ? { ...n, async: !1, abortEarly: !0 } : { async: !1, abortEarly: !0 }, s = e._zod.bag.fallbackRun;
  let r;
  if (s ? (i[Ka] = !0, r = s({ value: t, issues: [] }, i)) : r = e._zod.run({ value: t, issues: [] }, i), r instanceof Promise)
    throw new Xe();
  return r.issues.length === 0;
}
const Xa = async (e, t, n) => {
  const i = n ? { ...n, async: !0, abortEarly: !0 } : { async: !0, abortEarly: !0 };
  let s = e._zod.run({ value: t, issues: [] }, i);
  return s instanceof Promise && (s = await s), s.issues.length === 0;
}, Ga = (e) => {
  const t = zi(e), n = (i, s, r, o) => {
    const a = r ? { ...r, direction: "backward" } : { direction: "backward" };
    return t(i, s, a, Sn(n, o));
  };
  return n;
}, Ya = (e) => {
  const t = zi(e), n = (i, s, r, o) => t(i, s, r, Sn(n, o));
  return n;
}, Qa = (e) => {
  const t = Ti(e), n = async (i, s, r, o) => {
    const a = r ? { ...r, direction: "backward" } : { direction: "backward" };
    return await t(i, s, a, Sn(n, o));
  };
  return n;
}, ec = (e) => {
  const t = Ti(e), n = async (i, s, r, o) => await t(i, s, r, Sn(n, o));
  return n;
}, tc = (e) => (t, n, i) => {
  const s = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Oi(e)(t, n, s);
}, nc = (e) => (t, n, i) => Oi(e)(t, n, i), ic = (e) => async (t, n, i) => {
  const s = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return Ai(e)(t, n, s);
}, sc = (e) => async (t, n, i) => Ai(e)(t, n, i), rc = /^[cC][0-9a-z]{6,}$/, oc = /^[0-9a-z]+$/, ac = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, cc = /^[0-9a-vA-V]{20}$/, uc = /^[A-Za-z0-9]{27}$/, lc = /^[a-zA-Z0-9_-]{21}$/;
function dc(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
const fc = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, pc = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, gs = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, hc = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, mc = "^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function _c() {
  return new RegExp(mc, "u");
}
const gc = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, vc = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, bc = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, yc = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, wc = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, xc = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/, kc = /^https?$/, Sc = /^\+[1-9]\d{6,14}$/, kr = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Ec(e) {
  return new RegExp(`^${e}$`);
}
const Ic = /* @__PURE__ */ Ec(kr);
function ui(e) {
  const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function zc(e) {
  return new RegExp(`^${ui(e)}$`);
}
function Tc(e) {
  const t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${ui({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, i = e.local ? `${n}|${ui({ precision: e.precision })}` : n;
  return new RegExp(`^${kr}T(?:${i})$`);
}
const Oc = /^[\s\S]{0,}$/, Ac = /^-?\d+$/, Ni = /^-?\d+(?:\.\d+)?$/, Nc = /^(?:true|false)$/i, Cc = /^null$/i, $c = /^[^A-Z]*$/, Dc = /^[^a-z]*$/, ie = /* @__PURE__ */ v("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), Ci = (e) => {
  const t = e.value;
  return !pa(t) && t.length !== void 0;
}, gn = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Sr = /* @__PURE__ */ v("$ZodCheckLessThan", (e, t) => {
  ie.init(e, t);
  const n = gn[typeof t.value];
  e._zod.check = (i) => {
    (t.inclusive ? i.value <= t.value : i.value < t.value) || i.issues.push({
      origin: gn[typeof i.value] ?? n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Er = /* @__PURE__ */ v("$ZodCheckGreaterThan", (e, t) => {
  ie.init(e, t);
  const n = gn[typeof t.value];
  e._zod.check = (i) => {
    (t.inclusive ? i.value >= t.value : i.value > t.value) || i.issues.push({
      origin: gn[typeof i.value] ?? n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Fc = /* @__PURE__ */ v("$ZodCheckMultipleOf", (e, t) => {
  ie.init(e, t), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && n.value % t.value === BigInt(0)
    ) : ha(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Pc = /* @__PURE__ */ v("$ZodCheckNumberFormat", (e, t) => {
  ie.init(e, t), t.format = t.format || "float64";
  const n = t.format?.includes("int"), i = n ? "int" : "number", [s, r] = gr[t.format];
  e._zod.check = (o) => {
    const a = o.value;
    if (n) {
      if (!Number.isInteger(a)) {
        o.issues.push({
          expected: i,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: a,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(a)) {
        a > 0 ? o.issues.push({
          input: a,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        }) : o.issues.push({
          input: a,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    a < s && o.issues.push({
      origin: "number",
      input: a,
      code: "too_small",
      minimum: s,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), a > r && o.issues.push({
      origin: "number",
      input: a,
      code: "too_big",
      maximum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), Rc = /* @__PURE__ */ v("$ZodCheckMaxLength", (e, t) => {
  var n;
  ie.init(e, t), (n = e._zod.def).when ?? (n.when = Ci), e._zod.check = (i) => {
    const s = i.value, r = s.length;
    if ((typeof s == "string" && r > t.maximum ? Ei(s) : r) <= t.maximum)
      return;
    const a = Ii(s);
    i.issues.push({
      origin: a,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: s,
      inst: e,
      continue: !t.abort
    });
  };
}), Zc = /* @__PURE__ */ v("$ZodCheckMinLength", (e, t) => {
  var n;
  ie.init(e, t), (n = e._zod.def).when ?? (n.when = Ci), e._zod.check = (i) => {
    const s = i.value, r = s.length;
    if ((typeof s == "string" && r >= t.minimum && r < t.minimum * 2 ? Ei(s) : r) >= t.minimum)
      return;
    const a = Ii(s);
    i.issues.push({
      origin: a,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: s,
      inst: e,
      continue: !t.abort
    });
  };
}), Mc = /* @__PURE__ */ v("$ZodCheckLengthEquals", (e, t) => {
  var n;
  ie.init(e, t), (n = e._zod.def).when ?? (n.when = Ci), e._zod.check = (i) => {
    const s = i.value, r = s.length, o = typeof s == "string" && r >= t.length && r <= t.length * 2 ? Ei(s) : r;
    if (o === t.length)
      return;
    const a = Ii(s), l = o > t.length;
    i.issues.push({
      origin: a,
      ...l ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), En = /* @__PURE__ */ v("$ZodCheckStringFormat", (e, t) => {
  var n, i;
  ie.init(e, t), t.pattern ? (n = e._zod).check ?? (n.check = (s) => {
    t.pattern.lastIndex = 0, !t.pattern.test(s.value) && s.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: s.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (i = e._zod).check ?? (i.check = () => {
  });
}), jc = /* @__PURE__ */ v("$ZodCheckRegex", (e, t) => {
  En.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), Lc = /* @__PURE__ */ v("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = $c), En.init(e, t);
}), Uc = /* @__PURE__ */ v("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = Dc), En.init(e, t);
}), Bc = /* @__PURE__ */ v("$ZodCheckIncludes", (e, t) => {
  ie.init(e, t);
  const n = ht(t.includes), i = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
  t.pattern = i, e._zod.check = (s) => {
    s.value.includes(t.includes, t.position) || s.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: s.value,
      inst: e,
      continue: !t.abort
    });
  };
}), qc = /* @__PURE__ */ v("$ZodCheckStartsWith", (e, t) => {
  ie.init(e, t);
  const n = new RegExp(`^${ht(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.check = (i) => {
    i.value.startsWith(t.prefix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Hc = /* @__PURE__ */ v("$ZodCheckEndsWith", (e, t) => {
  ie.init(e, t);
  const n = new RegExp(`.*${ht(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.check = (i) => {
    i.value.endsWith(t.suffix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Wc = /* @__PURE__ */ v("$ZodCheckOverwrite", (e, t) => {
  ie.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});
class Kc {
  constructor(t = [], n = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = n;
  }
  // the compiler catches a child's throw and keeps writing into this doc, so the indent has to unwind with it
  indented(t) {
    this.indent += 1;
    try {
      t(this);
    } finally {
      this.indent -= 1;
    }
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    const i = t.split(`
`).filter((o) => o), s = Math.min(...i.map((o) => o.length - o.trimStart().length)), r = i.map((o) => o.slice(s)).map((o) => " ".repeat(this.indent * 2) + o);
    for (const o of r)
      this.content.push(o);
  }
  compile() {
    const t = Function, n = this?.content ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${n.join(`
`)}
};`)(...Object.values(this.closed));
  }
}
const Vc = {
  major: 4,
  minor: 6,
  patch: 1
}, M = /* @__PURE__ */ v("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Vc;
  const i = e._zod.def.checks, s = e._zod.traits.has("$ZodCheck") ? [e, ...i ?? []] : i?.length ? [...i] : [];
  for (const r of s)
    for (const o of r._zod.onattach)
      o(e);
  if (s.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    const r = (a, l, c) => {
      if (a.memo)
        return a;
      let f = me(a), u;
      for (const m of l) {
        if (m._zod.def.when) {
          if (Ta(a) || !m._zod.def.when(a))
            continue;
        } else if (f)
          continue;
        const h = a.issues.length, p = m._zod.check(a);
        if (p instanceof Promise && c?.async === !1)
          throw new Xe();
        if (u || p instanceof Promise)
          u = (u ?? Promise.resolve()).then(async () => {
            await p, a.issues.length !== h && (fs(a.issues, h, e), f || (f = me(a, h)));
          });
        else {
          if (a.issues.length === h)
            continue;
          fs(a.issues, h, e), f || (f = me(a, h));
        }
      }
      return u ? u.then(() => a) : a;
    }, o = (a, l, c) => {
      if (me(a))
        return a.aborted = !0, a;
      const f = r(l, s, c);
      if (f instanceof Promise) {
        if (c.async === !1)
          throw new Xe();
        return f.then((u) => e._zod.parse(u, c));
      }
      return e._zod.parse(f, c);
    };
    e._zod.run = (a, l) => {
      if (l.skipChecks)
        return e._zod.parse(a, l);
      if (l.direction === "backward") {
        const f = e._zod.parse({ value: a.value, issues: [] }, { ...l, skipChecks: !0 });
        return f instanceof Promise ? f.then((u) => o(u, a, l)) : o(f, a, l);
      }
      const c = e._zod.parse(a, l);
      if (c instanceof Promise) {
        if (l.async === !1)
          throw new Xe();
        return c.then((f) => r(f, s, l));
      }
      return r(c, s, l);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return br(this, "~standard", zr(this));
  },
  set "~standard"(e) {
    Le(this, "~standard", e);
  }
}), Ir = (e, t) => e.issues.length ? { issues: e.issues.map((n) => je(n, t, ve())) } : { value: e.value };
async function Jc(e, t) {
  const n = { async: !0 };
  return Ir(await e._zod.run({ value: t, issues: [] }, n), n);
}
function zr(e) {
  return {
    validate: (t) => {
      const n = { async: !1 };
      try {
        const i = e._zod.run({ value: t, issues: [] }, n);
        if (!(i instanceof Promise))
          return Ir(i, n);
      } catch {
      }
      return Jc(e, t);
    },
    vendor: "zod",
    version: 1
  };
}
const $i = /* @__PURE__ */ v("$ZodString", (e, t) => {
  M.init(e, t), e._zod.pattern = t.pattern ?? Oc, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), q = /* @__PURE__ */ v("$ZodStringFormat", (e, t) => {
  En.init(e, t), $i.init(e, t);
}), Xc = /* @__PURE__ */ v("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = pc), q.init(e, t);
}), Gc = /* @__PURE__ */ v("$ZodUUID", (e, t) => {
  if (t.version) {
    const i = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (i === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = gs(i));
  } else
    t.pattern ?? (t.pattern = gs());
  q.init(e, t);
}), Yc = /* @__PURE__ */ v("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = hc), q.init(e, t);
}), Tr = 1, Or = 2;
function Qc(e, t) {
  if (!t.normalize && t.protocol?.source === kc.source && !/^https?:\/\//i.test(e))
    return Tr;
  try {
    return new URL(e);
  } catch {
    return Or;
  }
}
const eu = /[\t\n\r]/g;
function tu(e) {
  return e.replace(eu, "");
}
function nu(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
function iu(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
const su = /* @__PURE__ */ v("$ZodURL", (e, t) => {
  q.init(e, t), e._zod.check = (n) => {
    try {
      const i = n.value.trim(), s = Qc(i, t);
      if (s === Tr) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (s === Or) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      t.hostname && !nu(s, t.hostname) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !iu(s, t.protocol) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), n.value = t.normalize ? s.href : tu(i);
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), ru = /* @__PURE__ */ v("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = _c()), q.init(e, t);
}), ou = /* @__PURE__ */ v("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? lc : dc(t.length)), q.init(e, t);
}), au = /* @__PURE__ */ v("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = rc), q.init(e, t);
}), cu = /* @__PURE__ */ v("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = oc), q.init(e, t);
}), uu = /* @__PURE__ */ v("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = ac), q.init(e, t);
}), lu = /* @__PURE__ */ v("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = cc), q.init(e, t);
}), du = /* @__PURE__ */ v("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = uc), q.init(e, t);
}), fu = /* @__PURE__ */ v("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = Tc(t)), q.init(e, t);
}), pu = /* @__PURE__ */ v("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Ic), q.init(e, t);
}), hu = /* @__PURE__ */ v("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = zc(t)), q.init(e, t);
}), mu = /* @__PURE__ */ v("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = fc), q.init(e, t);
}), _u = /* @__PURE__ */ v("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = gc), q.init(e, t);
}), gu = /^[0-9a-fA-F:.]+$/;
function Ar(e) {
  if (!gu.test(e))
    return !1;
  try {
    return new URL(`http://[${e}]`), !0;
  } catch {
    return !1;
  }
}
const vu = /* @__PURE__ */ v("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = vc), q.init(e, t), e._zod.check = (n) => {
    Ar(n.value) || n.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), bu = /* @__PURE__ */ v("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = bc), q.init(e, t);
});
function yu(e) {
  const t = e.split("/");
  if (t.length !== 2)
    return !1;
  const [n, i] = t;
  if (!i)
    return !1;
  const s = Number(i);
  return `${s}` !== i || s < 0 || s > 128 ? !1 : Ar(n);
}
const wu = /* @__PURE__ */ v("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = yc), q.init(e, t), e._zod.check = (n) => {
    yu(n.value) || n.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Nr(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
const Cr = /^[0-9a-zA-Z+/]*={0,2}$/, xu = /* @__PURE__ */ v("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Cr), q.init(e, t), e._zod.check = (n) => {
    Nr(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Di = /^[A-Za-z0-9_-]*$/;
function ku(e) {
  if (!Di.test(e))
    return !1;
  const t = e.replace(/[-_]/g, (i) => i === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return Nr(n);
}
const Su = /* @__PURE__ */ v("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = Di), q.init(e, t), e._zod.check = (n) => {
    ku(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Eu = /* @__PURE__ */ v("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = Sc), q.init(e, t);
});
function Iu(e, t = null) {
  try {
    const n = e.split(".");
    if (n.length !== 3)
      return !1;
    const [i] = n;
    if (!i)
      return !1;
    const s = JSON.parse(atob(i));
    return !("typ" in s && s?.typ !== "JWT" || !s.alg || t && (!("alg" in s) || s.alg !== t));
  } catch {
    return !1;
  }
}
const zu = /* @__PURE__ */ v("$ZodJWT", (e, t) => {
  q.init(e, t), e._zod.check = (n) => {
    Iu(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), $r = /* @__PURE__ */ v("$ZodNumber", (e, t) => {
  M.init(e, t), e._zod.pattern = Ni, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    const s = n.value;
    if (typeof s == "number" && !Number.isNaN(s) && Number.isFinite(s))
      return n;
    const r = typeof s == "number" ? Number.isNaN(s) ? "NaN" : Number.isFinite(s) ? void 0 : String(s) : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: s,
      inst: e,
      ...r ? { received: r } : {}
    }), n;
  };
}), Tu = /* @__PURE__ */ v("$ZodNumberFormat", (e, t) => {
  Pc.init(e, t), $r.init(e, t);
}), Ou = /* @__PURE__ */ v("$ZodBoolean", (e, t) => {
  M.init(e, t), e._zod.pattern = Nc, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    const s = n.value;
    return typeof s == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: s,
      inst: e
    }), n;
  };
}), Au = /* @__PURE__ */ v("$ZodNull", (e, t) => {
  M.init(e, t), e._zod.pattern = Cc, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, i) => {
    const s = n.value;
    return s === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: s,
      inst: e
    }), n;
  };
}), Nu = /* @__PURE__ */ v("$ZodUnknown", (e, t) => {
  M.init(e, t), e._zod.parse = (n) => n;
}), Cu = /* @__PURE__ */ v("$ZodNever", (e, t) => {
  M.init(e, t), e._zod.parse = (n, i) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
});
function vs(e, t, n) {
  e.issues.length && t.issues.push(...Re(n, e.issues)), t.value[n] = e.value;
}
const $u = /* @__PURE__ */ v("$ZodArray", (e, t) => {
  M.init(e, t);
  const n = le.memoizer;
  n?.attach(e), e._zod.parse = (i, s) => {
    const r = i.value;
    if (!Array.isArray(r))
      return i.issues.push({
        expected: "array",
        code: "invalid_type",
        input: r,
        inst: e
      }), i;
    i.value = n ? n.alloc(e, i, Array(r.length), s) : Array(r.length);
    const o = [], a = s?.abortEarly;
    for (let l = 0; l < r.length; l++) {
      const c = r[l], f = t.element._zod.run({
        value: c,
        issues: []
      }, s);
      if (f instanceof Promise)
        o.push(f.then((u) => vs(u, i, l)));
      else if (vs(f, i, l), a && f.issues.length !== 0 && me(f))
        break;
    }
    return o.length ? Promise.all(o).then(() => i) : i;
  };
});
function vn(e, t, n, i, s, r) {
  const o = n in i, a = r === "optional";
  if (!(!o && a && s === "optional")) {
    if (e.issues.length) {
      if (s !== void 0 && a && !o)
        return;
      t.issues.push(...Re(n, e.issues));
    }
    if (!o && s === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [n]
      });
      return;
    }
    e.value === void 0 ? o && (t.value[n] = void 0) : t.value[n] = e.value;
  }
}
const Du = [];
function Dr(e) {
  const t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), i = n.length ? n : Du, s = i.length ? [...t, ...i] : t;
  for (const o of s)
    if (!e.shape?.[o]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(o)}": expected a Zod schema`);
  const r = ya(e.shape);
  return {
    ...e,
    allKeys: s,
    symbolKeys: i,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(r)
  };
}
function Fr(e, t, n, i, s, r, o) {
  const a = [], l = s.keySet, c = s.catchall._zod, f = c.def.type, u = c.optin, m = c.optout;
  let h = 0;
  for (const p in t) {
    if (o && n.issues.length !== h) {
      if (me(n, h))
        break;
      h = n.issues.length;
    }
    if (l.has(p))
      continue;
    if (p === "__proto__") {
      f === "never" && a.push(p);
      continue;
    }
    if (f === "never") {
      a.push(p);
      continue;
    }
    const y = c.run({ value: t[p], issues: [] }, i);
    y instanceof Promise ? e.push(y.then((x) => vn(x, n, p, t, u, m))) : vn(y, n, p, t, u, m);
  }
  return a.length && n.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: r,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => n) : n;
}
const Fu = /* @__PURE__ */ v("$ZodObject", (e, t) => {
  M.init(e, t);
  const n = Object.getOwnPropertyDescriptor(t, "shape"), i = n?.get ? n.get.raw : t.shape ?? {};
  if (i) {
    const c = () => {
      const f = { ...i };
      return Object.defineProperty(t, "shape", { value: f }), c.raw = f, f;
    };
    c.raw = i, Object.defineProperty(t, "shape", { get: c });
  }
  const s = xn(() => Dr(t));
  F(e, "propValues", (c) => {
    const f = c.def.shape, u = {};
    for (const m in f) {
      const h = f[m]._zod;
      if (h.values) {
        Object.prototype.hasOwnProperty.call(u, m) || Oe(u, m, /* @__PURE__ */ new Set());
        for (const p of h.values)
          u[m].add(p);
        h.optin !== void 0 && u[m].add(void 0);
      }
    }
    return u;
  });
  const r = Zt, o = t.catchall;
  let a;
  const l = le.memoizer;
  l?.attach(e), e._zod.parse = (c, f) => {
    a ?? (a = s.value);
    const u = c.value;
    if (!r(u))
      return c.issues.push({
        expected: "object",
        code: "invalid_type",
        input: u,
        inst: e
      }), c;
    c.value = l ? l.alloc(e, c, {}, f) : {};
    const m = [], h = a.shape, p = f?.abortEarly;
    let y = c.issues.length;
    for (const x of a.allKeys) {
      if (p && c.issues.length !== y) {
        if (me(c, y))
          break;
        y = c.issues.length;
      }
      if (x === "__proto__")
        continue;
      const k = h[x], N = k._zod.optin, j = k._zod.optout, se = k._zod.run({ value: u[x], issues: [] }, f);
      se instanceof Promise ? m.push(se.then((Z) => vn(Z, c, x, u, N, j))) : vn(se, c, x, u, N, j);
    }
    return o ? Fr(m, u, c, f, s.value, e, p === !0) : m.length ? Promise.all(m).then(() => c) : c;
  };
}), Pu = /* @__PURE__ */ v("$ZodObjectJIT", (e, t) => {
  Fu.init(e, t);
  const n = e._zod.parse, i = xn(() => Dr(t)), s = le.memoizer, r = (h) => {
    const p = i.value, y = p.symbolKeys, x = new Kc(["payload", "ctx"], { shape: h, inst: e, memo: s, syms: y }), k = (Z) => `shape[${Z}]._zod.run({ value: input[${Z}], issues: [] }, ctx)`, N = (Z, P) => `
          let ${Z}_ab = false;
          for (let i = 0; i < ${Z}.issues.length; i++) {
            const iss = ${Z}.issues[i];
            iss.path = iss.path ? [${P}, ...iss.path] : [${P}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${Z}_ab = true;
          }
          if (${Z}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
    x.write("const input = payload.value;");
    const j = /* @__PURE__ */ Object.create(null);
    let se = 0;
    for (const Z of p.allKeys)
      j[Z] = `key_${se++}`;
    x.write(s ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (const Z of p.allKeys) {
      if (Z === "__proto__")
        continue;
      const P = j[Z], V = typeof Z == "symbol" ? `syms[${y.indexOf(Z)}]` : _a(Z), Ne = `${V} in input`, be = h[Z], Ce = be?._zod?.optin, J = Ce !== void 0, nt = be?._zod?.optout === "optional";
      if (x.write(`const ${P} = ${k(V)};`), J && nt) {
        const wt = Ce === "optional" ? `${P}_present` : `${P}.value !== undefined || ${P}_present`;
        x.write(`
        const ${P}_present = ${Ne};
        if (!${P}.issues.length || ${P}_present) {
          if (${P}.issues.length) {${N(P, V)}
          }

          if (${wt}) {
            newResult[${V}] = ${P}.value;
          }
        }

      `);
      } else J ? x.write(`
        if (${P}.issues.length) {${N(P, V)}
        }
        
        if (${P}.value === undefined) {
          if (${Ne}) {
            newResult[${V}] = undefined;
          }
        } else {
          newResult[${V}] = ${P}.value;
        }

      `) : x.write(`
        const ${P}_present = ${Ne};
        if (${P}.issues.length) {${N(P, V)}
        }
        if (!${P}_present && !${P}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${V}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${P}_present) {
          newResult[${V}] = ${P}.value;
        }

      `);
    }
    return x.write("payload.value = newResult;"), x.write("return payload;"), x.compile();
  };
  let o;
  const a = Zt, l = !le.jitless, f = l && va.value, u = t.catchall;
  let m;
  e._zod.parse = (h, p) => {
    m ?? (m = i.value);
    const y = h.value;
    return a(y) ? l && f && p?.async === !1 && p.jitless !== !0 ? (o || (o = r(t.shape)), h = o(h, p), u ? Fr([], y, h, p, m, e, p?.abortEarly === !0) : h) : n(h, p) : (h.issues.push({
      expected: "object",
      code: "invalid_type",
      input: y,
      inst: e
    }), h);
  };
});
function bs(e, t, n, i) {
  for (const r of e)
    if (r.issues.length === 0)
      return t.value = r.value, t;
  const s = e.filter((r) => !me(r));
  return s.length === 1 ? (t.value = s[0].value, s[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((r) => r.issues.map((o) => je(o, i, ve())))
  }), t);
}
const Pr = /* @__PURE__ */ v("$ZodUnion", (e, t) => {
  M.init(e, t), F(e, "optin", (i) => i.def.options.some((s) => s._zod.optin === "defaulted") ? "defaulted" : i.def.options.some((s) => s._zod.optin !== void 0) ? "optional" : void 0), F(e, "optout", (i) => i.def.options.some((s) => s._zod.optout === "optional") ? "optional" : void 0), F(e, "values", (i) => {
    if (i.def.options.every((s) => s._zod.values))
      return new Set(i.def.options.flatMap((s) => Array.from(s._zod.values)));
  }), F(e, "pattern", (i) => {
    if (i.def.options.every((s) => s._zod.pattern)) {
      const s = i.def.options.map((r) => r._zod.pattern);
      return new RegExp(`^(${s.map((r) => ki(r.source)).join("|")})$`);
    }
  });
  const n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (i, s) => {
    if (n)
      return n(i, s);
    let r = !1;
    const o = [];
    for (const a of t.options) {
      const l = a._zod.run({
        value: i.value,
        issues: []
      }, s);
      if (l instanceof Promise)
        o.push(l), r = !0;
      else {
        if (l.issues.length === 0)
          return l;
        o.push(l);
      }
    }
    return r ? Promise.all(o).then((a) => bs(a, i, e, s)) : bs(o, i, e, s);
  };
});
function Ru(e) {
  const t = /* @__PURE__ */ new Map();
  for (const n of e.options) {
    const i = n._zod.propValues?.[e.discriminator];
    if (!i || i.size === 0)
      throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(n)}"`);
    for (const s of i)
      if (t.has(s)) {
        if (s !== void 0)
          throw new Error(`Duplicate discriminator value "${String(s)}"`);
        t.set(s, null);
      } else
        t.set(s, n);
  }
  return t;
}
const Zu = /* @__PURE__ */ v("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, Pr.init(e, t);
  const n = e._zod.parse;
  F(e, "propValues", (s) => {
    const r = {};
    let o = 0;
    for (const a of s.def.options) {
      const l = a._zod.propValues;
      if (!l || Object.keys(l).length === 0)
        throw new Error(`Invalid discriminated union option at index "${s.def.options.indexOf(a)}"`);
      l[s.def.discriminator]?.has(void 0) && o++;
      for (const [c, f] of Object.entries(l)) {
        Object.prototype.hasOwnProperty.call(r, c) || Oe(r, c, /* @__PURE__ */ new Set());
        for (const u of f)
          r[c].add(u);
      }
    }
    return !s.def.unionFallback && o > 1 && r[s.def.discriminator]?.delete(void 0), r;
  }), t.options.forEach((s, r) => {
    const o = Si(s._zod.def);
    if (o && !Object.prototype.hasOwnProperty.call(o, t.discriminator))
      throw new Error(`Invalid discriminated union option at index "${r}"`);
  });
  const i = xn(() => Ru(t));
  e._zod.parse = (s, r) => {
    const o = s.value;
    if (!Zt(o))
      return s.issues.push({
        code: "invalid_type",
        expected: "object",
        input: o,
        inst: e
      }), s;
    const a = o?.[t.discriminator], l = i.value.get(a);
    return l && (a !== void 0 || r.direction !== "backward") ? l._zod.run(s, r) : t.unionFallback || r.direction === "backward" ? n(s, r) : (s.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(i.value.keys()).filter((c) => i.value.get(c) !== null),
      input: o,
      path: [t.discriminator],
      inst: e
    }), s);
  };
}), Mu = /* @__PURE__ */ v("$ZodIntersection", (e, t) => {
  M.init(e, t), e._zod.parse = (n, i) => {
    const s = n.value, r = t.left._zod.run({ value: s, issues: [] }, i), o = t.right._zod.run({ value: s, issues: [] }, i);
    return r instanceof Promise || o instanceof Promise ? Promise.all([r, o]).then(([l, c]) => ys(n, l, c)) : ys(n, r, o);
  };
});
function li(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (pt(e) && pt(t)) {
    const n = Object.keys(t), i = Object.keys(e).filter((r) => n.indexOf(r) !== -1), s = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(s, "__proto__") && delete s.__proto__;
    for (const r of i) {
      if (r === "__proto__")
        continue;
      const o = li(e[r], t[r]);
      if (!o.valid)
        return {
          valid: !1,
          mergeErrorPath: [r, ...o.mergeErrorPath]
        };
      s[r] = o.data;
    }
    return { valid: !0, data: s };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    const n = [];
    for (let i = 0; i < e.length; i++) {
      const s = e[i], r = t[i], o = li(s, r);
      if (!o.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...o.mergeErrorPath]
        };
      n.push(o.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function ys(e, t, n) {
  const i = /* @__PURE__ */ new Map();
  let s;
  const r = /* @__PURE__ */ new Map(), o = (c, f) => {
    let u;
    if (c.code === "unrecognized_keys" && !c.path?.length)
      s ?? (s = c), u = c.keys;
    else if (c.code === "invalid_key" && c.origin === "record" && c.path?.length === 1) {
      const m = String(c.path[0]);
      r.has(m) || r.set(m, c), u = [m];
    } else
      return !1;
    for (const m of u)
      i.has(m) || i.set(m, {}), i.get(m)[f] = !0;
    return !0;
  };
  for (const c of t.issues)
    o(c, "l") || e.issues.push(c);
  for (const c of n.issues)
    o(c, "r") || e.issues.push(c);
  const a = [...i].filter(([, c]) => c.l && c.r).map(([c]) => c);
  if (a.length) {
    const c = s ? a.filter((f) => s.keys.includes(f)) : [];
    c.length && e.issues.push({ ...s, keys: c });
    for (const f of a)
      !c.includes(f) && r.has(f) && e.issues.push(r.get(f));
  }
  const l = li(t.value, n.value);
  if (!l.valid) {
    if (me(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(l.mergeErrorPath)}`);
  }
  return e.value = l.data, e;
}
const ju = /* @__PURE__ */ v("$ZodTuple", (e, t) => {
  M.init(e, t);
  const n = t.items, i = le.memoizer;
  i?.attach(e), e._zod.parse = (s, r) => {
    const o = s.value;
    if (!Array.isArray(o))
      return s.issues.push({
        input: o,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), s;
    s.value = i ? i.alloc(e, s, [], r) : [];
    const a = [], l = ws(n, "optin"), c = ws(n, "optout");
    if (!t.rest) {
      if (o.length < l)
        return s.issues.push({
          code: "too_small",
          minimum: l,
          inclusive: !0,
          input: o,
          inst: e,
          origin: "array"
        }), s;
      o.length > n.length && s.issues.push({
        code: "too_big",
        maximum: n.length,
        inclusive: !0,
        input: o,
        inst: e,
        origin: "array"
      });
    }
    const f = new Array(n.length), u = t.rest ? r?.abortEarly : void 0;
    let m = !1;
    for (let h = 0; h < n.length; h++) {
      const p = n[h]._zod.run({ value: o[h], issues: [] }, r);
      p instanceof Promise ? a.push(p.then((y) => {
        f[h] = y;
      })) : (f[h] = p, u && !m && p.issues.length && (m = me(p)));
    }
    if (t.rest && !m) {
      let h = n.length - 1;
      const p = o.slice(n.length);
      let y = s.issues.length;
      for (const x of p) {
        if (u && s.issues.length !== y) {
          if (me(s, y))
            break;
          y = s.issues.length;
        }
        h++;
        const k = t.rest._zod.run({ value: x, issues: [] }, r);
        k instanceof Promise ? a.push(k.then((N) => xs(N, s, h))) : xs(k, s, h);
      }
    }
    return a.length ? Promise.all(a).then(() => ks(f, s, n, o, c)) : ks(f, s, n, o, c);
  };
});
function ws(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional"))
      return n + 1;
  return 0;
}
function xs(e, t, n) {
  e.issues.length && t.issues.push(...Re(n, e.issues)), t.value[n] = e.value;
}
function ks(e, t, n, i, s) {
  for (let r = 0; r < n.length; r++) {
    const o = e[r], a = r < i.length;
    if (!a && r >= s && n[r]._zod.optin === "optional") {
      t.value.length = r;
      break;
    }
    if (o.issues.length) {
      if (!a && r >= s) {
        t.value.length = r;
        break;
      }
      t.issues.push(...Re(r, o.issues));
    }
    t.value[r] = o.value;
  }
  for (let r = t.value.length - 1; r >= i.length && (n[r]._zod.optout === "optional" && t.value[r] === void 0); r--)
    t.value.length = r;
  return t;
}
const Lu = /* @__PURE__ */ v("$ZodRecord", (e, t) => {
  M.init(e, t);
  const n = le.memoizer;
  n?.attach(e), e._zod.parse = (i, s) => {
    const r = i.value;
    if (!pt(r))
      return i.issues.push({
        expected: "record",
        code: "invalid_type",
        input: r,
        inst: e
      }), i;
    const o = [], a = t.keyType._zod.values;
    if (a && !t.partial) {
      i.value = n ? n.alloc(e, i, {}, s) : {};
      const l = /* @__PURE__ */ new Set();
      for (const f of a)
        if (typeof f == "string" || typeof f == "number" || typeof f == "symbol") {
          if (l.add(typeof f == "number" ? f.toString() : f), f === "__proto__")
            continue;
          const u = t.keyType._zod.run({ value: f, issues: [] }, s);
          if (u instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (u.issues.length) {
            i.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: u.issues.map((p) => je(p, s, ve())),
              input: f,
              path: [f],
              inst: e
            });
            continue;
          }
          const m = u.value;
          if (m === "__proto__")
            continue;
          const h = t.valueType._zod.run({ value: r[f], issues: [] }, s);
          h instanceof Promise ? o.push(h.then((p) => {
            p.issues.length && i.issues.push(...Re(f, p.issues)), i.value[m] = p.value;
          })) : (h.issues.length && i.issues.push(...Re(f, h.issues)), i.value[m] = h.value);
        }
      let c;
      for (const f in r)
        if (!l.has(f))
          if (t.mode === "loose") {
            if (f === "__proto__")
              continue;
            i.value[f] = r[f];
          } else
            c = c ?? [], c.push(f);
      c && c.length > 0 && i.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: c,
        continue: !0
      });
    } else {
      i.value = n ? n.alloc(e, i, {}, s) : {};
      let l;
      for (const c of Reflect.ownKeys(r)) {
        if (c === "__proto__" || !Object.prototype.propertyIsEnumerable.call(r, c))
          continue;
        let f = t.keyType._zod.run({ value: c, issues: [] }, s);
        if (f instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof c == "string" && Ni.test(c) && f.issues.length) {
          const p = t.keyType._zod.run({ value: Number(c), issues: [] }, s);
          if (p instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          p.issues.length === 0 && (f = p);
        }
        if (f.issues.length) {
          t.mode === "loose" ? i.value[c] = r[c] : a ? (l = l ?? [], l.push(c)) : i.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: f.issues.map((p) => je(p, s, ve())),
            input: c,
            path: [c],
            inst: e
          });
          continue;
        }
        const m = f.value;
        if (m === "__proto__")
          continue;
        const h = t.valueType._zod.run({ value: r[c], issues: [] }, s);
        h instanceof Promise ? o.push(h.then((p) => {
          p.issues.length && i.issues.push(...Re(c, p.issues)), i.value[m] = p.value;
        })) : (h.issues.length && i.issues.push(...Re(c, h.issues)), i.value[m] = h.value);
      }
      l && l.length > 0 && i.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: l,
        continue: !0
      });
    }
    return o.length ? Promise.all(o).then(() => i) : i;
  };
}), Uu = /* @__PURE__ */ v("$ZodEnum", (e, t) => {
  M.init(e, t);
  const n = ai(t.entries), i = new Set(n);
  e._zod.values = i, F(e, "pattern", (s) => {
    const r = ai(s.def.entries).filter((o) => ba.has(typeof o));
    return new RegExp(r.length ? `^(${r.map((o) => ht(o.toString())).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (s, r) => {
    const o = s.value;
    return i.has(o) || s.issues.push({
      code: "invalid_value",
      values: n,
      input: o,
      inst: e
    }), s;
  };
}), Bu = /* @__PURE__ */ v("$ZodLiteral", (e, t) => {
  M.init(e, t);
  const n = new Set(t.values);
  e._zod.values = n, F(e, "pattern", (i) => {
    const s = i.def.values;
    return new RegExp(s.length ? `^(${s.map((r) => typeof r == "string" ? ht(r) : r ? ht(r.toString()) : String(r)).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (i, s) => {
    const r = i.value;
    return n.has(r) || i.issues.push({
      code: "invalid_value",
      values: t.values,
      input: r,
      inst: e
    }), i;
  };
}), qu = /* @__PURE__ */ v("$ZodTransform", (e, t) => {
  M.init(e, t), e._zod.optin = "optional", le.memoizer?.guard(e), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new wr(e.constructor.name);
    const s = t.transform(n.value, n);
    if (i.async)
      return (s instanceof Promise ? s : Promise.resolve(s)).then((o) => (n.value = o, n));
    if (s instanceof Promise)
      throw new Xe();
    return n.value = s, n;
  };
});
function Ss(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
const Rr = /* @__PURE__ */ v("$ZodOptional", (e, t) => {
  M.init(e, t), F(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", F(e, "values", (n) => {
    const i = n.def.innerType._zod.values;
    return i ? /* @__PURE__ */ new Set([...i, void 0]) : void 0;
  }), F(e, "pattern", (n) => {
    const i = n.def.innerType._zod.pattern;
    return i ? new RegExp(`^(${ki(i.source)})?$`) : void 0;
  }), e._zod.parse = (n, i) => {
    if (n.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return n;
      const s = t.innerType._zod.run({ value: n.value, issues: [] }, i);
      return s instanceof Promise ? s.then((r) => Ss(n, r)) : Ss(n, s);
    }
    return t.innerType._zod.run(n, i);
  };
}), Hu = /* @__PURE__ */ v("$ZodExactOptional", (e, t) => {
  Rr.init(e, t), F(e, "values", (n) => n.def.innerType._zod.values), F(e, "pattern", (n) => n.def.innerType._zod.pattern), e._zod.parse = (n, i) => t.innerType._zod.run(n, i);
}), Wu = /* @__PURE__ */ v("$ZodNullable", (e, t) => {
  M.init(e, t), F(e, "optin", (n) => n.def.innerType._zod.optin), F(e, "optout", (n) => n.def.innerType._zod.optout), F(e, "pattern", (n) => {
    const i = n.def.innerType._zod.pattern;
    return i ? new RegExp(`^(${ki(i.source)}|null)$`) : void 0;
  }), F(e, "values", (n) => n.def.innerType._zod.values ? /* @__PURE__ */ new Set([...n.def.innerType._zod.values, null]) : void 0), e._zod.parse = (n, i) => n.value === null ? n : t.innerType._zod.run(n, i);
}), Ku = /* @__PURE__ */ v("$ZodDefault", (e, t) => {
  M.init(e, t), e._zod.optin = "defaulted", F(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    const s = t.innerType._zod.run(n, i);
    return s instanceof Promise ? s.then((r) => Es(r, t)) : Es(s, t);
  };
});
function Es(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
const Vu = /* @__PURE__ */ v("$ZodPrefault", (e, t) => {
  M.init(e, t), e._zod.optin = "defaulted", F(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => (i.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, i));
}), Ju = /* @__PURE__ */ v("$ZodNonOptional", (e, t) => {
  M.init(e, t), F(e, "values", (n) => {
    const i = n.def.innerType._zod.values;
    return i ? new Set([...i].filter((s) => s !== void 0)) : void 0;
  }), e._zod.parse = (n, i) => {
    const s = t.innerType._zod.run(n, i);
    return s instanceof Promise ? s.then((r) => Is(r, e)) : Is(s, e);
  };
});
function Is(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
function zs(e, t, n, i) {
  return t.issues.length ? (e.value = n.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((s) => je(s, i, ve()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
const Xu = /* @__PURE__ */ v("$ZodCatch", (e, t) => {
  M.init(e, t), F(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), F(e, "optout", (n) => n.def.innerType._zod.optout), F(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    const s = t.innerType._zod.run({ value: n.value, issues: [] }, i);
    return s instanceof Promise ? s.then((r) => zs(n, r, t, i)) : zs(n, s, t, i);
  };
}), Gu = /* @__PURE__ */ v("$ZodPipe", (e, t) => {
  M.init(e, t), F(e, "values", (n) => n.def.in._zod.values), F(e, "optin", (n) => n.def.in._zod.optin), F(e, "optout", (n) => n.def.out._zod.optout), F(e, "propValues", (n) => n.def.in._zod.propValues), e._zod.parse = (n, i) => {
    if (i.direction === "backward") {
      const r = t.out._zod.run(n, i);
      return r instanceof Promise ? r.then((o) => sn(o, t.in, i)) : sn(r, t.in, i);
    }
    const s = t.in._zod.run(n, i);
    return s instanceof Promise ? s.then((r) => sn(r, t.out, i)) : sn(s, t.out, i);
  };
});
function sn(e, t, n) {
  return e.issues.some((i) => i.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
const Yu = /* @__PURE__ */ v("$ZodReadonly", (e, t) => {
  M.init(e, t), F(e, "propValues", (n) => n.def.innerType._zod.propValues), F(e, "values", (n) => n.def.innerType._zod.values), F(e, "optin", (n) => n.def.innerType?._zod?.optin), F(e, "optout", (n) => n.def.innerType?._zod?.optout), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    const s = t.innerType._zod.run(n, i);
    return s instanceof Promise ? s.then(Ts) : Ts(s);
  };
});
function Ts(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
const Qu = /* @__PURE__ */ v("$ZodCustom", (e, t) => {
  ie.init(e, t), M.init(e, t), e._zod.parse = (n, i) => n, e._zod.check = (n) => {
    const i = n.value, s = t.fn(i);
    if (s instanceof Promise)
      return s.then((r) => Os(r, n, i, e));
    Os(s, n, i, e);
  };
});
function Os(e, t, n, i) {
  if (!e) {
    const s = {
      code: "custom",
      input: n,
      inst: i,
      // incorporates params.error into issue reporting
      path: [...i._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !i._zod.def.abort
      // params: inst._zod.def.params,
    };
    i._zod.def.params && (s.params = i._zod.def.params), t.issues.push(Mt(s));
  }
}
class el extends Error {
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}
const di = "~memo", As = [];
function Zr(e) {
  return e !== null && (typeof e == "object" || typeof e == "function");
}
function Bn(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
const Mr = /* @__PURE__ */ new WeakMap(), Ct = 0, pn = 1, Ft = 2;
function hn(e, t, n) {
  const i = Mr.get(e);
  if (i !== void 0)
    return i ? Ft : Ct;
  if (t.has(e))
    return Ft;
  t.add(e);
  let s = Ct;
  const r = (f) => {
    if (s !== Ft && f?._zod) {
      const u = hn(f, t);
      u > s && (s = u);
    }
  }, o = (f, u) => {
    let m = Ct;
    for (const h of Reflect.ownKeys(f)) {
      const p = Object.getOwnPropertyDescriptor(f, h);
      if (u && !p.enumerable)
        continue;
      const y = p.get ? pn : p.value?._zod ? hn(p.value, t) : Ct;
      y > m && (m = y);
    }
    return m;
  }, a = (f) => {
    f > s && (s = f);
  }, l = e._zod.def;
  switch (l.type) {
    case "object": {
      const f = Si(l);
      a(f ? o(f, !0) : pn), r(l.catchall);
      break;
    }
    case "properties":
      a(o(l.shape, !1));
      break;
    case "array":
      r(l.element);
      break;
    case "tuple":
      for (const f of l.items)
        r(f);
      r(l.rest);
      break;
    case "record":
    case "map":
      r(l.keyType), r(l.valueType);
      break;
    case "set":
      r(l.valueType);
      break;
    case "union":
      for (const f of l.options)
        r(f);
      break;
    case "intersection":
      r(l.left), r(l.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      r(l.innerType);
      break;
    case "pipe":
      r(l.in), r(l.out);
      break;
    case "function":
      r(l.input), r(l.output);
      break;
    // `$ZodLazy` caches its inner on the def, so a resolved edge is followed exactly
    case "lazy": {
      const f = l._cachedInner ?? void 0;
      a(f ? hn(f, t) : pn);
      break;
    }
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (const f in l) {
        const u = Object.getOwnPropertyDescriptor(l, f);
        if (!u || u.get)
          continue;
        const m = u.value;
        if (!(!m || typeof m != "object")) {
          if (m._zod)
            r(m);
          else if (Array.isArray(m))
            for (const h of m)
              r(h);
        }
      }
  }
  return t.delete(e), tl(e, s);
}
function tl(e, t) {
  return t !== pn && Mr.set(e, t === Ft), t;
}
function nl(e, t) {
  let n = e.buckets.get(t);
  return n || (n = /* @__PURE__ */ new WeakMap(), e.buckets.set(t, n)), n;
}
let rn;
const on = [], il = {
  alloc(e, t, n) {
    const i = rn;
    if (!i)
      return n;
    rn = void 0;
    const s = { value: n, issues: null };
    return i.set(t.value, s), on.push(s), n;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const n = e._zod.parse, i = (s, r) => {
        if (r.direction !== "backward" && rl(r, s.value))
          throw new el();
        return n(s, r);
      };
      e._zod.parse = i, e._zod.run === n && (e._zod.run = i);
    });
  },
  attach(e) {
    var t;
    let n, i = !1, s, r;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const o = e._zod.parse, a = (l, c) => {
        if (n === void 0) {
          const k = hn(e, /* @__PURE__ */ new Set());
          if (k === Ct)
            return e._zod.parse = o, e._zod.run === a && (e._zod.run = o), o(l, c);
          k === Ft || i ? n = !0 : i = !0;
        }
        const f = l.value;
        if (!Zr(f))
          return o(l, c);
        let u = c[di];
        u || (u = { buckets: /* @__PURE__ */ new WeakMap(), backEdges: void 0 }, c[di] = u);
        let m;
        s === c ? m = r : (m = nl(u, e), s = c, r = m);
        const h = m.get(f);
        if (h)
          return l.value = h.value, h.issues ? h.issues.length && l.issues.push(...Bn(h.issues)) : (l.memo = !0, u.backEdges ?? (u.backEdges = /* @__PURE__ */ new WeakSet()), u.backEdges.add(h.value)), l;
        rn = m;
        const p = on.length, y = o(l, c);
        rn = void 0;
        const x = on.length > p ? on.pop() : void 0;
        return y instanceof Promise ? y.then((k) => (x && (x.issues = k.issues.length ? Bn(k.issues) : As), k)) : (x && (x.issues = y.issues.length ? Bn(y.issues) : As), y);
      };
      e._zod.parse = a, e._zod.run === o && (e._zod.run = a);
    });
  }
};
function sl() {
  return il;
}
function rl(e, t) {
  const n = e[di]?.backEdges;
  return n !== void 0 && Zr(t) && n.has(t);
}
const ol = () => {
  const e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  const n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    credit_card: "credit card number",
    iban: "IBAN",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function s(r, o) {
    return r === "number" && typeof o == "number" && !Number.isFinite(o) ? String(o) : i[r] ?? r;
  }
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        const o = s(r.expected), a = Aa(r.input), l = s(a, r.input);
        return `Invalid input: expected ${o}, received ${l}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${_r(r.values[0])}` : `Invalid option: expected one of ${ls(r.values, "|")}`;
      case "too_big": {
        const o = r.exact ? "exactly " : r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Too big: expected ${r.origin ?? "value"} to have ${o}${r.maximum.toString()} ${a.unit ?? "elements"}` : `Too big: expected ${r.origin ?? "value"} to be ${o}${r.maximum.toString()}`;
      }
      case "too_small": {
        const o = r.exact ? "exactly " : r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Too small: expected ${r.origin} to have ${o}${r.minimum.toString()} ${a.unit}` : `Too small: expected ${r.origin} to be ${o}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        const o = r;
        return o.format === "starts_with" ? `Invalid string: must start with "${o.prefix}"` : o.format === "ends_with" ? `Invalid string: must end with "${o.suffix}"` : o.format === "includes" ? `Invalid string: must include "${o.includes}"` : o.format === "regex" ? `Invalid string: must match pattern ${o.pattern}` : `Invalid ${n[o.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${r.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${r.keys.length > 1 ? "s" : ""}: ${ls(r.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${r.origin}`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `Invalid discriminator value. Expected ${r.options.map((a) => `'${a}'`).join(" | ")}` : r.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${r.origin}`;
      default:
        return "Invalid input";
    }
  };
};
function al() {
  return {
    localeError: ol()
  };
}
var Ns;
class cl {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    const i = n[0];
    return this._map.set(t, i), i && typeof i == "object" && "id" in i && this._idmap.set(i.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    const n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    const n = t._zod.parent;
    if (n) {
      const i = { ...this.get(n) ?? {} };
      delete i.id;
      const s = { ...i, ...this._map.get(t) };
      return Object.keys(s).length ? s : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
}
function ul() {
  return new cl();
}
(Ns = globalThis).__zod_globalRegistry ?? (Ns.__zod_globalRegistry = ul());
const $t = globalThis.__zod_globalRegistry;
// @__NO_SIDE_EFFECTS__
function ll(e, t) {
  return new e({
    type: "string",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function dl(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function fl(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function jr(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function pl(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function hl(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function ml(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Lr(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function _l(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function gl(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function vl(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function bl(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function yl(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function wl(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function xl(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function kl(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Sl(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function El(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Il(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function zl(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Tl(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ol(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Al(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Nl(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ur(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Cl(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function $l(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Dl(e, t) {
  return new e({
    type: "number",
    checks: [],
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Fl(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Pl(e, t) {
  return new e({
    type: "boolean",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Rl(e, t) {
  return new e({
    type: "null",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Zl(e) {
  return new e({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function Ml(e, t) {
  return new e({
    type: "never",
    ...z(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Cs(e, t) {
  return new Sr({
    check: "less_than",
    ...z(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function qn(e, t) {
  return new Sr({
    check: "less_than",
    ...z(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function $s(e, t) {
  return new Er({
    check: "greater_than",
    ...z(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Hn(e, t) {
  return new Er({
    check: "greater_than",
    ...z(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function Ds(e, t) {
  return new Fc({
    check: "multiple_of",
    ...z(t),
    value: e
  });
}
// @__NO_SIDE_EFFECTS__
function Br(e, t) {
  return new Rc({
    check: "max_length",
    ...z(t),
    maximum: e
  });
}
// @__NO_SIDE_EFFECTS__
function bn(e, t) {
  return new Zc({
    check: "min_length",
    ...z(t),
    minimum: e
  });
}
// @__NO_SIDE_EFFECTS__
function qr(e, t) {
  return new Mc({
    check: "length_equals",
    ...z(t),
    length: e
  });
}
// @__NO_SIDE_EFFECTS__
function jl(e, t) {
  return new jc({
    check: "string_format",
    format: "regex",
    ...z(t),
    pattern: e
  });
}
// @__NO_SIDE_EFFECTS__
function Ll(e) {
  return new Lc({
    check: "string_format",
    format: "lowercase",
    ...z(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Ul(e) {
  return new Uc({
    check: "string_format",
    format: "uppercase",
    ...z(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Bl(e, t) {
  return new Bc({
    check: "string_format",
    format: "includes",
    ...z(t),
    includes: e
  });
}
// @__NO_SIDE_EFFECTS__
function ql(e, t) {
  return new qc({
    check: "string_format",
    format: "starts_with",
    ...z(t),
    prefix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Hl(e, t) {
  return new Hc({
    check: "string_format",
    format: "ends_with",
    ...z(t),
    suffix: e
  });
}
// @__NO_SIDE_EFFECTS__
function vt(e) {
  return new Wc({
    check: "overwrite",
    tx: e
  });
}
// @__NO_SIDE_EFFECTS__
function Wl(e) {
  return /* @__PURE__ */ vt((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function Kl() {
  return /* @__PURE__ */ vt((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function Vl() {
  return /* @__PURE__ */ vt((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function Jl() {
  return /* @__PURE__ */ vt((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function Xl() {
  return /* @__PURE__ */ vt((e) => ga(e));
}
// @__NO_SIDE_EFFECTS__
function Gl(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...z(n)
  });
}
// @__NO_SIDE_EFFECTS__
function Yl(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...z(n)
  });
}
// @__NO_SIDE_EFFECTS__
function Ql(e, t) {
  const n = /* @__PURE__ */ ed((i) => (i.addIssue = (s) => {
    if (typeof s == "string")
      i.issues.push(Mt(s, i.value, n._zod.def));
    else {
      const r = s;
      r.fatal && (r.continue = !1), r.code ?? (r.code = "custom"), "input" in r || (r.input = i.value), r.inst ?? (r.inst = n), r.continue ?? (r.continue = !n._zod.def.abort), i.issues.push(Mt(r));
    }
  }, e(i.value, i)), t);
  return n;
}
// @__NO_SIDE_EFFECTS__
function ed(e, t) {
  const n = new ie({
    check: "custom",
    ...z(t)
  });
  return n._zod.check = e, n;
}
function Pt(e, ...t) {
  for (const n of t)
    for (const i of Reflect.ownKeys(n))
      Object.prototype.propertyIsEnumerable.call(n, i) && Oe(e, i, n[i]);
  return e;
}
function Hr(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? $t,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
function Ue(e, t, n, i, s) {
  const r = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: i.path, message: s }) : t.unrepresentable;
  if (r === "any")
    return !1;
  if (r === void 0 || r === "throw")
    throw new Error(s);
  return Object.assign(n, r), !0;
}
function K(e, t, n = { path: [], schemaPath: [] }) {
  var i;
  const s = e._zod.def, r = t.seen.get(e);
  if (r)
    return r.count++, n.schemaPath.includes(e) && (r.cycle = n.path), r.schema;
  const o = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, o), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  const a = e._zod.toJSONSchema?.();
  if (a)
    o.schema = a;
  else {
    const f = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, o.schema, f);
    else {
      const m = o.schema, h = t.processors[s.type];
      if (!h)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${s.type}`);
      h(e, t, m, f);
    }
    const u = e._zod.parent;
    u && (o.ref || (o.ref = u), K(u, t, f), t.seen.get(u).isParent = !0);
  }
  const l = t.metadataRegistry.get(e);
  return l && Pt(o.schema, l), t.io === "input" && ee(e) && (delete o.schema.examples, delete o.schema.default), t.io === "input" && "_prefault" in o.schema && ((i = o.schema).default ?? (i.default = o.schema._prefault)), delete o.schema._prefault, t.seen.get(e).schema;
}
function Fs(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function Wr(e, t) {
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  const i = /* @__PURE__ */ new Map();
  for (const o of e.seen.entries()) {
    const a = e.metadataRegistry.get(o[0])?.id;
    if (a) {
      const l = i.get(a);
      if (l && l !== o[0])
        throw new Error(`Duplicate schema id "${a}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      i.set(a, o[0]);
    }
  }
  const s = (o) => {
    const a = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      const u = e.external.registry.get(o[0])?.id, m = e.external.uri ?? ((p) => p);
      if (u)
        return { ref: m(u) };
      const h = o[1].defId ?? o[1].schema.id ?? `schema${e.counter++}`;
      return o[1].defId = h, { defId: h, ref: `${m("__shared")}#/${a}/${Fs(h)}` };
    }
    const l = "#", c = `${l}/${a}/`;
    if (o[1] === n && !o[1].schema.id)
      return { ref: l };
    const f = o[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: f, ref: c + Fs(f) };
  }, r = (o) => {
    if (o[1].schema.$ref)
      return;
    const a = o[1], { ref: l, defId: c } = s(o);
    a.def = { ...a.schema }, c && (a.defId = c);
    const f = a.schema;
    for (const u in f)
      delete f[u];
    f.$ref = l;
  };
  if (e.cycles === "throw")
    for (const o of e.seen.entries()) {
      const a = o[1];
      if (a.cycle)
        throw new Error(`Cycle detected: #/${a.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const o of e.seen.entries()) {
    const a = o[1];
    if (t === o[0]) {
      r(o);
      continue;
    }
    if (e.external) {
      const c = e.external.registry.get(o[0])?.id;
      if (t !== o[0] && c) {
        r(o);
        continue;
      }
    }
    if (e.metadataRegistry.get(o[0])?.id) {
      r(o);
      continue;
    }
    if (a.cycle) {
      r(o);
      continue;
    }
    a.count > 1 && e.reused === "ref" && r(o);
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
function Kr(e) {
  const t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  const n = [];
  for (const i of t) {
    if (!i || typeof i != "object")
      return;
    Kr(i);
    const s = Object.keys(i);
    if (s.length !== 1 || s[0] !== "type")
      return;
    const r = i.type;
    for (const o of Array.isArray(r) ? r : [r]) {
      if (typeof o != "string")
        return;
      n.includes(o) || n.push(o);
    }
  }
  delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
const Vr = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), Ps = ["oneOf", "anyOf"];
function Rs(e) {
  const t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
function fi(e) {
  const t = [];
  for (const r of e) {
    if (typeof r != "object" || r.type !== "object")
      return null;
    for (const o in r)
      if (!Vr.has(o))
        return null;
    t.push(r);
  }
  const n = {}, i = /* @__PURE__ */ new Set();
  for (const r of t) {
    for (const o in r.properties) {
      if (Object.prototype.hasOwnProperty.call(n, o))
        continue;
      const a = [];
      for (const c of t) {
        const f = c.properties?.[o] ?? Rs(c);
        f != null && (a.some((u) => JSON.stringify(u) === JSON.stringify(f)) || a.push(f));
      }
      const l = a.length === 1 ? a[0] : fi(a) ?? { allOf: a };
      Oe(n, o, l);
    }
    for (const o of r.required ?? [])
      i.add(o);
  }
  const s = { type: "object", properties: n };
  if (i.size && (s.required = [...i]), t.every((r) => r.additionalProperties === !1))
    s.additionalProperties = !1;
  else {
    const r = [];
    for (const o of t) {
      const a = Rs(o);
      a && !r.some((l) => JSON.stringify(l) === JSON.stringify(a)) && r.push(a);
    }
    r.length === 1 ? s.additionalProperties = r[0] : r.length > 1 && (s.additionalProperties = { allOf: r });
  }
  return s;
}
function td(e) {
  const t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (const s of Vr)
    if (s in e)
      return;
  const n = t.filter((s) => Ps.some((r) => Array.isArray(s[r])));
  let i = null;
  if (!n.length)
    i = fi(t);
  else {
    const s = n[0], r = Ps.find((l) => Array.isArray(s[l]));
    if (Object.keys(s).length !== 1)
      return;
    const o = t.filter((l) => l !== s), a = s[r].map((l) => fi([...o, l]));
    if (a.some((l) => !l))
      return;
    i = { [r]: a };
  }
  i && (delete e.allOf, Pt(e, i));
}
function Jr(e, t) {
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const i = (a) => {
    const l = e.seen.get(a);
    if (l.ref === null)
      return;
    const c = l.def ?? l.schema, f = { ...c }, u = l.ref;
    if (l.ref = null, u) {
      i(u);
      const h = e.seen.get(u), p = h.schema;
      if (p.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (c.allOf = c.allOf ?? [], c.allOf.push(p)) : Pt(c, p), Pt(c, f), a._zod.parent === u)
        for (const x in c)
          x === "$ref" || x === "allOf" || x in f || delete c[x];
      if (p.$ref && h.def)
        for (const x in c)
          x === "$ref" || x === "allOf" || x in h.def && JSON.stringify(c[x]) === JSON.stringify(h.def[x]) && delete c[x];
    }
    const m = a._zod.parent;
    if (m && m !== u) {
      i(m);
      const h = e.seen.get(m);
      if (h?.schema.$ref && (c.$ref = h.schema.$ref, h.def))
        for (const p in c)
          p === "$ref" || p === "allOf" || p in h.def && JSON.stringify(c[p]) === JSON.stringify(h.def[p]) && delete c[p];
    }
    e.override({
      zodSchema: a,
      jsonSchema: c,
      path: l.path ?? []
    });
  };
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (const a of [...e.seen.entries()].reverse())
      i(a[0]);
    if (e.target !== "openapi-3.0")
      for (const a of e.seen.entries())
        Kr(a[1].def ?? a[1].schema);
    for (const a of e.deferred)
      a();
    if (e.intersections.length) {
      const a = /* @__PURE__ */ new Map();
      for (const l of e.seen.values())
        for (const c of [l.schema, l.def]) {
          const f = c?.allOf;
          if (!Array.isArray(f))
            continue;
          const u = a.get(f);
          u ? u.push(c) : a.set(f, [c]);
        }
      for (const l of e.intersections)
        for (const c of a.get(l) ?? [])
          td(c);
    }
  }
  const s = {};
  if (e.target === "draft-2020-12" ? s.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? s.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? s.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    const a = e.external.registry.get(t)?.id;
    if (!a)
      throw new Error("Schema is missing an `id` property");
    s.$id = e.external.uri(a);
  }
  Pt(s, n.defId ? n.schema : n.def ?? n.schema);
  const r = e.metadataRegistry.get(t)?.id;
  r !== void 0 && s.id === r && delete s.id;
  const o = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (const a of e.seen.entries()) {
      const l = a[1];
      l.def && l.defId && (l.def.id === l.defId && delete l.def.id, Oe(o, l.defId, l.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(o).length > 0 && (e.target === "draft-2020-12" ? s.$defs = o : s.definitions = o);
  try {
    const a = JSON.parse(JSON.stringify(s));
    return Object.defineProperty(a, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: yn(t, "input", e.processors),
          output: yn(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), a;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function ee(e, t) {
  const n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  const i = e._zod.def;
  if (i.type === "transform")
    return !0;
  if (i.type === "array")
    return ee(i.element, n);
  if (i.type === "set")
    return ee(i.valueType, n);
  if (i.type === "lazy")
    return ee(i.getter(), n);
  if (i.type === "promise" || i.type === "optional" || i.type === "nonoptional" || i.type === "nullable" || i.type === "readonly" || i.type === "default" || i.type === "prefault" || i.type === "catch")
    return ee(i.innerType, n);
  if (i.type === "intersection")
    return ee(i.left, n) || ee(i.right, n);
  if (i.type === "record" || i.type === "map")
    return ee(i.keyType, n) || ee(i.valueType, n);
  if (i.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : ee(i.in, n) || ee(i.out, n);
  if (i.type === "object") {
    for (const s in i.shape)
      if (ee(i.shape[s], n))
        return !0;
    return !1;
  }
  if (i.type === "union") {
    for (const s of i.options)
      if (ee(s, n))
        return !0;
    return !1;
  }
  if (i.type === "tuple") {
    for (const s of i.items)
      if (ee(s, n))
        return !0;
    return !!(i.rest && ee(i.rest, n));
  }
  return !1;
}
const nd = (e, t = {}) => (n) => {
  const i = Hr({ ...n, processors: t });
  return K(e, i), Wr(i, e), Jr(i, e);
}, yn = (e, t, n = {}) => (i) => {
  const { libraryOptions: s, target: r } = i ?? {}, o = Hr({ ...s ?? {}, target: r, io: t, processors: n });
  return K(e, o), Wr(o, e), Jr(o, e);
}, mt = (e, t, n) => {
  (e[t] === void 0 || n > e[t]) && (e[t] = n);
}, _t = (e, t, n) => {
  (e[t] === void 0 || n < e[t]) && (e[t] = n);
}, Zs = (e, t) => {
  mt(e, "minimum", t), _t(e, "maximum", t);
}, Xr = (e, t) => {
  e.multipleOf ?? (e.multipleOf = []), e.multipleOf.includes(t) || e.multipleOf.push(t);
}, Gr = (e, t) => {
  e.patterns ?? (e.patterns = /* @__PURE__ */ new Set()), e.patterns.add(t);
}, Yr = (e, t) => {
  e.mime = e.mime ? e.mime.filter((n) => t.includes(n)) : [...t];
}, Qr = (e, t) => {
  e.format = t, t.includes("int") && (e.isInt = !0);
}, Ms = (e, t) => mt(e, "minimum", t.minimum), js = (e, t) => _t(e, "maximum", t.maximum), Ls = (e) => (t, n) => {
  Qr(t, n.format);
  const [i, s] = e[n.format];
  mt(t, "minimum", i), _t(t, "maximum", s);
}, id = {
  greater_than: (e, t) => mt(e, t.inclusive ? "minimum" : "exclusiveMinimum", t.value),
  less_than: (e, t) => _t(e, t.inclusive ? "maximum" : "exclusiveMaximum", t.value),
  multiple_of: (e, t) => Xr(e, t.value),
  number_format: Ls(gr),
  bigint_format: Ls(wa),
  min_length: Ms,
  max_length: js,
  length_equals: (e, t) => Zs(e, t.length),
  min_size: Ms,
  max_size: js,
  size_equals: (e, t) => Zs(e, t.size),
  string_format: (e, t) => {
    Qr(e, t.format), t.pattern && Gr(e, t.pattern), (t.format === "base64" || t.format === "base64url") && (e.contentEncoding = t.format), (t.local || t.precision === -1) && (e.laxFormat = !0);
  },
  mime_type: (e, t) => Yr(e, t.mime)
};
function ue(e) {
  const t = {}, n = e._zod.def, i = e._zod.traits.has("$ZodCheck") ? [e, ...n.checks ?? []] : n.checks ?? [];
  for (const r of i)
    id[r._zod.def.check]?.(t, r._zod.def);
  const s = e._zod.bag;
  s.minimum !== void 0 && mt(t, "minimum", s.minimum), s.exclusiveMinimum !== void 0 && mt(t, "exclusiveMinimum", s.exclusiveMinimum), s.maximum !== void 0 && _t(t, "maximum", s.maximum), s.exclusiveMaximum !== void 0 && _t(t, "exclusiveMaximum", s.exclusiveMaximum), s.multipleOf !== void 0 && Xr(t, s.multipleOf), s.format !== void 0 && (t.format ?? (t.format = s.format), s.format.includes("int") && (t.isInt = !0)), s.mime && Yr(t, s.mime);
  for (const r of s.patterns ?? [])
    Gr(t, r);
  return t;
}
const sd = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, rd = /* @__PURE__ */ new Map([
  [Cr, wc],
  [Di, xc]
]), eo = (e) => rd.get(e) ?? e, od = (e, t, n, i) => {
  const s = n;
  s.type = "string";
  const { minimum: r, maximum: o, format: a, patterns: l, contentEncoding: c, laxFormat: f } = ue(e);
  if (typeof r == "number" && (s.minLength = r), typeof o == "number" && (s.maxLength = o), a && (s.format = sd[a] ?? a, s.format === "" && delete s.format, (a === "time" || f) && delete s.format), c && (s.contentEncoding = c), l && l.size > 0) {
    const u = [...l].map(eo);
    u.length === 1 ? s.pattern = u[0].source : u.length > 1 && (s.allOf = [
      ...u.map((m) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: m.source
      }))
    ]);
  }
}, ad = (e, t, n, i) => {
  const s = n, { minimum: r, maximum: o, multipleOf: a, exclusiveMaximum: l, exclusiveMinimum: c, isInt: f } = ue(e);
  s.type = f ? "integer" : "number";
  const u = typeof c == "number" && c >= (r ?? Number.NEGATIVE_INFINITY), m = typeof l == "number" && l <= (o ?? Number.POSITIVE_INFINITY), h = t.target === "draft-04" || t.target === "openapi-3.0";
  if (u ? h ? (s.minimum = c, s.exclusiveMinimum = !0) : s.exclusiveMinimum = c : typeof r == "number" && (s.minimum = r), m ? h ? (s.maximum = l, s.exclusiveMaximum = !0) : s.exclusiveMaximum = l : typeof o == "number" && (s.maximum = o), a) {
    const p = /* @__PURE__ */ new Set();
    for (const k of a)
      Number.isFinite(k) && k !== 0 ? p.add(Math.abs(k)) : Ue(e, t, s, i, `A multipleOf divisor of ${k} cannot be represented in JSON Schema`);
    const [y, ...x] = p;
    y !== void 0 && (s.multipleOf = y), x.length && (s.allOf = [...s.allOf ?? [], ...x.map((k) => ({ multipleOf: k }))]);
  }
}, cd = (e, t, n, i) => {
  n.type = "boolean";
}, ud = (e, t, n, i) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, ld = (e, t, n, i) => {
  n.not = {};
}, dd = (e, t, n, i) => {
}, fd = (e, t, n, i) => {
  const s = e._zod.def, r = ai(s.entries);
  if (r.length === 0) {
    n.not = {};
    return;
  }
  r.every((o) => typeof o == "number") && (n.type = "number"), r.every((o) => typeof o == "string") && (n.type = "string"), n.enum = r;
}, pd = (e, t, n, i) => {
  const s = e._zod.def;
  if (s.values.length === 0) {
    n.not = {};
    return;
  }
  const r = [];
  for (const o of s.values)
    if (o === void 0) {
      if (Ue(e, t, n, i, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof o == "bigint") {
      if (Ue(e, t, n, i, "BigInt literals cannot be represented in JSON Schema"))
        return;
      r.push(Number(o));
    } else
      r.push(o);
  if (r.length !== 0) if (r.length === 1) {
    const o = r[0];
    n.type = o === null ? "null" : typeof o, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [o] : n.const = o;
  } else
    r.every((o) => typeof o == "number") && (n.type = "number"), r.every((o) => typeof o == "string") && (n.type = "string"), r.every((o) => typeof o == "boolean") && (n.type = "boolean"), r.every((o) => o === null) && (n.type = "null"), n.enum = r;
}, hd = (e, t, n, i) => {
  Ue(e, t, n, i, "Custom types cannot be represented in JSON Schema");
}, md = (e, t, n, i) => {
  Ue(e, t, n, i, "Transforms cannot be represented in JSON Schema");
}, _d = (e, t, n, i) => {
  const s = n, r = e._zod.def, { minimum: o, maximum: a } = ue(e);
  typeof o == "number" && (s.minItems = o), typeof a == "number" && (s.maxItems = a), s.type = "array", s.items = K(r.element, t, {
    ...i,
    path: [...i.path, "items"]
  });
};
function jt(e) {
  const t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? jt(t.out) : t.type === "catch" ? jt(t.innerType) : e._zod.optin;
}
const gd = (e, t, n, i) => {
  const s = n, r = e._zod.def, o = r.shape;
  if (Object.getOwnPropertySymbols(o).length && Ue(e, t, s, i, "Symbol keys cannot be represented in JSON Schema"))
    return;
  s.type = "object", s.properties = {};
  for (const f in o)
    Oe(s.properties, f, K(o[f], t, {
      ...i,
      path: [...i.path, "properties", f]
    }));
  const l = new Set(Object.keys(o)), c = new Set([...l].filter((f) => {
    const u = r.shape[f];
    return t.io === "input" ? jt(u) === void 0 : u._zod.optout === void 0;
  }));
  c.size > 0 && (s.required = Array.from(c)), r.catchall?._zod.def.type === "never" ? s.additionalProperties = !1 : r.catchall ? r.catchall && (s.additionalProperties = K(r.catchall, t, {
    ...i,
    path: [...i.path, "additionalProperties"]
  })) : t.io === "output" && (s.additionalProperties = !1);
}, vd = (e, t, n, i) => {
  const s = e._zod.def, r = s.inclusive === !1, o = s.options.map((a, l) => K(a, t, {
    ...i,
    path: [...i.path, r ? "oneOf" : "anyOf", l]
  }));
  r ? n.oneOf = o : n.anyOf = o;
}, bd = (e, t, n, i) => {
  const s = e._zod.def, r = K(s.left, t, {
    ...i,
    path: [...i.path, "allOf", 0]
  }), o = K(s.right, t, {
    ...i,
    path: [...i.path, "allOf", 1]
  }), a = (c) => "allOf" in c && Object.keys(c).length === 1, l = [
    ...a(r) ? r.allOf : [r],
    ...a(o) ? o.allOf : [o]
  ];
  n.allOf = l, t.intersections.push(l);
}, yd = (e, t, n, i) => {
  const s = n, r = e._zod.def;
  s.type = "array";
  const o = t.target === "draft-2020-12" ? "prefixItems" : "items", a = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", l = r.items.map((y, x) => K(y, t, {
    ...i,
    path: [...i.path, o, x]
  })), c = r.rest ? K(r.rest, t, {
    ...i,
    path: [...i.path, a, ...t.target === "openapi-3.0" ? [r.items.length] : []]
  }) : null;
  let f = r.items.length;
  for (; f > 0; ) {
    const y = r.items[f - 1];
    if (!(t.io === "input" ? jt(y) !== void 0 : y._zod.optout === "optional"))
      break;
    f--;
  }
  const u = r.items.length, m = !r.rest;
  t.target === "draft-2020-12" ? (s.prefixItems = l, m ? s.items = !1 : c && (s.items = c), f > 0 && (s.minItems = f), m && (s.maxItems = u)) : t.target === "openapi-3.0" ? (s.items = {
    anyOf: l
  }, c && s.items.anyOf.push(c), f > 0 && (s.minItems = f), m && (s.maxItems = u)) : (s.items = l, m ? s.additionalItems = !1 : c && (s.additionalItems = c), f > 0 && (s.minItems = f), m && (s.maxItems = u));
  const { minimum: h, maximum: p } = ue(e);
  typeof h == "number" && (s.minItems = h), typeof p == "number" && (s.maxItems = p);
};
function pi(e, t, n) {
  if (t.$ref) {
    if (n.has(t))
      return t;
    n.add(t);
    const p = e.get(t)?.def;
    if (!p)
      return t;
    const y = pi(e, p, n);
    return y === p ? t : y;
  }
  for (const p of ["anyOf", "oneOf"]) {
    const y = t[p];
    if (!Array.isArray(y))
      continue;
    const x = y.map((k) => pi(e, k, n));
    x.some((k, N) => k !== y[N]) && (t = { ...t, [p]: x });
  }
  const i = Array.isArray(t.type) ? t.type : [t.type], s = !i.includes("string") && i.some((p) => p === "number" || p === "integer"), r = t.enum ?? (t.const !== void 0 ? [t.const] : void 0);
  if (!s && !r?.some((p) => typeof p == "number"))
    return t;
  const { minimum: o, maximum: a, exclusiveMinimum: l, exclusiveMaximum: c, multipleOf: f, format: u, id: m, ...h } = t;
  return h.enum ? h.enum = h.enum.map((p) => typeof p == "number" ? String(p) : p) : typeof h.const == "number" && (h.const = String(h.const)), s && (h.type = "string", r || (h.pattern = (i.includes("number") ? Ni : Ac).source)), h;
}
const hi = /* @__PURE__ */ new WeakMap();
function wd(e) {
  const t = /* @__PURE__ */ new Map();
  for (const i of e.seen.values())
    i.def && !t.has(i.schema) && t.set(i.schema, i);
  const n = /* @__PURE__ */ new Map();
  for (const i of hi.get(e) ?? []) {
    const s = e.seen.get(i), r = (s?.def ?? s?.schema)?.propertyNames;
    if (!r || r === !0 || n.has(r))
      continue;
    const o = pi(t, r, /* @__PURE__ */ new Set());
    o !== r && n.set(r, o);
  }
  if (n.size)
    for (const i of e.seen.values())
      for (const s of [i.schema, i.def]) {
        const r = s && n.get(s.propertyNames);
        r && (s.propertyNames = r);
      }
}
const xd = (e, t, n, i) => {
  const s = n, r = e._zod.def;
  s.type = "object";
  const o = r.keyType, a = ue(o).patterns;
  if (r.mode === "loose" && a && a.size > 0) {
    const f = K(r.valueType, t, {
      ...i,
      path: [...i.path, "patternProperties", "*"]
    });
    s.patternProperties = {};
    for (const u of a)
      Oe(s.patternProperties, eo(u).source, f);
  } else {
    if (t.target === "draft-07" || t.target === "draft-2020-12") {
      s.propertyNames = K(r.keyType, t, {
        ...i,
        path: [...i.path, "propertyNames"]
      });
      let f = hi.get(t);
      f || (f = [], hi.set(t, f), t.deferred.push(() => wd(t))), f.push(e);
    }
    s.additionalProperties = K(r.valueType, t, {
      ...i,
      path: [...i.path, "additionalProperties"]
    });
  }
  const l = o._zod.values, c = t.io === "input" && jt(r.valueType) !== void 0;
  if (l && !r.partial && !c) {
    const f = [...l].filter((u) => typeof u == "string" || typeof u == "number");
    f.length > 0 && (s.required = f.map(String));
  }
}, kd = (e, t, n, i) => {
  const s = e._zod.def, r = K(s.innerType, t, i), o = t.seen.get(e);
  t.target === "openapi-3.0" ? (o.ref = s.innerType, n.nullable = !0) : n.anyOf = [r, { type: "null" }];
}, Sd = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
}, Fi = /* @__PURE__ */ Symbol();
function to(e, t, n, i, s) {
  let r = !1;
  const o = JSON.stringify(e, (a, l) => typeof l != "bigint" ? l : (r = !0, null));
  return r ? (Ue(t, n, i, s, "BigInt defaults cannot be represented in JSON Schema"), Fi) : JSON.parse(o);
}
const Ed = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
  const o = to(s.defaultValue, e, t, n, i);
  o !== Fi && (n.default = o);
}, Id = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  if (r.ref = s.innerType, t.io !== "input")
    return;
  const o = to(s.defaultValue, e, t, n, i);
  o !== Fi && (n._prefault = o);
}, zd = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
  let o;
  try {
    o = s.catchValue(void 0);
  } catch {
    Ue(e, t, n, i, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  n.default = o;
}, Td = (e, t, n, i) => {
  const s = e._zod.def, r = s.in._zod.traits.has("$ZodTransform"), o = t.io === "input" ? r ? s.out : s.in : s.out;
  K(o, t, i);
  const a = t.seen.get(e);
  a.ref = o;
}, Od = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType, n.readOnly = !0;
}, no = (e, t, n, i) => {
  const s = e._zod.def;
  K(s.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = s.innerType;
}, Us = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function an(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    get() {
      const i = n(this);
      return Object.defineProperty(this, t, { value: i, configurable: !0, writable: !0 }), i;
    },
    set(i) {
      Object.defineProperty(this, t, { value: i, configurable: !0, writable: !0 });
    }
  });
}
const Ad = (e, t) => {
  Ua.init(e, t), e.name = "ZodError";
  const n = Object.getPrototypeOf(e);
  Us.has(n) || (Us.add(n), an(n, "format", (i) => (s) => Ha(i, s)), an(n, "flatten", (i) => (s) => qa(i, s)), an(n, "addIssue", (i) => (s) => {
    i.issues.push(s), i.message = JSON.stringify(i.issues, ci, 2);
  }), an(n, "addIssues", (i) => (s) => {
    i.issues.push(...s), i.message = JSON.stringify(i.issues, ci, 2);
  }), Object.defineProperty(n, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, de = /* @__PURE__ */ v("ZodError", Ad, void 0, {
  Parent: Error
}), Nd = /* @__PURE__ */ zi(de), Cd = /* @__PURE__ */ Ti(de), $d = /* @__PURE__ */ Oi(de), Dd = /* @__PURE__ */ Ai(de), Fd = /* @__PURE__ */ Ga(de), Pd = /* @__PURE__ */ Ya(de), Rd = /* @__PURE__ */ Qa(de), Zd = /* @__PURE__ */ ec(de), Md = /* @__PURE__ */ tc(de), jd = /* @__PURE__ */ nc(de), Ld = /* @__PURE__ */ ic(de), Ud = /* @__PURE__ */ sc(de);
function Bd() {
  le.localeError || ve(al());
}
function Bt() {
  le.memoizer || ve({ memoizer: sl() });
}
const B = /* @__PURE__ */ v("ZodType", (e, t) => (Bd(), M.init(e, t), e.def = t, e.type = t.type, e), {
  check(...e) {
    const t = this.def;
    return this.clone(oe(t, {
      checks: [
        ...t.checks ?? [],
        ...e.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, t) {
    return Be(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  refine(e, t) {
    return this.check(Mf(e, t));
  },
  superRefine(e, t) {
    return this.check(jf(e, t));
  },
  overwrite(e) {
    return this.check(/* @__PURE__ */ vt(e));
  },
  optional() {
    return Ws(this);
  },
  exactOptional() {
    return If(this);
  },
  nullable() {
    return Ks(this);
  },
  nullish() {
    return Ws(Ks(this));
  },
  nonoptional(e) {
    return Cf(this, e);
  },
  array() {
    return A(this);
  },
  or(e) {
    return Ae([this, e]);
  },
  and(e) {
    return wf(this, e);
  },
  transform(e) {
    return Vs(this, Ef(e));
  },
  default(e) {
    return Of(this, e);
  },
  prefault(e) {
    return Nf(this, e);
  },
  catch(e) {
    return Df(this, e);
  },
  pipe(e) {
    return Vs(this, e);
  },
  readonly() {
    return Rf(this);
  },
  describe(e) {
    const t = this.clone();
    return $t.add(t, { description: e }), t;
  },
  meta(...e) {
    if (e.length === 0)
      return $t.get(this);
    const t = this.clone();
    return $t.add(t, e[0]), t;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return br(this, "~standard", {
      ...zr(this),
      jsonSchema: {
        input: yn(this, "input"),
        output: yn(this, "output")
      }
    });
  },
  set "~standard"(e) {
    Le(this, "~standard", e);
  },
  parse: function e(t, n) {
    return Nd(this, t, n, { callee: e });
  },
  parseAsync: async function e(t, n) {
    return await Cd(this, t, n, { callee: e });
  },
  safeParse(e, t) {
    return $d(this, e, t);
  },
  async safeParseAsync(e, t) {
    return Dd(this, e, t);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    Le(this, "spa", e);
  },
  validate(e, t) {
    return Va(this, e, t);
  },
  validateAsync(e, t) {
    return Xa(this, e, t);
  },
  encode: function e(t, n) {
    return Fd(this, t, n, { callee: e });
  },
  decode: function e(t, n) {
    return Pd(this, t, n, { callee: e });
  },
  encodeAsync: async function e(t, n) {
    return await Rd(this, t, n, { callee: e });
  },
  decodeAsync: async function e(t, n) {
    return await Zd(this, t, n, { callee: e });
  },
  safeEncode(e, t) {
    return Md(this, e, t);
  },
  safeDecode(e, t) {
    return jd(this, e, t);
  },
  async safeEncodeAsync(e, t) {
    return Ld(this, e, t);
  },
  async safeDecodeAsync(e, t) {
    return Ud(this, e, t);
  },
  toJSONSchema(e) {
    return nd(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return $t.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), io = /* @__PURE__ */ v(
  "_ZodString",
  (e, t) => {
    $i.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => od(e, n, i);
  },
  /* @__PURE__ */ yr({
    format: (e) => ue(e).format ?? null,
    minLength: (e) => ue(e).minimum ?? null,
    maxLength: (e) => ue(e).maximum ?? null
  }, {
    regex(...e) {
      return this.check(/* @__PURE__ */ jl(...e));
    },
    includes(...e) {
      return this.check(/* @__PURE__ */ Bl(...e));
    },
    startsWith(...e) {
      return this.check(/* @__PURE__ */ ql(...e));
    },
    endsWith(...e) {
      return this.check(/* @__PURE__ */ Hl(...e));
    },
    min(...e) {
      return this.check(/* @__PURE__ */ bn(...e));
    },
    max(...e) {
      return this.check(/* @__PURE__ */ Br(...e));
    },
    length(...e) {
      return this.check(/* @__PURE__ */ qr(...e));
    },
    nonempty(...e) {
      return this.check(/* @__PURE__ */ bn(1, ...e));
    },
    lowercase(e) {
      return this.check(/* @__PURE__ */ Ll(e));
    },
    uppercase(e) {
      return this.check(/* @__PURE__ */ Ul(e));
    },
    trim() {
      return this.check(/* @__PURE__ */ Kl());
    },
    normalize(...e) {
      return this.check(/* @__PURE__ */ Wl(...e));
    },
    toLowerCase() {
      return this.check(/* @__PURE__ */ Vl());
    },
    toUpperCase() {
      return this.check(/* @__PURE__ */ Jl());
    },
    slugify() {
      return this.check(/* @__PURE__ */ Xl());
    }
  })
), qd = /* @__PURE__ */ v("ZodString", (e, t) => {
  $i.init(e, t), io.init(e, t);
}, {
  email(e) {
    return this.check(/* @__PURE__ */ dl(Vd, e));
  },
  url(e) {
    return this.check(/* @__PURE__ */ Lr(ro, e));
  },
  jwt(e) {
    return this.check(/* @__PURE__ */ Al(df, e));
  },
  emoji(e) {
    return this.check(/* @__PURE__ */ _l(Xd, e));
  },
  guid(e) {
    return this.check(/* @__PURE__ */ fl(Jd, e));
  },
  uuid(e) {
    return this.check(/* @__PURE__ */ jr(Dt, e));
  },
  uuidv4(e) {
    return this.check(/* @__PURE__ */ pl(Dt, e));
  },
  uuidv6(e) {
    return this.check(/* @__PURE__ */ hl(Dt, e));
  },
  uuidv7(e) {
    return this.check(/* @__PURE__ */ ml(Dt, e));
  },
  nanoid(e) {
    return this.check(/* @__PURE__ */ gl(Gd, e));
  },
  cuid(e) {
    return this.check(/* @__PURE__ */ vl(Yd, e));
  },
  cuid2(e) {
    return this.check(/* @__PURE__ */ bl(Qd, e));
  },
  ulid(e) {
    return this.check(/* @__PURE__ */ yl(ef, e));
  },
  base64(e) {
    return this.check(/* @__PURE__ */ zl(cf, e));
  },
  base64url(e) {
    return this.check(/* @__PURE__ */ Tl(uf, e));
  },
  xid(e) {
    return this.check(/* @__PURE__ */ wl(tf, e));
  },
  ksuid(e) {
    return this.check(/* @__PURE__ */ xl(nf, e));
  },
  ipv4(e) {
    return this.check(/* @__PURE__ */ kl(sf, e));
  },
  ipv6(e) {
    return this.check(/* @__PURE__ */ Sl(rf, e));
  },
  cidrv4(e) {
    return this.check(/* @__PURE__ */ El(of, e));
  },
  cidrv6(e) {
    return this.check(/* @__PURE__ */ Il(af, e));
  },
  e164(e) {
    return this.check(/* @__PURE__ */ Ol(lf, e));
  },
  datetime(e) {
    return this.check(/* @__PURE__ */ Nl(Hd, e));
  },
  date(e) {
    return this.check(/* @__PURE__ */ Ur(so, e));
  },
  time(e) {
    return this.check(/* @__PURE__ */ Cl(Wd, e));
  },
  duration(e) {
    return this.check(/* @__PURE__ */ $l(Kd, e));
  }
});
function S(e) {
  return /* @__PURE__ */ ll(qd, e);
}
const H = /* @__PURE__ */ v("ZodStringFormat", (e, t) => {
  q.init(e, t), io.init(e, t);
}), Hd = /* @__PURE__ */ v("ZodISODateTime", (e, t) => {
  fu.init(e, t), H.init(e, t);
}), so = /* @__PURE__ */ v("ZodISODate", (e, t) => {
  pu.init(e, t), H.init(e, t);
}), Wd = /* @__PURE__ */ v("ZodISOTime", (e, t) => {
  hu.init(e, t), H.init(e, t);
}), Kd = /* @__PURE__ */ v("ZodISODuration", (e, t) => {
  mu.init(e, t), H.init(e, t);
}), Vd = /* @__PURE__ */ v("ZodEmail", (e, t) => {
  Yc.init(e, t), H.init(e, t);
}), Jd = /* @__PURE__ */ v("ZodGUID", (e, t) => {
  Xc.init(e, t), H.init(e, t);
}), Dt = /* @__PURE__ */ v("ZodUUID", (e, t) => {
  Gc.init(e, t), H.init(e, t);
});
function Qe(e) {
  return /* @__PURE__ */ jr(Dt, e);
}
const ro = /* @__PURE__ */ v("ZodURL", (e, t) => {
  su.init(e, t), H.init(e, t);
});
function Ge(e) {
  return /* @__PURE__ */ Lr(ro, e);
}
const Xd = /* @__PURE__ */ v("ZodEmoji", (e, t) => {
  ru.init(e, t), H.init(e, t);
}), Gd = /* @__PURE__ */ v("ZodNanoID", (e, t) => {
  ou.init(e, t), H.init(e, t);
}), Yd = /* @__PURE__ */ v("ZodCUID", (e, t) => {
  au.init(e, t), H.init(e, t);
}), Qd = /* @__PURE__ */ v("ZodCUID2", (e, t) => {
  cu.init(e, t), H.init(e, t);
}), ef = /* @__PURE__ */ v("ZodULID", (e, t) => {
  uu.init(e, t), H.init(e, t);
}), tf = /* @__PURE__ */ v("ZodXID", (e, t) => {
  lu.init(e, t), H.init(e, t);
}), nf = /* @__PURE__ */ v("ZodKSUID", (e, t) => {
  du.init(e, t), H.init(e, t);
}), sf = /* @__PURE__ */ v("ZodIPv4", (e, t) => {
  _u.init(e, t), H.init(e, t);
}), rf = /* @__PURE__ */ v("ZodIPv6", (e, t) => {
  vu.init(e, t), H.init(e, t);
}), of = /* @__PURE__ */ v("ZodCIDRv4", (e, t) => {
  bu.init(e, t), H.init(e, t);
}), af = /* @__PURE__ */ v("ZodCIDRv6", (e, t) => {
  wu.init(e, t), H.init(e, t);
}), cf = /* @__PURE__ */ v("ZodBase64", (e, t) => {
  xu.init(e, t), H.init(e, t);
}), uf = /* @__PURE__ */ v("ZodBase64URL", (e, t) => {
  Su.init(e, t), H.init(e, t);
}), lf = /* @__PURE__ */ v("ZodE164", (e, t) => {
  Eu.init(e, t), H.init(e, t);
}), df = /* @__PURE__ */ v("ZodJWT", (e, t) => {
  zu.init(e, t), H.init(e, t);
}), oo = /* @__PURE__ */ v(
  "ZodNumber",
  (e, t) => {
    $r.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => ad(e, n, i, s), e.isFinite = !0;
  },
  /* @__PURE__ */ yr({
    minValue: (e) => {
      const { minimum: t, exclusiveMinimum: n } = ue(e);
      return Math.max(t ?? Number.NEGATIVE_INFINITY, n ?? Number.NEGATIVE_INFINITY);
    },
    maxValue: (e) => {
      const { maximum: t, exclusiveMaximum: n } = ue(e);
      return Math.min(t ?? Number.POSITIVE_INFINITY, n ?? Number.POSITIVE_INFINITY);
    },
    isInt: (e) => {
      const { isInt: t, multipleOf: n } = ue(e);
      return !!t || !!n?.some(Number.isSafeInteger);
    },
    format: (e) => ue(e).format ?? null
  }, {
    gt(e, t) {
      return this.check(/* @__PURE__ */ $s(e, t));
    },
    gte(e, t) {
      return this.check(/* @__PURE__ */ Hn(e, t));
    },
    min(e, t) {
      return this.check(/* @__PURE__ */ Hn(e, t));
    },
    lt(e, t) {
      return this.check(/* @__PURE__ */ Cs(e, t));
    },
    lte(e, t) {
      return this.check(/* @__PURE__ */ qn(e, t));
    },
    max(e, t) {
      return this.check(/* @__PURE__ */ qn(e, t));
    },
    int(e) {
      return this.check(Bs(e));
    },
    safe(e) {
      return this.check(Bs(e));
    },
    positive(e) {
      return this.check(/* @__PURE__ */ $s(0, e));
    },
    nonnegative(e) {
      return this.check(/* @__PURE__ */ Hn(0, e));
    },
    negative(e) {
      return this.check(/* @__PURE__ */ Cs(0, e));
    },
    nonpositive(e) {
      return this.check(/* @__PURE__ */ qn(0, e));
    },
    multipleOf(e, t) {
      return this.check(/* @__PURE__ */ Ds(e, t));
    },
    step(e, t) {
      return this.check(/* @__PURE__ */ Ds(e, t));
    },
    finite() {
      return this;
    }
  })
);
function D(e) {
  return /* @__PURE__ */ Dl(oo, e);
}
const ff = /* @__PURE__ */ v("ZodNumberFormat", (e, t) => {
  Tu.init(e, t), oo.init(e, t);
});
function Bs(e) {
  return /* @__PURE__ */ Fl(ff, e);
}
const pf = /* @__PURE__ */ v("ZodBoolean", (e, t) => {
  Ou.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => cd(e, n, i);
});
function ze(e) {
  return /* @__PURE__ */ Pl(pf, e);
}
const hf = /* @__PURE__ */ v("ZodNull", (e, t) => {
  Au.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => ud(e, n, i);
});
function mi(e) {
  return /* @__PURE__ */ Rl(hf, e);
}
const mf = /* @__PURE__ */ v("ZodUnknown", (e, t) => {
  Nu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => dd();
});
function qs() {
  return /* @__PURE__ */ Zl(mf);
}
const _f = /* @__PURE__ */ v("ZodNever", (e, t) => {
  Cu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => ld(e, n, i);
});
function ao(e) {
  return /* @__PURE__ */ Ml(_f, e);
}
const gf = /* @__PURE__ */ v("ZodArray", (e, t) => {
  Bt(), $u.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => _d(e, n, i, s), e.element = t.element;
}, {
  min(e, t) {
    return this.check(/* @__PURE__ */ bn(e, t));
  },
  nonempty(e) {
    return this.check(/* @__PURE__ */ bn(1, e));
  },
  max(e, t) {
    return this.check(/* @__PURE__ */ Br(e, t));
  },
  length(e, t) {
    return this.check(/* @__PURE__ */ qr(e, t));
  },
  unwrap() {
    return this.element;
  }
});
function A(e, t) {
  return /* @__PURE__ */ Gl(gf, e, t);
}
const vf = /* @__PURE__ */ v("ZodObject", (e, t) => {
  Bt(), Pu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => gd(e, n, i, s), Da(e, "shape", (n) => n._zod.def.shape, !1);
}, {
  keyof() {
    return b(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone(oe(this._zod.def, { catchall: e }));
  },
  passthrough() {
    return this.clone(oe(this._zod.def, { catchall: qs() }));
  },
  loose() {
    return this.clone(oe(this._zod.def, { catchall: qs() }));
  },
  strict() {
    return this.clone(oe(this._zod.def, { catchall: ao() }));
  },
  strip() {
    return this.clone(oe(this._zod.def, { catchall: void 0 }));
  },
  extend(e) {
    return Sa(this, e);
  },
  safeExtend(e) {
    return Ea(this, e);
  },
  merge(e) {
    return Ia(this, e);
  },
  pick(e) {
    return xa(this, e);
  },
  omit(e) {
    return ka(this, e);
  },
  partial(...e) {
    return ds(Pi, this, e[0]);
  },
  exactPartial(...e) {
    return ds(uo, this, e[0], "exactPartial");
  },
  required(...e) {
    return za(lo, this, e[0]);
  }
});
function w(e, t) {
  return new vf({
    type: "object",
    shape: e,
    catchall: ao(),
    ...z(t)
  });
}
const co = /* @__PURE__ */ v("ZodUnion", (e, t) => {
  Pr.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => vd(e, n, i, s), e.options = t.options;
});
function Ae(e, t) {
  return new co({
    type: "union",
    options: e,
    ...z(t)
  });
}
const bf = /* @__PURE__ */ v("ZodDiscriminatedUnion", (e, t) => {
  co.init(e, t), Zu.init(e, t);
});
function bt(e, t, n) {
  return new bf({
    type: "union",
    options: t,
    discriminator: e,
    ...z(n)
  });
}
const yf = /* @__PURE__ */ v("ZodIntersection", (e, t) => {
  Mu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => bd(e, n, i, s);
});
function wf(e, t) {
  return new yf({
    type: "intersection",
    left: e,
    right: t
  });
}
const xf = /* @__PURE__ */ v("ZodTuple", (e, t) => {
  Bt(), ju.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => yd(e, n, i, s);
}, {
  rest(e) {
    return this.clone({
      ...this._zod.def,
      rest: e
    });
  },
  partial() {
    const e = this._zod.def;
    if (e.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...e,
      items: e.items.map((t) => new Pi({ type: "optional", innerType: t }))
    });
  }
});
function Hs(e, t, n) {
  const i = t instanceof M, s = i ? n : t, r = i ? t : null;
  return new xf({
    type: "tuple",
    items: e,
    rest: r,
    ...z(s)
  });
}
const _i = /* @__PURE__ */ v("ZodRecord", (e, t) => {
  Bt(), Lu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => xd(e, n, i, s), e.keyType = t.keyType, e.valueType = t.valueType;
});
function ke(e, t, n) {
  return !t || !t._zod ? new _i({
    type: "record",
    keyType: S(),
    valueType: e,
    ...z(t)
  }) : new _i({
    type: "record",
    keyType: e,
    valueType: t,
    ...z(n)
  });
}
function Ze(e, t, n) {
  return new _i({
    type: "record",
    keyType: e,
    valueType: t,
    ...z(n),
    partial: !0
  });
}
const gi = /* @__PURE__ */ v("ZodEnum", (e, t) => {
  Uu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (i, s, r) => fd(e, i, s), e.enum = t.entries, e.options = [...e._zod.values];
  const n = new Set(Object.keys(t.entries));
  e.extract = (i, s) => {
    const r = {};
    for (const o of i)
      if (n.has(o))
        r[o] = t.entries[o];
      else
        throw new Error(`Key ${o} not found in enum`);
    return new gi({
      ...t,
      checks: [],
      ...z(s),
      entries: r
    });
  }, e.exclude = (i, s) => {
    const r = { ...t.entries };
    for (const o of i)
      if (n.has(o))
        delete r[o];
      else
        throw new Error(`Key ${o} not found in enum`);
    return new gi({
      ...t,
      checks: [],
      ...z(s),
      entries: r
    });
  };
});
function b(e, t) {
  const n = Array.isArray(e) ? Object.fromEntries(e.map((i) => [i, i])) : e;
  return new gi({
    type: "enum",
    entries: n,
    ...z(t)
  });
}
const kf = /* @__PURE__ */ v("ZodLiteral", (e, t) => {
  Bu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => pd(e, n, i, s), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function E(e, t) {
  return new kf({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...z(t)
  });
}
const Sf = /* @__PURE__ */ v("ZodTransform", (e, t) => {
  Bt(), qu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => md(e, n, i, s), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new wr(e.constructor.name);
    n.addIssue = (r) => {
      if (typeof r == "string")
        n.issues.push(Mt(r, n.value, t));
      else {
        const o = r;
        o.fatal && (o.continue = !1), o.code ?? (o.code = "custom"), "input" in o || (o.input = n.value), o.inst ?? (o.inst = e), n.issues.push(Mt(o));
      }
    };
    const s = t.transform(n.value, n);
    return s instanceof Promise ? s.then((r) => (n.value = r, n)) : (n.value = s, n);
  };
});
function Ef(e) {
  return new Sf({
    type: "transform",
    transform: e
  });
}
const Pi = /* @__PURE__ */ v("ZodOptional", (e, t) => {
  Rr.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => no(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Ws(e) {
  return new Pi({
    type: "optional",
    innerType: e
  });
}
const uo = /* @__PURE__ */ v("ZodExactOptional", (e, t) => {
  Hu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => no(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function If(e) {
  return new uo({
    type: "optional",
    innerType: e
  });
}
const zf = /* @__PURE__ */ v("ZodNullable", (e, t) => {
  Wu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => kd(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Ks(e) {
  return new zf({
    type: "nullable",
    innerType: e
  });
}
const Tf = /* @__PURE__ */ v("ZodDefault", (e, t) => {
  Ku.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Ed(e, n, i, s), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Of(e, t) {
  return new Tf({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : mr(t);
    }
  });
}
const Af = /* @__PURE__ */ v("ZodPrefault", (e, t) => {
  Vu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Id(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Nf(e, t) {
  return new Af({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : mr(t);
    }
  });
}
const lo = /* @__PURE__ */ v("ZodNonOptional", (e, t) => {
  Ju.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Sd(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Cf(e, t) {
  return new lo({
    type: "nonoptional",
    innerType: e,
    ...z(t)
  });
}
const $f = /* @__PURE__ */ v("ZodCatch", (e, t) => {
  Xu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => zd(e, n, i, s), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function Df(e, t) {
  return new $f({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : Pa(t)
  });
}
const Ff = /* @__PURE__ */ v("ZodPipe", (e, t) => {
  Gu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Td(e, n, i, s), e.in = t.in, e.out = t.out;
});
function Vs(e, t) {
  return new Ff({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
const Pf = /* @__PURE__ */ v("ZodReadonly", (e, t) => {
  Yu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => Od(e, n, i, s), e.unwrap = () => e._zod.def.innerType;
});
function Rf(e) {
  return new Pf({
    type: "readonly",
    innerType: e
  });
}
const Zf = /* @__PURE__ */ v("ZodCustom", (e, t) => {
  Qu.init(e, t), B.init(e, t), e._zod.processJSONSchema = (n, i, s) => hd(e, n, i, s);
});
function Mf(e, t = {}) {
  return /* @__PURE__ */ Yl(Zf, e, t);
}
function jf(e, t) {
  return /* @__PURE__ */ Ql(e, t);
}
function In(e) {
  return /* @__PURE__ */ Ur(so, e);
}
ve({ jitless: !0 });
const C = S().regex(/^(0|[1-9][0-9]{0,18})$/).refine(
  (e) => /^(0|[1-9][0-9]{0,18})$/.test(e) && BigInt(e) <= 9223372036854775807n,
  "Counter overflow"
), zn = S().regex(/^(0|[1-9][0-9]*)(\.[0-9]{1,18})?$/).refine((e) => e.replace(".", "").length <= 38, "Decimal overflow"), _e = S().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/).refine(
  (e) => !Number.isNaN(Date.parse(e)) && new Date(e).toISOString() === e,
  "Invalid calendar instant"
), O = S().regex(/^[0-9a-f]{64}$/), L = S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/), Ri = S().max(96).regex(/^-?(0|[1-9][0-9]*)(\.[0-9]+)?(e[+-]?[0-9]{1,3})?$/).refine((e) => Number.isFinite(Number(e)), "Nonfinite quantity").refine(
  (e) => Number(e) !== 0 || /^-?0(\.0+)?(e[+-]?[0-9]{1,3})?$/.test(e),
  "Quantity underflow"
), Se = Ri.refine(
  (e) => Number(e) >= 0 && !Object.is(Number(e), -0),
  "Negative quantity"
), wn = b(["original", "ecologits"]), Tn = b([
  "build_default",
  "original",
  "ecologits"
]), vi = D().int().min(1).max(2147483647), lt = S().regex(/^[a-z][a-z0-9_-]{0,63}$/), fo = S().regex(/^[A-Za-z0-9][A-Za-z0-9._:/@+\-]{0,191}$/), qt = w({
  provider: lt,
  model_name: fo,
  workload: b(["text", "video"])
}), Zi = w({
  strategy: E("original_engine")
}), Mi = w({
  strategy: E("unavailable")
}), po = w({
  strategy: E("upstream_provider_flagship"),
  profile: qt
}), Lf = bt("strategy", [
  po,
  Zi,
  Mi
]), Uf = b([
  "nearest_record",
  "family_benchmark",
  "model_not_named",
  "model_not_in_library",
  // The highest version of the same family in the catalog, for a version not listed yet.
  "model_family_stand_in",
  // The highest version of the same variant (GPT Pro, Gemini Pro Image) for a variant not listed.
  "model_variant_stand_in",
  // The highest model of the same kind and vendor when the catalog has no record of the variant.
  "model_kind_stand_in"
]), Bf = bt("strategy", [
  w({
    strategy: E("upstream_profile"),
    profile: qt,
    basis: Uf
  }),
  Zi,
  Mi
]), ho = w({
  policy_version: L,
  review_date: In(),
  provider_defaults: ke(lt, Lf),
  model_overrides: ke(L, Bf),
  /** A site without an identified provider may name one explicit benchmark profile. */
  unknown_provider: bt("strategy", [
    po,
    Zi,
    Mi
  ])
}).superRefine((e, t) => {
  (Object.keys(e.provider_defaults).length > 64 || Object.keys(e.model_overrides).length > 4096) && t.addIssue({
    code: "custom",
    message: "Policy exceeds its entry limit"
  });
  for (const [n, i] of Object.entries(
    e.provider_defaults
  ))
    i.strategy === "upstream_provider_flagship" && i.profile.provider !== n && t.addIssue({
      code: "custom",
      message: "A provider flagship must belong to that provider",
      path: ["provider_defaults", n]
    });
}), qf = w({
  schema_version: E("1.0.0"),
  review_date: In(),
  mapping_basis: E("consumer_to_api_assumption"),
  source: Ge(),
  bindings: ke(L, qt).refine(
    (e) => Object.keys(e).length <= 4096,
    "Too many mappings"
  )
}), cn = b([
  "chatgpt",
  "claude",
  "gemini",
  "perplexity",
  "notebooklm"
]), Ie = S().regex(/^(0|[1-9][0-9]{0,6})(\.[0-9]{1,9})?$/).refine((e) => Number(e) > 0, "Coefficient must be positive"), Js = Ae([
  Ie,
  w({ min: Ie, max: Ie }).refine(
    (e) => Number(e.min) <= Number(e.max),
    "Range minimum exceeds its maximum"
  )
]), Hf = w({
  factor: Ie,
  tokenizer_profile_id: E("o200k-base-4.0.0-reference"),
  measured_on: In(),
  source: Ge()
}), Xs = w({
  width: D().int().min(1).max(65536),
  height: D().int().min(1).max(65536),
  duration_seconds: Ie,
  with_audio: ze()
}), Wf = w({
  schema_version: E("1.0.0"),
  review_date: In(),
  image: w({
    method_id: L,
    it_energy_wh_per_image: Ie,
    source: Ge(),
    model_providers: ke(L, lt),
    site_providers: Ze(cn, lt)
  }),
  speech: w({
    method_id: L,
    profile: qt,
    tokens_per_second: ke(lt, Ie),
    characters_per_second: Ie,
    site_providers: Ze(cn, lt),
    source: Ge()
  }),
  video: w({
    method_id: L,
    // The registry model that stands in when the page shows a video but names no model.
    site_models: Ze(cn, L),
    site_defaults: Ze(cn, Xs),
    model_defaults: ke(fo, Xs),
    source: Ge()
  }),
  overview: w({
    method_id: L,
    seconds_per_illustration: Ie
  }),
  // A model served away from its catalog provider's data centres takes the grid and, when
  // given, the PUE and WUE of where it runs. Factors replace the provider's for that model only.
  environment_overrides: ke(
    L,
    w({
      electricity_mix_zone: S().regex(/^[A-Z]{3}$/),
      datacenter_pue: Js.optional(),
      datacenter_wue: Js.optional()
    }).refine(
      (e) => e.datacenter_pue === void 0 || Number(
        typeof e.datacenter_pue == "string" ? e.datacenter_pue : e.datacenter_pue.min
      ) >= 1,
      "PUE cannot be below 1"
    )
  ),
  // Optional, so method definitions saved before 15 October 2026 stay readable: a method
  // without it estimates Claude text from the tokenizer's count unchanged.
  claude_token_factor: Hf.optional()
}), Kf = w({
  catalog_schema: L,
  catalog_sha256: O,
  converter_version: L,
  core_sha256: O,
  core_version: L,
  requested_git_commit: S().regex(/^[a-f0-9]{40}$/),
  source_artifact_sha256: O,
  upstream_version: L
});
w({
  schema_version: E("1.0.0"),
  engine_id: E("ecologits"),
  core: Kf,
  mappings: qf,
  fallback: ho,
  media: Wf,
  product_policy: E("operational-only-output-1"),
  latency_policy: E("observed-live-then-history-then-modeled-1"),
  environment_policy: E("upstream-provider-default-assumed"),
  water_total_policy: E("upstream-wcf-1"),
  original_fallback: w({
    method_id: L,
    method_hash: O
  })
});
w({
  schema_version: E("1.0.0"),
  default_engine: wn,
  // Keep historical research configurations readable after retiring the Original engine.
  available_engines: Ae([
    Hs([E("ecologits")]),
    Hs([E("original"), E("ecologits")])
  ]),
  ecologits_fallback: ho
});
w({
  schema_version: E("1.0.0"),
  preference: Tn,
  selection_revision: vi,
  updated_at: _e
});
const Lt = w({
  engine_id: wn,
  implementation_version: L,
  method_id: L,
  method_hash: O,
  source_version: L.nullable(),
  source_commit: S().regex(/^[a-f0-9]{40}$/).nullable(),
  catalog_hash: O.nullable(),
  profile_policy_hash: O,
  environment_policy_hash: O,
  product_scope: E("operational-only")
}), Vf = w({
  observed_request_id: Qe(),
  canonical_request_id: Qe(),
  relation_hash: O
}), Jf = w({
  message_key: O,
  observation_hash: O
}), Xf = bt("family", [
  w({
    family: E("live"),
    request_id: Qe(),
    request_revision: vi,
    request_hash: O,
    attempt_id: Qe(),
    attempt_revision: vi,
    attempt_hash: O,
    canonical_request_binding: Vf.optional(),
    history_binding: Jf.optional()
  }),
  w({
    family: E("history"),
    message_key: O,
    observation_hash: O
  })
]), ce = S().regex(/^[0-9]+(\.[0-9]+)?$/).refine((e) => Number(e) > 0 && Number(e) < 1e9), un = S().regex(/^(0|[1-9][0-9]*)(\.[0-9]+)?$/).refine((e) => Number(e) < 1e9).nullable(), ji = w({
  publisher: S(),
  title: S(),
  url: Ge(),
  section: S(),
  source_revision: S(),
  license: S(),
  access_date: S(),
  activity_period: S().nullable(),
  factor_data_period: S().nullable(),
  publication_date: S().nullable(),
  software_snapshot: S(),
  review_date: S(),
  unknown_period_reason: S(),
  population: S(),
  statistic: b(["scenario_example", "measured_configuration"])
}), mo = w({
  id: S(),
  pue: un,
  carbon: un,
  carbon_gas: b(["CO2", "CO2e"]),
  carbon_boundary: b(["generation", "lifecycle", "unknown"]),
  carbon_accounting: b(["location", "market"]),
  gases: A(S()),
  gwp: S().nullable(),
  direct_water: un,
  direct_denominator: b(["it", "facility"]),
  upstream_water: un,
  water_kind: E("consumption"),
  direct_water_source: b(["freshwater", "all_source", "unknown"]),
  upstream_water_source: b(["freshwater", "all_source", "unknown"]),
  common_water_scope: b(["freshwater_consumption", "all_source_consumption"]).nullable(),
  upstream_exclusions: A(S()),
  provenance: ji
}).refine((e) => e.pue === null || Number(e.pue) >= 1, "PUE below 1");
w({
  schema_version: E("1.0.0"),
  method_id: S().regex(/^[a-z0-9.-]+$/),
  equation_id: b(["ecologits-output-v1", "test-linear-v1"]),
  runtime_selection_allowed: E(!0),
  validation_state: E("unvalidated_reference"),
  reviewer: S().min(1),
  review_date: S(),
  release_validation: E("pending"),
  coefficients: w({
    energyAlpha: ce,
    energyBeta: S().regex(/^-[0-9]+\.[0-9]+$/),
    energyGamma: ce,
    latencyAlpha: ce,
    latencyBeta: ce,
    latencyGamma: ce
  }),
  settings: w({
    gpuMemoryGb: ce,
    precisionBits: E("16"),
    batchSize: ce,
    memoryMultiplier: ce,
    hostPowerKw: ce,
    serverGpuCount: ce
  }),
  profiles: A(
    w({
      id: S(),
      model: S(),
      activeBillions: ce,
      totalBillions: ce,
      architecture_source: Ge()
    })
  ).min(1).max(1e3),
  scenario: mo,
  provenance: ji,
  missing_components: A(S())
});
const _o = [
  "capture_hook_missing",
  "protocol_unsupported",
  "composer_anchor_missing",
  "capture_limit_exceeded",
  "model_unverified",
  "tokenizer_unavailable",
  "storage_write_failed",
  "ledger_integrity_failed",
  "auth_reconnect_required",
  "enrollment_revoked",
  "sync_delayed",
  "payload_rejected",
  "revision_conflict",
  "request_identity_ambiguous",
  "dependency_missing",
  "clock_skew",
  "estimate_pending",
  "estimate_unavailable",
  "method_update_invalid",
  "aggregate_inconsistent",
  "ip_unresolved",
  "ip_history_expired",
  "retention_expired",
  "deletion_in_progress",
  "policy_unavailable",
  "guidance_budget_unavailable",
  "host_interference_detected",
  "conversation_identity_local_only",
  "cross_device_dedup_unverified",
  "hidden_reasoning_unobserved",
  "context_unobserved",
  "cache_semantics_unknown",
  "tool_work_unobserved",
  "media_processing_unobserved",
  "media_metadata_limit_exceeded",
  "image_dimensions_unknown",
  "image_settings_unknown",
  "image_execution_incomplete",
  "tokenizer_mapping_unverified",
  "observed_text_only",
  "not_applicable",
  "provider_usage_unavailable",
  "malformed_frame",
  "unsupported_operation",
  "conflicting_duplicate_identity",
  "capture_body_missing",
  "buffer_overflow",
  "stale_tokenizer_response",
  "tokenizer_timeout",
  "unknown_model",
  "profile_absent",
  "no_comparable_profile",
  "input_length_not_modelled",
  "unvalidated_reference",
  "factor_unavailable",
  "factor_incompatible",
  "method_unsupported",
  "partial_capture",
  "history_only",
  "historical_timing_conflict",
  "unknown_terminal_state",
  "media_direction_unknown",
  "provider_selection_unverified",
  "reasoning_overlap_unknown",
  "record_erased",
  // Tracking accuracy rules of 30 Sep to 4 Oct 2026. Each names what Details explains.
  "reasoning_summary_only",
  "research_work_unobserved",
  "side_calls_unobserved",
  "unknown_event_observed",
  "model_not_in_library",
  "model_not_named",
  "model_stand_in",
  "component_unavailable",
  "media_default_assumed",
  "speech_length_estimated",
  "file_size_estimated",
  "content_not_opened",
  "environment_override",
  // A saved row no live capture can produce (NotebookLM Studio); never an unresolved match.
  "no_live_request"
], yt = b(_o), Gf = (e) => e / 2 ** 32 | 0, Yf = (e) => e >>> 0;
function Qf(e, t, n, i) {
  const s = Gf(n), r = Yf(n);
  e.setUint32(t, i ? r : s, i), e.setUint32(t + 4, i ? s : r, i);
}
function Gs(e) {
  return e instanceof Uint8Array || ArrayBuffer.isView(e) && e.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in e && e.BYTES_PER_ELEMENT === 1;
}
const ep = (e) => e ? `"${e}" ` : "";
function Li(e, t, n = "") {
  if (Gs(e) && t === void 0)
    return e;
  const i = Gs(e), s = "", r = i ? `length=${e.length}` : `type=${typeof e}`, o = ep(n) + "expected Uint8Array" + s + ", got " + r;
  throw i ? new RangeError(o) : new TypeError(o);
}
const tp = (e, t) => {
  if (e === null || typeof e != "object" || Array.isArray(e))
    throw new TypeError((t === "object" ? "" : `"${t}" `) + "expected object, got type=" + typeof e);
}, Ys = (e, t) => {
  tp(e, t);
  const n = Object.getPrototypeOf(e);
  if (n !== Object.prototype && n !== null)
    throw new TypeError(`"${t}" expected plain object`);
  if (Object.hasOwn(e, "__proto__"))
    throw new TypeError(`"${t}.__proto__" is not allowed`);
};
function Qs(e, t = !0) {
  if (e.destroyed)
    throw new Error("hash was destroyed");
  if (t && e.finished)
    throw new Error("digest() was already called");
}
function np(e, t) {
  Li(e, void 0, "output");
  const n = t.outputLen;
  if (!(e.length >= n))
    throw new RangeError('"output" expected length >= ' + n);
}
function er(...e) {
  for (let t = 0; t < e.length; t++)
    e[t].fill(0);
}
function Wn(e) {
  return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function xe(e, t) {
  return e << 32 - t | e >>> t;
}
const ip = /* @ts-ignore */ typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function", sp = /* @__PURE__ */ Array.from({ length: 256 }, (e, t) => t.toString(16).padStart(2, "0"));
function rp(e) {
  if (Li(e), ip)
    return e.toHex();
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += sp[e[n]];
  return t;
}
function op(e, t, n = "opts") {
  return Ys(e, "defaults"), t !== void 0 && Ys(t, n), Object.assign(/* @__PURE__ */ Object.create(null), e, t);
}
function ap(e, t = {}) {
  if (typeof e != "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof e);
  t = op({}, t, "info");
  const n = (s, r) => e(r).update(s).digest(), i = e(void 0);
  return n.outputLen = i.outputLen, n.blockLen = i.blockLen, n.canXOF = i.canXOF, n.create = (s) => e(s), Object.assign(n, t), Object.freeze(n);
}
const cp = (e) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, e])
});
function up(e, t, n) {
  return e & t ^ ~e & n;
}
function lp(e, t, n) {
  return e & t ^ e & n ^ t & n;
}
class dp {
  blockLen;
  outputLen;
  canXOF = !1;
  padOffset;
  isLE;
  // For partial updates less than block size
  buffer;
  view;
  finished = !1;
  length = 0;
  pos = 0;
  destroyed = !1;
  constructor(t, n, i, s) {
    this.blockLen = t, this.outputLen = n, this.padOffset = i, this.isLE = s, this.buffer = new Uint8Array(t), this.view = Wn(this.buffer);
  }
  update(t) {
    Qs(this), Li(t);
    const { view: n, buffer: i, blockLen: s } = this, r = t.length;
    let o = !1;
    for (let a = 0; a < r; ) {
      const l = Math.min(s - this.pos, r - a);
      if (l === s) {
        const c = Wn(t);
        for (; s <= r - a; a += s)
          this.process(c, a);
        o = !0;
        continue;
      }
      i.set(a === 0 && l === r ? t : t.subarray(a, a + l), this.pos), this.pos += l, a += l, this.pos === s && (this.process(n, 0), this.pos = 0, o = !0);
    }
    return this.length += t.length, o && this.roundClean(), this;
  }
  digestInto(t) {
    Qs(this), np(t, this), this.finished = !0;
    const { buffer: n, view: i, blockLen: s, isLE: r } = this;
    let { pos: o } = this;
    n[o++] = 128, n.fill(0, o), this.padOffset > s - o && (this.process(i, 0), n.fill(0)), Qf(i, s - 8, this.length * 8, r), this.process(i, 0), this.roundClean();
    const a = t === n ? i : Wn(t), l = this.outputLen, c = l / 4, f = this.get();
    if (l % 4 || c > f.length)
      throw new Error("invalid outputLen");
    for (let u = 0; u < c; u++)
      a.setUint32(4 * u, f[u], r);
  }
  digest() {
    const { buffer: t, outputLen: n } = this;
    this.digestInto(t);
    const i = t.slice(0, n);
    return this.destroy(), i;
  }
  _cloneIntoMeta(t) {
    const { buffer: n, length: i, finished: s, destroyed: r, pos: o } = this;
    return t.destroyed = r, t.finished = s, t.length = i, t.pos = o, o && t.buffer.set(n), t;
  }
  clone() {
    return this._cloneInto();
  }
}
const fp = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]), pp = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), De = /* @__PURE__ */ new Uint32Array(64);
class hp extends dp {
  // We cannot use array here since array allows indexing by variable
  // which means optimizer/compiler cannot use registers.
  // Numeric initializers matter: starting the fields as `undefined` changes
  // V8's field representation and makes sha256 3x slower (measured).
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(t, n) {
    super(64, t, 8, !1), this.A = n[0] | 0, this.B = n[1] | 0, this.C = n[2] | 0, this.D = n[3] | 0, this.E = n[4] | 0, this.F = n[5] | 0, this.G = n[6] | 0, this.H = n[7] | 0;
  }
  get() {
    const { A: t, B: n, C: i, D: s, E: r, F: o, G: a, H: l } = this;
    return [t, n, i, s, r, o, a, l];
  }
  // prettier-ignore
  set(t, n, i, s, r, o, a, l) {
    this.A = t | 0, this.B = n | 0, this.C = i | 0, this.D = s | 0, this.E = r | 0, this.F = o | 0, this.G = a | 0, this.H = l | 0;
  }
  _cloneInto(t) {
    return (t ||= new this.constructor()).set(...this.get()), this._cloneIntoMeta(t);
  }
  process(t, n) {
    for (let u = 0; u < 16; u++, n += 4)
      De[u] = t.getUint32(n, !1);
    for (let u = 16; u < 64; u++) {
      const m = De[u - 15], h = De[u - 2], p = xe(m, 7) ^ xe(m, 18) ^ m >>> 3, y = xe(h, 17) ^ xe(h, 19) ^ h >>> 10;
      De[u] = y + De[u - 7] + p + De[u - 16] | 0;
    }
    let { A: i, B: s, C: r, D: o, E: a, F: l, G: c, H: f } = this;
    for (let u = 0; u < 64; u++) {
      const m = xe(a, 6) ^ xe(a, 11) ^ xe(a, 25), h = f + m + up(a, l, c) + pp[u] + De[u] | 0, y = (xe(i, 2) ^ xe(i, 13) ^ xe(i, 22)) + lp(i, s, r) | 0;
      f = c, c = l, l = a, a = o + h | 0, o = r, r = s, s = i, i = h + y | 0;
    }
    i = i + this.A | 0, s = s + this.B | 0, r = r + this.C | 0, o = o + this.D | 0, a = a + this.E | 0, l = l + this.F | 0, c = c + this.G | 0, f = f + this.H | 0, this.set(i, s, r, o, a, l, c, f);
  }
  roundClean() {
    er(De);
  }
  destroy() {
    this.destroyed = !0, this.set(0, 0, 0, 0, 0, 0, 0, 0), er(this.buffer);
  }
}
class mp extends hp {
  constructor() {
    super(32, fp);
  }
}
const _p = /* @__PURE__ */ ap(
  () => new mp(),
  /* @__PURE__ */ cp(1)
);
function et(e, t = 0) {
  if (t > 16) throw new Error("payload_rejected");
  if (e === null || typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isSafeInteger(e))
    return JSON.stringify(e);
  if (Array.isArray(e))
    return "[" + e.map((n) => et(n, t + 1)).join(",") + "]";
  if (typeof e == "object" && Object.getPrototypeOf(e) === Object.prototype)
    return "{" + Object.keys(e).sort().map(
      (n) => JSON.stringify(n) + ":" + et(e[n], t + 1)
    ).join(",") + "}";
  throw new Error("payload_rejected");
}
function gt(e) {
  return rp(_p(new TextEncoder().encode(et(e))));
}
const go = Ae([
  yt,
  b([
    "provider_unknown",
    "model_override",
    "provider_policy",
    "unknown_provider_policy",
    "model_provider_conflict",
    "unsupported_workload",
    "numeric_domain_unsupported",
    "model_proxy",
    "original_engine_fallback",
    "provider_environment_assumed",
    "source_error",
    "source_warning",
    "cancelled",
    "stale_estimation_result",
    "original_method_missing"
  ])
]), On = A(go).max(96);
function vo(e, t, n) {
  return n === "original_fallback" ? e === "ecologits" && t === "original" : n === "legacy_reference" ? e === "original" && t === "original" : ["direct_mapping", "model_override", "provider_flagship"].includes(
    n
  ) ? e === "ecologits" && t === "ecologits" : n === "unavailable" && e === t;
}
const gp = Ae([
  Se,
  w({
    min: Se,
    max: Se
  }).refine(
    (e) => Number(e.min) <= Number(e.max),
    "Reversed impact interval"
  )
]);
function Ht(e, t, n) {
  return w({
    type: E(e),
    name: E(t),
    unit: E(n),
    value: gp
  });
}
const tr = Ht("energy", "Energy", "kWh"), Kn = Ht("GWP", "Global Warming Potential", "kgCO2eq"), Vn = Ht("ADPe", "Abiotic Depletion Potential (elements)", "kgSbeq"), Jn = Ht("PE", "Primary Energy", "MJ"), nr = Ht("WCF", "Water Consumption Footprint", "L"), ir = w({
  code: S().regex(/^[a-z][a-z0-9_-]{0,127}$/),
  message: S().max(1024)
}), bo = w({
  energy: tr.nullable(),
  gwp: Kn.nullable(),
  adpe: Vn.nullable(),
  pe: Jn.nullable(),
  wcf: nr.nullable(),
  usage: w({
    type: E("usage"),
    name: E("Usage"),
    energy: tr,
    gwp: Kn,
    adpe: Vn,
    pe: Jn,
    wcf: nr
  }).nullable(),
  embodied: w({
    type: E("embodied"),
    name: E("Embodied"),
    gwp: Kn,
    adpe: Vn,
    pe: Jn
  }).nullable(),
  warnings: A(ir).min(1).max(64).nullable(),
  errors: A(ir).min(1).max(64).nullable()
}).superRefine((e, t) => {
  const n = [
    e.energy,
    e.gwp,
    e.adpe,
    e.pe,
    e.wcf,
    e.usage,
    e.embodied
  ];
  (e.errors === null ? n.some((i) => i === null) : n.some((i) => i !== null)) && t.addIssue({
    code: "custom",
    message: "Inconsistent upstream outcome"
  });
}), At = w({
  value: zn.nullable(),
  unit: b(["kWh", "gCO2e", "gCO2", "L"]),
  status: b(["partial_estimate", "unavailable"]),
  scope: S(),
  scenario_low: mi(),
  scenario_high: mi(),
  reasons: A(S())
}), yo = w({
  profile_selection: b(["reference_only", "unavailable"]),
  reference_only: E(!0),
  selected_profile_id: S().nullable(),
  cohort_id: S(),
  cohort_hash: O,
  eligible_candidate_count: D().int().nonnegative(),
  result_scope: E("gpu_associated_reference"),
  starting_energy_boundary: E("gpu"),
  gpu_kwh: zn.nullable(),
  generated_image_count: C.nullable(),
  known_settings: w({
    width: D().nullable().optional(),
    height: D().nullable().optional(),
    steps: D().nullable().optional(),
    precision: S().optional(),
    kind: S().optional()
  }),
  reasons: A(S())
}), vp = w({
  schema_version: E("1.0.0"),
  attempt_id: Qe(),
  observation_revision: D().int().min(1),
  observation_hash: O,
  method_id: L,
  method_hash: O,
  view: b(["original", "recalculated"]),
  original_method_hash: O.nullable(),
  observed_model_key: S().nullable(),
  model_evidence: S(),
  profile_selection: b([
    "matched_profile",
    "highest_comparable",
    "reference_only",
    "unavailable"
  ]),
  selected_profile_id: S().nullable(),
  cohort_id: S(),
  cohort_hash: O,
  eligible_candidate_count: D().int().nonnegative(),
  eligibility_signature: O,
  environment_scenario_id: S(),
  factor_provenance_status: S(),
  starting_energy_boundary: E("it"),
  result_scope: E("modeled_text_component"),
  reference_only: ze(),
  validation_state: E("unvalidated_reference"),
  known_settings: ke(S(), S()),
  assumed_settings: ke(S(), S()),
  selection_reason: S(),
  included_components: A(S()),
  missing_components: A(S()),
  reasons: A(S()),
  metrics: w({
    energy: At,
    carbon: At,
    water_direct: At,
    water_upstream: At,
    water_total: At
  }),
  image_references: A(yo),
  provenance: ji,
  environment_provenance: mo
}), wo = w({
  quantity: b([
    "energy",
    "carbon",
    "water_direct",
    "water_upstream",
    "water_total"
  ]),
  value: zn.nullable(),
  unit: S(),
  scope: E("historical_visible_response"),
  method_id: L,
  method_hash: O,
  status: b(["partial_estimate", "unavailable"]),
  validation_state: E("unvalidated_reference"),
  profile_selection: b(["highest_comparable", "unavailable"]),
  selected_profile_id: S().nullable(),
  reasons: A(S()),
  missing_components: A(S()),
  known_message_count: C,
  unknown_message_count: C
}), bp = A(wo).max(5).refine(
  (e) => (e.length === 0 || e.length === 5) && new Set(e.map((t) => t.quantity)).size === e.length,
  "Incomplete historical result"
), Nt = w({
  value: Se.nullable(),
  unit: b(["kWh", "gCO2e", "gCO2", "L"]),
  status: b(["partial_estimate", "unavailable"]),
  scope: b([
    "modeled_text_component",
    "historical_visible_response",
    "modeled_video_component",
    "modeled_image_component",
    "modeled_speech_component"
  ]),
  phase: E("usage"),
  scenario_low: Se.nullable(),
  scenario_high: Se.nullable(),
  interval_kind: b(["upstream_approximation", "scenario"]).nullable(),
  value_kind: b(["scalar", "midpoint", "unavailable"]),
  reasons: On
}).superRefine((e, t) => {
  const n = e.value === null, i = e.scenario_low !== null && e.scenario_high !== null;
  (n !== (e.status === "unavailable") || n !== (e.value_kind === "unavailable")) && t.addIssue({
    code: "custom",
    message: "Metric availability contradicts value"
  }), (i !== (e.value_kind === "midpoint") || i !== (e.interval_kind !== null) || e.scenario_low === null != (e.scenario_high === null)) && t.addIssue({
    code: "custom",
    message: "Incomplete interval metadata"
  }), i && (Number(e.scenario_low) > Number(e.value) || Number(e.value) > Number(e.scenario_high)) && t.addIssue({
    code: "custom",
    message: "Display value outside interval"
  });
});
b(["minimum", "midpoint", "maximum"]);
const xo = w({
  energy: Nt,
  carbon: Nt,
  water_direct: Nt,
  water_upstream: Nt,
  water_total: Nt
}).superRefine((e, t) => {
  (e.energy.unit !== "kWh" || !["gCO2e", "gCO2"].includes(e.carbon.unit) || [e.water_direct, e.water_upstream, e.water_total].some(
    (n) => n.unit !== "L"
  )) && t.addIssue({
    code: "custom",
    message: "Metric has incompatible units"
  });
}), ko = "3.0.0", yp = [
  "exact_record",
  "nearest_record",
  "family_benchmark",
  "model_not_named",
  "model_not_in_library",
  "model_family_stand_in",
  "model_variant_stand_in",
  "model_kind_stand_in"
], wp = b(yp), So = w({
  kind: b([
    "legacy_reference",
    "direct_mapping",
    "model_override",
    "provider_flagship",
    "original_fallback",
    "unavailable"
  ]),
  observed_model_id: L.nullable(),
  profile: qt.nullable(),
  reason: go.nullable(),
  basis: wp.nullable()
}), Xn = Se.nullable(), xp = w({
  output_tokens: C.nullable(),
  latency_seconds: Xn,
  latency_basis: b(["measured", "history", "research_task", "modeled"]).nullable(),
  environment_provider: S().regex(/^[a-z][a-z0-9_-]{0,63}$/).nullable(),
  electricity_mix_zone: S().regex(/^[A-Z]{3}$/).nullable(),
  units: C.nullable(),
  width: D().int().min(1).max(65536).nullable(),
  height: D().int().min(1).max(65536).nullable(),
  duration_seconds: Xn,
  with_audio: ze().nullable(),
  audio_seconds: Xn,
  defaults_applied: A(b(["resolution", "duration", "audio", "length", "model"])).max(5)
}), kp = w({
  component_id: S().regex(/^[a-z][a-z_]{0,31}_[0-9]{1,3}$/),
  kind: b(["text", "image", "video", "speech"]),
  role: b([
    "main",
    "side_calls",
    "research",
    "storyboard",
    "generated_image",
    "generated_video",
    "generated_speech",
    "overview_illustrations",
    "overview_narration"
  ]),
  method_id: L,
  selection: So.nullable(),
  inputs: xp,
  raw: bo.nullable(),
  status: b(["estimated", "unavailable"]),
  metrics: xo,
  reasons: On
}).superRefine((e, t) => {
  Object.values(e.metrics).some(
    (i) => i.value !== null
  ) !== (e.status === "estimated") && t.addIssue({
    code: "custom",
    message: "Component status contradicts its metrics"
  }), e.selection !== null && ["direct_mapping", "model_override", "provider_flagship"].includes(
    e.selection.kind
  ) !== (e.selection.profile !== null) && t.addIssue({
    code: "custom",
    message: "Component selection profile mismatch"
  }), e.raw?.errors && e.status === "estimated" && t.addIssue({
    code: "custom",
    message: "Component estimate carries upstream errors"
  });
}), Sp = w({
  schema_version: E(ko),
  source: Xf,
  input_hash: O,
  auxiliary_method_hashes: w({
    image_reference: O
  }),
  requested_method: Lt,
  effective_method: Lt,
  execution_origin: b(["local", "organization"]),
  view: b(["original", "recalculated"]),
  original_method_hash: O.nullable(),
  selection: So,
  components: A(kp).max(96),
  raw: bt("engine_id", [
    w({
      engine_id: E("original"),
      result: Ae([
        vp,
        bp
      ])
    }),
    w({
      engine_id: E("ecologits"),
      result: bo
    })
  ]).nullable(),
  status: b(["estimated", "unavailable"]),
  metrics: xo,
  image_references: A(yo).max(100),
  reasons: On,
  missing_components: A(S().regex(/^[a-z][a-z0-9_]{0,127}$/)).max(64),
  validation_state: E("unvalidated_reference"),
  comparability: w({
    energy_boundary: E("facility"),
    carbon_boundary: b(["generation", "lifecycle", "unknown"]),
    carbon_accounting: b(["location", "market"]),
    water_kind: E("consumption"),
    direct_water_source: b(["freshwater", "all_source", "unknown"]),
    upstream_water_source: b(["freshwater", "all_source", "unknown"]),
    common_water_scope: b(["freshwater_consumption", "all_source_consumption"]).nullable(),
    tokenizer_profile_id: L.nullable()
  })
}).superRefine((e, t) => {
  e.requested_method.engine_id === e.effective_method.engine_id && gt(e.requested_method) !== gt(e.effective_method) && t.addIssue({
    code: "custom",
    message: "The same engine must retain its complete method identity"
  }), e.input_hash !== Ip(e) && t.addIssue({
    code: "custom",
    message: "Calculation input hash mismatch"
  }), e.image_references.some(
    (r) => r.cohort_hash !== e.auxiliary_method_hashes.image_reference
  ) && t.addIssue({
    code: "custom",
    message: "Independent image method mismatch"
  }), vo(
    e.requested_method.engine_id,
    e.effective_method.engine_id,
    e.selection.kind
  ) || t.addIssue({
    code: "custom",
    message: "Selection misattributes its engine"
  }), ["direct_mapping", "model_override", "provider_flagship"].includes(
    e.selection.kind
  ) !== (e.selection.profile !== null) && t.addIssue({
    code: "custom",
    message: "Selection profile mismatch"
  }), e.raw !== null && e.raw.engine_id !== e.effective_method.engine_id && t.addIssue({
    code: "custom",
    message: "Raw output engine mismatch"
  });
  const n = e.reasons.includes("original_method_missing");
  n && (e.view !== "recalculated" || e.source.family !== "live" || e.original_method_hash !== null) && t.addIssue({
    code: "custom",
    message: "Missing original lineage is only valid for an explicitly unrecorded live calculation"
  }), e.view === "recalculated" && e.original_method_hash === null && !n && t.addIssue({
    code: "custom",
    message: "Recalculation requires original lineage"
  }), e.status === "unavailable" && Object.values(e.metrics).some((r) => r.value !== null) && t.addIssue({
    code: "custom",
    message: "Unavailable result has a successful metric"
  });
  const i = e.components.some(
    (r) => r.status === "estimated"
  );
  e.status === "estimated" && (e.raw === null && !i || Object.values(e.metrics).every(
    (r) => r.value === null
  ) || e.raw?.engine_id === "ecologits" && e.raw.result.errors !== null && !i) && t.addIssue({
    code: "custom",
    message: "Estimated result lacks numerical evidence"
  }), (i || e.effective_method.engine_id === "ecologits") && !Ep(e.metrics, e.components) && t.addIssue({
    code: "custom",
    message: "Top-level metrics must equal the sum of the estimated components"
  }), e.effective_method.engine_id === "original" && e.components.length > 0 && t.addIssue({
    code: "custom",
    message: "The original method has no components"
  }), new Set(e.components.map((r) => r.component_id)).size !== e.components.length && t.addIssue({
    code: "custom",
    message: "Duplicate component identity"
  });
  const s = e.components.filter(
    (r) => r.role === "main"
  );
  if (e.effective_method.engine_id === "ecologits" && (s.length > 1 || et(e.raw) !== et(
    s[0]?.raw ? { engine_id: "ecologits", result: s[0].raw } : null
  )) && t.addIssue({
    code: "custom",
    message: "Raw output must be the main component's raw output"
  }), e.requested_method.engine_id !== e.effective_method.engine_id && !(e.requested_method.engine_id === "ecologits" && e.effective_method.engine_id === "original" && e.selection.kind === "original_fallback") && t.addIssue({
    code: "custom",
    message: "Unsupported engine substitution"
  }), e.raw?.engine_id === "original") {
    const r = e.raw.result;
    Array.isArray(r) ? (e.source.family !== "history" || r.some(
      (o) => o.method_hash !== e.effective_method.method_hash || o.method_id !== e.effective_method.method_id
    ) || r.length === 0 && e.status === "estimated") && t.addIssue({
      code: "custom",
      message: "Original historical result binding mismatch"
    }) : (e.source.family !== "live" || r.observation_hash !== e.source.attempt_hash || r.observation_revision !== e.source.attempt_revision || r.attempt_id !== e.source.attempt_id || r.method_hash !== e.effective_method.method_hash || r.method_id !== e.effective_method.method_id || r.observed_model_key !== e.selection.observed_model_id) && t.addIssue({
      code: "custom",
      message: "Original live result binding mismatch"
    });
  }
});
function ln(e, t) {
  if (e === null) return !1;
  const n = Number(e);
  return Math.abs(n - t) <= 1e-9 * Math.max(Math.abs(n), Math.abs(t));
}
function Ep(e, t) {
  const n = t.filter(
    (i) => i.status === "estimated"
  );
  return Object.keys(e).every((i) => {
    const s = n.map((l) => l.metrics[i]).filter((l) => l.value !== null), r = e[i];
    if (!s.length) return r.value === null;
    if (r.value_kind === "scalar")
      return !s.some((l) => l.value_kind === "midpoint") && ln(
        r.value,
        s.reduce((l, c) => l + Number(c.value), 0)
      );
    const o = s.reduce(
      (l, c) => l + Number(c.scenario_low ?? c.value),
      0
    ), a = s.reduce(
      (l, c) => l + Number(c.scenario_high ?? c.value),
      0
    );
    return r.value_kind === "midpoint" && ln(r.scenario_low, o) && ln(r.scenario_high, a) && ln(r.value, (o + a) / 2);
  });
}
function Ip(e) {
  return gt({
    schema_version: ko,
    source: e.source,
    requested_method_hash: e.requested_method.method_hash,
    effective_method_hash: e.effective_method.method_hash,
    selection: e.selection,
    auxiliary_method_hashes: e.auxiliary_method_hashes
  });
}
const zp = w({
  ...wo.shape,
  value: Se.nullable(),
  unit: b(["kWh", "gCO2e", "gCO2", "L"]),
  phase: E("usage"),
  scenario_low: Se.nullable(),
  scenario_high: Se.nullable(),
  interval_kind: b(["upstream_approximation", "scenario"]).nullable(),
  value_kind: b(["scalar", "midpoint", "midpoint_sum", "unavailable"]),
  profile_selection: b([
    "legacy_reference",
    "direct_mapping",
    "model_override",
    "provider_flagship",
    "original_fallback",
    "unavailable"
  ]),
  selected_profile_id: S().max(320).regex(/^[A-Za-z0-9][A-Za-z0-9._:/@+\-]*$/).nullable(),
  reasons: On,
  requested_method: Lt,
  effective_method: Lt,
  comparability: Sp.shape.comparability
}).superRefine((e, t) => {
  const n = (r) => t.addIssue({ code: "custom", message: r });
  e.requested_method.engine_id === e.effective_method.engine_id && gt(e.requested_method) !== gt(e.effective_method) && n(
    "The same historical engine must retain its complete method identity"
  ), vo(
    e.requested_method.engine_id,
    e.effective_method.engine_id,
    e.profile_selection
  ) || n("Historical selection misattributes its engine"), (e.method_id !== e.requested_method.method_id || e.method_hash !== e.requested_method.method_hash) && n("Historical method binding mismatch"), (e.value === null != (e.status === "unavailable") || e.value === null != (e.value_kind === "unavailable")) && n("Historical availability mismatch"), (e.profile_selection === "unavailable" && e.selected_profile_id !== null || e.value !== null && e.selected_profile_id === null) && n("Historical profile mismatch");
  const i = e.scenario_low !== null && e.scenario_high !== null, s = e.value_kind === "midpoint" || e.value_kind === "midpoint_sum";
  (e.scenario_low === null != (e.scenario_high === null) || e.value_kind === "midpoint" && (!i || e.interval_kind === null) || e.value_kind === "midpoint_sum" && e.interval_kind !== null || !s && (i || e.interval_kind !== null)) && n("Historical interval metadata mismatch"), i && (Number(e.scenario_low) > Number(e.value) || Number(e.value) > Number(e.scenario_high)) && n("Historical value outside interval"), (e.quantity === "energy" ? e.unit !== "kWh" : e.quantity === "carbon" ? !["gCO2e", "gCO2"].includes(e.unit) : e.unit !== "L") && n("Historical quantity unit mismatch"), e.requested_method.engine_id !== e.effective_method.engine_id && !(e.requested_method.engine_id === "ecologits" && e.effective_method.engine_id === "original" && e.profile_selection === "original_fallback") && n("Historical engine substitution mismatch");
}), Tp = [
  "chatgpt-latest",
  "chatgpt-gpt-5-6-sol",
  "chatgpt-gpt-5-5",
  "chatgpt-gpt-5-6-luna",
  "chatgpt-gpt-5-6-sol-pro",
  "chatgpt-gpt-6-pro",
  "chatgpt-reasoning-effort",
  "chatgpt-pro-option",
  "chatgpt-think",
  "chatgpt-images-2-5",
  "chatgpt-images-thinking",
  "chatgpt-gpt-live-1",
  "chatgpt-gpt-live-1-mini",
  "chatgpt-voice-live",
  "chatgpt-voice-advanced",
  "chatgpt-voice-standard",
  "chatgpt-gpt-6-1-sol",
  "chatgpt-gpt-6-sol",
  "chatgpt-gpt-6-luna",
  "chatgpt-gpt-6-astra",
  "chatgpt-gpt-6-1-sol-pro",
  "chatgpt-gpt-6-sol-pro",
  "chatgpt-gpt-6-luna-pro",
  "chatgpt-gpt-5-6-luna-pro",
  "chatgpt-gpt-5-6-terra-pro",
  "chatgpt-gpt-5-6-terra",
  "chatgpt-gpt-5-5-pro",
  "chatgpt-gpt-5-5-mini",
  "chatgpt-gpt-5-4",
  "chatgpt-gpt-5-4-pro",
  "chatgpt-gpt-5-4-mini",
  "chatgpt-gpt-5-3-mini",
  "chatgpt-gpt-5-2",
  "chatgpt-gpt-5-2-pro",
  "chatgpt-gpt-5-1",
  "chatgpt-gpt-5",
  "chatgpt-gpt-5-mini",
  "chatgpt-gpt-5-pro",
  "chatgpt-gpt-4-1",
  "chatgpt-gpt-4-1-mini",
  "chatgpt-gpt-4o",
  "chatgpt-gpt-4o-mini",
  "chatgpt-gpt-4",
  "chatgpt-gpt-3-5",
  "chatgpt-o4-mini",
  "chatgpt-o3",
  "chatgpt-o3-pro",
  "chatgpt-o3-mini",
  "chatgpt-o1",
  "chatgpt-voice-bidi",
  "chatgpt-deep-research",
  "chatgpt-agent",
  "chatgpt-unlisted",
  "chatgpt-gpt-sol-unlisted",
  "chatgpt-gpt-astra-unlisted",
  "chatgpt-gpt-luna-unlisted",
  "chatgpt-gpt-terra-unlisted",
  "chatgpt-gpt-pro-unlisted",
  "chatgpt-gpt-mini-unlisted",
  "chatgpt-gpt-nano-unlisted",
  "chatgpt-gpt-codex-unlisted",
  "chatgpt-gpt-sol-pro-unlisted",
  "chatgpt-gpt-astra-pro-unlisted",
  "chatgpt-gpt-luna-pro-unlisted",
  "chatgpt-gpt-terra-pro-unlisted",
  "claude-fable-5-1",
  "claude-opus-5",
  "claude-sonnet-5",
  "claude-haiku-4-5",
  "claude-fable-5",
  "claude-opus-4-8",
  "claude-opus-4-7",
  "claude-opus-4-6",
  "claude-opus-3",
  "claude-sonnet-4-6",
  "claude-effort",
  "claude-thinking",
  "claude-opus-5-5",
  "claude-sonnet-5-5",
  "claude-opus-4-5",
  "claude-sonnet-4-5",
  "claude-opus-4-1",
  "claude-opus-4",
  "claude-sonnet-4",
  "claude-sonnet-3-7",
  "claude-sonnet-3-5",
  "claude-haiku-3-5",
  "claude-haiku-3",
  "claude-unlisted",
  "claude-haiku-unlisted",
  "claude-sonnet-unlisted",
  "claude-opus-unlisted",
  "claude-fable-unlisted",
  "claude-small-unlisted",
  "gemini-3-6-flash",
  "gemini-3-6-thinking",
  "gemini-3-1-pro",
  "gemini-public-flash-lite",
  "gemini-public-flash",
  "gemini-public-pro",
  "gemini-thinking-level",
  "gemini-deep-think",
  "gemini-deep-research",
  "gemini-nano-banana-2-lite",
  "gemini-nano-banana-2",
  "gemini-nano-banana-pro",
  "gemini-omni",
  "gemini-lyria",
  "gemini-3-8-flash",
  "gemini-3-7-flash",
  "gemini-3-5-flash",
  "gemini-3-5-flash-lite",
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-2-5-flash",
  "gemini-2-5-flash-lite",
  "gemini-2-5-pro",
  "gemini-nano-banana",
  "gemini-omni-video",
  "gemini-unnamed",
  "gemini-unlisted",
  "gemini-flash-unlisted",
  "gemini-flash-lite-unlisted",
  "gemini-pro-unlisted",
  "gemini-pro-image-unlisted",
  "gemini-flash-image-unlisted",
  "gemini-image-unlisted",
  "perplexity-best",
  "perplexity-sonar-2",
  "perplexity-gpt-5-6-terra",
  "perplexity-gpt-5-6-sol",
  "perplexity-gemini-3-8-flash",
  "perplexity-claude-sonnet-5",
  "perplexity-claude-opus-5",
  "perplexity-kimi-k3",
  "perplexity-glm-5-3",
  "perplexity-grok-4-6",
  "perplexity-nemotron-3-ultra",
  "perplexity-gemini-3-7-flash",
  "perplexity-thinking",
  "perplexity-search",
  "perplexity-deep-research",
  "perplexity-learn",
  "perplexity-council",
  "perplexity-computer",
  "perplexity-comet",
  "perplexity-image-default",
  "perplexity-gpt-image-1",
  "perplexity-nano-banana",
  "perplexity-nano-banana-pro",
  "perplexity-seedream-4-5",
  "perplexity-veo-3-1",
  "perplexity-gpt-6-1-sol",
  "perplexity-gpt-6-sol",
  "perplexity-gpt-6-astra",
  "perplexity-gpt-6-1-sol-pro",
  "perplexity-gpt-6-sol-pro",
  "perplexity-gpt-6-astra-pro",
  "perplexity-gpt-5-6-sol-pro",
  "perplexity-gpt-5-6-terra-pro",
  "perplexity-gpt-5-5",
  "perplexity-gpt-5-4",
  "perplexity-gpt-5-2",
  "perplexity-gpt-5-2-pro",
  "perplexity-gpt-5-1",
  "perplexity-gpt-5",
  "perplexity-gpt-5-mini",
  "perplexity-gpt-5-nano",
  "perplexity-gpt-5-pro",
  "perplexity-gpt-4-1",
  "perplexity-gpt-4o",
  "perplexity-o4-mini",
  "perplexity-o3-pro",
  "perplexity-claude-fable-5-1",
  "perplexity-claude-opus-5-5",
  "perplexity-claude-sonnet-5-5",
  "perplexity-claude-opus-4-8",
  "perplexity-claude-opus-4-7",
  "perplexity-claude-opus-4-6",
  "perplexity-claude-opus-4-5",
  "perplexity-claude-opus-4-1",
  "perplexity-claude-opus-4",
  "perplexity-claude-sonnet-4-6",
  "perplexity-claude-sonnet-4-5",
  "perplexity-claude-sonnet-4",
  "perplexity-claude-haiku-4-5",
  "perplexity-gemini-3-5-flash",
  "perplexity-gemini-3-1-pro",
  "perplexity-gemini-3-flash",
  "perplexity-gemini-3-pro",
  "perplexity-gemini-2-5-pro",
  "perplexity-glm-5-2",
  "perplexity-deepseek",
  "perplexity-qwen",
  "perplexity-kimi",
  "perplexity-grok",
  "perplexity-nemotron",
  "perplexity-agentic-research",
  "perplexity-create-files",
  "perplexity-study",
  "perplexity-nano-banana-2",
  "perplexity-veo-3-1-fast",
  "perplexity-veo-3-0",
  "perplexity-veo-3-0-fast",
  "perplexity-sora-2-pro",
  "perplexity-video-unlisted",
  "perplexity-unlisted",
  "perplexity-unlisted-anthropic",
  "perplexity-unlisted-google",
  "perplexity-claude-haiku-unlisted",
  "perplexity-claude-sonnet-unlisted",
  "perplexity-claude-opus-unlisted",
  "perplexity-claude-fable-unlisted",
  "perplexity-gpt-sol-unlisted",
  "perplexity-gpt-astra-unlisted",
  "perplexity-gpt-luna-unlisted",
  "perplexity-gpt-terra-unlisted",
  "perplexity-gemini-flash-unlisted",
  "perplexity-gemini-flash-lite-unlisted",
  "perplexity-gemini-pro-unlisted",
  "perplexity-claude-small-unlisted",
  "perplexity-gpt-pro-unlisted",
  "perplexity-gpt-mini-unlisted",
  "perplexity-gpt-nano-unlisted",
  "perplexity-gpt-codex-unlisted",
  "perplexity-gpt-sol-pro-unlisted",
  "perplexity-gpt-astra-pro-unlisted",
  "perplexity-gpt-luna-pro-unlisted",
  "perplexity-gpt-terra-pro-unlisted",
  "perplexity-gemini-pro-image-unlisted",
  "perplexity-gemini-flash-image-unlisted",
  "perplexity-gemini-image-unlisted",
  "notebooklm-default",
  "notebooklm-image"
], Op = w({
  namespace: S().min(1).max(256),
  mode: b(["personal", "company"]),
  era: S().max(256).nullable()
});
w({
  preference: Tn,
  expectedRevision: D().int().min(1).max(2147483647).nullable()
});
w({
  schema_version: E("1.0.0"),
  scope: Op,
  scopeToken: S().min(1).max(256),
  preference: Tn.nullable(),
  selectionRevision: D().int().min(1).max(2147483647).nullable(),
  buildDefault: wn,
  effectiveEngine: wn.nullable(),
  method: Lt.nullable(),
  local: w({
    status: b(["idle", "running", "complete", "pending", "failed"]),
    jobId: S().max(128).nullable(),
    processed: D().int().nonnegative(),
    unavailable: D().int().nonnegative(),
    pending: D().int().nonnegative()
  }),
  organization: w({
    status: b([
      "personal",
      "current",
      "pending",
      "unavailable",
      "invalidated"
    ]),
    reason: b([
      "sync_delayed",
      "method_unsupported",
      "deletion_changed",
      "auth_reconnect_required",
      "policy_unavailable"
    ]).nullable()
  }),
  reason: b([
    "invalid_preference",
    "engine_unavailable",
    "selection_conflict",
    "storage_write_failed",
    "estimate_unavailable",
    "policy_unavailable"
  ]).nullable()
});
const Ap = w({
  preference: Tn,
  selection_revision: D().int().min(1).max(2147483647),
  method_id: L,
  method_hash: O,
  operation_id: Qe()
});
w({
  selection: Ap.extend({
    selection_generation: D().int().min(1),
    job_id: O,
    updated_at: _e
  }).nullable(),
  compatibility: w({
    status: b(["supported", "pending"]),
    reason: b([
      "method_unsupported",
      "method_hash_mismatch",
      "engine_mismatch",
      "engine_unavailable"
    ]).nullable()
  }).nullable(),
  recalculation: Ae([
    w({
      job_id: O,
      status: E("invalidated"),
      completed_at: mi(),
      error_code: E("deletion_changed")
    }),
    w({
      job_id: O,
      method_id: L,
      calculation_view: E("recalculated"),
      status: b([
        "pending",
        "completed",
        "failed",
        "invalidated",
        "superseded"
      ]),
      processed_estimates: D().int().nonnegative(),
      created_at: _e,
      completed_at: _e.nullable(),
      error_code: S().regex(/^[a-z][a-z0-9_]{0,127}$/).nullable(),
      requires_advance: E(!1),
      selection_revision: D().int().min(1),
      selection_generation: D().int().min(1)
    })
  ]).nullable()
}).superRefine((e, t) => {
  (e.selection === null ? e.compatibility !== null || e.recalculation !== null : e.compatibility === null || e.recalculation === null) && t.addIssue({
    code: "custom",
    message: "Incomplete organization selection"
  }), e.selection && e.recalculation && (e.selection.job_id !== e.recalculation.job_id || "method_id" in e.recalculation && (e.recalculation.method_id !== e.selection.method_id || e.recalculation.selection_revision !== e.selection.selection_revision || e.recalculation.selection_generation !== e.selection.selection_generation)) && t.addIssue({
    code: "custom",
    message: "Organization selection binding mismatch"
  });
});
const Ui = O.nullable(), Wt = "3.0.0", An = A(yt).max(32).refine((e) => new Set(e).size === e.length, "Duplicate reasons"), Eo = E("0.1.0"), Np = [
  "chatgpt",
  "claude",
  "gemini",
  "perplexity",
  "notebooklm"
], Bi = b(Np), tt = b(Tp).nullable(), Nn = b([
  "response_field",
  "request_field",
  "ui_selection",
  "unknown"
]), Ut = Qe(), Io = D().int().min(1).max(2147483647), Cp = [
  "o200k-base-4.0.0-reference",
  "cl100k-base-4.0.0-reference",
  "observed-text-v1",
  // Uploaded image tokens from each vendor's published rule (A7), not a text tokenizer.
  "vendor-image-rules-1"
], Kt = b(Cp).nullable(), $p = [
  "browser_request",
  "chatgpt_history",
  "claude_history",
  "perplexity_history",
  "gemini_history",
  "cowork_history",
  "notebooklm_history"
], Dp = Object.freeze({
  browser_request: ["request"],
  chatgpt_history: ["provider_message", "research_task"],
  claude_history: ["content_blocks", "research_task"],
  perplexity_history: ["workflow"],
  gemini_history: ["research_task"],
  cowork_history: ["provider_message"],
  notebooklm_history: ["provider_message"]
}), qi = w({
  duration_seconds: Ri.refine((e) => {
    const t = Number(e);
    if (!(t > 0 && t <= 86400)) return !1;
    const n = /^(0|[1-9][0-9]*)(?:\.([0-9]+))?(?:e([+-]?[0-9]{1,3}))?$/.exec(e);
    if (!n) return !1;
    const i = BigInt(n[1] + (n[2] ?? "")), s = Number(n[3] ?? 0) - (n[2]?.length ?? 0);
    return s >= 0 ? i * 10n ** BigInt(s) <= 86400n : i <= 86400n * 10n ** BigInt(-s);
  }, "Timing duration must be greater than zero and at most one day"),
  source: b($p),
  scope: b([
    "request",
    "provider_message",
    "content_blocks",
    "workflow",
    "research_task"
  ]),
  completeness: b(["complete_for_scope", "partial", "unknown"]),
  profile_version: E("timing-observation-1")
}).superRefine((e, t) => {
  Dp[e.source].includes(e.scope) || t.addIssue({
    code: "custom",
    path: ["scope"],
    message: "Timing source and scope do not match"
  });
});
function Fp(e) {
  return e === "claude" ? ["claude_history", "cowork_history"] : [`${e}_history`];
}
const ge = w({
  value: C.nullable(),
  evidence: b([
    "provider_reported",
    "official_tokenizer",
    "calibrated_estimate",
    "heuristic_estimate",
    "unknown",
    "not_applicable"
  ]),
  scope: b([
    "provider_request",
    "observed_text",
    "reconstructed_context",
    "provider_defined_subset"
  ]),
  completeness: b(["complete_for_scope", "partial", "unknown"]),
  profile_id: Kt,
  reason: yt.nullable()
}).superRefine((e, t) => {
  (e.evidence === "unknown" || e.evidence === "not_applicable") && (e.value !== null || e.reason === null) && t.addIssue({
    code: "custom",
    message: "Unknown or inapplicable measurements require null and a reason"
  }), e.value === null && e.reason === null && t.addIssue({
    code: "custom",
    message: "Missing quantity requires a reason"
  }), e.value !== null && e.evidence === "calibrated_estimate" && t.addIssue({
    code: "custom",
    message: "No calibrated tokenizer profiles are approved"
  });
}), Pp = [
  "new_input_text",
  "logical_input_total",
  "input_uncached",
  "input_cache_read",
  "input_cache_write",
  "answer_output",
  "visible_thinking",
  "reported_reasoning",
  "output_total",
  "tool_input",
  "intermediate_output",
  "tool_output",
  "image_input_tokens",
  "image_output_tokens"
], Hi = [
  "answer_output",
  "visible_thinking",
  "tool_input",
  "intermediate_output"
], Rp = [
  ...Hi,
  "reported_reasoning",
  "tool_output",
  "image_input_tokens"
], sr = [
  "visible_thinking",
  "tool_input",
  "intermediate_output",
  "tool_output"
], Zp = w(
  Object.fromEntries(
    Pp.map((e) => [e, ge])
  )
);
function zo(e = "provider_usage_unavailable") {
  return {
    value: null,
    evidence: "unknown",
    scope: "observed_text",
    completeness: "unknown",
    profile_id: null,
    reason: e
  };
}
function Mp(e) {
  const t = Hi.map((a) => e[a]), n = t.filter((a) => a.value !== null), i = t.filter(
    (a) => a.value === null && a.evidence !== "not_applicable"
  );
  if (!n.length)
    return zo(
      i[0]?.reason ?? e.answer_output.reason ?? "estimate_unavailable"
    );
  const s = new Set(n.map((a) => a.profile_id)), r = new Set(n.map((a) => a.evidence)), o = i.length > 0 || n.some(
    (a) => a.completeness !== "complete_for_scope"
  ) || s.size > 1 || r.size > 1;
  return {
    value: n.reduce((a, l) => a + BigInt(l.value), 0n).toString(),
    evidence: r.size === 1 ? [...r][0] : "heuristic_estimate",
    scope: "observed_text",
    completeness: o ? "partial" : "complete_for_scope",
    profile_id: s.size === 1 ? [...s][0] : null,
    reason: o ? i[0]?.reason ?? n.find(
      (a) => a.completeness !== "complete_for_scope"
    )?.reason ?? "partial_capture" : n[0].reason ?? null
  };
}
const To = (e, t) => et(e) === et(Mp(t)), Me = D().int().min(1).max(65536).nullable(), Wi = w({
  width: Me,
  height: Me,
  steps: D().int().min(1).max(1e4).nullable(),
  precision: b(["bfloat16", "float16", "float32", "unknown"]),
  architecture: b(["diffusion", "autoregressive", "unknown"])
}), Oo = {
  width: Me,
  height: Me,
  dimension_source: b([
    "original",
    "provider_resized",
    "thumbnail_only",
    "unknown"
  ])
}, Ao = b([
  "text_to_image",
  "image_edit",
  "inpaint",
  "upscale",
  "unknown"
]), jp = b([
  "requested",
  "generating",
  "completed",
  "cancelled",
  "failed",
  "interrupted_unconfirmed"
]), Lp = w({
  count: C,
  origin: b(["new_upload", "retained_context", "unknown_origin"]),
  ...Oo,
  detail: b(["low", "high", "auto", "unknown"]),
  token_profile_id: Kt,
  tokens: ge
}), Up = w({
  operation_key: O,
  kind: Ao,
  requested_count: C.nullable(),
  settings: Wi
}), Bp = w({
  operation_key: O,
  kind: Ao,
  requested_count: C.nullable(),
  returned_count: C.nullable(),
  state: jp,
  execution_evidence: b([
    "none",
    "provider_started",
    "content_observed",
    "usage_reported"
  ]),
  settings: Wi,
  model_id: tt,
  model_evidence: Nn
}), qp = w({
  operation_key: O,
  count: C,
  ...Oo,
  settings: Wi
}), Hp = w({
  input_images: A(Lp).max(100),
  requested_operations: A(Up).max(100),
  coverage_reasons: An
}).refine(
  (e) => e.input_images.length + e.requested_operations.length <= 100,
  "Media entry limit"
).refine(
  (e) => new Set(e.requested_operations.map((t) => t.operation_key)).size === e.requested_operations.length,
  "Duplicate operation"
), Wp = w({
  image_operations: A(Bp).max(100),
  generated_images: A(qp).max(100),
  coverage_reasons: An
}).superRefine((e, t) => {
  e.image_operations.length + e.generated_images.length > 100 && t.addIssue({ code: "custom", message: "Media entry limit" }), new Set(e.image_operations.map((n) => n.operation_key)).size !== e.image_operations.length && t.addIssue({ code: "custom", message: "Duplicate operation" });
  for (const n of e.generated_images)
    e.image_operations.some((i) => i.operation_key === n.operation_key) || t.addIssue({
      code: "custom",
      message: "Generated image requires operation"
    });
  for (const n of e.image_operations) {
    const i = e.generated_images.filter(
      (s) => s.operation_key === n.operation_key
    );
    n.returned_count !== null && C.safeParse(n.returned_count).success && i.every((s) => C.safeParse(s.count).success) && i.reduce((r, o) => r + BigInt(o.count), 0n) > BigInt(n.returned_count) && t.addIssue({
      code: "custom",
      message: "Grouped outputs exceed returned count"
    });
  }
}), Gn = Ri.refine((e) => {
  const t = Number(e);
  return t > 0 && t <= 86400;
}, "Media length must be greater than zero and at most one day"), Kp = w({
  role: b(["side_calls", "research", "storyboard"]),
  model_id: tt,
  model_evidence: Nn,
  tokens: ge,
  timing: qi.nullable()
}), Vp = bt("kind", [
  w({
    kind: E("image"),
    model_id: tt,
    count: C,
    width: Me,
    height: Me,
    // A stopped or failed job counts as one image only when generation visibly started.
    outcome: b(["returned", "started_not_returned"])
  }),
  w({
    kind: E("video"),
    model_id: tt,
    width: Me,
    height: Me,
    duration_seconds: Gn.nullable(),
    with_audio: ze().nullable()
  }),
  w({
    kind: E("speech"),
    length_basis: b(["audio_frames", "stored_length", "characters"]),
    seconds: Gn.nullable(),
    characters: C.nullable()
  }),
  w({
    kind: E("video_overview"),
    duration_seconds: Gn
  })
]), No = w({
  text_components: A(Kp).max(16),
  media: A(Vp).max(64)
}).superRefine((e, t) => {
  for (const [n, i] of e.media.entries())
    i.kind === "speech" && (i.length_basis === "characters" ? i.characters === null || i.characters === "0" || i.seconds !== null : i.seconds === null || i.characters !== null) && t.addIssue({
      code: "custom",
      path: ["media", n],
      message: "Speech length must match its basis"
    }), i.kind === "image" && (i.count === "0" || i.outcome === "started_not_returned" && i.count !== "1") && t.addIssue({
      code: "custom",
      path: ["media", n],
      message: "Image entries need a positive count; a started job is one image"
    });
}), Jp = [
  "local-file-text-utf8-pdfjs6.3.289-opc-v1",
  "observed-inline-file-text-v1"
], Co = b(Jp), $o = [
  "provider_processing",
  "ocr",
  "image_encoding",
  "retrieval_selection",
  "layout_and_drawing_text",
  "rendered_visibility",
  "formula_recalculation",
  "external_font_mapping"
], Do = b($o), Xp = w({
  ...ge.shape,
  scope: E("extracted_file_text"),
  evidence: b(["heuristic_estimate", "unknown"])
}).superRefine((e, t) => {
  e.value === null && (e.reason === null || e.evidence !== "unknown" || e.completeness !== "unknown") && t.addIssue({
    code: "custom",
    message: "Missing file text requires unknown evidence and a reason"
  }), e.value !== null && (e.evidence !== "heuristic_estimate" || e.profile_id === null || e.completeness === "unknown" || e.reason === null) && t.addIssue({
    code: "custom",
    message: "Known file text requires an approved profile and scoped evidence"
  });
}), Ki = w({
  component_id: S().regex(
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/
  ),
  origin: b(["new_upload", "retained_context", "unknown_origin"]),
  extraction_profile_id: Co,
  page_count: D().int().min(0).max(200).nullable(),
  tokens: Xp,
  missing: A(Do).min(1).max($o.length).refine(
    (e) => new Set(e).size === e.length && e.includes("provider_processing"),
    "Local extraction does not establish provider processing"
  )
}), Gp = w({
  schema_version: E(Wt),
  kind: E("request"),
  request_id: Ut,
  revision: Io,
  conversation_key: O,
  key_version: E("1"),
  provider_request_key: O.nullable(),
  site: Bi,
  adapter_version: Eo,
  // `read_aloud` is speech made from a reply already shown (ChatGPT, G1) and
  // `notebook_guide` a NotebookLM guide the page asks for itself (W9).
  // Neither has a prompt: they add energy, never a request (see countsAsRequest).
  action: b([
    "send",
    "regenerate",
    "continue",
    "edit_and_send",
    "read_aloud",
    "notebook_guide"
  ]),
  dispatched_at: _e,
  ended_at: _e.nullable(),
  state: b([
    "dispatched",
    "generating",
    "completed",
    "cancelled",
    "failed",
    "interrupted_unconfirmed"
  ]),
  model_id: tt,
  model_evidence: Nn,
  features: A(
    b([
      "text",
      "thinking",
      "search",
      "document",
      "image_input",
      "image_generation",
      "image_edit",
      "audio",
      "video",
      "other_tool"
    ])
  ).max(10).refine((e) => new Set(e).size === e.length),
  observed_search_operations: C.nullable(),
  documents: w({
    extracted_text: A(Ki).max(100).nullable(),
    upload_count: C.nullable(),
    types: A(
      b([
        "text_pdf",
        "scanned_pdf",
        "text",
        "office",
        "other",
        "unknown"
      ])
    ).max(6).refine((e) => new Set(e).size === e.length),
    processing: b([
      "observed_text",
      "opaque",
      "mixed",
      "none",
      "unknown"
    ])
  }),
  media: Hp,
  coverage_reasons: An,
  policy_version: S().regex(/^(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})$/),
  company_dedup_key: Ui
}).superRefine((e, t) => {
  e.coverage_reasons.includes("historical_timing_conflict") && t.addIssue({
    code: "custom",
    message: "Historical timing conflicts require a historical response"
  }), e.coverage_reasons.includes("no_live_request") && t.addIssue({
    code: "custom",
    message: "Only saved history rows can lack a live request"
  }), e.company_dedup_key !== null && t.addIssue({
    code: "custom",
    path: ["company_dedup_key"],
    message: "The company key travels beside the record"
  }), e.ended_at !== null && e.ended_at < e.dispatched_at && t.addIssue({ code: "custom", message: "End precedes dispatch" }), e.action === "read_aloud" && (e.site !== "chatgpt" || e.features.length !== 1 || e.features[0] !== "audio" || e.documents.upload_count !== null && e.documents.upload_count !== "0" || e.documents.types.length > 0 || e.documents.extracted_text !== null || !["none", "unknown"].includes(e.documents.processing) || e.media.input_images.length > 0 || e.media.requested_operations.length > 0 || e.observed_search_operations !== null && e.observed_search_operations !== "0") && t.addIssue({
    code: "custom",
    message: "Read aloud is ChatGPT audio only"
  }), e.action === "notebook_guide" && (e.site !== "notebooklm" || e.features.length !== 1 || e.features[0] !== "text" || e.documents.upload_count !== null && e.documents.upload_count !== "0" || e.documents.types.length > 0 || e.documents.extracted_text !== null || !["none", "unknown"].includes(e.documents.processing) || e.media.input_images.length > 0 || e.media.requested_operations.length > 0 || e.observed_search_operations !== null && e.observed_search_operations !== "0") && t.addIssue({
    code: "custom",
    message: "A notebook guide is NotebookLM text only"
  });
  const n = e.documents.extracted_text ?? [];
  new Set(n.map((i) => i.component_id)).size !== n.length && t.addIssue({
    code: "custom",
    message: "Duplicate file component identity"
  }), e.documents.upload_count !== null && C.safeParse(e.documents.upload_count).success && BigInt(n.filter((i) => i.origin === "new_upload").length) > BigInt(e.documents.upload_count) && t.addIssue({
    code: "custom",
    message: "New file components exceed observed uploads"
  }), n.length + e.media.input_images.length + e.media.requested_operations.length > 100 && t.addIssue({
    code: "custom",
    message: "Combined media metadata limit exceeded"
  });
}), Yp = w({
  schema_version: E(Wt),
  kind: E("attempt"),
  attempt_id: Ut,
  request_id: Ut,
  revision: Io,
  provider_attempt_key: O.nullable(),
  key_version: E("1"),
  started_at: _e,
  ended_at: _e.nullable(),
  state: b([
    "dispatch_only",
    "generating",
    "completed",
    "cancelled",
    "failed",
    "interrupted_unconfirmed"
  ]),
  execution_evidence: b([
    "none",
    "provider_started",
    "content_observed",
    "usage_reported"
  ]),
  model_id: tt,
  model_evidence: Nn,
  tokens: Zp,
  timing: qi.nullable(),
  media: Wp,
  generation: No,
  coverage_reasons: An,
  tokenizer_profile_id: Kt,
  tokenizer_asset_hash: O.nullable(),
  proposed_method_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/).nullable(),
  company_dedup_key: Ui
}).refine(
  (e) => !e.coverage_reasons.includes("historical_timing_conflict"),
  "Historical timing conflicts require a historical response"
).refine(
  (e) => !e.coverage_reasons.includes("no_live_request"),
  "Only saved history rows can lack a live request"
).refine(
  (e) => e.company_dedup_key === null,
  "The company key travels beside the record"
).refine(
  (e) => To(e.tokens.output_total, e.tokens) || e.tokens.output_total.evidence === "provider_reported" && e.tokens.output_total.scope === "provider_request" && e.tokens.output_total.value !== null,
  "Output total must equal its parts unless the provider reports it for the request"
).refine(
  (e) => e.ended_at === null || e.ended_at >= e.started_at,
  "End precedes start"
).refine(
  (e) => e.timing === null || e.timing.source === "browser_request",
  "Live attempts require browser timing"
).refine(
  (e) => e.timing?.completeness !== "complete_for_scope" || e.state === "completed",
  "Complete live timing requires a completed attempt"
), Qp = Ae([
  Gp,
  Yp
]), eh = w({
  kind: b(["request", "attempt"]),
  record_id: Ut,
  company_dedup_key: O
});
w({
  schema_version: E(Wt),
  batch_id: Ut,
  sent_at: _e,
  client_version: Eo,
  deletion_epoch: D().int().min(0).max(Number.MAX_SAFE_INTEGER),
  records: A(Qp).min(1).max(100),
  // Left out when no record has a key, so a server without company keys accepts it.
  company_dedup_keys: A(eh).max(100).optional()
}).superRefine((e, t) => {
  if (!e.company_dedup_keys) return;
  const n = new Set(
    e.records.map(
      (s) => s.kind === "request" ? `request:${s.request_id}` : `attempt:${s.attempt_id}`
    )
  ), i = e.company_dedup_keys.map((s) => `${s.kind}:${s.record_id}`);
  (new Set(i).size !== i.length || i.some((s) => !n.has(s))) && t.addIssue({
    code: "custom",
    path: ["company_dedup_keys"],
    message: "Each company key names one record of the batch"
  });
});
const rr = {
  historical_timing_conflict: [
    "Historical timing is uncertain. Valid message and token counts are retained.",
    "No action is required. Estimates use valid live timing when available, otherwise modeled timing."
  ],
  storage_write_failed: [
    "This activity could not be saved.",
    "Check browser storage and retry. Keep this tab open while recording recovers."
  ],
  ledger_integrity_failed: [
    "Some saved records need repair.",
    "Open tracking details. Affected totals remain unavailable until the records reconcile."
  ],
  tokenizer_unavailable: [
    "The request was recorded, but text counting failed.",
    "Reload the extension to restart its local counting worker."
  ],
  tokenizer_mapping_unverified: [
    "This text count uses an approximate model mapping.",
    "Read the counting scope in Details."
  ],
  sync_delayed: [
    "Saved activity is waiting to sync.",
    "Check the company connection; pending records will retry automatically."
  ],
  auth_reconnect_required: [
    "Your company connection needs renewal.",
    "Open Company and connect again with your work email."
  ],
  protocol_unsupported: [
    "This provider response is not supported by the current parser.",
    "Update the extension. Independently recorded activity remains available."
  ],
  estimate_unavailable: [
    "Resources are unavailable for part of this activity.",
    "Read the missing components in Details."
  ],
  method_update_invalid: [
    "The calculation update could not be verified.",
    "Keep the current valid method and contact the deployment operator."
  ],
  revision_conflict: [
    "Two versions of this record conflict.",
    "Keep the record in the reconciliation queue; do not create a replacement identity."
  ],
  capture_limit_exceeded: [
    "The measurement limit was reached. Your AI request continues.",
    "The recorded subtotal remains partial; review its coverage in Details."
  ],
  retention_expired: [
    "These company records are outside the retention period.",
    "Remove the expired local records after applying the server receipt."
  ],
  host_interference_detected: [
    "On-page measurement has stopped to preserve the AI tool.",
    "Reload the page and inspect the extension diagnostic."
  ],
  factor_incompatible: [
    "The available environmental factors cover different scopes.",
    "Show the supported components separately."
  ],
  payload_rejected: [
    "This numerical record does not match the accepted contract.",
    "Keep it quarantined and update the extension before retrying."
  ]
};
Object.freeze(
  Object.fromEntries(
    _o.map((e) => [
      e,
      Object.freeze({
        code: e,
        retryable: [
          "sync_delayed",
          "dependency_missing",
          "estimate_pending",
          "tokenizer_timeout",
          "storage_write_failed"
        ].includes(e),
        safe_message: rr[e]?.[0] ?? "This component has limited or unavailable coverage.",
        safe_action: rr[e]?.[1] ?? "Open Details for the affected scope and its recorded reason."
      })
    ])
  )
);
const Fo = Wt, th = S().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3,6}Z$/).refine((e) => {
  const t = e.replace(/(\.\d{3})\d*Z$/, "$1Z");
  return Number.isFinite(Date.parse(t)) && new Date(t).toISOString() === t;
}, "Invalid history date"), nh = w(
  Object.fromEntries(
    Rp.map((e) => [e, ge])
  )
);
function ih(e, t) {
  return e.evidence === "provider_reported" ? t === "response" && e.scope === "provider_request" && e.value !== null : e.scope === "observed_text" && (e.value === null ? e.evidence === "unknown" : e.evidence === "heuristic_estimate" && e.profile_id !== null);
}
function sh(e, t, n) {
  return n === "prompt" ? [...Hi, "reported_reasoning", "tool_output"].every((i) => t[i].evidence === "not_applicable") : t.image_input_tokens.evidence !== "not_applicable" ? !1 : e.evidence === "provider_reported" ? !0 : To(e, t);
}
const rh = w({
  schema_version: E(Fo),
  kind: E("history_message"),
  message_key: O,
  role: b(["prompt", "response"]),
  conversation_key: O,
  key_version: E("1"),
  site: Bi,
  parent_key: O.nullable(),
  prompt_key: O.nullable(),
  provider_request_key: O.nullable(),
  provider_attempt_key: O.nullable(),
  occurred_at: th.nullable(),
  date_basis: b([
    "message_created",
    "entry_created",
    "turn_created",
    "unknown"
  ]),
  observed_at: _e,
  proposed_method_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/),
  proposed_method_hash: O,
  model_id: tt,
  tokens: ge,
  parts: nh.nullable(),
  generation: No,
  inline_file_text: A(Ki.omit({ component_id: !0 })).max(16).nullable(),
  timing: qi.nullable(),
  text_complete: ze(),
  coverage_reasons: A(yt).max(33).refine(
    (e) => new Set(e).size === e.length && (e.length <= 32 || e.includes("historical_timing_conflict")),
    "Historical timing conflict reserves one additional reason slot"
  ),
  company_dedup_key: Ui
}).superRefine((e, t) => {
  e.company_dedup_key !== null && t.addIssue({
    code: "custom",
    path: ["company_dedup_key"],
    message: "The company key travels beside the message"
  }), e.coverage_reasons.includes("no_live_request") && e.site !== "notebooklm" && t.addIssue({
    code: "custom",
    path: ["coverage_reasons"],
    message: "Only NotebookLM Studio rows lack a live request"
  }), e.coverage_reasons.includes("historical_timing_conflict") && (e.role !== "response" || e.timing !== null) && t.addIssue({
    code: "custom",
    path: ["timing"],
    message: "Conflicting historical response timing must be unavailable"
  }), e.timing !== null && (e.role !== "response" || !Fp(e.site).includes(e.timing.source) || e.timing.completeness === "complete_for_scope" && !e.text_complete) && t.addIssue({
    code: "custom",
    path: ["timing"],
    message: "Historical timing must match the response provider"
  }), (e.occurred_at === null != (e.date_basis === "unknown") || !ih(e.tokens, e.role) || e.role === "prompt" && e.provider_attempt_key !== null) && t.addIssue({
    code: "custom",
    message: "Invalid historical text evidence"
  }), (e.role === "response" && e.parts === null || e.parts !== null && !sh(e.tokens, e.parts, e.role)) && t.addIssue({
    code: "custom",
    path: ["parts"],
    message: "Historical parts do not match the recorded total"
  }), e.role === "prompt" && (e.generation.text_components.length || e.generation.media.length) && t.addIssue({
    code: "custom",
    path: ["generation"],
    message: "Prompts carry no generated output"
  });
});
w({
  schema_version: E(Fo),
  site: Bi,
  conversation_key: O,
  observed_at: _e,
  deletion_epoch: D().int().min(0).max(Number.MAX_SAFE_INTEGER),
  messages: A(rh).max(100),
  branch_scope: b(["selected_branch", "loaded_messages", "unknown"]),
  selected_leaf_key: O.nullable(),
  branch_message_keys: A(O).max(100).nullable(),
  root_message_key: O.nullable(),
  first_request_verified: ze(),
  has_earlier: ze().nullable(),
  has_later: ze().nullable(),
  // Company keys of the page's messages, beside them as in a usage batch (W11). Left out
  // when no message has one.
  company_dedup_keys: A(
    w({
      message_key: O,
      company_dedup_key: O
    })
  ).max(100).optional()
}).superRefine((e, t) => {
  if ((new Set(e.messages.map((n) => n.message_key)).size !== e.messages.length || e.messages.some(
    (n) => n.site !== e.site || n.conversation_key !== e.conversation_key
  ) || e.first_request_verified && e.root_message_key === null || e.branch_message_keys !== null && new Set(e.branch_message_keys).size !== e.branch_message_keys.length) && t.addIssue({ code: "custom", message: "Inconsistent history page" }), e.company_dedup_keys) {
    const n = new Set(e.messages.map((s) => s.message_key)), i = e.company_dedup_keys.map((s) => s.message_key);
    (new Set(i).size !== i.length || i.some((s) => !n.has(s))) && t.addIssue({
      code: "custom",
      path: ["company_dedup_keys"],
      message: "Each company key names one message of the page"
    });
  }
});
const oh = 2097152, ah = 262144, Yn = D().int().min(0).max(oh);
w({
  units: Yn,
  fileUnits: A(D().int().min(0).max(ah)).max(16).nullable(),
  // Lengths and counts of the reply's other text parts and other-model text, so a
  // message whose reasoning or tool input changed is counted again.
  partUnits: Ze(b(sr), Yn),
  partTokens: Ze(b(sr), ge),
  componentUnits: A(Yn.nullable()).max(16),
  componentTokens: A(ge.nullable()).max(16),
  implementationId: S().min(1).max(128),
  profileId: S().min(1).max(128),
  assetHash: S().min(1).max(256),
  tokens: ge,
  inlineFileComponents: A(Ki.omit({ component_id: !0 })).max(16).nullable(),
  // The tokens of each text or code file Perplexity Computer created in the reply, by a
  // keyed hash of the file's id, and whether they were counted from its content or its
  // size (14 Oct 2026). Kept so a reopened chat neither downloads nor counts it again.
  computerFiles: ke(
    S().regex(/^[0-9a-f]{64}$/),
    w({
      tokens: C,
      basis: b(["content", "size"])
    })
  ).refine((e) => Object.keys(e).length <= 64).optional()
});
const ch = [
  "total",
  "tool_output",
  "image_input_tokens",
  "other_models"
], uh = w({
  quantity: E("extracted_file_text"),
  scope: E("extracted_file_text"),
  unit: E("tokens"),
  additive: E(!1),
  value: C.nullable(),
  measurement_group: w({
    origin: b(["new_upload", "retained_context", "unknown_origin"]),
    extraction_profile_id: Co,
    evidence: b(["heuristic_estimate", "unknown"]),
    profile_id: Kt
  }),
  applicable_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  contributing_component_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  unknown_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  partial_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  unvalidated_count: D().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  reason_counts: Ze(
    yt,
    D().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
  ),
  missing_counts: Ze(
    Do,
    D().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
  )
});
function lh(e, t) {
  if ([
    "observed_prompt_count",
    "observed_response_count",
    "prompt_count",
    "response_count",
    "dated_message_count",
    "undated_message_count",
    "calculated_message_count",
    "uncalculated_message_count",
    "matched_live_message_count",
    "unresolved_overlap_message_count",
    "conflicting_message_count"
  ].some((a) => !C.safeParse(e[a]).success))
    return;
  const i = (a) => BigInt(e[a]), s = i("observed_prompt_count") + i("observed_response_count"), r = i("calculated_message_count") + i("uncalculated_message_count"), o = i("prompt_count") + i("response_count") - r;
  (s !== i("dated_message_count") + i("undated_message_count") || s !== r + i("matched_live_message_count") + i("conflicting_message_count") || o < 0n || o > i("response_count") || // Rows no live capture can produce (no_live_request) contribute without waiting for a
  // live match, so only the other contributing rows are unresolved.
  i("unresolved_overlap_message_count") > r) && t.addIssue({
    code: "custom",
    message: "Inconsistent historical coverage"
  });
  for (const a of e.resources)
    (a.value === null != (a.status === "unavailable") || !("requested_method" in a) && a.profile_selection === "unavailable" != (a.selected_profile_id === null)) && t.addIssue({
      code: "custom",
      message: "Inconsistent historical assessment"
    });
}
const dh = A(
  Ae([
    w({
      quantity: b([
        "energy",
        "carbon",
        "water_direct",
        "water_upstream",
        "water_total"
      ]),
      value: zn.nullable(),
      unit: b(["kWh", "gCO2e", "gCO2", "L"]),
      scope: E("historical_visible_response"),
      method_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/),
      method_hash: O,
      status: b(["partial_estimate", "unavailable"]),
      validation_state: E("unvalidated_reference"),
      profile_selection: b(["highest_comparable", "unavailable"]),
      selected_profile_id: S().regex(/^[a-z0-9][a-z0-9.-]{0,159}$/).nullable(),
      reasons: A(yt).max(32),
      missing_components: A(S().regex(/^[a-z0-9_]{1,100}$/)).max(32),
      known_message_count: C,
      unknown_message_count: C
    }),
    zp
  ])
).max(160);
w({
  schema_version: E(Wt),
  scope: E("loaded_history"),
  status: b(["available", "empty", "unavailable"]),
  observed_prompt_count: C,
  observed_response_count: C,
  prompt_count: C,
  response_count: C,
  dated_message_count: C,
  undated_message_count: C,
  calculated_message_count: C,
  uncalculated_message_count: C,
  matched_live_message_count: C,
  unresolved_overlap_message_count: C,
  conflicting_message_count: C,
  first_request_verified: ze(),
  branch_scope: b(["selected_branch", "loaded_messages", "unknown"]),
  provider_history_complete: E(!1),
  tokens: A(
    w({
      role: b(["prompt", "response"]),
      part: b(ch),
      profile_id: Kt,
      evidence: b(["heuristic_estimate", "provider_reported", "unknown"]),
      value: C.nullable(),
      known_message_count: C,
      unknown_message_count: C
    })
  ).max(128),
  file_text: A(uh).max(256),
  file_text_coverage: w({
    observed_message_count: C,
    unknown_message_count: C,
    scope: E("extracted_file_text"),
    additive: E(!1)
  }),
  resources: dh
}).superRefine(lh);
const Po = "gpt-tokenizer-4.0.0", Vi = "o200k-base-4.0.0-reference", bi = Object.freeze({
  jobId: 128,
  modelId: 256,
  fieldTextUnits: 2097152,
  fieldTextBytes: 8 * 1024 * 1024,
  inlineFileTextUnits: 262144,
  // Six text fields, up to 16 inline files and up to 16 other-model components.
  fields: 38,
  pendingJobs: 16,
  timeoutMs: 2e4
}), fh = new TextEncoder();
function ph(e, t) {
  const n = Object.keys(e).sort(), i = [...t].sort();
  return n.length === i.length && n.every((s, r) => s === i[r]);
}
function hh(e, t) {
  return typeof e == "string" && e.length > 0 && e.length <= bi.jobId && !/[\u0000-\u001f\u007f]/.test(e) && Number.isSafeInteger(t) && Number(t) >= 1;
}
function Qn(e, t) {
  return {
    jobId: e.jobId,
    revision: e.revision,
    measurement: zo(t),
    assetHash: null,
    profileId: null,
    encoding: null,
    modelExactness: "unverified",
    status: "unavailable"
  };
}
function Ro(e, t) {
  const n = e.profiles.filter(
    (i) => i.profileId === t
  );
  return n.length === 1 ? n[0] : null;
}
function mh(e, t, n) {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const i = e;
  if (!ph(i, [
    "assetHash",
    "encoding",
    "jobId",
    "measurement",
    "modelExactness",
    "profileId",
    "revision",
    "status"
  ]) || i.jobId !== t.jobId || i.revision !== t.revision || i.modelExactness !== "unverified")
    return !1;
  const s = ge.safeParse(i.measurement);
  return i.status === "counted" ? !s.success || s.data.value === null || !/^(0|[1-9][0-9]*)$/.test(s.data.value) || BigInt(s.data.value) > BigInt(fh.encode(t.text).byteLength) || t.text.length > 0 && BigInt(s.data.value) === 0n ? !1 : i.assetHash === n.assetHash && i.profileId === n.profileId && i.encoding === n.encoding && s.data.evidence === "heuristic_estimate" && s.data.scope === "observed_text" && s.data.completeness === "complete_for_scope" && s.data.profile_id === n.profileId && s.data.reason === "tokenizer_mapping_unverified" : i.status === "unavailable" && s.success && s.data.value === null && s.data.evidence === "unknown" && s.data.scope === "observed_text" && s.data.completeness === "unknown" && s.data.profile_id === null && (s.data.reason === "tokenizer_unavailable" || s.data.reason === "capture_limit_exceeded") && i.assetHash === null && i.profileId === null && i.encoding === null;
}
const _h = "4.0.0", gh = { o200k_base: { profile_id: "o200k-base-4.0.0-reference", asset_hash: "4cd35a52f4ece645422670151ccbdbd6afd2bcb47b83efd13e47e5d8942aecb4" }, cl100k_base: { profile_id: "cl100k-base-4.0.0-reference", asset_hash: "b56372fb0b95dbd370f9de6f44b6c15006a8a36980fbc6c0568a0108971aea45" } };
var Ji = {
  version: _h,
  profiles: gh
};
const yi = Object.freeze({
  "o200k-base-4.0.0-reference": "o200k_base",
  "cl100k-base-4.0.0-reference": "cl100k_base"
}), Zo = Object.freeze({
  id: Po,
  profiles: Object.freeze(
    Object.entries(yi).map(
      ([e, t]) => Object.freeze({
        profileId: e,
        encoding: t,
        assetHash: Ji.profiles[t].asset_hash
      })
    )
  )
}), ei = (e) => typeof e == "string" && /^[a-z0-9][a-z0-9._-]{0,127}$/.test(e), ti = (e, t) => Object.keys(e).sort().join(",") === t.sort().join(","), mn = () => {
  throw new Error("tokenizer_manifest_invalid");
};
function vh(e) {
  (!e || typeof e != "object" || Array.isArray(e) || !ei(e.id) || !Array.isArray(e.profiles) || e.profiles.length < 1 || e.profiles.length > 16 || !ti(e, ["id", "profiles"]) && !ti(e, ["id", "profiles", "count"]) || "count" in e && typeof e.count != "function") && mn();
  const t = e.profiles.map((n) => ((!n || typeof n != "object" || Array.isArray(n) || !ti(n, ["profileId", "encoding", "assetHash"]) || !ei(n.profileId) || !ei(n.encoding) || typeof n.assetHash != "string" || !/^[a-f0-9]{64}$/.test(n.assetHash) || !ge.safeParse({
    value: "0",
    evidence: "heuristic_estimate",
    scope: "observed_text",
    completeness: "complete_for_scope",
    profile_id: n.profileId,
    reason: "tokenizer_mapping_unverified"
  }).success) && mn(), Object.freeze({
    profileId: n.profileId,
    encoding: n.encoding,
    assetHash: n.assetHash
  })));
  return new Set(t.map((n) => n.profileId)).size !== t.length && mn(), Object.freeze({ id: e.id, profiles: Object.freeze(t) });
}
function bh(e, t) {
  const n = vh(e);
  return Ro(n, t) || mn(), Object.freeze({
    selection: Object.freeze({ implementationId: n.id, profileId: t }),
    manifest: n
  });
}
bh(
  Zo,
  Vi
);
const dn = { maxDimension: 65535, budget: null }, re = (e, t) => ({ kind: "openai_patches", ...e, multiplier: t }), Ve = (e, t) => ({
  kind: "openai_tiles",
  base: e,
  tile: t
}), yh = Object.freeze({
  "gpt-6-astra": re(dn, 120),
  "gpt-5-6-sol": re(dn, 120),
  "gpt-5-6-terra": re(dn, 120),
  "gpt-5-6-luna": re(dn, 120),
  // Auto is original detail: up to 10,000 patches and 6,000 pixels.
  "gpt-5-5": re({ maxDimension: 6e3, budget: 1e4 }, 120),
  // Auto is high detail: up to 2,500 patches and 2,048 pixels.
  "gpt-5-4": re({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-4-mini": re({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-4-nano": re({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-2": re({ maxDimension: 2048, budget: 6144 }, 120),
  "gpt-4-1-mini": re({ maxDimension: 2048, budget: 6144 }, 162),
  // Retired patch models have a published multiplier but no sizing row; they use the
  // sizing of the other patch models of their generation.
  "gpt-5-mini": re({ maxDimension: 2048, budget: 6144 }, 120),
  "gpt-5-nano": re({ maxDimension: 2048, budget: 6144 }, 150),
  "o4-mini": re({ maxDimension: 2048, budget: 6144 }, 172),
  "gpt-5-1": Ve(70, 140),
  "gpt-5": Ve(70, 140),
  "gpt-4o": Ve(85, 170),
  "gpt-4-1": Ve(85, 170),
  "gpt-4o-mini": Ve(2833, 5667),
  o1: Ve(75, 150),
  o3: Ve(75, 150)
});
yh["gpt-6-astra"];
const or = /* @__PURE__ */ new Map(), wh = new TextEncoder();
function xh(e, t) {
  if (gt(e) !== t)
    throw new Error("tokenizer_unavailable");
}
async function kh(e) {
  let t = or.get(e);
  return t || (t = (async () => {
    const [n, i] = e === "o200k_base" ? await Promise.all([
      import("./o200k_base-CvUU9Zmb.js"),
      import("./o200k_base-BYTgCC8K.js")
    ]) : await Promise.all([
      import("./cl100k_base-BhiXU_Ff.js"),
      import("./cl100k_base-MCg9hpJE.js")
    ]);
    return xh(i.default, Ji.profiles[e].asset_hash), n.setMergeCacheSize(0), n;
  })(), or.set(e, t)), t;
}
async function Sh(e) {
  if (e.text.length > bi.fieldTextBytes || wh.encode(e.text).byteLength > bi.fieldTextBytes)
    return Qn(e, "capture_limit_exceeded");
  const t = e.profileId ?? Vi;
  if (!(t in yi))
    return Qn(e, "tokenizer_unavailable");
  const n = yi[t];
  try {
    const s = (await kh(n)).countTokens(e.text, { disallowedSpecial: /* @__PURE__ */ new Set() });
    return {
      jobId: e.jobId,
      revision: e.revision,
      measurement: {
        value: String(s),
        evidence: "heuristic_estimate",
        scope: "observed_text",
        completeness: "complete_for_scope",
        profile_id: t,
        reason: "tokenizer_mapping_unverified"
      },
      assetHash: Ji.profiles[n].asset_hash,
      profileId: t,
      encoding: n,
      modelExactness: "unverified",
      status: "counted"
    };
  } catch {
    return Qn(e, "tokenizer_unavailable");
  }
}
const Xi = Object.freeze({
  ...Zo,
  count: Sh
});
new TextEncoder();
async function Eh(e, t = Xi) {
  if (!e || typeof e != "object" || typeof e.text != "string" || e.modelId !== null && typeof e.modelId != "string" || !hh(e.jobId, e.revision) || e.profileId !== void 0 && typeof e.profileId != "string")
    throw new Error("payload_rejected");
  return t.count(e);
}
var te = Uint8Array, dt = Uint16Array, Ih = Int32Array, Mo = new te([
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  0,
  1,
  1,
  1,
  1,
  2,
  2,
  2,
  2,
  3,
  3,
  3,
  3,
  4,
  4,
  4,
  4,
  5,
  5,
  5,
  5,
  0,
  /* unused */
  0,
  0,
  /* impossible */
  0
]), jo = new te([
  0,
  0,
  0,
  0,
  1,
  1,
  2,
  2,
  3,
  3,
  4,
  4,
  5,
  5,
  6,
  6,
  7,
  7,
  8,
  8,
  9,
  9,
  10,
  10,
  11,
  11,
  12,
  12,
  13,
  13,
  /* unused */
  0,
  0
]), zh = new te([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), Lo = function(e, t) {
  for (var n = new dt(31), i = 0; i < 31; ++i)
    n[i] = t += 1 << e[i - 1];
  for (var s = new Ih(n[30]), i = 1; i < 30; ++i)
    for (var r = n[i]; r < n[i + 1]; ++r)
      s[r] = r - n[i] << 5 | i;
  return { b: n, r: s };
}, Uo = Lo(Mo, 2), Bo = Uo.b, Th = Uo.r;
Bo[28] = 258, Th[258] = 28;
var Oh = Lo(jo, 0), Ah = Oh.b, wi = new dt(32768);
for (var U = 0; U < 32768; ++U) {
  var Fe = (U & 43690) >> 1 | (U & 21845) << 1;
  Fe = (Fe & 52428) >> 2 | (Fe & 13107) << 2, Fe = (Fe & 61680) >> 4 | (Fe & 3855) << 4, wi[U] = ((Fe & 65280) >> 8 | (Fe & 255) << 8) >> 1;
}
var Rt = (function(e, t, n) {
  for (var i = e.length, s = 0, r = new dt(t); s < i; ++s)
    e[s] && ++r[e[s] - 1];
  var o = new dt(t);
  for (s = 1; s < t; ++s)
    o[s] = o[s - 1] + r[s - 1] << 1;
  var a;
  if (n) {
    a = new dt(1 << t);
    var l = 15 - t;
    for (s = 0; s < i; ++s)
      if (e[s])
        for (var c = s << 4 | e[s], f = t - e[s], u = o[e[s] - 1]++ << f, m = u | (1 << f) - 1; u <= m; ++u)
          a[wi[u] >> l] = c;
  } else
    for (a = new dt(i), s = 0; s < i; ++s)
      e[s] && (a[s] = wi[o[e[s] - 1]++] >> 15 - e[s]);
  return a;
}), Vt = new te(288);
for (var U = 0; U < 144; ++U)
  Vt[U] = 8;
for (var U = 144; U < 256; ++U)
  Vt[U] = 9;
for (var U = 256; U < 280; ++U)
  Vt[U] = 7;
for (var U = 280; U < 288; ++U)
  Vt[U] = 8;
var qo = new te(32);
for (var U = 0; U < 32; ++U)
  qo[U] = 5;
var Nh = /* @__PURE__ */ Rt(Vt, 9, 1), Ch = /* @__PURE__ */ Rt(qo, 5, 1), ni = function(e) {
  for (var t = e[0], n = 1; n < e.length; ++n)
    e[n] > t && (t = e[n]);
  return t;
}, pe = function(e, t, n) {
  var i = t / 8 | 0;
  return (e[i] | e[i + 1] << 8) >> (t & 7) & n;
}, ii = function(e, t) {
  var n = t / 8 | 0;
  return (e[n] | e[n + 1] << 8 | e[n + 2] << 16) >> (t & 7);
}, $h = function(e) {
  return (e + 7) / 8 | 0;
}, _n = function(e, t, n) {
  return (t == null || t < 0) && (t = 0), (n == null || n > e.length) && (n = e.length), new te(e.subarray(t, n));
}, Dh = [
  "unexpected EOF",
  "invalid block type",
  "invalid length/literal",
  "invalid distance",
  "stream finished",
  "no stream handler",
  ,
  // determined by compression function
  "no callback",
  "invalid UTF-8 data",
  "extra field too long",
  "date not in range 1980-2099",
  "filename too long",
  "stream finishing",
  "invalid zip data"
  // determined by unknown compression method
], he = function(e, t, n) {
  var i = new Error(t || Dh[e]);
  if (i.code = e, Error.captureStackTrace && Error.captureStackTrace(i, he), !n)
    throw i;
  return i;
}, Fh = function(e, t, n, i) {
  var s = e.length, r = 0;
  if (!s || t.f && !t.l)
    return n || new te(0);
  var o = !n, a = o || t.i != 2, l = t.i;
  o && (n = new te(s * 3));
  var c = function(Yt) {
    var Qt = n.length;
    if (Yt > Qt) {
      var Et = new te(Math.max(Qt * 2, Yt));
      Et.set(n), n = Et;
    }
  }, f = t.f || 0, u = t.p || 0, m = t.b || 0, h = t.l, p = t.d, y = t.m, x = t.n, k = s * 8;
  do {
    if (!h) {
      f = pe(e, u, 1);
      var N = pe(e, u + 1, 3);
      if (u += 3, N)
        if (N == 1)
          h = Nh, p = Ch, y = 9, x = 5;
        else if (N == 2) {
          var P = pe(e, u, 31) + 257, V = pe(e, u + 10, 15) + 4, Ne = P + pe(e, u + 5, 31) + 1;
          u += 14;
          for (var be = new te(Ne), Ce = new te(19), J = 0; J < V; ++J)
            Ce[zh[J]] = pe(e, u + J * 3, 7);
          u += V * 3;
          for (var nt = ni(Ce), wt = (1 << nt) - 1, Cn = Rt(Ce, nt, 1), J = 0; J < Ne; ) {
            var Jt = Cn[pe(e, u, wt)];
            u += Jt & 15;
            var j = Jt >> 4;
            if (j < 16)
              be[J++] = j;
            else {
              var W = 0, Ee = 0;
              for (j == 16 ? (Ee = 3 + pe(e, u, 3), u += 2, W = be[J - 1]) : j == 17 ? (Ee = 3 + pe(e, u, 7), u += 3) : j == 18 && (Ee = 11 + pe(e, u, 127), u += 7); Ee--; )
                be[J++] = W;
            }
          }
          var it = be.subarray(0, P), ye = be.subarray(P);
          y = ni(it), x = ni(ye), h = Rt(it, y, 1), p = Rt(ye, x, 1);
        } else
          he(1);
      else {
        var j = $h(u) + 4, se = e[j - 4] | e[j - 3] << 8, Z = j + se;
        if (Z > s) {
          l && he(0);
          break;
        }
        a && c(m + se), n.set(e.subarray(j, Z), m), t.b = m += se, t.p = u = Z * 8, t.f = f;
        continue;
      }
      if (u > k) {
        l && he(0);
        break;
      }
    }
    a && c(m + 131072);
    for (var xt = (1 << y) - 1, $n = (1 << x) - 1, kt = u; ; kt = u) {
      var W = h[ii(e, u) & xt], we = W >> 4;
      if (u += W & 15, u > k) {
        l && he(0);
        break;
      }
      if (W || he(2), we < 256)
        n[m++] = we;
      else if (we == 256) {
        kt = u, h = null;
        break;
      } else {
        var Xt = we - 254;
        if (we > 264) {
          var J = we - 257, qe = Mo[J];
          Xt = pe(e, u, (1 << qe) - 1) + Bo[J], u += qe;
        }
        var St = p[ii(e, u) & $n], st = St >> 4;
        St || he(3), u += St & 15;
        var ye = Ah[st];
        if (st > 3) {
          var qe = jo[st];
          ye += ii(e, u) & (1 << qe) - 1, u += qe;
        }
        if (u > k) {
          l && he(0);
          break;
        }
        a && c(m + 131072);
        var rt = m + Xt;
        if (m < ye) {
          var He = r - ye, Gt = Math.min(ye, rt);
          for (He + m < 0 && he(3); m < Gt; ++m)
            n[m] = i[He + m];
        }
        for (; m < rt; ++m)
          n[m] = n[m - ye];
      }
    }
    t.l = h, t.p = kt, t.b = m, t.f = f, h && (f = 1, t.m = y, t.d = p, t.n = x);
  } while (!f);
  return m != n.length && o ? _n(n, 0, m) : n.subarray(0, m);
}, Ph = /* @__PURE__ */ new te(0), Rh = /* @__PURE__ */ (function() {
  function e(t, n) {
    typeof t == "function" && (n = t, t = {}), this.ondata = n;
    var i = t && t.dictionary && t.dictionary.subarray(-32768);
    this.s = { i: 0, b: i ? i.length : 0 }, this.o = new te(32768), this.p = new te(0), i && this.o.set(i);
  }
  return e.prototype.e = function(t) {
    if (this.ondata || he(5), this.d && he(4), !this.p.length)
      this.p = t;
    else if (t.length) {
      var n = new te(this.p.length + t.length);
      n.set(this.p), n.set(t, this.p.length), this.p = n;
    }
  }, e.prototype.c = function(t) {
    this.s.i = +(this.d = t || !1);
    var n = this.s.b, i = Fh(this.p, this.s, this.o);
    this.ondata(_n(i, n, this.s.b), this.d), this.o = _n(i, this.s.b - 32768), this.s.b = this.o.length, this.p = _n(this.p, this.s.p / 8 | 0), this.s.p &= 7;
  }, e.prototype.push = function(t, n) {
    this.e(t), this.c(n);
  }, e;
})(), Zh = typeof TextDecoder < "u" && /* @__PURE__ */ new TextDecoder(), Mh = 0;
try {
  Zh.decode(Ph, { stream: !0 }), Mh = 1;
} catch {
}
var Je = {}, si = {}, ar;
function jh() {
  return ar || (ar = 1, (function(e) {
    Object.defineProperty(e, "__esModule", { value: !0 }), e.CHAR = `	
\r -\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}`, e.S = ` 	\r
`, e.NAME_START_CHAR = ":A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}", e.NAME_CHAR = "-" + e.NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040", e.CHAR_RE = new RegExp("^[" + e.CHAR + "]$", "u"), e.S_RE = new RegExp("^[" + e.S + "]+$", "u"), e.NAME_START_CHAR_RE = new RegExp("^[" + e.NAME_START_CHAR + "]$", "u"), e.NAME_CHAR_RE = new RegExp("^[" + e.NAME_CHAR + "]$", "u"), e.NAME_RE = new RegExp("^[" + e.NAME_START_CHAR + "][" + e.NAME_CHAR + "]*$", "u"), e.NMTOKEN_RE = new RegExp("^[" + e.NAME_CHAR + "]+$", "u");
    var t = 9, n = 10, i = 13, s = 32;
    e.S_LIST = [s, n, i, t];
    function r(c) {
      return c >= s && c <= 55295 || c === n || c === i || c === t || c >= 57344 && c <= 65533 || c >= 65536 && c <= 1114111;
    }
    e.isChar = r;
    function o(c) {
      return c === s || c === n || c === i || c === t;
    }
    e.isS = o;
    function a(c) {
      return c >= 65 && c <= 90 || c >= 97 && c <= 122 || c === 58 || c === 95 || c === 8204 || c === 8205 || c >= 192 && c <= 214 || c >= 216 && c <= 246 || c >= 248 && c <= 767 || c >= 880 && c <= 893 || c >= 895 && c <= 8191 || c >= 8304 && c <= 8591 || c >= 11264 && c <= 12271 || c >= 12289 && c <= 55295 || c >= 63744 && c <= 64975 || c >= 65008 && c <= 65533 || c >= 65536 && c <= 983039;
    }
    e.isNameStartChar = a;
    function l(c) {
      return a(c) || c >= 48 && c <= 57 || c === 45 || c === 46 || c === 183 || c >= 768 && c <= 879 || c >= 8255 && c <= 8256;
    }
    e.isNameChar = l;
  })(si)), si;
}
var ri = {}, cr;
function Lh() {
  return cr || (cr = 1, (function(e) {
    Object.defineProperty(e, "__esModule", { value: !0 }), e.CHAR = "-\uD7FF\uE000-\uFFFD\u{10000}-\u{10FFFF}", e.RESTRICTED_CHAR = "-\b\v\f-\x7F-\x84\x86-\x9F", e.S = ` 	\r
`, e.NAME_START_CHAR = ":A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}", e.NAME_CHAR = "-" + e.NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040", e.CHAR_RE = new RegExp("^[" + e.CHAR + "]$", "u"), e.RESTRICTED_CHAR_RE = new RegExp("^[" + e.RESTRICTED_CHAR + "]$", "u"), e.S_RE = new RegExp("^[" + e.S + "]+$", "u"), e.NAME_START_CHAR_RE = new RegExp("^[" + e.NAME_START_CHAR + "]$", "u"), e.NAME_CHAR_RE = new RegExp("^[" + e.NAME_CHAR + "]$", "u"), e.NAME_RE = new RegExp("^[" + e.NAME_START_CHAR + "][" + e.NAME_CHAR + "]*$", "u"), e.NMTOKEN_RE = new RegExp("^[" + e.NAME_CHAR + "]+$", "u");
    var t = 9, n = 10, i = 13, s = 32;
    e.S_LIST = [s, n, i, t];
    function r(u) {
      return u >= 1 && u <= 55295 || u >= 57344 && u <= 65533 || u >= 65536 && u <= 1114111;
    }
    e.isChar = r;
    function o(u) {
      return u >= 1 && u <= 8 || u === 11 || u === 12 || u >= 14 && u <= 31 || u >= 127 && u <= 132 || u >= 134 && u <= 159;
    }
    e.isRestrictedChar = o;
    function a(u) {
      return u === 9 || u === 10 || u === 13 || u > 31 && u < 127 || u === 133 || u > 159 && u <= 55295 || u >= 57344 && u <= 65533 || u >= 65536 && u <= 1114111;
    }
    e.isCharAndNotRestricted = a;
    function l(u) {
      return u === s || u === n || u === i || u === t;
    }
    e.isS = l;
    function c(u) {
      return u >= 65 && u <= 90 || u >= 97 && u <= 122 || u === 58 || u === 95 || u === 8204 || u === 8205 || u >= 192 && u <= 214 || u >= 216 && u <= 246 || u >= 248 && u <= 767 || u >= 880 && u <= 893 || u >= 895 && u <= 8191 || u >= 8304 && u <= 8591 || u >= 11264 && u <= 12271 || u >= 12289 && u <= 55295 || u >= 63744 && u <= 64975 || u >= 65008 && u <= 65533 || u >= 65536 && u <= 983039;
    }
    e.isNameStartChar = c;
    function f(u) {
      return c(u) || u >= 48 && u <= 57 || u === 45 || u === 46 || u === 183 || u >= 768 && u <= 879 || u >= 8255 && u <= 8256;
    }
    e.isNameChar = f;
  })(ri)), ri;
}
var oi = {}, ur;
function Uh() {
  return ur || (ur = 1, (function(e) {
    Object.defineProperty(e, "__esModule", { value: !0 }), e.NC_NAME_START_CHAR = "A-Z_a-z\xC0-\xD6\xD8-\xF6\xF8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}", e.NC_NAME_CHAR = "-" + e.NC_NAME_START_CHAR + ".0-9\xB7\u0300-\u036F\u203F-\u2040", e.NC_NAME_START_CHAR_RE = new RegExp("^[" + e.NC_NAME_START_CHAR + "]$", "u"), e.NC_NAME_CHAR_RE = new RegExp("^[" + e.NC_NAME_CHAR + "]$", "u"), e.NC_NAME_RE = new RegExp("^[" + e.NC_NAME_START_CHAR + "][" + e.NC_NAME_CHAR + "]*$", "u");
    function t(i) {
      return i >= 65 && i <= 90 || i === 95 || i >= 97 && i <= 122 || i >= 192 && i <= 214 || i >= 216 && i <= 246 || i >= 248 && i <= 767 || i >= 880 && i <= 893 || i >= 895 && i <= 8191 || i >= 8204 && i <= 8205 || i >= 8304 && i <= 8591 || i >= 11264 && i <= 12271 || i >= 12289 && i <= 55295 || i >= 63744 && i <= 64975 || i >= 65008 && i <= 65533 || i >= 65536 && i <= 983039;
    }
    e.isNCNameStartChar = t;
    function n(i) {
      return t(i) || i === 45 || i === 46 || i >= 48 && i <= 57 || i === 183 || i >= 768 && i <= 879 || i >= 8255 && i <= 8256;
    }
    e.isNCNameChar = n;
  })(oi)), oi;
}
var lr;
function Bh() {
  if (lr) return Je;
  lr = 1, Object.defineProperty(Je, "__esModule", { value: !0 }), Je.SaxesParser = Je.EVENTS = void 0;
  const e = jh(), t = Lh(), n = Uh();
  var i = e.isS, s = e.isChar, r = e.isNameStartChar, o = e.isNameChar, a = e.S_LIST, l = e.NAME_RE, c = t.isChar, f = n.isNCNameStartChar, u = n.isNCNameChar, m = n.NC_NAME_RE;
  const h = "http://www.w3.org/XML/1998/namespace", p = "http://www.w3.org/2000/xmlns/", y = {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment
    __proto__: null,
    xml: h,
    xmlns: p
  }, x = {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment
    __proto__: null,
    amp: "&",
    gt: ">",
    lt: "<",
    quot: '"',
    apos: "'"
  }, k = -1, N = -2, j = 0, se = 1, Z = 2, P = 3, V = 4, Ne = 5, be = 6, Ce = 7, J = 8, nt = 9, wt = 10, Cn = 11, Jt = 12, W = 13, Ee = 14, it = 15, ye = 16, xt = 17, $n = 18, kt = 19, we = 20, Xt = 21, qe = 22, St = 23, st = 24, rt = 25, He = 26, Gt = 27, Yt = 28, Qt = 29, Et = 30, Jo = 31, Xo = 32, We = 33, Go = 34, Dn = 35, It = 36, Fn = 37, Yo = 38, Gi = 39, Yi = 40, Qo = 41, Qi = 42, ea = 43, ta = 44, Pn = 9, fe = 10, Rn = 13, es = 32, ts = 33, ns = 34, zt = 38, is = 39, en = 45, tn = 47, na = 59, $e = 60, ot = 61, X = 62, G = 63, ss = 91, at = 93, rs = 133, os = 8232, nn = (Q) => Q === ns || Q === is, as = [ns, is], ia = [...as, ss, X], sa = [...as, $e, at], ra = [ot, G, ...a], oa = [...a, X, zt, $e];
  function Zn(Q, d, _) {
    switch (d) {
      case "xml":
        _ !== h && Q.fail(`xml prefix must be bound to ${h}.`);
        break;
      case "xmlns":
        _ !== p && Q.fail(`xmlns prefix must be bound to ${p}.`);
        break;
    }
    switch (_) {
      case p:
        Q.fail(d === "" ? `the default namespace may not be set to ${_}.` : `may not assign a prefix (even "xmlns") to the URI ${p}.`);
        break;
      case h:
        switch (d) {
          case "xml":
            break;
          case "":
            Q.fail(`the default namespace may not be set to ${_}.`);
            break;
          default:
            Q.fail("may not assign the xml namespace to another prefix.");
        }
        break;
    }
  }
  function aa(Q, d) {
    for (const _ of Object.keys(d))
      Zn(Q, _, d[_]);
  }
  const ca = (Q) => m.test(Q), ua = (Q) => l.test(Q), Ke = 0, cs = 1, Mn = 2;
  Je.EVENTS = [
    "xmldecl",
    "text",
    "processinginstruction",
    "doctype",
    "comment",
    "opentagstart",
    "attribute",
    "opentag",
    "closetag",
    "cdata",
    "error",
    "end",
    "ready"
  ];
  const us = {
    xmldecl: "xmldeclHandler",
    text: "textHandler",
    processinginstruction: "piHandler",
    doctype: "doctypeHandler",
    comment: "commentHandler",
    opentagstart: "openTagStartHandler",
    attribute: "attributeHandler",
    opentag: "openTagHandler",
    closetag: "closeTagHandler",
    cdata: "cdataHandler",
    error: "errorHandler",
    end: "endHandler",
    ready: "readyHandler"
  };
  class la {
    /**
     * @param opt The parser options.
     */
    constructor(d) {
      this.opt = d ?? {}, this.fragmentOpt = !!this.opt.fragment;
      const _ = this.xmlnsOpt = !!this.opt.xmlns;
      if (this.trackPosition = this.opt.position !== !1, this.fileName = this.opt.fileName, _) {
        this.nameStartCheck = f, this.nameCheck = u, this.isName = ca, this.processAttribs = this.processAttribsNS, this.pushAttrib = this.pushAttribNS, this.ns = Object.assign({ __proto__: null }, y);
        const g = this.opt.additionalNamespaces;
        g != null && (aa(this, g), Object.assign(this.ns, g));
      } else
        this.nameStartCheck = r, this.nameCheck = o, this.isName = ua, this.processAttribs = this.processAttribsPlain, this.pushAttrib = this.pushAttribPlain;
      this.stateTable = [
        /* eslint-disable @typescript-eslint/unbound-method */
        this.sBegin,
        this.sBeginWhitespace,
        this.sDoctype,
        this.sDoctypeQuote,
        this.sDTD,
        this.sDTDQuoted,
        this.sDTDOpenWaka,
        this.sDTDOpenWakaBang,
        this.sDTDComment,
        this.sDTDCommentEnding,
        this.sDTDCommentEnded,
        this.sDTDPI,
        this.sDTDPIEnding,
        this.sText,
        this.sEntity,
        this.sOpenWaka,
        this.sOpenWakaBang,
        this.sComment,
        this.sCommentEnding,
        this.sCommentEnded,
        this.sCData,
        this.sCDataEnding,
        this.sCDataEnding2,
        this.sPIFirstChar,
        this.sPIRest,
        this.sPIBody,
        this.sPIEnding,
        this.sXMLDeclNameStart,
        this.sXMLDeclName,
        this.sXMLDeclEq,
        this.sXMLDeclValueStart,
        this.sXMLDeclValue,
        this.sXMLDeclSeparator,
        this.sXMLDeclEnding,
        this.sOpenTag,
        this.sOpenTagSlash,
        this.sAttrib,
        this.sAttribName,
        this.sAttribNameSawWhite,
        this.sAttribValue,
        this.sAttribValueQuoted,
        this.sAttribValueClosed,
        this.sAttribValueUnquoted,
        this.sCloseTag,
        this.sCloseTagSawWhite
        /* eslint-enable @typescript-eslint/unbound-method */
      ], this._init();
    }
    /**
     * Indicates whether or not the parser is closed. If ``true``, wait for
     * the ``ready`` event to write again.
     */
    get closed() {
      return this._closed;
    }
    _init() {
      var d;
      this.openWakaBang = "", this.text = "", this.name = "", this.piTarget = "", this.entity = "", this.q = null, this.tags = [], this.tag = null, this.topNS = null, this.chunk = "", this.chunkPosition = 0, this.i = 0, this.prevI = 0, this.carriedFromPrevious = void 0, this.forbiddenState = Ke, this.attribList = [];
      const { fragmentOpt: _ } = this;
      this.state = _ ? W : j, this.reportedTextBeforeRoot = this.reportedTextAfterRoot = this.closedRoot = this.sawRoot = _, this.xmlDeclPossible = !_, this.xmlDeclExpects = ["version"], this.entityReturnState = void 0;
      let { defaultXMLVersion: g } = this.opt;
      if (g === void 0) {
        if (this.opt.forceXMLVersion === !0)
          throw new Error("forceXMLVersion set but defaultXMLVersion is not set");
        g = "1.0";
      }
      this.setXMLVersion(g), this.positionAtNewLine = 0, this.doctype = !1, this._closed = !1, this.xmlDecl = {
        version: void 0,
        encoding: void 0,
        standalone: void 0
      }, this.line = 1, this.column = 0, this.ENTITIES = Object.create(x), (d = this.readyHandler) === null || d === void 0 || d.call(this);
    }
    /**
     * The stream position the parser is currently looking at. This field is
     * zero-based.
     *
     * This field is not based on counting Unicode characters but is to be
     * interpreted as a plain index into a JavaScript string.
     */
    get position() {
      return this.chunkPosition + this.i;
    }
    /**
     * The column number of the next character to be read by the parser.  *
     * This field is zero-based. (The first column in a line is 0.)
     *
     * This field reports the index at which the next character would be in the
     * line if the line were represented as a JavaScript string.  Note that this
     * *can* be different to a count based on the number of *Unicode characters*
     * due to how JavaScript handles astral plane characters.
     *
     * See [[column]] for a number that corresponds to a count of Unicode
     * characters.
     */
    get columnIndex() {
      return this.position - this.positionAtNewLine;
    }
    /**
     * Set an event listener on an event. The parser supports one handler per
     * event type. If you try to set an event handler over an existing handler,
     * the old handler is silently overwritten.
     *
     * @param name The event to listen to.
     *
     * @param handler The handler to set.
     */
    on(d, _) {
      this[us[d]] = _;
    }
    /**
     * Unset an event handler.
     *
     * @parma name The event to stop listening to.
     */
    off(d) {
      this[us[d]] = void 0;
    }
    /**
     * Make an error object. The error object will have a message that contains
     * the ``fileName`` option passed at the creation of the parser. If position
     * tracking was turned on, it will also have line and column number
     * information.
     *
     * @param message The message describing the error to report.
     *
     * @returns An error object with a properly formatted message.
     */
    makeError(d) {
      var _;
      let g = (_ = this.fileName) !== null && _ !== void 0 ? _ : "";
      return this.trackPosition && (g.length > 0 && (g += ":"), g += `${this.line}:${this.column}`), g.length > 0 && (g += ": "), new Error(g + d);
    }
    /**
     * Report a parsing error. This method is made public so that client code may
     * check for issues that are outside the scope of this project and can report
     * errors.
     *
     * @param message The error to report.
     *
     * @returns this
     */
    fail(d) {
      const _ = this.makeError(d), g = this.errorHandler;
      if (g === void 0)
        throw _;
      return g(_), this;
    }
    /**
     * Write a XML data to the parser.
     *
     * @param chunk The XML data to write.
     *
     * @returns this
     */
    // We do need object for the type here. Yes, it often causes problems
    // but not in this case.
    write(d) {
      if (this.closed)
        return this.fail("cannot write after close; assign an onready handler.");
      let _ = !1;
      d === null ? (_ = !0, d = "") : typeof d == "object" && (d = d.toString()), this.carriedFromPrevious !== void 0 && (d = `${this.carriedFromPrevious}${d}`, this.carriedFromPrevious = void 0);
      let g = d.length;
      const I = d.charCodeAt(g - 1);
      !_ && // A trailing CR or surrogate must be carried over to the next
      // chunk.
      (I === Rn || I >= 55296 && I <= 56319) && (this.carriedFromPrevious = d[g - 1], g--, d = d.slice(0, g));
      const { stateTable: $ } = this;
      for (this.chunk = d, this.i = 0; this.i < g; )
        $[this.state].call(this);
      return this.chunkPosition += g, _ ? this.end() : this;
    }
    /**
     * Close the current stream. Perform final well-formedness checks and reset
     * the parser tstate.
     *
     * @returns this
     */
    close() {
      return this.write(null);
    }
    /**
     * Get a single code point out of the current chunk. This updates the current
     * position if we do position tracking.
     *
     * This is the algorithm to use for XML 1.0.
     *
     * @returns The character read.
     */
    getCode10() {
      const { chunk: d, i: _ } = this;
      if (this.prevI = _, this.i = _ + 1, _ >= d.length)
        return k;
      const g = d.charCodeAt(_);
      if (this.column++, g < 55296) {
        if (g >= es || g === Pn)
          return g;
        switch (g) {
          case fe:
            return this.line++, this.column = 0, this.positionAtNewLine = this.position, fe;
          case Rn:
            return d.charCodeAt(_ + 1) === fe && (this.i = _ + 2), this.line++, this.column = 0, this.positionAtNewLine = this.position, N;
          default:
            return this.fail("disallowed character."), g;
        }
      }
      if (g > 56319)
        return g >= 57344 && g <= 65533 || this.fail("disallowed character."), g;
      const I = 65536 + (g - 55296) * 1024 + (d.charCodeAt(_ + 1) - 56320);
      return this.i = _ + 2, I > 1114111 && this.fail("disallowed character."), I;
    }
    /**
     * Get a single code point out of the current chunk. This updates the current
     * position if we do position tracking.
     *
     * This is the algorithm to use for XML 1.1.
     *
     * @returns {number} The character read.
     */
    getCode11() {
      const { chunk: d, i: _ } = this;
      if (this.prevI = _, this.i = _ + 1, _ >= d.length)
        return k;
      const g = d.charCodeAt(_);
      if (this.column++, g < 55296) {
        if (g > 31 && g < 127 || g > 159 && g !== os || g === Pn)
          return g;
        switch (g) {
          case fe:
            return this.line++, this.column = 0, this.positionAtNewLine = this.position, fe;
          case Rn: {
            const $ = d.charCodeAt(_ + 1);
            ($ === fe || $ === rs) && (this.i = _ + 2);
          }
          /* yes, fall through */
          case rs:
          // 0x85
          case os:
            return this.line++, this.column = 0, this.positionAtNewLine = this.position, N;
          default:
            return this.fail("disallowed character."), g;
        }
      }
      if (g > 56319)
        return g >= 57344 && g <= 65533 || this.fail("disallowed character."), g;
      const I = 65536 + (g - 55296) * 1024 + (d.charCodeAt(_ + 1) - 56320);
      return this.i = _ + 2, I > 1114111 && this.fail("disallowed character."), I;
    }
    /**
     * Like ``getCode`` but with the return value normalized so that ``NL`` is
     * returned for ``NL_LIKE``.
     */
    getCodeNorm() {
      const d = this.getCode();
      return d === N ? fe : d;
    }
    unget() {
      this.i = this.prevI, this.column--;
    }
    /**
     * Capture characters into a buffer until encountering one of a set of
     * characters.
     *
     * @param chars An array of codepoints. Encountering a character in the array
     * ends the capture. (``chars`` may safely contain ``NL``.)
     *
     * @return The character code that made the capture end, or ``EOC`` if we hit
     * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
     * instead.
     */
    captureTo(d) {
      let { i: _ } = this;
      const { chunk: g } = this;
      for (; ; ) {
        const I = this.getCode(), $ = I === N, R = $ ? fe : I;
        if (R === k || d.includes(R))
          return this.text += g.slice(_, this.prevI), R;
        $ && (this.text += `${g.slice(_, this.prevI)}
`, _ = this.i);
      }
    }
    /**
     * Capture characters into a buffer until encountering a character.
     *
     * @param char The codepoint that ends the capture. **NOTE ``char`` MAY NOT
     * CONTAIN ``NL``.** Passing ``NL`` will result in buggy behavior.
     *
     * @return ``true`` if we ran into the character. Otherwise, we ran into the
     * end of the current chunk.
     */
    captureToChar(d) {
      let { i: _ } = this;
      const { chunk: g } = this;
      for (; ; ) {
        let I = this.getCode();
        switch (I) {
          case N:
            this.text += `${g.slice(_, this.prevI)}
`, _ = this.i, I = fe;
            break;
          case k:
            return this.text += g.slice(_), !1;
        }
        if (I === d)
          return this.text += g.slice(_, this.prevI), !0;
      }
    }
    /**
     * Capture characters that satisfy ``isNameChar`` into the ``name`` field of
     * this parser.
     *
     * @return The character code that made the test fail, or ``EOC`` if we hit
     * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
     * instead.
     */
    captureNameChars() {
      const { chunk: d, i: _ } = this;
      for (; ; ) {
        const g = this.getCode();
        if (g === k)
          return this.name += d.slice(_), k;
        if (!o(g))
          return this.name += d.slice(_, this.prevI), g === N ? fe : g;
      }
    }
    /**
     * Skip white spaces.
     *
     * @return The character that ended the skip, or ``EOC`` if we hit
     * the end of the chunk. The return value cannot be NL_LIKE: NL is returned
     * instead.
     */
    skipSpaces() {
      for (; ; ) {
        const d = this.getCodeNorm();
        if (d === k || !i(d))
          return d;
      }
    }
    setXMLVersion(d) {
      this.currentXMLVersion = d, d === "1.0" ? (this.isChar = s, this.getCode = this.getCode10) : (this.isChar = c, this.getCode = this.getCode11);
    }
    // STATE ENGINE METHODS
    // This needs to be a state separate from S_BEGIN_WHITESPACE because we want
    // to be sure never to come back to this state later.
    sBegin() {
      this.chunk.charCodeAt(0) === 65279 && (this.i++, this.column++), this.state = se;
    }
    sBeginWhitespace() {
      const d = this.i, _ = this.skipSpaces();
      switch (this.prevI !== d && (this.xmlDeclPossible = !1), _) {
        case $e:
          if (this.state = it, this.text.length !== 0)
            throw new Error("no-empty text at start");
          break;
        case k:
          break;
        default:
          this.unget(), this.state = W, this.xmlDeclPossible = !1;
      }
    }
    sDoctype() {
      var d;
      const _ = this.captureTo(ia);
      switch (_) {
        case X: {
          (d = this.doctypeHandler) === null || d === void 0 || d.call(this, this.text), this.text = "", this.state = W, this.doctype = !0;
          break;
        }
        case k:
          break;
        default:
          this.text += String.fromCodePoint(_), _ === ss ? this.state = V : nn(_) && (this.state = P, this.q = _);
      }
    }
    sDoctypeQuote() {
      const d = this.q;
      this.captureToChar(d) && (this.text += String.fromCodePoint(d), this.q = null, this.state = Z);
    }
    sDTD() {
      const d = this.captureTo(sa);
      d !== k && (this.text += String.fromCodePoint(d), d === at ? this.state = Z : d === $e ? this.state = be : nn(d) && (this.state = Ne, this.q = d));
    }
    sDTDQuoted() {
      const d = this.q;
      this.captureToChar(d) && (this.text += String.fromCodePoint(d), this.state = V, this.q = null);
    }
    sDTDOpenWaka() {
      const d = this.getCodeNorm();
      switch (this.text += String.fromCodePoint(d), d) {
        case ts:
          this.state = Ce, this.openWakaBang = "";
          break;
        case G:
          this.state = Cn;
          break;
        default:
          this.state = V;
      }
    }
    sDTDOpenWakaBang() {
      const d = String.fromCodePoint(this.getCodeNorm()), _ = this.openWakaBang += d;
      this.text += d, _ !== "-" && (this.state = _ === "--" ? J : V, this.openWakaBang = "");
    }
    sDTDComment() {
      this.captureToChar(en) && (this.text += "-", this.state = nt);
    }
    sDTDCommentEnding() {
      const d = this.getCodeNorm();
      this.text += String.fromCodePoint(d), this.state = d === en ? wt : J;
    }
    sDTDCommentEnded() {
      const d = this.getCodeNorm();
      this.text += String.fromCodePoint(d), d === X ? this.state = V : (this.fail("malformed comment."), this.state = J);
    }
    sDTDPI() {
      this.captureToChar(G) && (this.text += "?", this.state = Jt);
    }
    sDTDPIEnding() {
      const d = this.getCodeNorm();
      this.text += String.fromCodePoint(d), d === X && (this.state = V);
    }
    sText() {
      this.tags.length !== 0 ? this.handleTextInRoot() : this.handleTextOutsideRoot();
    }
    sEntity() {
      let { i: d } = this;
      const { chunk: _ } = this;
      e:
        for (; ; )
          switch (this.getCode()) {
            case N:
              this.entity += `${_.slice(d, this.prevI)}
`, d = this.i;
              break;
            case na: {
              const { entityReturnState: g } = this, I = this.entity + _.slice(d, this.prevI);
              this.state = g;
              let $;
              I === "" ? (this.fail("empty entity name."), $ = "&;") : ($ = this.parseEntity(I), this.entity = ""), (g !== W || this.textHandler !== void 0) && (this.text += $);
              break e;
            }
            case k:
              this.entity += _.slice(d);
              break e;
          }
    }
    sOpenWaka() {
      const d = this.getCode();
      if (r(d))
        this.state = Go, this.unget(), this.xmlDeclPossible = !1;
      else
        switch (d) {
          case tn:
            this.state = ea, this.xmlDeclPossible = !1;
            break;
          case ts:
            this.state = ye, this.openWakaBang = "", this.xmlDeclPossible = !1;
            break;
          case G:
            this.state = St;
            break;
          default:
            this.fail("disallowed character in tag name"), this.state = W, this.xmlDeclPossible = !1;
        }
    }
    sOpenWakaBang() {
      switch (this.openWakaBang += String.fromCodePoint(this.getCodeNorm()), this.openWakaBang) {
        case "[CDATA[":
          !this.sawRoot && !this.reportedTextBeforeRoot && (this.fail("text data outside of root node."), this.reportedTextBeforeRoot = !0), this.closedRoot && !this.reportedTextAfterRoot && (this.fail("text data outside of root node."), this.reportedTextAfterRoot = !0), this.state = we, this.openWakaBang = "";
          break;
        case "--":
          this.state = xt, this.openWakaBang = "";
          break;
        case "DOCTYPE":
          this.state = Z, (this.doctype || this.sawRoot) && this.fail("inappropriately located doctype declaration."), this.openWakaBang = "";
          break;
        default:
          this.openWakaBang.length >= 7 && this.fail("incorrect syntax.");
      }
    }
    sComment() {
      this.captureToChar(en) && (this.state = $n);
    }
    sCommentEnding() {
      var d;
      const _ = this.getCodeNorm();
      _ === en ? (this.state = kt, (d = this.commentHandler) === null || d === void 0 || d.call(this, this.text), this.text = "") : (this.text += `-${String.fromCodePoint(_)}`, this.state = xt);
    }
    sCommentEnded() {
      const d = this.getCodeNorm();
      d !== X ? (this.fail("malformed comment."), this.text += `--${String.fromCodePoint(d)}`, this.state = xt) : this.state = W;
    }
    sCData() {
      this.captureToChar(at) && (this.state = Xt);
    }
    sCDataEnding() {
      const d = this.getCodeNorm();
      d === at ? this.state = qe : (this.text += `]${String.fromCodePoint(d)}`, this.state = we);
    }
    sCDataEnding2() {
      var d;
      const _ = this.getCodeNorm();
      switch (_) {
        case X: {
          (d = this.cdataHandler) === null || d === void 0 || d.call(this, this.text), this.text = "", this.state = W;
          break;
        }
        case at:
          this.text += "]";
          break;
        default:
          this.text += `]]${String.fromCodePoint(_)}`, this.state = we;
      }
    }
    // We need this separate state to check the first character fo the pi target
    // with this.nameStartCheck which allows less characters than this.nameCheck.
    sPIFirstChar() {
      const d = this.getCodeNorm();
      this.nameStartCheck(d) ? (this.piTarget += String.fromCodePoint(d), this.state = st) : d === G || i(d) ? (this.fail("processing instruction without a target."), this.state = d === G ? He : rt) : (this.fail("disallowed character in processing instruction name."), this.piTarget += String.fromCodePoint(d), this.state = st);
    }
    sPIRest() {
      const { chunk: d, i: _ } = this;
      for (; ; ) {
        const g = this.getCodeNorm();
        if (g === k) {
          this.piTarget += d.slice(_);
          return;
        }
        if (!this.nameCheck(g)) {
          this.piTarget += d.slice(_, this.prevI);
          const I = g === G;
          I || i(g) ? this.piTarget === "xml" ? (this.xmlDeclPossible || this.fail("an XML declaration must be at the start of the document."), this.state = I ? We : Gt) : this.state = I ? He : rt : (this.fail("disallowed character in processing instruction name."), this.piTarget += String.fromCodePoint(g));
          break;
        }
      }
    }
    sPIBody() {
      if (this.text.length === 0) {
        const d = this.getCodeNorm();
        d === G ? this.state = He : i(d) || (this.text = String.fromCodePoint(d));
      } else this.captureToChar(G) && (this.state = He);
    }
    sPIEnding() {
      var d;
      const _ = this.getCodeNorm();
      if (_ === X) {
        const { piTarget: g } = this;
        g.toLowerCase() === "xml" && this.fail("the XML declaration must appear at the start of the document."), (d = this.piHandler) === null || d === void 0 || d.call(this, {
          target: g,
          body: this.text
        }), this.piTarget = this.text = "", this.state = W;
      } else _ === G ? this.text += "?" : (this.text += `?${String.fromCodePoint(_)}`, this.state = rt);
      this.xmlDeclPossible = !1;
    }
    sXMLDeclNameStart() {
      const d = this.skipSpaces();
      if (d === G) {
        this.state = We;
        return;
      }
      d !== k && (this.state = Yt, this.name = String.fromCodePoint(d));
    }
    sXMLDeclName() {
      const d = this.captureTo(ra);
      if (d === G) {
        this.state = We, this.name += this.text, this.text = "", this.fail("XML declaration is incomplete.");
        return;
      }
      if (i(d) || d === ot) {
        if (this.name += this.text, this.text = "", !this.xmlDeclExpects.includes(this.name))
          switch (this.name.length) {
            case 0:
              this.fail("did not expect any more name/value pairs.");
              break;
            case 1:
              this.fail(`expected the name ${this.xmlDeclExpects[0]}.`);
              break;
            default:
              this.fail(`expected one of ${this.xmlDeclExpects.join(", ")}`);
          }
        this.state = d === ot ? Et : Qt;
      }
    }
    sXMLDeclEq() {
      const d = this.getCodeNorm();
      if (d === G) {
        this.state = We, this.fail("XML declaration is incomplete.");
        return;
      }
      i(d) || (d !== ot && this.fail("value required."), this.state = Et);
    }
    sXMLDeclValueStart() {
      const d = this.getCodeNorm();
      if (d === G) {
        this.state = We, this.fail("XML declaration is incomplete.");
        return;
      }
      i(d) || (nn(d) ? this.q = d : (this.fail("value must be quoted."), this.q = es), this.state = Jo);
    }
    sXMLDeclValue() {
      const d = this.captureTo([this.q, G]);
      if (d === G) {
        this.state = We, this.text = "", this.fail("XML declaration is incomplete.");
        return;
      }
      if (d === k)
        return;
      const _ = this.text;
      switch (this.text = "", this.name) {
        case "version": {
          this.xmlDeclExpects = ["encoding", "standalone"];
          const g = _;
          this.xmlDecl.version = g, /^1\.[0-9]+$/.test(g) ? this.opt.forceXMLVersion || this.setXMLVersion(g) : this.fail("version number must match /^1\\.[0-9]+$/.");
          break;
        }
        case "encoding":
          /^[A-Za-z][A-Za-z0-9._-]*$/.test(_) || this.fail("encoding value must match 	/^[A-Za-z0-9][A-Za-z0-9._-]*$/."), this.xmlDeclExpects = ["standalone"], this.xmlDecl.encoding = _;
          break;
        case "standalone":
          _ !== "yes" && _ !== "no" && this.fail('standalone value must match "yes" or "no".'), this.xmlDeclExpects = [], this.xmlDecl.standalone = _;
          break;
      }
      this.name = "", this.state = Xo;
    }
    sXMLDeclSeparator() {
      const d = this.getCodeNorm();
      if (d === G) {
        this.state = We;
        return;
      }
      i(d) || (this.fail("whitespace required."), this.unget()), this.state = Gt;
    }
    sXMLDeclEnding() {
      var d;
      this.getCodeNorm() === X ? (this.piTarget !== "xml" ? this.fail("processing instructions are not allowed before root.") : this.name !== "version" && this.xmlDeclExpects.includes("version") && this.fail("XML declaration must contain a version."), (d = this.xmldeclHandler) === null || d === void 0 || d.call(this, this.xmlDecl), this.name = "", this.piTarget = this.text = "", this.state = W) : this.fail("The character ? is disallowed anywhere in XML declarations."), this.xmlDeclPossible = !1;
    }
    sOpenTag() {
      var d;
      const _ = this.captureNameChars();
      if (_ === k)
        return;
      const g = this.tag = {
        name: this.name,
        attributes: /* @__PURE__ */ Object.create(null)
      };
      switch (this.name = "", this.xmlnsOpt && (this.topNS = g.ns = /* @__PURE__ */ Object.create(null)), (d = this.openTagStartHandler) === null || d === void 0 || d.call(this, g), this.sawRoot = !0, !this.fragmentOpt && this.closedRoot && this.fail("documents may contain only one root."), _) {
        case X:
          this.openTag();
          break;
        case tn:
          this.state = Dn;
          break;
        default:
          i(_) || this.fail("disallowed character in tag name."), this.state = It;
      }
    }
    sOpenTagSlash() {
      this.getCode() === X ? this.openSelfClosingTag() : (this.fail("forward-slash in opening tag not followed by >."), this.state = It);
    }
    sAttrib() {
      const d = this.skipSpaces();
      d !== k && (r(d) ? (this.unget(), this.state = Fn) : d === X ? this.openTag() : d === tn ? this.state = Dn : this.fail("disallowed character in attribute name."));
    }
    sAttribName() {
      const d = this.captureNameChars();
      d === ot ? this.state = Gi : i(d) ? this.state = Yo : d === X ? (this.fail("attribute without value."), this.pushAttrib(this.name, this.name), this.name = this.text = "", this.openTag()) : d !== k && this.fail("disallowed character in attribute name.");
    }
    sAttribNameSawWhite() {
      const d = this.skipSpaces();
      switch (d) {
        case k:
          return;
        case ot:
          this.state = Gi;
          break;
        default:
          this.fail("attribute without value."), this.text = "", this.name = "", d === X ? this.openTag() : r(d) ? (this.unget(), this.state = Fn) : (this.fail("disallowed character in attribute name."), this.state = It);
      }
    }
    sAttribValue() {
      const d = this.getCodeNorm();
      nn(d) ? (this.q = d, this.state = Yi) : i(d) || (this.fail("unquoted attribute value."), this.state = Qi, this.unget());
    }
    sAttribValueQuoted() {
      const { q: d, chunk: _ } = this;
      let { i: g } = this;
      for (; ; )
        switch (this.getCode()) {
          case d:
            this.pushAttrib(this.name, this.text + _.slice(g, this.prevI)), this.name = this.text = "", this.q = null, this.state = Qo;
            return;
          case zt:
            this.text += _.slice(g, this.prevI), this.state = Ee, this.entityReturnState = Yi;
            return;
          case fe:
          case N:
          case Pn:
            this.text += `${_.slice(g, this.prevI)} `, g = this.i;
            break;
          case $e:
            this.text += _.slice(g, this.prevI), this.fail("disallowed character.");
            return;
          case k:
            this.text += _.slice(g);
            return;
        }
    }
    sAttribValueClosed() {
      const d = this.getCodeNorm();
      i(d) ? this.state = It : d === X ? this.openTag() : d === tn ? this.state = Dn : r(d) ? (this.fail("no whitespace between attributes."), this.unget(), this.state = Fn) : this.fail("disallowed character in attribute name.");
    }
    sAttribValueUnquoted() {
      const d = this.captureTo(oa);
      switch (d) {
        case zt:
          this.state = Ee, this.entityReturnState = Qi;
          break;
        case $e:
          this.fail("disallowed character.");
          break;
        case k:
          break;
        default:
          this.text.includes("]]>") && this.fail('the string "]]>" is disallowed in char data.'), this.pushAttrib(this.name, this.text), this.name = this.text = "", d === X ? this.openTag() : this.state = It;
      }
    }
    sCloseTag() {
      const d = this.captureNameChars();
      d === X ? this.closeTag() : i(d) ? this.state = ta : d !== k && this.fail("disallowed character in closing tag.");
    }
    sCloseTagSawWhite() {
      switch (this.skipSpaces()) {
        case X:
          this.closeTag();
          break;
        case k:
          break;
        default:
          this.fail("disallowed character in closing tag.");
      }
    }
    // END OF STATE ENGINE METHODS
    handleTextInRoot() {
      let { i: d, forbiddenState: _ } = this;
      const { chunk: g, textHandler: I } = this;
      e:
        for (; ; )
          switch (this.getCode()) {
            case $e: {
              if (this.state = it, I !== void 0) {
                const { text: $ } = this, R = g.slice(d, this.prevI);
                $.length !== 0 ? (I($ + R), this.text = "") : R.length !== 0 && I(R);
              }
              _ = Ke;
              break e;
            }
            case zt:
              this.state = Ee, this.entityReturnState = W, I !== void 0 && (this.text += g.slice(d, this.prevI)), _ = Ke;
              break e;
            case at:
              switch (_) {
                case Ke:
                  _ = cs;
                  break;
                case cs:
                  _ = Mn;
                  break;
                case Mn:
                  break;
                default:
                  throw new Error("impossible state");
              }
              break;
            case X:
              _ === Mn && this.fail('the string "]]>" is disallowed in char data.'), _ = Ke;
              break;
            case N:
              I !== void 0 && (this.text += `${g.slice(d, this.prevI)}
`), d = this.i, _ = Ke;
              break;
            case k:
              I !== void 0 && (this.text += g.slice(d));
              break e;
            default:
              _ = Ke;
          }
      this.forbiddenState = _;
    }
    handleTextOutsideRoot() {
      let { i: d } = this;
      const { chunk: _, textHandler: g } = this;
      let I = !1;
      e:
        for (; ; ) {
          const $ = this.getCode();
          switch ($) {
            case $e: {
              if (this.state = it, g !== void 0) {
                const { text: R } = this, Y = _.slice(d, this.prevI);
                R.length !== 0 ? (g(R + Y), this.text = "") : Y.length !== 0 && g(Y);
              }
              break e;
            }
            case zt:
              this.state = Ee, this.entityReturnState = W, g !== void 0 && (this.text += _.slice(d, this.prevI)), I = !0;
              break e;
            case N:
              g !== void 0 && (this.text += `${_.slice(d, this.prevI)}
`), d = this.i;
              break;
            case k:
              g !== void 0 && (this.text += _.slice(d));
              break e;
            default:
              i($) || (I = !0);
          }
        }
      I && (!this.sawRoot && !this.reportedTextBeforeRoot && (this.fail("text data outside of root node."), this.reportedTextBeforeRoot = !0), this.closedRoot && !this.reportedTextAfterRoot && (this.fail("text data outside of root node."), this.reportedTextAfterRoot = !0));
    }
    pushAttribNS(d, _) {
      var g;
      const { prefix: I, local: $ } = this.qname(d), R = { name: d, prefix: I, local: $, value: _ };
      if (this.attribList.push(R), (g = this.attributeHandler) === null || g === void 0 || g.call(this, R), I === "xmlns") {
        const Y = _.trim();
        this.currentXMLVersion === "1.0" && Y === "" && this.fail("invalid attempt to undefine prefix in XML 1.0"), this.topNS[$] = Y, Zn(this, $, Y);
      } else if (d === "xmlns") {
        const Y = _.trim();
        this.topNS[""] = Y, Zn(this, "", Y);
      }
    }
    pushAttribPlain(d, _) {
      var g;
      const I = { name: d, value: _ };
      this.attribList.push(I), (g = this.attributeHandler) === null || g === void 0 || g.call(this, I);
    }
    /**
     * End parsing. This performs final well-formedness checks and resets the
     * parser to a clean state.
     *
     * @returns this
     */
    end() {
      var d, _;
      this.sawRoot || this.fail("document must contain a root element.");
      const { tags: g } = this;
      for (; g.length > 0; ) {
        const $ = g.pop();
        this.fail(`unclosed tag: ${$.name}`);
      }
      this.state !== j && this.state !== W && this.fail("unexpected end.");
      const { text: I } = this;
      return I.length !== 0 && ((d = this.textHandler) === null || d === void 0 || d.call(this, I), this.text = ""), this._closed = !0, (_ = this.endHandler) === null || _ === void 0 || _.call(this), this._init(), this;
    }
    /**
     * Resolve a namespace prefix.
     *
     * @param prefix The prefix to resolve.
     *
     * @returns The namespace URI or ``undefined`` if the prefix is not defined.
     */
    resolve(d) {
      var _, g;
      let I = this.topNS[d];
      if (I !== void 0)
        return I;
      const { tags: $ } = this;
      for (let R = $.length - 1; R >= 0; R--)
        if (I = $[R].ns[d], I !== void 0)
          return I;
      return I = this.ns[d], I !== void 0 ? I : (g = (_ = this.opt).resolvePrefix) === null || g === void 0 ? void 0 : g.call(_, d);
    }
    /**
     * Parse a qname into its prefix and local name parts.
     *
     * @param name The name to parse
     *
     * @returns
     */
    qname(d) {
      const _ = d.indexOf(":");
      if (_ === -1)
        return { prefix: "", local: d };
      const g = d.slice(_ + 1), I = d.slice(0, _);
      return (I === "" || g === "" || g.includes(":")) && this.fail(`malformed name: ${d}.`), { prefix: I, local: g };
    }
    processAttribsNS() {
      var d;
      const { attribList: _ } = this, g = this.tag;
      {
        const { prefix: R, local: Y } = this.qname(g.name);
        g.prefix = R, g.local = Y;
        const ct = g.uri = (d = this.resolve(R)) !== null && d !== void 0 ? d : "";
        R !== "" && (R === "xmlns" && this.fail('tags may not have "xmlns" as prefix.'), ct === "" && (this.fail(`unbound namespace prefix: ${JSON.stringify(R)}.`), g.uri = R));
      }
      if (_.length === 0)
        return;
      const { attributes: I } = g, $ = /* @__PURE__ */ new Set();
      for (const R of _) {
        const { name: Y, prefix: ct, local: da } = R;
        let ut, Tt;
        ct === "" ? (ut = Y === "xmlns" ? p : "", Tt = Y) : (ut = this.resolve(ct), ut === void 0 && (this.fail(`unbound namespace prefix: ${JSON.stringify(ct)}.`), ut = ct), Tt = `{${ut}}${da}`), $.has(Tt) && this.fail(`duplicate attribute: ${Tt}.`), $.add(Tt), R.uri = ut, I[Y] = R;
      }
      this.attribList = [];
    }
    processAttribsPlain() {
      const { attribList: d } = this, _ = this.tag.attributes;
      for (const { name: g, value: I } of d)
        _[g] !== void 0 && this.fail(`duplicate attribute: ${g}.`), _[g] = I;
      this.attribList = [];
    }
    /**
     * Handle a complete open tag. This parser code calls this once it has seen
     * the whole tag. This method checks for well-formeness and then emits
     * ``onopentag``.
     */
    openTag() {
      var d;
      this.processAttribs();
      const { tags: _ } = this, g = this.tag;
      g.isSelfClosing = !1, (d = this.openTagHandler) === null || d === void 0 || d.call(this, g), _.push(g), this.state = W, this.name = "";
    }
    /**
     * Handle a complete self-closing tag. This parser code calls this once it has
     * seen the whole tag. This method checks for well-formeness and then emits
     * ``onopentag`` and ``onclosetag``.
     */
    openSelfClosingTag() {
      var d, _, g;
      this.processAttribs();
      const { tags: I } = this, $ = this.tag;
      $.isSelfClosing = !0, (d = this.openTagHandler) === null || d === void 0 || d.call(this, $), (_ = this.closeTagHandler) === null || _ === void 0 || _.call(this, $), (this.tag = (g = I[I.length - 1]) !== null && g !== void 0 ? g : null) === null && (this.closedRoot = !0), this.state = W, this.name = "";
    }
    /**
     * Handle a complete close tag. This parser code calls this once it has seen
     * the whole tag. This method checks for well-formeness and then emits
     * ``onclosetag``.
     */
    closeTag() {
      const { tags: d, name: _ } = this;
      if (this.state = W, this.name = "", _ === "") {
        this.fail("weird empty close tag."), this.text += "</>";
        return;
      }
      const g = this.closeTagHandler;
      let I = d.length;
      for (; I-- > 0; ) {
        const $ = this.tag = d.pop();
        if (this.topNS = $.ns, g?.($), $.name === _)
          break;
        this.fail("unexpected close tag.");
      }
      I === 0 ? this.closedRoot = !0 : I < 0 && (this.fail(`unmatched closing tag: ${_}.`), this.text += `</${_}>`);
    }
    /**
     * Resolves an entity. Makes any necessary well-formedness checks.
     *
     * @param entity The entity to resolve.
     *
     * @returns The parsed entity.
     */
    parseEntity(d) {
      if (d[0] !== "#") {
        const g = this.ENTITIES[d];
        return g !== void 0 ? g : (this.fail(this.isName(d) ? "undefined entity." : "disallowed character in entity name."), `&${d};`);
      }
      let _ = NaN;
      return d[1] === "x" && /^#x[0-9a-f]+$/i.test(d) ? _ = parseInt(d.slice(2), 16) : /^#[0-9]+$/.test(d) && (_ = parseInt(d.slice(1), 10)), this.isChar(_) ? String.fromCodePoint(_) : (this.fail("malformed character entity."), `&${d};`);
    }
  }
  return Je.SaxesParser = la, Je;
}
var qh = Bh();
const ne = Object.freeze({
  inputBytes: 25 * 1024 * 1024,
  textBytes: 8 * 1024 * 1024,
  pages: 200,
  zipEntries: 512,
  zipExpandedBytes: 32 * 1024 * 1024,
  zipEntryBytes: 8 * 1024 * 1024,
  zipRatio: 200,
  xmlDepth: 128,
  cells: 5e4,
  sheets: 64,
  timeoutMs: 3e4
});
class T extends Error {
  constructor(t) {
    super(t), this.code = t;
  }
  code;
}
const Ho = "local-file-text-utf8-pdfjs6.3.289-opc-v1";
function Hh(e, t = {
  implementationId: Po,
  profileId: Vi
}) {
  return {
    implementationId: e.tokenizerImplementationId ?? t.implementationId,
    profileId: e.tokenizerProfileId ?? t.profileId
  };
}
function Wo(e) {
  if (!e || typeof e != "object") throw new T("invalid_job");
  const t = e;
  if (![
    "bytes,jobId,kind,revision",
    "bytes,jobId,kind,revision,tokenizerImplementationId,tokenizerProfileId"
  ].includes(Object.keys(t).sort().join(",")) || typeof t.jobId != "string" || !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(t.jobId) || !Number.isSafeInteger(t.revision) || t.revision < 1 || !["text", "pdf", "docx", "xlsx", "pptx"].includes(t.kind) || !(t.bytes instanceof ArrayBuffer) || t.tokenizerImplementationId !== void 0 && (typeof t.tokenizerImplementationId != "string" || !/^[a-z0-9][a-z0-9._-]{0,127}$/.test(t.tokenizerImplementationId)) || t.tokenizerProfileId !== void 0 && (typeof t.tokenizerProfileId != "string" || !/^[a-z0-9][a-z0-9._-]{0,127}$/.test(t.tokenizerProfileId)))
    throw new T("invalid_job");
  if (t.bytes.byteLength > ne.inputBytes)
    throw new T("input_limit");
}
function Ko(e, t) {
  return {
    jobId: e.jobId,
    revision: e.revision,
    kind: e.kind,
    status: t === "cancelled" ? "cancelled" : "unavailable",
    reason: t,
    inputBytes: e.bytes?.byteLength ?? 0,
    extractedTextBytes: null,
    pages: null,
    textParts: null,
    tokens: null,
    scope: "extracted_file_text",
    tokenizerProfile: null,
    tokenizerAssetHash: null,
    evidence: "unknown",
    modelExactness: "unverified",
    extractionProfile: Ho,
    coverage: "unavailable",
    missing: [
      "provider_processing",
      "ocr",
      "image_encoding",
      "retrieval_selection"
    ],
    association: "unassociated",
    telemetryAllowed: !1
  };
}
function ae(e) {
  if (e?.aborted) throw new T("cancelled");
}
class Wh {
  pieces = [];
  size = 0;
  append(t) {
    if (this.size += new TextEncoder().encode(t).byteLength, this.size > ne.textBytes) throw new T("text_limit");
    this.pieces.push(t);
  }
  finish() {
    return this.pieces.join("");
  }
}
const Kh = new Uint32Array(256).map((e, t) => {
  for (let n = 0; n < 8; n++) t = t & 1 ? 3988292384 ^ t >>> 1 : t >>> 1;
  return t >>> 0;
}), dr = (e) => {
  try {
    return new TextDecoder("utf-8", { fatal: !0 }).decode(e);
  } catch {
    throw new T("invalid_utf8");
  }
};
function Vo(e) {
  if (e[0] === 208 && e[1] === 207)
    throw new T("unsupported_file");
  const t = new DataView(e.buffer, e.byteOffset, e.byteLength);
  let n = -1;
  for (let f = e.length - 22; f >= Math.max(0, e.length - 65557); f--)
    if (t.getUint32(f, !0) === 101010256 && f + 22 + t.getUint16(f + 20, !0) === e.length) {
      n = f;
      break;
    }
  if (n < 0) throw new T("truncated_file");
  const i = t.getUint16(n + 10, !0), s = t.getUint32(n + 16, !0), r = t.getUint32(n + 12, !0);
  if (i > ne.zipEntries || i === 65535 || s === 4294967295 || r === 4294967295)
    throw new T("zip_limit");
  if (t.getUint16(n + 4, !0) || t.getUint16(n + 6, !0) || t.getUint16(n + 8, !0) !== i || s + r !== n)
    throw new T("unsupported_file");
  const o = [], a = /* @__PURE__ */ new Set();
  let l = s, c = 0;
  for (let f = 0; f < i; f++) {
    if (l + 46 > n || t.getUint32(l, !0) !== 33639248)
      throw new T("malformed_file");
    const u = t.getUint16(l + 28, !0), m = t.getUint16(l + 30, !0), h = t.getUint16(l + 32, !0);
    if (l + 46 + u + m + h > n)
      throw new T("truncated_file");
    const p = {
      name: dr(e.subarray(l + 46, l + 46 + u)),
      flags: t.getUint16(l + 8, !0),
      method: t.getUint16(l + 10, !0),
      crc: t.getUint32(l + 16, !0),
      size: t.getUint32(l + 20, !0),
      expanded: t.getUint32(l + 24, !0),
      offset: t.getUint32(l + 42, !0)
    };
    if (p.flags & 1) throw new T("encrypted_file");
    if (![0, 8].includes(p.method))
      throw new T("unsupported_file");
    if (!p.name || /[\\\x00-\x1f:]/.test(p.name) || p.name.startsWith("/") || p.name.split("/").includes("..") || a.has(p.name))
      throw new T("malformed_file");
    if (/vbaproject|vbaData|activex/i.test(p.name))
      throw new T("macros_unsupported");
    if (a.add(p.name), c += p.expanded, p.expanded > ne.zipEntryBytes || c > ne.zipExpandedBytes || p.expanded > Math.max(1, p.size) * ne.zipRatio)
      throw new T("zip_limit");
    if (p.offset + 30 > s || t.getUint32(p.offset, !0) !== 67324752 || t.getUint16(p.offset + 6, !0) !== p.flags || t.getUint16(p.offset + 8, !0) !== p.method)
      throw new T("malformed_file");
    const y = t.getUint16(p.offset + 26, !0), x = t.getUint16(p.offset + 28, !0);
    if (dr(
      e.subarray(p.offset + 30, p.offset + 30 + y)
    ) !== p.name)
      throw new T("malformed_file");
    if (p.offset += 30 + y + x, p.offset + p.size > s)
      throw new T("truncated_file");
    o.push(p), l += 46 + u + m + h;
  }
  if (l !== n) throw new T("malformed_file");
  return o;
}
async function ft(e, t, n) {
  let i = 0, s = 4294967295;
  const r = new TextDecoder("utf-8", { fatal: !0 }), o = [];
  function a(f, u) {
    if (i += f.length, i > t.expanded || i > ne.zipEntryBytes)
      throw new T("zip_limit");
    for (const m of f)
      s = s >>> 8 ^ Kh[(s ^ m) & 255];
    try {
      o.push(r.decode(f, { stream: !u }));
    } catch {
      throw new T("invalid_utf8");
    }
  }
  const l = e.subarray(t.offset, t.offset + t.size), c = t.method === 8 ? new Rh(a) : null;
  for (let f = 0; f < l.length || f === 0; f += 1024) {
    ae(n);
    const u = l.subarray(f, f + 1024), m = f + 1024 >= l.length;
    c ? c.push(u, m) : a(u, m), f % 32768 === 0 && await new Promise((h) => setTimeout(h, 0));
  }
  if (i !== t.expanded || (s ^ 4294967295) >>> 0 !== t.crc)
    throw new T("malformed_file");
  return o.join("");
}
function xi() {
  const e = new qh.SaxesParser({ xmlns: !0, position: !1 });
  return e.on("doctype", () => {
    throw new T("unsafe_xml");
  }), e.on("error", () => {
    throw new T("malformed_file");
  }), e;
}
async function Vh(e, t, n) {
  const i = Vo(e), s = i.find(
    (c) => c.name === "[Content_Types].xml"
  );
  if (!s || !i.some((c) => c.name === "word/document.xml"))
    throw new T("unsupported_file");
  let r = !1, o = 0;
  const a = xi();
  if (a.on("opentag", (c) => {
    if (++o > ne.xmlDepth) throw new T("zip_limit");
    const f = c.attributes.ContentType?.value;
    if (f?.includes("macroEnabled"))
      throw new T("macros_unsupported");
    c.attributes.PartName?.value === "/word/document.xml" && f === "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml" && (r = !0);
  }), a.on("closetag", () => {
    o--;
  }), a.write(await ft(e, s, n)).close(), !r) throw new T("unsupported_file");
  const l = i.filter(
    (c) => /^word\/(document|header\d+|footer\d+|footnotes|endnotes)\.xml$/.test(
      c.name
    )
  ).sort(
    (c, f) => c.name === "word/document.xml" ? -1 : f.name === "word/document.xml" ? 1 : c.name.localeCompare(f.name, "en")
  );
  for (const c of l) {
    ae(n);
    const f = await ft(e, c, n), u = xi();
    let m = 0, h = 0, p = 0;
    const y = [];
    u.on("opentag", (k) => {
      if (++m > ne.xmlDepth) throw new T("zip_limit");
      if ([
        "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
        "http://purl.oclc.org/ooxml/wordprocessingml/main"
      ].includes(k.uri)) {
        if (k.local === "r" && y.push({ depth: m, hidden: !1 }), k.local === "vanish" && y.length) {
          const j = Object.values(k.attributes).find(
            (se) => se.local === "val"
          )?.value;
          ["0", "false", "off"].includes(j ?? "true") || (y[y.length - 1].hidden = !0);
        }
        ["del", "moveFrom"].includes(k.local) && !p && (p = m), k.local === "t" && !p && (h = m), ["tab", "br", "cr"].includes(k.local) && !p && !y.at(-1)?.hidden && t.append(k.local === "tab" ? "	" : `
`);
      }
    });
    const x = (k) => {
      h && !p && !y.at(-1)?.hidden && t.append(k);
    };
    u.on("text", x), u.on("cdata", x), u.on("closetag", (k) => {
      m === h && (h = 0), m === p && (p = 0), k.local === "p" && !p && t.append(`
`), y.at(-1)?.depth === m && y.pop(), m--;
    });
    for (let k = 0; k < f.length; k += 16384)
      ae(n), u.write(f.slice(k, k + 16384)), await new Promise((N) => setTimeout(N, 0));
    u.close(), t.append(`
`);
  }
  return l.length;
}
async function Jh(e, t, n, i) {
  if (!new TextDecoder("latin1").decode(e.subarray(0, 8)).startsWith("%PDF-")) throw new T("unsupported_file");
  const r = new TextDecoder("latin1").decode(
    e.subarray(Math.max(0, e.length - 1024))
  );
  if (!/%%EOF\s*$/.test(r)) throw new T("truncated_file");
  const o = await import("./pdf-BL_IY-hq.js");
  ae(n);
  const a = i ? new Worker(i, { type: "module" }) : null, l = a ? o.PDFWorker.create({ port: a, verbosity: 0 }) : void 0;
  let c = !1;
  class f {
    async fetch() {
      throw c = !0, new Error("external_document_resources_disabled");
    }
  }
  const u = o.getDocument({
    data: e,
    worker: l,
    verbosity: 0,
    stopAtErrors: !0,
    enableXfa: !1,
    disableFontFace: !0,
    useSystemFonts: !1,
    useWorkerFetch: !1,
    useWasm: !1,
    isOffscreenCanvasSupported: !1,
    isImageDecoderSupported: !1,
    maxImageSize: 0,
    disableAutoFetch: !0,
    disableStream: !0,
    disableRange: !0,
    BinaryDataFactory: f
  }), m = () => {
    u.destroy().catch(() => {
    });
  };
  n?.addEventListener("abort", m, { once: !0 });
  try {
    const h = await u.promise;
    if (ae(n), await h.getPermissions() !== null)
      throw new T("encrypted_file");
    if (h.numPages > ne.pages)
      throw new T("page_limit");
    for (let p = 1; p <= h.numPages; p++) {
      ae(n);
      const y = await h.getPage(p), x = y.streamTextContent({ disableNormalization: !0 }).getReader();
      try {
        for (; ; ) {
          ae(n);
          const { value: k, done: N } = await x.read();
          if (N) break;
          for (const j of k.items)
            "str" in j && (t.append(j.str), j.hasEOL && t.append(`
`));
        }
      } finally {
        await x.cancel().catch(() => {
        }), y.cleanup();
      }
      t.append(`
`);
    }
    if (!t.finish().trim()) throw new T("no_extractable_text");
    return { pages: h.numPages, externalFontMapping: c };
  } catch (h) {
    throw ae(n), h instanceof T ? h : h && typeof h == "object" && "name" in h && h.name === "PasswordException" ? new T("encrypted_file") : new T("malformed_file");
  } finally {
    n?.removeEventListener("abort", m), await u.destroy().catch(() => {
    }), l?.destroy(), a?.terminate();
  }
}
async function fn(e, t, n) {
  const i = xi();
  let s = 0;
  i.on("opentag", (r) => {
    if (++s > ne.xmlDepth) throw new T("zip_limit");
    t.open?.(r);
  }), i.on("text", (r) => t.text?.(r)), i.on("cdata", (r) => t.text?.(r)), i.on("closetag", (r) => {
    t.close?.(r), s--;
  });
  for (let r = 0; r < e.length; r += 16384)
    ae(n), i.write(e.slice(r, r + 16384)), await new Promise((o) => setTimeout(o, 0));
  i.close();
}
async function Xh(e, t, n, i) {
  const s = Vo(e), r = s.find((h) => h.name === "[Content_Types].xml"), o = t === "xlsx" ? "xl/workbook.xml" : "ppt/presentation.xml";
  if (!r || !s.some((h) => h.name === o))
    throw new T("unsupported_file");
  const a = t === "xlsx" ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml" : "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml";
  let l = !1;
  if (await fn(
    await ft(e, r, i),
    {
      open(h) {
        const p = h.attributes.ContentType?.value;
        if (p?.includes("macroEnabled"))
          throw new T("macros_unsupported");
        h.attributes.PartName?.value === "/" + o && p === a && (l = !0);
      }
    },
    i
  ), !l) throw new T("unsupported_file");
  if (t === "pptx") {
    const h = s.filter((p) => /^ppt\/slides\/slide\d+\.xml$/.test(p.name)).sort((p, y) => p.name.localeCompare(y.name, "en", { numeric: !0 }));
    if (!h.length) throw new T("no_extractable_text");
    if (h.length > ne.pages) throw new T("page_limit");
    for (const p of h) {
      let y = !1;
      await fn(
        await ft(e, p, i),
        {
          open(x) {
            y = x.local === "t" && [
              "http://schemas.openxmlformats.org/drawingml/2006/main",
              "http://purl.oclc.org/ooxml/drawingml/main"
            ].includes(x.uri);
          },
          text(x) {
            y && n.append(x);
          },
          close(x) {
            x.local === "t" && (y = !1), x.local === "p" && n.append(`
`);
          }
        },
        i
      ), n.append(`
`);
    }
    return h.length;
  }
  const c = [], f = s.find((h) => h.name === "xl/sharedStrings.xml");
  if (f) {
    let h = "", p = !1, y = !1;
    await fn(
      await ft(e, f, i),
      {
        open(x) {
          x.local === "si" && (h = ""), x.local === "rPh" && (y = !0), x.local === "t" && (p = !0);
        },
        text(x) {
          p && !y && (h += x);
        },
        close(x) {
          if (x.local === "t" && (p = !1), x.local === "rPh" && (y = !1), x.local === "si") {
            if (c.length >= ne.cells)
              throw new T("zip_limit");
            c.push(h);
          }
        }
      },
      i
    );
  }
  const u = s.filter((h) => /^xl\/worksheets\/sheet\d+\.xml$/.test(h.name)).sort((h, p) => h.name.localeCompare(p.name, "en", { numeric: !0 }));
  if (!u.length) throw new T("no_extractable_text");
  if (u.length > ne.sheets) throw new T("page_limit");
  let m = 0;
  for (const h of u) {
    let p = !1, y = !1, x = "", k = "";
    await fn(
      await ft(e, h, i),
      {
        open(N) {
          if (N.local === "c") {
            if (++m > ne.cells) throw new T("zip_limit");
            p = !0, x = N.attributes.t?.value ?? "n", k = "";
          }
          p && (N.local === "v" || x === "inlineStr" && N.local === "t") && (y = !0);
        },
        text(N) {
          y && (k += N);
        },
        close(N) {
          if ((N.local === "v" || N.local === "t") && (y = !1), N.local === "c") {
            if (x === "s") {
              if (!/^[0-9]{1,6}$/.test(k) || Number(k) >= c.length)
                throw new T("malformed_file");
              k = c[Number(k)];
            }
            n.append(k + "	"), p = !1;
          }
          N.local === "row" && n.append(`
`);
        }
      },
      i
    ), n.append(`
`);
  }
  return u.length;
}
async function Gh(e, t = {}) {
  Wo(e);
  const n = e.bytes.byteLength;
  try {
    ae(t.signal);
    const i = new Uint8Array(e.bytes), s = new Wh();
    let r = null, o = 1, a = !1;
    if (e.kind === "text") {
      const p = new TextDecoder("utf-8", { fatal: !0 });
      for (let y = 0; y < i.length || y === 0; y += 16384) {
        ae(t.signal);
        try {
          s.append(
            p.decode(i.subarray(y, y + 16384), {
              stream: y + 16384 < i.length
            })
          );
        } catch (x) {
          throw x instanceof T ? x : new T("invalid_utf8");
        }
        await new Promise((x) => setTimeout(x, 0));
      }
    } else if (e.kind === "docx")
      o = await Vh(i, s, t.signal);
    else if (e.kind === "xlsx" || e.kind === "pptx")
      o = await Xh(i, e.kind, s, t.signal), e.kind === "pptx" && (r = o);
    else {
      const p = await Jh(
        i,
        s,
        t.signal,
        t.pdfWorkerSrc
      );
      r = p.pages, o = p.pages, a = p.externalFontMapping;
    }
    ae(t.signal);
    const l = s.finish();
    if (e.kind !== "text" && !l.trim())
      throw new T("no_extractable_text");
    const c = t.tokenizer ?? Xi, f = Hh(e), u = Ro(c, f.profileId);
    if (c.id !== f.implementationId || !u)
      throw new T("tokenizer_unavailable");
    const m = {
      text: l,
      jobId: e.jobId,
      revision: e.revision,
      modelId: null,
      profileId: f.profileId
    }, h = await Eh(m, c);
    if (ae(t.signal), h.status !== "counted" || !mh(h, m, u))
      throw new T("tokenizer_unavailable");
    return {
      jobId: e.jobId,
      revision: e.revision,
      kind: e.kind,
      status: "counted",
      reason: null,
      inputBytes: n,
      extractedTextBytes: s.size,
      pages: r,
      textParts: o,
      tokens: h.measurement.value,
      scope: "extracted_file_text",
      tokenizerProfile: h.profileId,
      tokenizerAssetHash: h.assetHash,
      evidence: "heuristic_estimate",
      modelExactness: "unverified",
      extractionProfile: Ho,
      coverage: "complete_for_extraction_profile",
      missing: [
        "provider_processing",
        "ocr",
        "image_encoding",
        "retrieval_selection",
        ...e.kind !== "text" ? ["layout_and_drawing_text", "rendered_visibility"] : [],
        ...e.kind === "xlsx" ? ["formula_recalculation"] : [],
        ...a ? ["external_font_mapping"] : []
      ],
      association: "unassociated",
      telemetryAllowed: !1
    };
  } catch (i) {
    return {
      ...Ko(
        e,
        i instanceof T ? i.code : "malformed_file"
      ),
      inputBytes: n
    };
  }
}
var Yh = "/assets/pdf-worker-BKUmZ-vi.js";
const Qh = Xi;
class em {
  constructor(t, n = Qh, i = Yh) {
    this.post = t, this.tokenizer = n, this.pdfSource = i;
  }
  post;
  tokenizer;
  pdfSource;
  active = null;
  disposed = !1;
  async receive(t) {
    if (this.disposed) return;
    if (t && typeof t == "object" && "cancel" in t) {
      const r = t, o = Object.keys(r).sort().join(",");
      (o === "cancel" || o === "cancel,revision") && typeof r.cancel == "string" && (r.revision === void 0 || Number.isSafeInteger(r.revision) && r.revision === this.active?.job.revision) && this.active && r.cancel === this.active.job.jobId && this.active.abort.abort();
      return;
    }
    const n = t;
    try {
      Wo(n);
    } catch {
      return;
    }
    if (this.active) {
      this.post(Ko(n, "busy"));
      return;
    }
    const i = new AbortController(), s = { job: n, abort: i };
    this.active = s;
    try {
      const r = await Gh(n, {
        signal: i.signal,
        pdfWorkerSrc: this.pdfSource,
        tokenizer: this.tokenizer
      });
      !this.disposed && this.active === s && this.post(r);
    } finally {
      this.active === s && (this.active = null);
    }
  }
  dispose() {
    this.disposed = !0, this.active?.abort.abort();
  }
}
const tm = new em((e) => self.postMessage(e));
self.onmessage = (e) => tm.receive(e.data);
