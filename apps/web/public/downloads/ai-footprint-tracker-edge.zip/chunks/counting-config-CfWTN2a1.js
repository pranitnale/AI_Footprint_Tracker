import{c as E,i as I,B as N}from"./types-CBXiF5R7.js";const _=N,t=E(_,I);export{t as P};
