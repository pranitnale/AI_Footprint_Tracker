function Jt(e) {
  const t = Object.values(e).filter((i) => typeof i == "number");
  return Object.entries(e).filter(([i, o]) => t.indexOf(+i) === -1).map(([i, o]) => o);
}
function jn(e, t = "|") {
  return e.map((n) => Ci(n)).join(t);
}
function Ht(e, t) {
  return typeof t == "bigint" ? t.toString() : t;
}
class dr {
  constructor(t) {
    this._getter = t, this._value = void 0;
  }
  get value() {
    const t = this._getter;
    return t !== void 0 && (this._value = t(), this._getter = void 0), this._value;
  }
}
function gt(e) {
  return new dr(e);
}
function pr(e) {
  return e == null;
}
function sn(e) {
  const t = e.startsWith("^") ? 1 : 0, n = e.endsWith("$") ? e.length - 1 : e.length;
  return e.slice(t, n);
}
function fr(e, t) {
  const n = e / t, i = Math.round(n), o = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
  return Math.abs(n - i) < o ? 0 : n - i;
}
function re(e, t, n) {
  Object.defineProperty(e, t, {
    value: n,
    writable: !0,
    enumerable: !0,
    configurable: !0
  });
}
function an(e) {
  const t = Object.getOwnPropertyDescriptor(e, "shape");
  return t?.get ? t.get.raw : t?.value;
}
function oe(e) {
  return an(e._zod.def) ?? e._zod.def.shape;
}
function Ai(e, t, n) {
  Object.defineProperty(e, t, {
    get() {
      const i = n();
      return re(this, t, i), i;
    },
    enumerable: !0,
    configurable: !0
  });
}
function Ni(e, t, n) {
  t in e ? re(e, t, n) : e[t] = n;
}
function ye(e, t, n, i) {
  const o = oe(t);
  for (const r of n) {
    const s = Object.getOwnPropertyDescriptor(o, r);
    s.enumerable && (s.get ? Ai(e, r, () => {
      const a = t._zod.def.shape[r];
      return i ? i(a, r) : a;
    }) : Ni(e, r, i ? i(s.value, r) : s.value));
  }
}
function mr(e, t) {
  for (const n of Reflect.ownKeys(t)) {
    const i = Object.getOwnPropertyDescriptor(t, n);
    i.enumerable && (i.get ? Ai(e, n, () => t[n]) : Ni(e, n, i.value));
  }
}
function U(...e) {
  const t = {};
  for (const n of e) {
    const i = Object.getOwnPropertyDescriptors(n);
    Object.assign(t, i);
  }
  return Object.defineProperties({}, t);
}
function hr(e) {
  return JSON.stringify(e);
}
function _r(e) {
  return e.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
const ji = "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {
};
function Le(e) {
  return typeof e == "object" && e !== null && !Array.isArray(e);
}
const gr = /* @__PURE__ */ gt(() => {
  if (J.jitless || typeof navigator < "u" && navigator?.userAgent?.includes("Cloudflare"))
    return !1;
  try {
    const e = Function;
    return new e(""), !0;
  } catch {
    return !1;
  }
});
function xe(e) {
  if (Le(e) === !1)
    return !1;
  const t = e.constructor;
  if (t === void 0 || typeof t != "function")
    return !0;
  const n = t.prototype;
  return !(Le(n) === !1 || Object.prototype.hasOwnProperty.call(n, "isPrototypeOf") === !1);
}
function Ri(e) {
  return xe(e) ? { ...e } : Array.isArray(e) ? [...e] : e instanceof Map ? new Map(e) : e instanceof Set ? new Set(e) : e;
}
const br = /* @__PURE__ */ new Set(["string", "number", "symbol"]);
function Ie(e) {
  return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function he(e, t, n) {
  const i = new e._zod.constr(t ?? e._zod.def);
  return (!t || n?.parent) && (i._zod.parent = e), i;
}
function w(e) {
  const t = e;
  if (!t)
    return {};
  if (typeof t == "string")
    return { error: () => t };
  if (t?.message !== void 0) {
    if (t?.error !== void 0)
      throw new Error("Cannot specify both `message` and `error` params");
    t.error = t.message;
  }
  return delete t.message, typeof t.error == "string" ? { ...t, error: () => t.error } : t;
}
function Ci(e) {
  return typeof e == "bigint" ? e.toString() + "n" : typeof e == "string" ? `"${e}"` : `${e}`;
}
function yr(e) {
  return Object.keys(e).filter((t) => e[t]._zod.optin !== void 0 && e[t]._zod.optout === "optional");
}
const Di = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-34028234663852886e22, 34028234663852886e22],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}, vr = {
  int64: [/* @__PURE__ */ BigInt("-9223372036854775808"), /* @__PURE__ */ BigInt("9223372036854775807")],
  uint64: [/* @__PURE__ */ BigInt(0), /* @__PURE__ */ BigInt("18446744073709551615")]
};
function wr(e, t) {
  const n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  const r = {};
  return ye(r, e, bt(e, t)), he(e, U(n, { shape: r, checks: [] }));
}
function bt(e, t) {
  const n = oe(e), i = [];
  for (const o of Reflect.ownKeys(t)) {
    if (!Object.getOwnPropertyDescriptor(n, o)?.enumerable)
      throw new Error(`Unrecognized key: "${String(o)}"`);
    t[o] && i.push(o);
  }
  return i;
}
function kr(e, t) {
  const n = e._zod.def, i = n.checks;
  if (i && i.length > 0)
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  const r = new Set(bt(e, t)), s = {};
  return ye(s, e, Reflect.ownKeys(oe(e)).filter((a) => !r.has(a))), he(e, U(n, { shape: s, checks: [] }));
}
function zr(e, t) {
  if (!xe(t))
    throw new Error("Invalid input to extend: expected a plain object");
  const n = e._zod.def.checks;
  if (n && n.length > 0) {
    const o = oe(e);
    for (const r of Reflect.ownKeys(t))
      if (Object.getOwnPropertyDescriptor(o, r) !== void 0)
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
  }
  return he(e, U(e._zod.def, { shape: Mi(e, t) }));
}
function Mi(e, t) {
  const n = {};
  return ye(n, e, Reflect.ownKeys(oe(e))), mr(n, t), n;
}
function xr(e, t) {
  if (!xe(t))
    throw new Error("Invalid input to safeExtend: expected a plain object");
  return he(e, U(e._zod.def, { shape: Mi(e, t) }));
}
function Ir(e, t) {
  if (!t?._zod?.def)
    throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
  if (e._zod.def.checks?.length)
    throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
  const n = {};
  ye(n, e, Reflect.ownKeys(oe(e))), ye(n, t, Reflect.ownKeys(oe(t)));
  const i = U(e._zod.def, {
    shape: n,
    get catchall() {
      return t._zod.def.catchall;
    },
    checks: t._zod.def.checks ?? []
  });
  return he(e, i);
}
function Rn(e, t, n, i = "partial") {
  const r = t._zod.def.checks;
  if (r && r.length > 0)
    throw new Error(`.${i}() cannot be used on object schemas containing refinements`);
  const a = n ? new Set(bt(t, n)) : void 0, c = {};
  return ye(c, t, Reflect.ownKeys(oe(t)), e && ((u, l) => a && !a.has(l) ? u : new e({ type: "optional", innerType: u }))), he(t, U(t._zod.def, { shape: c, checks: [] }));
}
function Sr(e, t, n) {
  const i = n ? new Set(bt(t, n)) : void 0, o = {};
  return ye(o, t, Reflect.ownKeys(oe(t)), (r, s) => (
    // overwrite with non-optional
    i && !i.has(s) ? r : new e({ type: "nonoptional", innerType: r })
  )), he(t, U(t._zod.def, { shape: o }));
}
function V(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue !== !0)
      return !0;
  return !1;
}
function Or(e, t = 0) {
  if (e.aborted === !0)
    return !0;
  for (let n = t; n < e.issues.length; n++)
    if (e.issues[n]?.continue === !1)
      return !0;
  return !1;
}
function ue(e, t) {
  return t.map((n) => {
    var i;
    return (i = n).path ?? (i.path = []), n.path.unshift(e), n;
  });
}
function Ne(e) {
  return typeof e == "string" ? e : e?.message;
}
function Cn(e) {
  const t = [];
  for (const n of e ?? []) {
    const i = n._zod.def;
    if (!/_(length|size)$|_equals$/.test(i.check))
      break;
    const o = i.maximum ?? i.length ?? i.size;
    o >= 0 && t.push([o, n]);
  }
  return t;
}
function Kt(e, t, n) {
  var i;
  for (let o = t; o < e.length; o++)
    (i = e[o]).schema ?? (i.schema = n);
}
function pe(e, t, n) {
  var i;
  const o = e.inst?._zod?.traits;
  o?.has("$ZodType") && (o.has("$ZodCheck") ? (i = e).schema ?? (i.schema = e.inst) : e.schema = e.inst);
  const r = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0, s = e.message ? e.message : Ne(e.inst?._zod.def?.error?.(e)) ?? Ne(r?.(e)) ?? Ne(t?.error?.(e)) ?? Ne(n.customError?.(e)) ?? Ne(n.localeError?.(e)) ?? "Invalid input", a = {};
  for (const c of Object.keys(e))
    c === "inst" || c === "schema" || c === "continue" || c === "input" || c === "__proto__" || (a[c] = e[c]);
  return a.path ?? (a.path = []), a.message = s, t?.reportInput && (a.input = e.input), a;
}
const $r = /[\uD800-\uDBFF]/;
function cn(e) {
  const t = e.length;
  if (!$r.test(e))
    return t;
  let n = t;
  for (let i = 0; i < t - 1; i++)
    (e.charCodeAt(i) & 64512) === 55296 && (e.charCodeAt(i + 1) & 64512) === 56320 && (n--, i++);
  return n;
}
function un(e) {
  return Array.isArray(e) ? "array" : typeof e == "string" ? "string" : "unknown";
}
function Er(e) {
  const t = typeof e;
  switch (t) {
    case "number":
      return Number.isNaN(e) ? "nan" : "number";
    case "object": {
      if (e === null)
        return "null";
      if (Array.isArray(e))
        return "array";
      const n = e;
      if (n && Object.getPrototypeOf(n) !== Object.prototype && "constructor" in n && n.constructor)
        return n.constructor.name;
    }
  }
  return t;
}
function qe(...e) {
  const [t, n, i] = e;
  return typeof t == "string" ? {
    message: t,
    code: "custom",
    input: n,
    inst: i
  } : { ...t };
}
function Tr(e, t) {
  for (const n in t) {
    const i = Object.getOwnPropertyDescriptor(t, n);
    i.get ? Object.defineProperty(e, n, { ...i, enumerable: !1 }) : Pr(e, n, i.value);
  }
}
function fe(e, t, n, i = !0) {
  return Object.defineProperty(e, t, { configurable: !0, writable: !0, enumerable: i, value: n }), n;
}
function Fi(e, t, n) {
  return fe(e, t, n, !1);
}
function Ui(e, t) {
  for (const n in e) {
    const i = e[n];
    Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      get() {
        return fe(this, n, i(this));
      },
      set(o) {
        fe(this, n, o);
      }
    });
  }
  return t;
}
function Pr(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    get() {
      return this == null ? n : fe(this, t, n.bind(this));
    },
    set(i) {
      fe(this, t, i);
    }
  });
}
function Zr(e, t) {
  const n = Object.getPrototypeOf(e);
  return t in n ? void 0 : n;
}
let Tt, ce = !1;
const Ar = {
  configurable: !0,
  get() {
    ce = !0;
  }
};
function $(e, t, n) {
  const i = Object.getPrototypeOf(e._zod);
  if (t in i && Tt !== e._zod) {
    Tt = void 0;
    return;
  }
  Tt = e._zod, Object.defineProperty(i, t, {
    configurable: !0,
    get() {
      Object.defineProperty(this, t, Ar);
      const o = ce;
      ce = !1;
      try {
        const r = n(this);
        return ce ? delete this[t] : Object.defineProperty(this, t, { configurable: !0, writable: !0, value: r }), ce = ce || o, r;
      } catch (r) {
        throw delete this[t], ce = ce || o, r;
      }
    },
    set(o) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, value: o });
    }
  });
}
function Nr(e, t, n, i) {
  const o = Zr(e, t);
  o && Object.defineProperty(o, t, {
    configurable: !0,
    get() {
      const r = { configurable: !0, writable: !0, enumerable: i, value: void 0 };
      return Object.defineProperty(this, t, r), r.value = n(this), Object.defineProperty(this, t, r), r.value;
    },
    set(r) {
      Object.defineProperty(this, t, { configurable: !0, writable: !0, enumerable: i, value: r });
    }
  });
}
const jr = "~constantCatch";
function Rr(e) {
  const t = () => e;
  return t[jr] = !0, t;
}
var Dn;
const Pt = { value: void 0, enumerable: !1 };
let Mn = "captureStackTrace" in Error ? Error : null;
function Cr(e) {
  const t = Mn;
  if (t) {
    const n = t.stackTraceLimit;
    if (typeof n == "number") {
      try {
        t.stackTraceLimit = 0;
      } catch {
        return Mn = null, new e();
      }
      try {
        return new e();
      } finally {
        t.stackTraceLimit = n;
      }
    }
  }
  return new e();
}
function p(e, t, n, i) {
  const o = {};
  function r(m) {
    this.def = m, this.constr = d, this.traits = /* @__PURE__ */ new Set();
  }
  r.prototype = o;
  const s = n, a = s && /* @__PURE__ */ new WeakSet();
  function c(m, f) {
    if (m._zod) {
      if (m._zod.traits.has(e))
        return;
    } else {
      Pt.value = new r(f);
      try {
        Object.defineProperty(m, "_zod", Pt);
      } finally {
        Pt.value = void 0;
      }
    }
    if (m._zod.traits.add(e), t(m, f), a) {
      const v = Object.getPrototypeOf(m), z = m._zod.constr.prototype;
      let O = v;
      for (; O && O !== z; )
        O = Object.getPrototypeOf(O);
      const D = O ?? v;
      a.has(D) || (a.add(D), Tr(D, s));
    }
    const _ = d.prototype;
    for (const v in _)
      Object.prototype.hasOwnProperty.call(_, v) && (v in m || (m[v] = _[v].bind(m)));
  }
  const u = i?.Parent ?? Object;
  class l extends u {
  }
  Object.defineProperty(l, "name", { value: e });
  function d(m) {
    const f = i?.Parent ? Cr(l) : this;
    c(f, m);
    const _ = f._zod.deferred;
    if (_) {
      for (const z of _)
        z();
      f._zod.deferred = void 0;
    }
    const v = globalThis.__zod_globalConfig?.postProcessor;
    return v && v(f), f;
  }
  return Object.defineProperty(d, "init", { value: c }), Object.defineProperty(d, Symbol.hasInstance, {
    value: (m) => i?.Parent && m instanceof i.Parent ? !0 : m?._zod?.traits?.has(e)
  }), Object.defineProperty(d, "name", { value: e }), d;
}
class ge extends Error {
  constructor() {
    super("Encountered Promise during synchronous parse. Use .parseAsync() instead.");
  }
}
class Li extends Error {
  constructor(t) {
    super(`Encountered unidirectional transform during encode: ${t}`), this.name = "ZodEncodeError";
  }
}
(Dn = globalThis).__zod_globalConfig ?? (Dn.__zod_globalConfig = {});
const J = globalThis.__zod_globalConfig;
function X(e) {
  return e && Object.assign(J, e), J;
}
function Dr() {
  const e = this._zod;
  return e.message ?? (e.message = JSON.stringify(e.def, Ht, 2)), e.message;
}
function Mr(e) {
  this._zod.message = e;
}
const Fr = {
  get: Dr,
  set: Mr,
  enumerable: !0,
  configurable: !0
}, Zt = { value: void 0, enumerable: !1 }, Fn = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]), Ur = (e, t) => {
  e.name = "$ZodError", Zt.value = t, Object.defineProperty(e, "issues", Zt), Zt.value = void 0, Object.defineProperty(e, "message", Fr);
  const n = Object.getPrototypeOf(e);
  Fn.has(n) || (Fn.add(n), Object.defineProperty(n, "toString", {
    configurable: !0,
    enumerable: !1,
    get() {
      const i = () => this.message;
      return Object.defineProperty(this, "toString", { value: i, configurable: !0, writable: !0 }), i;
    },
    set(i) {
      Object.defineProperty(this, "toString", { value: i, configurable: !0, writable: !0 });
    }
  }));
}, Lr = p("$ZodError", Ur);
function qr(e, t, n) {
  return Object.prototype.hasOwnProperty.call(e, t) || (t === "__proto__" ? Object.defineProperty(e, t, { value: n(), writable: !0, enumerable: !0, configurable: !0 }) : e[t] = n()), e[t];
}
function Br(e, t = (n) => n.message) {
  const n = {}, i = [];
  for (const o of e.issues)
    o.path.length > 0 ? qr(n, o.path[0], () => []).push(t(o)) : i.push(t(o));
  return { formErrors: i, fieldErrors: n };
}
function Jr(e, t = (n) => n.message) {
  const n = { _errors: [] }, i = (o, r = []) => {
    for (const s of o.issues)
      if (s.code === "invalid_union" && s.errors.length)
        s.errors.map((a) => i({ issues: a }, [...r, ...s.path]));
      else if (s.code === "invalid_key")
        i({ issues: s.issues }, [...r, ...s.path]);
      else if (s.code === "invalid_element")
        i({ issues: s.issues }, [...r, ...s.path]);
      else {
        const a = [...r, ...s.path];
        if (a.length === 0)
          n._errors.push(t(s));
        else {
          let c = n, u = 0;
          for (; u < a.length; ) {
            const l = a[u], d = u === a.length - 1;
            if (l === "_errors") {
              d && c._errors.push(t(s)), u++;
              continue;
            }
            Object.prototype.hasOwnProperty.call(c, l) || Object.defineProperty(c, l, {
              value: { _errors: [] },
              enumerable: !0,
              writable: !0,
              configurable: !0
            });
            const m = c[l];
            d && m._errors.push(t(s)), c = m, u++;
          }
        }
      }
  };
  return i(e), n;
}
function yt(e, t) {
  return { callee: t?.callee ?? e, Err: t?.Err };
}
const ln = (e) => {
  const t = (n, i, o, r) => {
    const s = o ? { ...o, async: !1 } : { async: !1 }, a = n._zod.run({ value: i, issues: [] }, s);
    if (a instanceof Promise)
      throw new ge();
    if (a.issues.length) {
      const c = new (r?.Err ?? e)(a.issues.map((u) => pe(u, s, X())));
      throw ji(c, r?.callee ?? t), c;
    }
    return a.value;
  };
  return t;
}, dn = (e) => {
  const t = async (n, i, o, r) => {
    const s = o ? { ...o, async: !0 } : { async: !0 };
    let a = n._zod.run({ value: i, issues: [] }, s);
    if (a instanceof Promise && (a = await a), a.issues.length) {
      const c = new (r?.Err ?? e)(a.issues.map((u) => pe(u, s, X())));
      throw ji(c, r?.callee ?? t), c;
    }
    return a.value;
  };
  return t;
}, pn = (e) => (t, n, i) => {
  const o = i ? { ...i, async: !1 } : { async: !1 }, r = t._zod.run({ value: n, issues: [] }, o);
  if (r instanceof Promise)
    throw new ge();
  return r.issues.length ? qi(e, r.issues, o) : { success: !0, data: r.value };
};
function qi(e, t, n) {
  let i;
  return {
    success: !1,
    get error() {
      return i || (i = new e(t.map((o) => pe(o, n, X()))), t = void 0, n = void 0), i;
    },
    set error(o) {
      i = o, t = void 0, n = void 0;
    }
  };
}
const fn = (e) => async (t, n, i) => {
  const o = i ? { ...i, async: !0 } : { async: !0 };
  let r = t._zod.run({ value: n, issues: [] }, o);
  return r instanceof Promise && (r = await r), r.issues.length ? qi(e, r.issues, o) : { success: !0, data: r.value };
}, Hr = /* @__PURE__ */ Symbol.for("zod.compile.invalid"), Kr = /* @__PURE__ */ Symbol.for("zod.compile.fallback"), Vr = ((e, t, n) => {
  const i = e._zod.bag.validator;
  if (i !== void 0) {
    if (i(t) !== Hr)
      return !0;
    if (i.definite === !0 && n === void 0)
      return !1;
  }
  return Gr(e, t, n);
});
function Gr(e, t, n) {
  const i = n ? { ...n, async: !1, abortEarly: !0 } : { async: !1, abortEarly: !0 }, o = e._zod.bag.fallbackRun;
  let r;
  if (o ? (i[Kr] = !0, r = o({ value: t, issues: [] }, i)) : r = e._zod.run({ value: t, issues: [] }, i), r instanceof Promise)
    throw new ge();
  return r.issues.length === 0;
}
const Wr = async (e, t, n) => {
  const i = n ? { ...n, async: !0, abortEarly: !0 } : { async: !0, abortEarly: !0 };
  let o = e._zod.run({ value: t, issues: [] }, i);
  return o instanceof Promise && (o = await o), o.issues.length === 0;
}, Xr = (e) => {
  const t = ln(e), n = (i, o, r, s) => {
    const a = r ? { ...r, direction: "backward" } : { direction: "backward" };
    return t(i, o, a, yt(n, s));
  };
  return n;
}, Yr = (e) => {
  const t = ln(e), n = (i, o, r, s) => t(i, o, r, yt(n, s));
  return n;
}, Qr = (e) => {
  const t = dn(e), n = async (i, o, r, s) => {
    const a = r ? { ...r, direction: "backward" } : { direction: "backward" };
    return await t(i, o, a, yt(n, s));
  };
  return n;
}, es = (e) => {
  const t = dn(e), n = async (i, o, r, s) => await t(i, o, r, yt(n, s));
  return n;
}, ts = (e) => (t, n, i) => {
  const o = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return pn(e)(t, n, o);
}, ns = (e) => (t, n, i) => pn(e)(t, n, i), is = (e) => async (t, n, i) => {
  const o = i ? { ...i, direction: "backward" } : { direction: "backward" };
  return fn(e)(t, n, o);
}, os = (e) => async (t, n, i) => fn(e)(t, n, i), rs = /^[cC][0-9a-z]{6,}$/, ss = /^[0-9a-z]+$/, as = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/, cs = /^[0-9a-vA-V]{20}$/, us = /^[A-Za-z0-9]{27}$/, ls = /^[a-zA-Z0-9_-]{21}$/;
function ds(e) {
  return new RegExp(`^[a-zA-Z0-9_-]{${e}}$`);
}
const ps = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/, fs = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/, Un = (e) => e ? new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`) : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/, ms = /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/, hs = "^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$";
function _s() {
  return new RegExp(hs, "u");
}
const gs = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/, bs = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/, ys = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/, vs = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/, ws = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/, ks = /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/, zs = /^https?$/, xs = /^\+[1-9]\d{6,14}$/, Bi = "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
function Is(e) {
  return new RegExp(`^${e}$`);
}
const Ss = /* @__PURE__ */ Is(Bi);
function Vt(e) {
  const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
  return typeof e.precision == "number" ? e.precision === -1 ? `${t}` : e.precision === 0 ? `${t}:[0-5]\\d` : `${t}:[0-5]\\d\\.\\d{${e.precision}}` : e.seconds ? `${t}:[0-5]\\d(?:\\.\\d+)?` : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function Os(e) {
  return new RegExp(`^${Vt(e)}$`);
}
function $s(e) {
  const t = ["Z"];
  e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
  const n = `${Vt({ precision: e.precision, seconds: !0 })}(?:${t.join("|")})`, i = e.local ? `${n}|${Vt({ precision: e.precision })}` : n;
  return new RegExp(`^${Bi}T(?:${i})$`);
}
const Es = /^[\s\S]{0,}$/, Ts = /^-?\d+$/, mn = /^-?\d+(?:\.\d+)?$/, Ps = /^(?:true|false)$/i, Zs = /^null$/i, As = /^[^A-Z]*$/, Ns = /^[^a-z]*$/, M = /* @__PURE__ */ p("$ZodCheck", (e, t) => {
  var n;
  e._zod ?? (e._zod = {}), e._zod.def = t, (n = e._zod).onattach ?? (n.onattach = []);
}), hn = (e) => {
  const t = e.value;
  return !pr(t) && t.length !== void 0;
}, lt = {
  number: "number",
  bigint: "bigint",
  object: "date"
}, Ji = /* @__PURE__ */ p("$ZodCheckLessThan", (e, t) => {
  M.init(e, t);
  const n = lt[typeof t.value];
  e._zod.check = (i) => {
    (t.inclusive ? i.value <= t.value : i.value < t.value) || i.issues.push({
      origin: lt[typeof i.value] ?? n,
      code: "too_big",
      maximum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), Hi = /* @__PURE__ */ p("$ZodCheckGreaterThan", (e, t) => {
  M.init(e, t);
  const n = lt[typeof t.value];
  e._zod.check = (i) => {
    (t.inclusive ? i.value >= t.value : i.value > t.value) || i.issues.push({
      origin: lt[typeof i.value] ?? n,
      code: "too_small",
      minimum: typeof t.value == "object" ? t.value.getTime() : t.value,
      input: i.value,
      inclusive: t.inclusive,
      inst: e,
      continue: !t.abort
    });
  };
}), js = /* @__PURE__ */ p("$ZodCheckMultipleOf", (e, t) => {
  M.init(e, t), e._zod.check = (n) => {
    if (typeof n.value != typeof t.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    (typeof n.value == "bigint" ? (
      // `value % 0n` throws, and nothing is a multiple of zero — the number branch already fails this way via NaN
      t.value !== BigInt(0) && n.value % t.value === BigInt(0)
    ) : fr(n.value, t.value) === 0) || n.issues.push({
      origin: typeof n.value,
      code: "not_multiple_of",
      divisor: t.value,
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Rs = /* @__PURE__ */ p("$ZodCheckNumberFormat", (e, t) => {
  M.init(e, t), t.format = t.format || "float64";
  const n = t.format?.includes("int"), i = n ? "int" : "number", [o, r] = Di[t.format];
  e._zod.check = (s) => {
    const a = s.value;
    if (n) {
      if (!Number.isInteger(a)) {
        s.issues.push({
          expected: i,
          format: t.format,
          code: "invalid_type",
          continue: !1,
          input: a,
          inst: e
        });
        return;
      }
      if (!Number.isSafeInteger(a)) {
        a > 0 ? s.issues.push({
          input: a,
          code: "too_big",
          maximum: Number.MAX_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        }) : s.issues.push({
          input: a,
          code: "too_small",
          minimum: Number.MIN_SAFE_INTEGER,
          note: "Integers must be within the safe integer range.",
          inst: e,
          origin: i,
          inclusive: !0,
          continue: !t.abort
        });
        return;
      }
    }
    a < o && s.issues.push({
      origin: "number",
      input: a,
      code: "too_small",
      minimum: o,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    }), a > r && s.issues.push({
      origin: "number",
      input: a,
      code: "too_big",
      maximum: r,
      inclusive: !0,
      inst: e,
      continue: !t.abort
    });
  };
}), Cs = /* @__PURE__ */ p("$ZodCheckMaxLength", (e, t) => {
  var n;
  M.init(e, t), (n = e._zod.def).when ?? (n.when = hn), e._zod.check = (i) => {
    const o = i.value, r = o.length;
    if ((typeof o == "string" && r > t.maximum ? cn(o) : r) <= t.maximum)
      return;
    const a = un(o);
    i.issues.push({
      origin: a,
      code: "too_big",
      maximum: t.maximum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), Ds = /* @__PURE__ */ p("$ZodCheckMinLength", (e, t) => {
  var n;
  M.init(e, t), (n = e._zod.def).when ?? (n.when = hn), e._zod.check = (i) => {
    const o = i.value, r = o.length;
    if ((typeof o == "string" && r >= t.minimum && r < t.minimum * 2 ? cn(o) : r) >= t.minimum)
      return;
    const a = un(o);
    i.issues.push({
      origin: a,
      code: "too_small",
      minimum: t.minimum,
      inclusive: !0,
      input: o,
      inst: e,
      continue: !t.abort
    });
  };
}), Ms = /* @__PURE__ */ p("$ZodCheckLengthEquals", (e, t) => {
  var n;
  M.init(e, t), (n = e._zod.def).when ?? (n.when = hn), e._zod.check = (i) => {
    const o = i.value, r = o.length, s = typeof o == "string" && r >= t.length && r <= t.length * 2 ? cn(o) : r;
    if (s === t.length)
      return;
    const a = un(o), c = s > t.length;
    i.issues.push({
      origin: a,
      ...c ? { code: "too_big", maximum: t.length } : { code: "too_small", minimum: t.length },
      inclusive: !0,
      exact: !0,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), vt = /* @__PURE__ */ p("$ZodCheckStringFormat", (e, t) => {
  var n, i;
  M.init(e, t), t.pattern ? (n = e._zod).check ?? (n.check = (o) => {
    t.pattern.lastIndex = 0, !t.pattern.test(o.value) && o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: t.format,
      input: o.value,
      ...t.pattern ? { pattern: t.pattern.toString() } : {},
      inst: e,
      continue: !t.abort
    });
  }) : (i = e._zod).check ?? (i.check = () => {
  });
}), Fs = /* @__PURE__ */ p("$ZodCheckRegex", (e, t) => {
  vt.init(e, t), e._zod.check = (n) => {
    t.pattern.lastIndex = 0, !t.pattern.test(n.value) && n.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: n.value,
      pattern: t.pattern.toString(),
      inst: e,
      continue: !t.abort
    });
  };
}), Us = /* @__PURE__ */ p("$ZodCheckLowerCase", (e, t) => {
  t.pattern ?? (t.pattern = As), vt.init(e, t);
}), Ls = /* @__PURE__ */ p("$ZodCheckUpperCase", (e, t) => {
  t.pattern ?? (t.pattern = Ns), vt.init(e, t);
}), qs = /* @__PURE__ */ p("$ZodCheckIncludes", (e, t) => {
  M.init(e, t);
  const n = Ie(t.includes), i = new RegExp(typeof t.position == "number" ? `^.{${t.position},}${n}` : n);
  t.pattern = i, e._zod.check = (o) => {
    o.value.includes(t.includes, t.position) || o.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: t.includes,
      input: o.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Bs = /* @__PURE__ */ p("$ZodCheckStartsWith", (e, t) => {
  M.init(e, t);
  const n = new RegExp(`^${Ie(t.prefix)}.*`);
  t.pattern ?? (t.pattern = n), e._zod.check = (i) => {
    i.value.startsWith(t.prefix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: t.prefix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Js = /* @__PURE__ */ p("$ZodCheckEndsWith", (e, t) => {
  M.init(e, t);
  const n = new RegExp(`.*${Ie(t.suffix)}$`);
  t.pattern ?? (t.pattern = n), e._zod.check = (i) => {
    i.value.endsWith(t.suffix) || i.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: t.suffix,
      input: i.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Hs = /* @__PURE__ */ p("$ZodCheckOverwrite", (e, t) => {
  M.init(e, t), e._zod.check = (n) => {
    n.value = t.tx(n.value);
  };
});
class Ks {
  constructor(t = [], n = {}) {
    this.content = [], this.indent = 0, this.args = t, this.closed = n;
  }
  // the compiler catches a child's throw and keeps writing into this doc, so the indent has to unwind with it
  indented(t) {
    this.indent += 1;
    try {
      t(this);
    } finally {
      this.indent -= 1;
    }
  }
  write(t) {
    if (typeof t == "function") {
      t(this, { execution: "sync" }), t(this, { execution: "async" });
      return;
    }
    const i = t.split(`
`).filter((s) => s), o = Math.min(...i.map((s) => s.length - s.trimStart().length)), r = i.map((s) => s.slice(o)).map((s) => " ".repeat(this.indent * 2) + s);
    for (const s of r)
      this.content.push(s);
  }
  compile() {
    const t = Function, n = this?.content ?? [""];
    return new t(...Object.keys(this.closed), `return function (${this.args.join(", ")}) {
${n.join(`
`)}
};`)(...Object.values(this.closed));
  }
}
const Vs = {
  major: 4,
  minor: 6,
  patch: 7
}, E = /* @__PURE__ */ p("$ZodType", (e, t) => {
  var n;
  e ?? (e = {}), e._zod.def = t, e._zod.bag = e._zod.bag || {}, e._zod.version = Vs;
  const i = e._zod.def.checks, o = e._zod.traits.has("$ZodCheck") ? [e, ...i ?? []] : i?.length ? [...i] : [];
  for (const r of o)
    for (const s of r._zod.onattach)
      s(e);
  if (o.length === 0)
    (n = e._zod).deferred ?? (n.deferred = []), e._zod.deferred?.push(() => {
      e._zod.run = e._zod.parse;
    });
  else {
    const r = (a, c, u) => {
      if (a.memo)
        return a;
      let l = V(a), d;
      for (const m of c) {
        if (m._zod.def.when) {
          if (Or(a) || !m._zod.def.when(a))
            continue;
        } else if (l)
          continue;
        const f = a.issues.length, _ = m._zod.check(a);
        if (_ instanceof Promise && u?.async === !1)
          throw new ge();
        if (d || _ instanceof Promise)
          d = (d ?? Promise.resolve()).then(async () => {
            await _, a.issues.length !== f && (Kt(a.issues, f, e), l || (l = V(a, f)));
          });
        else {
          if (a.issues.length === f)
            continue;
          Kt(a.issues, f, e), l || (l = V(a, f));
        }
      }
      return d ? d.then(() => a) : a;
    }, s = (a, c, u) => {
      if (V(a))
        return a.aborted = !0, a;
      const l = r(c, o, u);
      if (l instanceof Promise) {
        if (u.async === !1)
          throw new ge();
        return l.then((d) => e._zod.parse(d, u));
      }
      return e._zod.parse(l, u);
    };
    e._zod.run = (a, c) => {
      if (c.skipChecks)
        return e._zod.parse(a, c);
      if (c.direction === "backward") {
        const l = e._zod.parse({ value: a.value, issues: [] }, { ...c, skipChecks: !0 });
        return l instanceof Promise ? l.then((d) => s(d, a, c)) : s(l, a, c);
      }
      const u = e._zod.parse(a, c);
      if (u instanceof Promise) {
        if (c.async === !1)
          throw new ge();
        return u.then((l) => r(l, o, c));
      }
      return r(u, o, c);
    };
  }
}, {
  // Wrappers extend this by installing a richer factory over it; reading it eagerly would defeat the laziness.
  get "~standard"() {
    return Fi(this, "~standard", Vi(this));
  },
  set "~standard"(e) {
    fe(this, "~standard", e);
  }
}), Ki = (e, t) => e.issues.length ? { issues: e.issues.map((n) => pe(n, t, X())) } : { value: e.value };
async function Gs(e, t) {
  const n = { async: !0 };
  return Ki(await e._zod.run({ value: t, issues: [] }, n), n);
}
function Vi(e) {
  return {
    validate: (t) => {
      const n = { async: !1 };
      try {
        const i = e._zod.run({ value: t, issues: [] }, n);
        if (!(i instanceof Promise))
          return Ki(i, n);
      } catch {
      }
      return Gs(e, t);
    },
    vendor: "zod",
    version: 1
  };
}
const _n = /* @__PURE__ */ p("$ZodString", (e, t) => {
  E.init(e, t), e._zod.pattern = t.pattern ?? Es, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = String(n.value);
      } catch {
      }
    return typeof n.value == "string" || n.issues.push({
      expected: "string",
      code: "invalid_type",
      input: n.value,
      inst: e
    }), n;
  };
}), A = /* @__PURE__ */ p("$ZodStringFormat", (e, t) => {
  vt.init(e, t), _n.init(e, t);
}), Ws = /* @__PURE__ */ p("$ZodGUID", (e, t) => {
  t.pattern ?? (t.pattern = fs), A.init(e, t);
}), Xs = /* @__PURE__ */ p("$ZodUUID", (e, t) => {
  if (t.version) {
    const i = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    }[t.version];
    if (i === void 0)
      throw new Error(`Invalid UUID version: "${t.version}"`);
    t.pattern ?? (t.pattern = Un(i));
  } else
    t.pattern ?? (t.pattern = Un());
  A.init(e, t);
}), Ys = /* @__PURE__ */ p("$ZodEmail", (e, t) => {
  t.pattern ?? (t.pattern = ms), A.init(e, t);
}), Gi = 1, dt = 2;
function Wi(e) {
  try {
    return typeof URL < "u" && typeof URL.canParse == "function" ? URL.canParse(e) : (new URL(e), !0);
  } catch {
    return !1;
  }
}
function Qs(e, t) {
  return !("normalize" in t) && !("hostname" in t) && !("protocol" in t) ? Wi(e) || dt : ea(e, t);
}
function ea(e, t) {
  if (!t.normalize && t.protocol?.source === zs.source && !/^https?:\/\//i.test(e))
    return Gi;
  try {
    if (typeof URL < "u") {
      const n = URL;
      if (typeof n.parse == "function")
        return n.parse(e) ?? dt;
    }
    return new URL(e);
  } catch {
    return dt;
  }
}
const ta = /[\t\n\r]/g;
function Ln(e) {
  return e.replace(ta, "");
}
function na(e, t) {
  return t.lastIndex = 0, t.test(e.hostname);
}
function ia(e, t) {
  return t.lastIndex = 0, t.test(e.protocol.endsWith(":") ? e.protocol.slice(0, -1) : e.protocol);
}
const oa = /* @__PURE__ */ p("$ZodURL", (e, t) => {
  A.init(e, t), e._zod.check = (n) => {
    try {
      const i = n.value.trim(), o = Qs(i, t);
      if (o === Gi) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          note: "Invalid URL format",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (o === dt) {
        n.issues.push({
          code: "invalid_format",
          format: "url",
          input: n.value,
          inst: e,
          continue: !t.abort
        });
        return;
      }
      if (o === !0) {
        n.value = Ln(i);
        return;
      }
      t.hostname && !na(o, t.hostname) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid hostname",
        pattern: t.hostname.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), t.protocol && !ia(o, t.protocol) && n.issues.push({
        code: "invalid_format",
        format: "url",
        note: "Invalid protocol",
        pattern: t.protocol.source,
        input: n.value,
        inst: e,
        continue: !t.abort
      }), n.value = t.normalize ? o.href : Ln(i);
      return;
    } catch {
      n.issues.push({
        code: "invalid_format",
        format: "url",
        input: n.value,
        inst: e,
        continue: !t.abort
      });
    }
  };
}), ra = /* @__PURE__ */ p("$ZodEmoji", (e, t) => {
  t.pattern ?? (t.pattern = _s()), A.init(e, t);
}), sa = /* @__PURE__ */ p("$ZodNanoID", (e, t) => {
  if (t.length !== void 0 && (!Number.isInteger(t.length) || t.length < 1))
    throw new Error(`Invalid nanoid length: ${t.length}`);
  t.pattern ?? (t.pattern = t.length === void 0 ? ls : ds(t.length)), A.init(e, t);
}), aa = /* @__PURE__ */ p("$ZodCUID", (e, t) => {
  t.pattern ?? (t.pattern = rs), A.init(e, t);
}), ca = /* @__PURE__ */ p("$ZodCUID2", (e, t) => {
  t.pattern ?? (t.pattern = ss), A.init(e, t);
}), ua = /* @__PURE__ */ p("$ZodULID", (e, t) => {
  t.pattern ?? (t.pattern = as), A.init(e, t);
}), la = /* @__PURE__ */ p("$ZodXID", (e, t) => {
  t.pattern ?? (t.pattern = cs), A.init(e, t);
}), da = /* @__PURE__ */ p("$ZodKSUID", (e, t) => {
  t.pattern ?? (t.pattern = us), A.init(e, t);
}), pa = /* @__PURE__ */ p("$ZodISODateTime", (e, t) => {
  t.pattern ?? (t.pattern = $s(t)), A.init(e, t);
}), fa = /* @__PURE__ */ p("$ZodISODate", (e, t) => {
  t.pattern ?? (t.pattern = Ss), A.init(e, t);
}), ma = /* @__PURE__ */ p("$ZodISOTime", (e, t) => {
  t.pattern ?? (t.pattern = Os(t)), A.init(e, t);
}), ha = /* @__PURE__ */ p("$ZodISODuration", (e, t) => {
  t.pattern ?? (t.pattern = ps), A.init(e, t);
}), _a = /* @__PURE__ */ p("$ZodIPv4", (e, t) => {
  t.pattern ?? (t.pattern = gs), A.init(e, t);
}), ga = /^[0-9a-fA-F:.]+$/;
function Xi(e) {
  return ga.test(e) ? Wi(`http://[${e}]`) : !1;
}
const ba = /* @__PURE__ */ p("$ZodIPv6", (e, t) => {
  t.pattern ?? (t.pattern = bs), A.init(e, t), e._zod.check = (n) => {
    Xi(n.value) || n.issues.push({
      code: "invalid_format",
      format: "ipv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), ya = /* @__PURE__ */ p("$ZodCIDRv4", (e, t) => {
  t.pattern ?? (t.pattern = ys), A.init(e, t);
});
function va(e) {
  const t = e.split("/");
  if (t.length !== 2)
    return !1;
  const [n, i] = t;
  if (!i)
    return !1;
  const o = Number(i);
  return `${o}` !== i || o < 0 || o > 128 ? !1 : Xi(n);
}
const wa = /* @__PURE__ */ p("$ZodCIDRv6", (e, t) => {
  t.pattern ?? (t.pattern = vs), A.init(e, t), e._zod.check = (n) => {
    va(n.value) || n.issues.push({
      code: "invalid_format",
      format: "cidrv6",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
});
function Yi(e) {
  if (e === "")
    return !0;
  if (/\s/.test(e) || e.length % 4 !== 0)
    return !1;
  try {
    return atob(e), !0;
  } catch {
    return !1;
  }
}
const Qi = /^[0-9a-zA-Z+/]*={0,2}$/, ka = /* @__PURE__ */ p("$ZodBase64", (e, t) => {
  t.pattern ?? (t.pattern = Qi), A.init(e, t), e._zod.check = (n) => {
    Yi(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), gn = /^[A-Za-z0-9_-]*$/;
function za(e) {
  if (!gn.test(e))
    return !1;
  const t = e.replace(/[-_]/g, (i) => i === "-" ? "+" : "/"), n = t.padEnd(Math.ceil(t.length / 4) * 4, "=");
  return Yi(n);
}
const xa = /* @__PURE__ */ p("$ZodBase64URL", (e, t) => {
  t.pattern ?? (t.pattern = gn), A.init(e, t), e._zod.check = (n) => {
    za(n.value) || n.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), Ia = /* @__PURE__ */ p("$ZodE164", (e, t) => {
  t.pattern ?? (t.pattern = xs), A.init(e, t);
});
function Sa(e, t = null) {
  try {
    const n = e.split(".");
    if (n.length !== 3)
      return !1;
    const [i] = n;
    if (!i)
      return !1;
    const o = JSON.parse(atob(i));
    return !("typ" in o && o?.typ !== "JWT" || !o.alg || t && (!("alg" in o) || o.alg !== t));
  } catch {
    return !1;
  }
}
const Oa = /* @__PURE__ */ p("$ZodJWT", (e, t) => {
  A.init(e, t), e._zod.check = (n) => {
    Sa(n.value, t.alg) || n.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: n.value,
      inst: e,
      continue: !t.abort
    });
  };
}), eo = /* @__PURE__ */ p("$ZodNumber", (e, t) => {
  E.init(e, t), e._zod.pattern = mn, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = Number(n.value);
      } catch {
      }
    const o = n.value;
    if (typeof o == "number" && !Number.isNaN(o) && Number.isFinite(o))
      return n;
    const r = typeof o == "number" ? Number.isNaN(o) ? "NaN" : Number.isFinite(o) ? void 0 : String(o) : void 0;
    return n.issues.push({
      expected: "number",
      code: "invalid_type",
      input: o,
      inst: e,
      ...r ? { received: r } : {}
    }), n;
  };
}), $a = /* @__PURE__ */ p("$ZodNumberFormat", (e, t) => {
  Rs.init(e, t), eo.init(e, t);
}), Ea = /* @__PURE__ */ p("$ZodBoolean", (e, t) => {
  E.init(e, t), e._zod.pattern = Ps, e._zod.parse = (n, i) => {
    if (t.coerce)
      try {
        n.value = !!n.value;
      } catch {
      }
    const o = n.value;
    return typeof o == "boolean" || n.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input: o,
      inst: e
    }), n;
  };
}), Ta = /* @__PURE__ */ p("$ZodNull", (e, t) => {
  E.init(e, t), e._zod.pattern = Zs, e._zod.values = /* @__PURE__ */ new Set([null]), e._zod.parse = (n, i) => {
    const o = n.value;
    return o === null || n.issues.push({
      expected: "null",
      code: "invalid_type",
      input: o,
      inst: e
    }), n;
  };
}), Pa = /* @__PURE__ */ p("$ZodUnknown", (e, t) => {
  E.init(e, t), e._zod.parse = (n) => n;
}), Za = /* @__PURE__ */ p("$ZodNever", (e, t) => {
  E.init(e, t), e._zod.parse = (n, i) => (n.issues.push({
    expected: "never",
    code: "invalid_type",
    input: n.value,
    inst: e
  }), n);
});
function Aa(e, t) {
  const n = Cn(e._zod.def.checks);
  if (!n.length)
    return;
  const i = Math.min(...n.map((r) => r[0])), o = e._zod.parse;
  e._zod.parse = (r, s) => {
    const a = t(r.value);
    if (a > i && !s?.skipChecks && s?.direction !== "backward") {
      for (const [c, u] of Cn(e._zod.def.checks))
        if (a > c && u._zod.def.when(r)) {
          const l = r.issues.length;
          return u._zod.check(r), r.issues[l].continue = !1, Kt(r.issues, l, e), r;
        }
    }
    return o(r, s);
  };
}
const Na = (e) => Array.isArray(e) ? e.length : -1;
function qn(e, t, n) {
  e.issues.length && t.issues.push(...ue(n, e.issues)), t.value[n] = e.value;
}
const ja = /* @__PURE__ */ p("$ZodArray", (e, t) => {
  E.init(e, t);
  const n = J.memoizer;
  n?.attach(e), e._zod.parse = (i, o) => {
    const r = i.value;
    if (!Array.isArray(r))
      return i.issues.push({
        expected: "array",
        code: "invalid_type",
        input: r,
        inst: e
      }), i;
    i.value = n ? n.alloc(e, i, Array(r.length), o) : Array(r.length);
    const s = [], a = o?.abortEarly;
    for (let c = 0; c < r.length; c++) {
      const u = r[c], l = t.element._zod.run({
        value: u,
        issues: []
      }, o);
      if (l instanceof Promise)
        s.push(l.then((d) => qn(d, i, c)));
      else if (qn(l, i, c), a && l.issues.length !== 0 && V(l))
        break;
    }
    return s.length ? Promise.all(s).then(() => i) : i;
  }, Aa(e, Na);
});
function pt(e, t, n, i, o, r) {
  const s = n in i, a = r === "optional";
  if (!(!s && a && o === "optional")) {
    if (e.issues.length) {
      if (o !== void 0 && a && !s)
        return;
      t.issues.push(...ue(n, e.issues));
    }
    if (!s && o === void 0) {
      e.issues.length || t.issues.push({
        code: "invalid_type",
        expected: "nonoptional",
        input: void 0,
        path: [n]
      });
      return;
    }
    e.value === void 0 ? (s || o === "defaulted" && !a) && (t.value[n] = void 0) : t.value[n] = e.value;
  }
}
const Ra = [];
function to(e) {
  const t = Object.keys(e.shape), n = Object.getOwnPropertySymbols(e.shape), i = n.length ? n : Ra, o = i.length ? [...t, ...i] : t;
  for (const s of o)
    if (!e.shape?.[s]?._zod?.traits?.has("$ZodType"))
      throw new Error(`Invalid element at key "${String(s)}": expected a Zod schema`);
  const r = yr(e.shape);
  return {
    ...e,
    allKeys: o,
    symbolKeys: i,
    // string-only: handleCatchall matches it against `for...in`, which never yields a symbol
    keySet: new Set(t),
    numKeys: t.length,
    optionalKeys: new Set(r)
  };
}
function no(e, t, n, i, o, r, s) {
  const a = [], c = o.keySet, u = o.catchall._zod, l = u.def.type, d = u.optin, m = u.optout;
  let f = 0;
  for (const _ in t) {
    if (s && n.issues.length !== f) {
      if (V(n, f))
        break;
      f = n.issues.length;
    }
    if (c.has(_))
      continue;
    if (_ === "__proto__") {
      l === "never" && a.push(_);
      continue;
    }
    if (l === "never") {
      a.push(_);
      continue;
    }
    const v = u.run({ value: t[_], issues: [] }, i);
    v instanceof Promise ? e.push(v.then((z) => pt(z, n, _, t, d, m))) : pt(v, n, _, t, d, m);
  }
  return a.length && n.issues.push({
    code: "unrecognized_keys",
    keys: a,
    input: t,
    inst: r,
    // Describes the shape of the input, not the validity of the parsed value, so it never aborts. The parse still fails; the schema's own checks just get to run first, and an enclosing intersection can reconcile the key against a sibling operand.
    continue: !0
  }), e.length ? Promise.all(e).then(() => n) : n;
}
const Ca = /* @__PURE__ */ p("$ZodObject", (e, t) => {
  E.init(e, t);
  const n = Object.getOwnPropertyDescriptor(t, "shape"), i = n?.get ? n.get.raw : t.shape ?? {};
  if (i) {
    const u = () => {
      const l = { ...i };
      return Object.defineProperty(t, "shape", { value: l }), u.raw = l, l;
    };
    u.raw = i, Object.defineProperty(t, "shape", { get: u });
  }
  const o = gt(() => to(t));
  $(e, "propValues", (u) => {
    const l = u.def.shape, d = {};
    for (const m in l) {
      const f = l[m]._zod;
      if (f.values) {
        Object.prototype.hasOwnProperty.call(d, m) || re(d, m, /* @__PURE__ */ new Set());
        for (const _ of f.values)
          d[m].add(_);
        f.optin !== void 0 && d[m].add(void 0);
      }
    }
    return d;
  });
  const r = Le, s = t.catchall;
  let a;
  const c = J.memoizer;
  c?.attach(e), e._zod.parse = (u, l) => {
    a ?? (a = o.value);
    const d = u.value;
    if (!r(d))
      return u.issues.push({
        expected: "object",
        code: "invalid_type",
        input: d,
        inst: e
      }), u;
    u.value = c ? c.alloc(e, u, {}, l) : {};
    const m = [], f = a.shape, _ = l?.abortEarly;
    let v = u.issues.length;
    for (const z of a.allKeys) {
      if (_ && u.issues.length !== v) {
        if (V(u, v))
          break;
        v = u.issues.length;
      }
      if (z === "__proto__")
        continue;
      const O = f[z], D = O._zod.optin, Ze = O._zod.optout, Ae = O._zod.run({ value: d[z], issues: [] }, l);
      Ae instanceof Promise ? m.push(Ae.then((R) => pt(R, u, z, d, D, Ze))) : pt(Ae, u, z, d, D, Ze);
    }
    return s ? no(m, d, u, l, o.value, e, _ === !0) : m.length ? Promise.all(m).then(() => u) : u;
  };
}), Da = /* @__PURE__ */ p("$ZodObjectJIT", (e, t) => {
  Ca.init(e, t);
  const n = e._zod.parse, i = gt(() => to(t)), o = J.memoizer, r = (f) => {
    const _ = i.value, v = _.symbolKeys, z = new Ks(["payload", "ctx"], { shape: f, inst: e, memo: o, syms: v }), O = (R) => `shape[${R}]._zod.run({ value: input[${R}], issues: [] }, ctx)`, D = (R, T) => `
          let ${R}_ab = false;
          for (let i = 0; i < ${R}.issues.length; i++) {
            const iss = ${R}.issues[i];
            iss.path = iss.path ? [${T}, ...iss.path] : [${T}];
            payload.issues.push(iss);
            if (iss.continue !== true) ${R}_ab = true;
          }
          if (${R}_ab && ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }`;
    z.write("const input = payload.value;");
    const Ze = /* @__PURE__ */ Object.create(null);
    let Ae = 0;
    for (const R of _.allKeys)
      Ze[R] = `key_${Ae++}`;
    z.write(o ? "const newResult = memo.alloc(inst, payload, {}, ctx);" : "const newResult = {};");
    for (const R of _.allKeys) {
      if (R === "__proto__")
        continue;
      const T = Ze[R], Y = typeof R == "symbol" ? `syms[${v.indexOf(R)}]` : hr(R), $t = `${Y} in input`, An = f[R], Et = An?._zod?.optin, Nn = Et !== void 0, ur = An?._zod?.optout === "optional";
      if (z.write(`const ${T} = ${O(Y)};`), Nn && ur) {
        const lr = Et === "optional" ? `${T}_present` : `${T}.value !== undefined || ${T}_present`;
        z.write(`
        const ${T}_present = ${$t};
        if (!${T}.issues.length || ${T}_present) {
          if (${T}.issues.length) {${D(T, Y)}
          }

          if (${lr}) {
            newResult[${Y}] = ${T}.value;
          }
        }

      `);
      } else Nn ? (z.write(`
        if (${T}.issues.length) {${D(T, Y)}
        }
      `), Et === "defaulted" ? z.write(`newResult[${Y}] = ${T}.value;`) : z.write(`
        if (${T}.value !== undefined || ${$t}) {
          newResult[${Y}] = ${T}.value;
        }
      `)) : z.write(`
        const ${T}_present = ${$t};
        if (${T}.issues.length) {${D(T, Y)}
        }
        if (!${T}_present && !${T}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${Y}]
          });
          if (ctx && ctx.abortEarly) {
            payload.value = newResult;
            return payload;
          }
        }

        if (${T}_present) {
          newResult[${Y}] = ${T}.value;
        }

      `);
    }
    return z.write("payload.value = newResult;"), z.write("return payload;"), z.compile();
  };
  let s;
  const a = Le, c = !J.jitless, l = c && gr.value, d = t.catchall;
  let m;
  e._zod.parse = (f, _) => {
    m ?? (m = i.value);
    const v = f.value;
    return a(v) ? c && l && _?.async === !1 && _.jitless !== !0 ? (s || (s = r(t.shape)), f = s(f, _), d ? no([], v, f, _, m, e, _?.abortEarly === !0) : f) : n(f, _) : (f.issues.push({
      expected: "object",
      code: "invalid_type",
      input: v,
      inst: e
    }), f);
  };
});
function Bn(e, t, n, i) {
  for (const r of e)
    if (r.issues.length === 0)
      return t.value = r.value, t;
  const o = e.filter((r) => !V(r));
  return o.length === 1 ? (t.value = o[0].value, o[0]) : (t.issues.push({
    code: "invalid_union",
    input: t.value,
    inst: n,
    errors: e.map((r) => r.issues.map((s) => pe(s, i, X())))
  }), t);
}
const io = /* @__PURE__ */ p("$ZodUnion", (e, t) => {
  E.init(e, t), $(e, "optin", (i) => i.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : i.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0), $(e, "optout", (i) => i.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0), $(e, "values", (i) => {
    if (i.def.options.every((o) => o._zod.values))
      return new Set(i.def.options.flatMap((o) => Array.from(o._zod.values)));
  }), $(e, "pattern", (i) => {
    if (i.def.options.every((o) => o._zod.pattern)) {
      const o = i.def.options.map((r) => r._zod.pattern);
      return new RegExp(`^(${o.map((r) => sn(r.source)).join("|")})$`);
    }
  });
  const n = t.options.length === 1 ? t.options[0]._zod.run : null;
  e._zod.parse = (i, o) => {
    if (n)
      return n(i, o);
    let r = !1;
    const s = [];
    for (const a of t.options) {
      const c = a._zod.run({
        value: i.value,
        issues: []
      }, o);
      if (c instanceof Promise)
        s.push(c), r = !0;
      else {
        if (c.issues.length === 0)
          return c;
        s.push(c);
      }
    }
    return r ? Promise.all(s).then((a) => Bn(a, i, e, o)) : Bn(s, i, e, o);
  };
});
function Ma(e) {
  const t = /* @__PURE__ */ new Map();
  for (const n of e.options) {
    const i = n._zod.propValues?.[e.discriminator];
    if (!i || i.size === 0)
      throw new Error(`Invalid discriminated union option at index "${e.options.indexOf(n)}"`);
    for (const o of i)
      if (t.has(o)) {
        if (o !== void 0)
          throw new Error(`Duplicate discriminator value "${String(o)}"`);
        t.set(o, null);
      } else
        t.set(o, n);
  }
  return t;
}
const Fa = /* @__PURE__ */ p("$ZodDiscriminatedUnion", (e, t) => {
  t.inclusive = !1, io.init(e, t);
  const n = e._zod.parse;
  $(e, "propValues", (o) => {
    const r = {};
    let s = 0;
    for (const a of o.def.options) {
      const c = a._zod.propValues;
      if (!c || Object.keys(c).length === 0)
        throw new Error(`Invalid discriminated union option at index "${o.def.options.indexOf(a)}"`);
      c[o.def.discriminator]?.has(void 0) && s++;
      for (const [u, l] of Object.entries(c)) {
        Object.prototype.hasOwnProperty.call(r, u) || re(r, u, /* @__PURE__ */ new Set());
        for (const d of l)
          r[u].add(d);
      }
    }
    return !o.def.unionFallback && s > 1 && r[o.def.discriminator]?.delete(void 0), r;
  }), t.options.forEach((o, r) => {
    const s = an(o._zod.def);
    if (s && !Object.prototype.hasOwnProperty.call(s, t.discriminator))
      throw new Error(`Invalid discriminated union option at index "${r}"`);
  });
  const i = gt(() => Ma(t));
  e._zod.parse = (o, r) => {
    const s = o.value;
    if (!Le(s))
      return o.issues.push({
        code: "invalid_type",
        expected: "object",
        input: s,
        inst: e
      }), o;
    const a = s?.[t.discriminator], c = i.value.get(a);
    return c && (a !== void 0 || r.direction !== "backward") ? c._zod.run(o, r) : t.unionFallback || r.direction === "backward" ? n(o, r) : (o.issues.push({
      code: "invalid_union",
      errors: [],
      note: "No matching discriminator",
      discriminator: t.discriminator,
      options: Array.from(i.value.keys()).filter((u) => i.value.get(u) !== null),
      input: s,
      path: [t.discriminator],
      inst: e
    }), o);
  };
}), Ua = /* @__PURE__ */ p("$ZodIntersection", (e, t) => {
  E.init(e, t), e._zod.parse = (n, i) => {
    const o = n.value, r = t.left._zod.run({ value: o, issues: [] }, i), s = t.right._zod.run({ value: o, issues: [] }, i);
    return r instanceof Promise || s instanceof Promise ? Promise.all([r, s]).then(([c, u]) => Jn(n, c, u)) : Jn(n, r, s);
  };
});
function Gt(e, t) {
  if (e === t)
    return { valid: !0, data: e };
  if (e instanceof Date && t instanceof Date && +e == +t)
    return { valid: !0, data: e };
  if (xe(e) && xe(t)) {
    const n = Object.keys(t), i = Object.keys(e).filter((r) => n.indexOf(r) !== -1), o = { ...e, ...t };
    Object.prototype.hasOwnProperty.call(o, "__proto__") && delete o.__proto__;
    for (const r of i) {
      if (r === "__proto__")
        continue;
      const s = Gt(e[r], t[r]);
      if (!s.valid)
        return {
          valid: !1,
          mergeErrorPath: [r, ...s.mergeErrorPath]
        };
      o[r] = s.data;
    }
    return { valid: !0, data: o };
  }
  if (Array.isArray(e) && Array.isArray(t)) {
    if (e.length !== t.length)
      return { valid: !1, mergeErrorPath: [] };
    const n = [];
    for (let i = 0; i < e.length; i++) {
      const o = e[i], r = t[i], s = Gt(o, r);
      if (!s.valid)
        return {
          valid: !1,
          mergeErrorPath: [i, ...s.mergeErrorPath]
        };
      n.push(s.data);
    }
    return { valid: !0, data: n };
  }
  return { valid: !1, mergeErrorPath: [] };
}
function Jn(e, t, n) {
  const i = /* @__PURE__ */ new Map();
  let o;
  const r = /* @__PURE__ */ new Map(), s = (u, l) => {
    let d;
    if (u.code === "unrecognized_keys" && !u.path?.length)
      o ?? (o = u), d = u.keys;
    else if (u.code === "invalid_key" && u.origin === "record" && u.path?.length === 1) {
      const m = String(u.path[0]);
      r.has(m) || r.set(m, u), d = [m];
    } else
      return !1;
    for (const m of d)
      i.has(m) || i.set(m, {}), i.get(m)[l] = !0;
    return !0;
  };
  for (const u of t.issues)
    s(u, "l") || e.issues.push(u);
  for (const u of n.issues)
    s(u, "r") || e.issues.push(u);
  const a = [...i].filter(([, u]) => u.l && u.r).map(([u]) => u);
  if (a.length) {
    const u = o ? a.filter((l) => o.keys.includes(l)) : [];
    u.length && e.issues.push({ ...o, keys: u });
    for (const l of a)
      !u.includes(l) && r.has(l) && e.issues.push(r.get(l));
  }
  const c = Gt(t.value, n.value);
  if (!c.valid) {
    if (V(e))
      return e;
    throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(c.mergeErrorPath)}`);
  }
  return e.value = c.data, e;
}
const La = /* @__PURE__ */ p("$ZodTuple", (e, t) => {
  E.init(e, t);
  const n = t.items, i = J.memoizer;
  i?.attach(e), e._zod.parse = (o, r) => {
    const s = o.value;
    if (!Array.isArray(s))
      return o.issues.push({
        input: s,
        inst: e,
        expected: "tuple",
        code: "invalid_type"
      }), o;
    o.value = i ? i.alloc(e, o, [], r) : [];
    const a = [], c = Hn(n, "optin"), u = Hn(n, "optout");
    if (!t.rest) {
      if (s.length < c)
        return o.issues.push({
          code: "too_small",
          minimum: c,
          inclusive: !0,
          input: s,
          inst: e,
          origin: "array"
        }), o;
      s.length > n.length && o.issues.push({
        code: "too_big",
        maximum: n.length,
        inclusive: !0,
        input: s,
        inst: e,
        origin: "array"
      });
    }
    const l = new Array(n.length), d = t.rest ? r?.abortEarly : void 0;
    let m = !1;
    for (let f = 0; f < n.length; f++) {
      const _ = n[f]._zod.run({ value: s[f], issues: [] }, r);
      _ instanceof Promise ? a.push(_.then((v) => {
        l[f] = v;
      })) : (l[f] = _, d && !m && _.issues.length && (m = V(_)));
    }
    if (t.rest && !m) {
      let f = n.length - 1;
      const _ = s.slice(n.length);
      let v = o.issues.length;
      for (const z of _) {
        if (d && o.issues.length !== v) {
          if (V(o, v))
            break;
          v = o.issues.length;
        }
        f++;
        const O = t.rest._zod.run({ value: z, issues: [] }, r);
        O instanceof Promise ? a.push(O.then((D) => Kn(D, o, f))) : Kn(O, o, f);
      }
    }
    return a.length ? Promise.all(a).then(() => Vn(l, o, n, s, u)) : Vn(l, o, n, s, u);
  };
});
function Hn(e, t) {
  for (let n = e.length - 1; n >= 0; n--)
    if (!(t === "optin" ? e[n]._zod.optin !== void 0 : e[n]._zod.optout === "optional"))
      return n + 1;
  return 0;
}
function Kn(e, t, n) {
  e.issues.length && t.issues.push(...ue(n, e.issues)), t.value[n] = e.value;
}
function Vn(e, t, n, i, o) {
  for (let r = 0; r < n.length; r++) {
    const s = e[r], a = r < i.length;
    if (!a && r >= o && n[r]._zod.optin === "optional") {
      t.value.length = r;
      break;
    }
    if (s.issues.length) {
      if (!a && r >= o) {
        t.value.length = r;
        break;
      }
      t.issues.push(...ue(r, s.issues));
    }
    t.value[r] = s.value;
  }
  for (let r = t.value.length - 1; r >= i.length && (n[r]._zod.optout === "optional" && t.value[r] === void 0); r--)
    t.value.length = r;
  return t;
}
const qa = /* @__PURE__ */ p("$ZodRecord", (e, t) => {
  E.init(e, t);
  const n = J.memoizer;
  n?.attach(e), e._zod.parse = (i, o) => {
    const r = i.value;
    if (!xe(r))
      return i.issues.push({
        expected: "record",
        code: "invalid_type",
        input: r,
        inst: e
      }), i;
    const s = [], a = t.keyType._zod.values;
    if (a && !t.partial) {
      i.value = n ? n.alloc(e, i, {}, o) : {};
      const c = /* @__PURE__ */ new Set();
      for (const l of a)
        if (typeof l == "string" || typeof l == "number" || typeof l == "symbol") {
          if (c.add(typeof l == "number" ? l.toString() : l), l === "__proto__")
            continue;
          const d = t.keyType._zod.run({ value: l, issues: [] }, o);
          if (d instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          if (d.issues.length) {
            i.issues.push({
              code: "invalid_key",
              origin: "record",
              issues: d.issues.map((_) => pe(_, o, X())),
              input: l,
              path: [l],
              inst: e
            });
            continue;
          }
          const m = d.value;
          if (m === "__proto__")
            continue;
          const f = t.valueType._zod.run({ value: r[l], issues: [] }, o);
          f instanceof Promise ? s.push(f.then((_) => {
            _.issues.length && i.issues.push(...ue(l, _.issues)), i.value[m] = _.value;
          })) : (f.issues.length && i.issues.push(...ue(l, f.issues)), i.value[m] = f.value);
        }
      let u;
      for (const l in r)
        if (!c.has(l))
          if (t.mode === "loose") {
            if (l === "__proto__")
              continue;
            i.value[l] = r[l];
          } else
            u = u ?? [], u.push(l);
      u && u.length > 0 && i.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: u,
        continue: !0
      });
    } else {
      i.value = n ? n.alloc(e, i, {}, o) : {};
      let c;
      for (const u of Reflect.ownKeys(r)) {
        if (u === "__proto__" || !Object.prototype.propertyIsEnumerable.call(r, u))
          continue;
        let l = t.keyType._zod.run({ value: u, issues: [] }, o);
        if (l instanceof Promise)
          throw new Error("Async schemas not supported in object keys currently");
        if (typeof u == "string" && mn.test(u) && l.issues.length) {
          const _ = t.keyType._zod.run({ value: Number(u), issues: [] }, o);
          if (_ instanceof Promise)
            throw new Error("Async schemas not supported in object keys currently");
          _.issues.length === 0 && (l = _);
        }
        if (l.issues.length) {
          t.mode === "loose" ? i.value[u] = r[u] : a ? (c = c ?? [], c.push(u)) : i.issues.push({
            code: "invalid_key",
            origin: "record",
            issues: l.issues.map((_) => pe(_, o, X())),
            input: u,
            path: [u],
            inst: e
          });
          continue;
        }
        const m = l.value;
        if (m === "__proto__")
          continue;
        const f = t.valueType._zod.run({ value: r[u], issues: [] }, o);
        f instanceof Promise ? s.push(f.then((_) => {
          _.issues.length && i.issues.push(...ue(u, _.issues)), i.value[m] = _.value;
        })) : (f.issues.length && i.issues.push(...ue(u, f.issues)), i.value[m] = f.value);
      }
      c && c.length > 0 && i.issues.push({
        code: "unrecognized_keys",
        input: r,
        inst: e,
        keys: c,
        continue: !0
      });
    }
    return s.length ? Promise.all(s).then(() => i) : i;
  };
}), Ba = /* @__PURE__ */ p("$ZodEnum", (e, t) => {
  E.init(e, t);
  const n = Jt(t.entries), i = new Set(n);
  e._zod.values = i, $(e, "pattern", (o) => {
    const r = Jt(o.def.entries).filter((s) => br.has(typeof s));
    return new RegExp(r.length ? `^(${r.map((s) => Ie(s.toString())).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (o, r) => {
    const s = o.value;
    return i.has(s) || o.issues.push({
      code: "invalid_value",
      values: n,
      input: s,
      inst: e
    }), o;
  };
}), Ja = /* @__PURE__ */ p("$ZodLiteral", (e, t) => {
  E.init(e, t);
  const n = new Set(t.values);
  e._zod.values = n, $(e, "pattern", (i) => {
    const o = i.def.values;
    return new RegExp(o.length ? `^(${o.map((r) => typeof r == "string" ? Ie(r) : r ? Ie(r.toString()) : String(r)).join("|")})$` : "^[^\\s\\S]$");
  }), e._zod.parse = (i, o) => {
    const r = i.value;
    return n.has(r) || i.issues.push({
      code: "invalid_value",
      values: t.values,
      input: r,
      inst: e
    }), i;
  };
}), Ha = /* @__PURE__ */ p("$ZodTransform", (e, t) => {
  E.init(e, t), e._zod.optin = "optional", J.memoizer?.guard(e), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new Li(e.constructor.name);
    const o = t.transform(n.value, n);
    if (i.async)
      return (o instanceof Promise ? o : Promise.resolve(o)).then((s) => (n.value = s, n));
    if (o instanceof Promise)
      throw new ge();
    return n.value = o, n;
  };
});
function Gn(e, t) {
  return e.value = t.issues.length ? void 0 : t.value, e;
}
const oo = /* @__PURE__ */ p("$ZodOptional", (e, t) => {
  E.init(e, t), $(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), e._zod.optout = "optional", $(e, "values", (n) => {
    const i = n.def.innerType._zod.values;
    return i ? /* @__PURE__ */ new Set([...i, void 0]) : void 0;
  }), $(e, "pattern", (n) => {
    const i = n.def.innerType._zod.pattern;
    return i ? new RegExp(`^(${sn(i.source)})?$`) : void 0;
  }), e._zod.parse = (n, i) => {
    if (n.value === void 0) {
      if (t.innerType._zod.optin !== "defaulted")
        return n;
      const o = t.innerType._zod.run({ value: n.value, issues: [] }, i);
      return o instanceof Promise ? o.then((r) => Gn(n, r)) : Gn(n, o);
    }
    return t.innerType._zod.run(n, i);
  };
}), Ka = /* @__PURE__ */ p("$ZodExactOptional", (e, t) => {
  oo.init(e, t), $(e, "values", (n) => n.def.innerType._zod.values), $(e, "pattern", (n) => n.def.innerType._zod.pattern), e._zod.parse = (n, i) => t.innerType._zod.run(n, i);
}), Va = /* @__PURE__ */ p("$ZodNullable", (e, t) => {
  E.init(e, t), $(e, "optin", (n) => n.def.innerType._zod.optin), $(e, "optout", (n) => n.def.innerType._zod.optout), $(e, "pattern", (n) => {
    const i = n.def.innerType._zod.pattern;
    return i ? new RegExp(`^(${sn(i.source)}|null)$`) : void 0;
  }), $(e, "values", (n) => n.def.innerType._zod.values ? /* @__PURE__ */ new Set([...n.def.innerType._zod.values, null]) : void 0), e._zod.parse = (n, i) => n.value === null ? n : t.innerType._zod.run(n, i);
}), Ga = /* @__PURE__ */ p("$ZodDefault", (e, t) => {
  E.init(e, t), e._zod.optin = "defaulted", $(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    if (n.value === void 0)
      return n.value = t.defaultValue, n;
    const o = t.innerType._zod.run(n, i);
    return o instanceof Promise ? o.then((r) => Wn(r, t)) : Wn(o, t);
  };
});
function Wn(e, t) {
  return e.value === void 0 && (e.value = t.defaultValue), e;
}
const Wa = /* @__PURE__ */ p("$ZodPrefault", (e, t) => {
  E.init(e, t), e._zod.optin = "defaulted", $(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => (i.direction === "backward" || n.value === void 0 && (n.value = t.defaultValue), t.innerType._zod.run(n, i));
}), Xa = /* @__PURE__ */ p("$ZodNonOptional", (e, t) => {
  E.init(e, t), $(e, "values", (n) => {
    const i = n.def.innerType._zod.values;
    return i ? new Set([...i].filter((o) => o !== void 0)) : void 0;
  }), e._zod.parse = (n, i) => {
    const o = t.innerType._zod.run(n, i);
    return o instanceof Promise ? o.then((r) => Xn(r, e)) : Xn(o, e);
  };
});
function Xn(e, t) {
  return !e.issues.length && e.value === void 0 && e.issues.push({
    code: "invalid_type",
    expected: "nonoptional",
    input: e.value,
    inst: t
  }), e;
}
function Yn(e, t, n, i) {
  return t.issues.length ? (e.value = n.catchValue({
    ...t,
    value: e.value,
    error: {
      issues: t.issues.map((o) => pe(o, i, X()))
    },
    input: e.value
  }), e) : (e.value = t.value, t.memo && (e.memo = !0), e);
}
const Ya = /* @__PURE__ */ p("$ZodCatch", (e, t) => {
  E.init(e, t), $(e, "optin", (n) => n.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional"), $(e, "optout", (n) => n.def.innerType._zod.optout), $(e, "values", (n) => n.def.innerType._zod.values), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    const o = t.innerType._zod.run({ value: n.value, issues: [] }, i);
    return o instanceof Promise ? o.then((r) => Yn(n, r, t, i)) : Yn(n, o, t, i);
  };
}), Qa = /* @__PURE__ */ p("$ZodPipe", (e, t) => {
  E.init(e, t), $(e, "values", (n) => n.def.in._zod.values), $(e, "optin", (n) => n.def.in._zod.optin), $(e, "optout", (n) => n.def.out._zod.optout), $(e, "propValues", (n) => n.def.in._zod.propValues), e._zod.parse = (n, i) => {
    if (i.direction === "backward") {
      const r = t.out._zod.run(n, i);
      return r instanceof Promise ? r.then((s) => Ye(s, t.in, i)) : Ye(r, t.in, i);
    }
    const o = t.in._zod.run(n, i);
    return o instanceof Promise ? o.then((r) => Ye(r, t.out, i)) : Ye(o, t.out, i);
  };
});
function Ye(e, t, n) {
  return e.issues.some((i) => i.code !== "unrecognized_keys") ? (e.aborted = !0, e) : t._zod.run({ value: e.value, issues: e.issues }, n);
}
const ec = /* @__PURE__ */ p("$ZodReadonly", (e, t) => {
  E.init(e, t), $(e, "propValues", (n) => n.def.innerType._zod.propValues), $(e, "values", (n) => n.def.innerType._zod.values), $(e, "optin", (n) => n.def.innerType?._zod?.optin), $(e, "optout", (n) => n.def.innerType?._zod?.optout), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      return t.innerType._zod.run(n, i);
    const o = t.innerType._zod.run(n, i);
    return o instanceof Promise ? o.then(Qn) : Qn(o);
  };
});
function Qn(e) {
  return e.memo || (e.value = Object.freeze(e.value)), e;
}
const tc = /* @__PURE__ */ p("$ZodCustom", (e, t) => {
  M.init(e, t), E.init(e, t), e._zod.parse = (n, i) => n, e._zod.check = (n) => {
    const i = n.value, o = t.fn(i);
    if (o instanceof Promise)
      return o.then((r) => ei(r, n, i, e));
    ei(o, n, i, e);
  };
});
function ei(e, t, n, i) {
  if (!e) {
    const o = {
      code: "custom",
      input: n,
      inst: i,
      // incorporates params.error into issue reporting
      path: [...i._zod.def.path ?? []],
      // incorporates params.error into issue reporting
      continue: !i._zod.def.abort
      // params: inst._zod.def.params,
    };
    i._zod.def.params && (o.params = i._zod.def.params), t.issues.push(qe(o));
  }
}
class nc extends Error {
  constructor() {
    super("Cannot parse a reference cycle that closes through a transform"), this.name = "ZodCyclicError";
  }
}
const Wt = "~memo", ti = [];
function ro(e) {
  return e !== null && typeof e == "object";
}
function At(e) {
  return e.map((t) => t.path ? { ...t, path: t.path.slice() } : { ...t });
}
const so = /* @__PURE__ */ new WeakMap(), Ce = 0, st = 1, Fe = 2;
function at(e, t, n) {
  const i = so.get(e);
  if (i !== void 0)
    return i ? Fe : Ce;
  if (t.has(e))
    return Fe;
  t.add(e);
  let o = Ce;
  const r = (l) => {
    if (o !== Fe && l?._zod) {
      const d = at(l, t);
      d > o && (o = d);
    }
  }, s = (l, d) => {
    let m = Ce;
    for (const f of Reflect.ownKeys(l)) {
      const _ = Object.getOwnPropertyDescriptor(l, f);
      if (!_.enumerable)
        continue;
      const v = _.get ? st : _.value?._zod ? at(_.value, t) : Ce;
      v > m && (m = v);
    }
    return m;
  }, a = (l) => {
    l > o && (o = l);
  }, c = e._zod.def;
  switch (c.type) {
    case "object": {
      const l = an(c);
      a(l ? s(l) : st), r(c.catchall);
      break;
    }
    case "array":
      r(c.element);
      break;
    case "tuple":
      for (const l of c.items)
        r(l);
      r(c.rest);
      break;
    case "record":
    case "map":
      r(c.keyType), r(c.valueType);
      break;
    case "set":
      r(c.valueType);
      break;
    case "union":
      for (const l of c.options)
        r(l);
      break;
    case "intersection":
      r(c.left), r(c.right);
      break;
    case "optional":
    case "nullable":
    case "default":
    case "prefault":
    case "catch":
    case "readonly":
    case "nonoptional":
    case "promise":
    case "success":
      r(c.innerType);
      break;
    case "pipe":
      r(c.in), r(c.out);
      break;
    case "function":
      r(c.input), r(c.output);
      break;
    // `$ZodLazy` caches its inner on the def, so a resolved edge is followed exactly
    case "lazy": {
      const l = c._cachedInner ?? void 0;
      a(l ? at(l, t) : st);
      break;
    }
    // a leaf by choice: `parts` are regex fragments, not data positions
    case "template_literal":
    // leaves
    case "string":
    case "number":
    case "int":
    case "boolean":
    case "bigint":
    case "symbol":
    case "undefined":
    case "null":
    case "void":
    case "never":
    case "any":
    case "unknown":
    case "date":
    case "nan":
    case "enum":
    case "literal":
    case "file":
    case "transform":
    case "custom":
      break;
    default:
      for (const l in c) {
        const d = Object.getOwnPropertyDescriptor(c, l);
        if (!d || d.get)
          continue;
        const m = d.value;
        if (!(!m || typeof m != "object")) {
          if (m._zod)
            r(m);
          else if (Array.isArray(m))
            for (const f of m)
              r(f);
        }
      }
  }
  return t.delete(e), ic(e, o);
}
function ic(e, t) {
  return t !== st && so.set(e, t === Fe), t;
}
function oc(e, t) {
  let n = e.buckets.get(t);
  return n || (n = /* @__PURE__ */ new WeakMap(), e.buckets.set(t, n)), n;
}
let Qe;
const et = [], rc = {
  alloc(e, t, n) {
    const i = Qe;
    if (!i)
      return n;
    Qe = void 0;
    const o = { value: n, issues: null };
    return i.set(t.value, o), et.push(o), n;
  },
  guard(e) {
    var t;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const n = e._zod.parse, i = (o, r) => {
        if (r.direction !== "backward" && ac(r, o.value))
          throw new nc();
        return n(o, r);
      };
      e._zod.parse = i, e._zod.run === n && (e._zod.run = i);
    });
  },
  attach(e) {
    var t;
    let n, i = !1, o, r;
    (t = e._zod).deferred ?? (t.deferred = []), e._zod.deferred.push(() => {
      const s = e._zod.parse, a = (c, u) => {
        if (n === void 0) {
          const O = at(e, /* @__PURE__ */ new Set());
          if (O === Ce)
            return e._zod.parse = s, e._zod.run === a && (e._zod.run = s), s(c, u);
          O === Fe || i ? n = !0 : i = !0;
        }
        const l = c.value;
        if (!ro(l))
          return s(c, u);
        let d = u[Wt];
        d || (d = { buckets: /* @__PURE__ */ new WeakMap(), backEdges: void 0 }, u[Wt] = d);
        let m;
        o === u ? m = r : (m = oc(d, e), o = u, r = m);
        const f = m.get(l);
        if (f)
          return c.value = f.value, f.issues ? f.issues.length && c.issues.push(...At(f.issues)) : (c.memo = !0, d.backEdges ?? (d.backEdges = /* @__PURE__ */ new WeakSet()), d.backEdges.add(f.value)), c;
        Qe = m;
        const _ = et.length, v = s(c, u);
        Qe = void 0;
        const z = et.length > _ ? et.pop() : void 0;
        return v instanceof Promise ? v.then((O) => (z && (z.issues = O.issues.length ? At(O.issues) : ti), O)) : (z && (z.issues = v.issues.length ? At(v.issues) : ti), v);
      };
      e._zod.parse = a, e._zod.run === s && (e._zod.run = a);
    });
  }
};
function sc() {
  return rc;
}
function ac(e, t) {
  const n = e[Wt]?.backEdges;
  return n !== void 0 && ro(t) && n.has(t);
}
const cc = () => {
  const e = {
    string: { unit: "characters", verb: "to have" },
    file: { unit: "bytes", verb: "to have" },
    array: { unit: "items", verb: "to have" },
    set: { unit: "items", verb: "to have" },
    map: { unit: "entries", verb: "to have" }
  };
  function t(r) {
    return e[r] ?? null;
  }
  const n = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    mac: "MAC address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    currency_code: "currency code",
    credit_card: "credit card number",
    iban: "IBAN",
    jwt: "JWT",
    template_literal: "input"
  }, i = {
    // Compatibility: "nan" -> "NaN" for display
    nan: "NaN"
    // All other type names omitted - they fall back to raw values via ?? operator
  };
  function o(r, s) {
    return r === "number" && typeof s == "number" && !Number.isFinite(s) ? String(s) : i[r] ?? r;
  }
  return (r) => {
    switch (r.code) {
      case "invalid_type": {
        const s = o(r.expected), a = Er(r.input), c = o(a, r.input);
        return `Invalid input: expected ${s}, received ${c}`;
      }
      case "invalid_value":
        return r.values.length === 1 ? `Invalid input: expected ${Ci(r.values[0])}` : `Invalid option: expected one of ${jn(r.values, "|")}`;
      case "too_big": {
        const s = r.exact ? "exactly " : r.inclusive ? "<=" : "<", a = t(r.origin);
        return a ? `Too big: expected ${r.origin ?? "value"} to have ${s}${r.maximum.toString()} ${a.unit ?? "elements"}` : `Too big: expected ${r.origin ?? "value"} to be ${s}${r.maximum.toString()}`;
      }
      case "too_small": {
        const s = r.exact ? "exactly " : r.inclusive ? ">=" : ">", a = t(r.origin);
        return a ? `Too small: expected ${r.origin} to have ${s}${r.minimum.toString()} ${a.unit}` : `Too small: expected ${r.origin} to be ${s}${r.minimum.toString()}`;
      }
      case "invalid_format": {
        const s = r;
        return s.format === "starts_with" ? `Invalid string: must start with "${s.prefix}"` : s.format === "ends_with" ? `Invalid string: must end with "${s.suffix}"` : s.format === "includes" ? `Invalid string: must include "${s.includes}"` : s.format === "regex" ? `Invalid string: must match pattern ${s.pattern}` : `Invalid ${n[s.format] ?? r.format}`;
      }
      case "not_multiple_of":
        return `Invalid number: must be a multiple of ${r.divisor}`;
      case "unrecognized_keys":
        return `Unrecognized key${r.keys.length > 1 ? "s" : ""}: ${jn(r.keys, ", ")}`;
      case "invalid_key":
        return `Invalid key in ${r.origin}`;
      case "invalid_union":
        return r.options && Array.isArray(r.options) && r.options.length > 0 ? `Invalid discriminator value. Expected ${r.options.map((a) => `'${a}'`).join(" | ")}` : r.inclusive === !1 ? "Invalid input: more than one option matched" : "Invalid input";
      case "invalid_element":
        return `Invalid value in ${r.origin}`;
      default:
        return "Invalid input";
    }
  };
};
function uc() {
  return {
    localeError: cc()
  };
}
var ni;
class lc {
  constructor() {
    this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map();
  }
  add(t, ...n) {
    const i = n[0];
    return this._map.set(t, i), i && typeof i == "object" && "id" in i && this._idmap.set(i.id, t), this;
  }
  clear() {
    return this._map = /* @__PURE__ */ new WeakMap(), this._idmap = /* @__PURE__ */ new Map(), this;
  }
  remove(t) {
    const n = this._map.get(t);
    return n && typeof n == "object" && "id" in n && this._idmap.delete(n.id), this._map.delete(t), this;
  }
  get(t) {
    const n = t._zod.parent;
    if (n) {
      const i = { ...this.get(n) ?? {} };
      delete i.id;
      const o = { ...i, ...this._map.get(t) };
      return Object.keys(o).length ? o : void 0;
    }
    return this._map.get(t);
  }
  has(t) {
    return this._map.has(t);
  }
}
function dc() {
  return new lc();
}
(ni = globalThis).__zod_globalRegistry ?? (ni.__zod_globalRegistry = dc());
const De = globalThis.__zod_globalRegistry;
function ao(e) {
  return e.checks && (e.checks = [...e.checks]), e;
}
// @__NO_SIDE_EFFECTS__
function pc(e, t) {
  return new e(ao({ type: "string", ...w(t) }));
}
// @__NO_SIDE_EFFECTS__
function fc(e, t) {
  return new e({
    type: "string",
    format: "email",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function mc(e, t) {
  return new e({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function co(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function hc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v4",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function _c(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v6",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function gc(e, t) {
  return new e({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: !1,
    version: "v7",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function uo(e, t) {
  return new e({
    type: "string",
    format: "url",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function bc(e, t) {
  return new e({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function yc(e, t) {
  return new e({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function vc(e, t) {
  return new e({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function wc(e, t) {
  return new e({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function kc(e, t) {
  return new e({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function zc(e, t) {
  return new e({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function xc(e, t) {
  return new e({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ic(e, t) {
  return new e({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Sc(e, t) {
  return new e({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Oc(e, t) {
  return new e({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function $c(e, t) {
  return new e({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ec(e, t) {
  return new e({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Tc(e, t) {
  return new e({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Pc(e, t) {
  return new e({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Zc(e, t) {
  return new e({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: !1,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Ac(e, t) {
  return new e({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: !1,
    local: !1,
    precision: null,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function lo(e, t) {
  return new e({
    type: "string",
    format: "date",
    check: "string_format",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Nc(e, t) {
  return new e({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function jc(e, t) {
  return new e({
    type: "string",
    format: "duration",
    check: "string_format",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Rc(e, t) {
  return new e(ao({ type: "number", checks: [], ...w(t) }));
}
// @__NO_SIDE_EFFECTS__
function Cc(e, t) {
  return new e({
    type: "number",
    check: "number_format",
    abort: !1,
    format: "safeint",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Dc(e, t) {
  return new e({
    type: "boolean",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Mc(e, t) {
  return new e({
    type: "null",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function Fc(e) {
  return new e({
    type: "unknown"
  });
}
// @__NO_SIDE_EFFECTS__
function Uc(e, t) {
  return new e({
    type: "never",
    ...w(t)
  });
}
// @__NO_SIDE_EFFECTS__
function ii(e, t) {
  return new Ji({
    check: "less_than",
    ...w(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function Nt(e, t) {
  return new Ji({
    check: "less_than",
    ...w(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function oi(e, t) {
  return new Hi({
    check: "greater_than",
    ...w(t),
    value: e,
    inclusive: !1
  });
}
// @__NO_SIDE_EFFECTS__
function jt(e, t) {
  return new Hi({
    check: "greater_than",
    ...w(t),
    value: e,
    inclusive: !0
  });
}
// @__NO_SIDE_EFFECTS__
function ri(e, t) {
  return new js({
    check: "multiple_of",
    ...w(t),
    value: e
  });
}
// @__NO_SIDE_EFFECTS__
function po(e, t) {
  return new Cs({
    check: "max_length",
    ...w(t),
    maximum: e
  });
}
// @__NO_SIDE_EFFECTS__
function ft(e, t) {
  return new Ds({
    check: "min_length",
    ...w(t),
    minimum: e
  });
}
// @__NO_SIDE_EFFECTS__
function fo(e, t) {
  return new Ms({
    check: "length_equals",
    ...w(t),
    length: e
  });
}
// @__NO_SIDE_EFFECTS__
function Lc(e, t) {
  return new Fs({
    check: "string_format",
    format: "regex",
    ...w(t),
    pattern: e
  });
}
// @__NO_SIDE_EFFECTS__
function qc(e) {
  return new Us({
    check: "string_format",
    format: "lowercase",
    ...w(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Bc(e) {
  return new Ls({
    check: "string_format",
    format: "uppercase",
    ...w(e)
  });
}
// @__NO_SIDE_EFFECTS__
function Jc(e, t) {
  return new qs({
    check: "string_format",
    format: "includes",
    ...w(t),
    includes: e
  });
}
// @__NO_SIDE_EFFECTS__
function Hc(e, t) {
  return new Bs({
    check: "string_format",
    format: "starts_with",
    ...w(t),
    prefix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Kc(e, t) {
  return new Js({
    check: "string_format",
    format: "ends_with",
    ...w(t),
    suffix: e
  });
}
// @__NO_SIDE_EFFECTS__
function Ee(e) {
  return new Hs({
    check: "overwrite",
    tx: e
  });
}
// @__NO_SIDE_EFFECTS__
function Vc(e) {
  return /* @__PURE__ */ Ee((t) => t.normalize(e));
}
// @__NO_SIDE_EFFECTS__
function Gc() {
  return /* @__PURE__ */ Ee((e) => e.trim());
}
// @__NO_SIDE_EFFECTS__
function Wc() {
  return /* @__PURE__ */ Ee((e) => e.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function Xc() {
  return /* @__PURE__ */ Ee((e) => e.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function Yc() {
  return /* @__PURE__ */ Ee((e) => _r(e));
}
// @__NO_SIDE_EFFECTS__
function Qc(e, t, n) {
  return new e({
    type: "array",
    element: t,
    // get element() {
    //   return element;
    // },
    ...w(n)
  });
}
// @__NO_SIDE_EFFECTS__
function eu(e, t, n) {
  return new e({
    type: "custom",
    check: "custom",
    fn: t,
    ...w(n)
  });
}
// @__NO_SIDE_EFFECTS__
function tu(e, t) {
  const n = /* @__PURE__ */ nu((i) => (i.addIssue = (o) => {
    if (typeof o == "string")
      i.issues.push(qe(o, i.value, n._zod.def));
    else {
      const r = o;
      r.fatal && (r.continue = !1), r.code ?? (r.code = "custom"), "input" in r || (r.input = i.value), r.inst ?? (r.inst = n), r.continue ?? (r.continue = !n._zod.def.abort), i.issues.push(qe(r));
    }
  }, e(i.value, i)), t);
  return n;
}
// @__NO_SIDE_EFFECTS__
function nu(e, t) {
  const n = new M({
    check: "custom",
    ...w(t)
  });
  return n._zod.check = e, n;
}
function Ue(e, ...t) {
  for (const n of t)
    for (const i of Reflect.ownKeys(n))
      Object.prototype.propertyIsEnumerable.call(n, i) && re(e, i, n[i]);
  return e;
}
function mo(e) {
  let t = e?.target ?? "draft-2020-12";
  return t === "draft-4" && (t = "draft-04"), t === "draft-7" && (t = "draft-07"), {
    processors: e.processors ?? {},
    metadataRegistry: e?.metadata ?? De,
    target: t,
    unrepresentable: e?.unrepresentable ?? "throw",
    override: e?.override ?? (() => {
    }),
    io: e?.io ?? "output",
    counter: 0,
    seen: /* @__PURE__ */ new Map(),
    sharedDefsExtractedFor: void 0,
    sharedEmitDoneFor: void 0,
    cycles: e?.cycles ?? "ref",
    reused: e?.reused ?? "inline",
    intersections: [],
    deferred: [],
    external: e?.external ?? void 0
  };
}
function me(e, t, n, i, o) {
  const r = typeof t.unrepresentable == "function" ? t.unrepresentable({ zodSchema: e, path: i.path, message: o }) : t.unrepresentable;
  if (r === "any")
    return !1;
  if (r === void 0 || r === "throw")
    throw new Error(o);
  return Object.assign(n, r), !0;
}
function j(e, t, n = { path: [], schemaPath: [] }) {
  var i;
  const o = e._zod.def, r = t.seen.get(e);
  if (r)
    return r.count++, n.schemaPath.includes(e) && (r.cycle = n.path), r.schema;
  const s = { schema: {}, count: 1, cycle: void 0, path: n.path };
  t.seen.set(e, s), t.sharedDefsExtractedFor = void 0, t.sharedEmitDoneFor = void 0;
  const a = e._zod.toJSONSchema?.();
  if (a)
    s.schema = a;
  else {
    const l = {
      ...n,
      schemaPath: [...n.schemaPath, e],
      path: n.path
    };
    if (e._zod.processJSONSchema)
      e._zod.processJSONSchema(t, s.schema, l);
    else {
      const m = s.schema, f = t.processors[o.type];
      if (!f)
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${o.type}`);
      f(e, t, m, l);
    }
    const d = e._zod.parent;
    d && (s.ref || (s.ref = d), j(d, t, l), t.seen.get(d).isParent = !0);
  }
  const c = t.metadataRegistry.get(e);
  return c && Ue(s.schema, c), t.io === "input" && C(e) && (delete s.schema.examples, delete s.schema.default), t.io === "input" && "_prefault" in s.schema && ((i = s.schema).default ?? (i.default = s.schema._prefault)), delete s.schema._prefault, t.seen.get(e).schema;
}
function si(e) {
  return e.replace(/~/g, "~0").replace(/\//g, "~1");
}
function ho(e, t) {
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  if (e.external && e.sharedDefsExtractedFor === e.external)
    return;
  const i = /* @__PURE__ */ new Map();
  for (const s of e.seen.entries()) {
    const a = e.metadataRegistry.get(s[0])?.id;
    if (a) {
      const c = i.get(a);
      if (c && c !== s[0])
        throw new Error(`Duplicate schema id "${a}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      i.set(a, s[0]);
    }
  }
  const o = (s) => {
    const a = e.target === "draft-2020-12" ? "$defs" : "definitions";
    if (e.external) {
      const d = e.external.registry.get(s[0])?.id, m = e.external.uri ?? ((_) => _);
      if (d)
        return { ref: m(d) };
      const f = s[1].defId ?? s[1].schema.id ?? `schema${e.counter++}`;
      return s[1].defId = f, { defId: f, ref: `${m("__shared")}#/${a}/${si(f)}` };
    }
    const c = "#", u = `${c}/${a}/`;
    if (s[1] === n && !s[1].schema.id)
      return { ref: c };
    const l = s[1].schema.id ?? `__schema${e.counter++}`;
    return { defId: l, ref: u + si(l) };
  }, r = (s) => {
    if (s[1].schema.$ref)
      return;
    const a = s[1], { ref: c, defId: u } = o(s);
    a.def = { ...a.schema }, u && (a.defId = u);
    const l = a.schema;
    for (const d in l)
      delete l[d];
    l.$ref = c;
  };
  if (e.cycles === "throw")
    for (const s of e.seen.entries()) {
      const a = s[1];
      if (a.cycle)
        throw new Error(`Cycle detected: #/${a.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
    }
  for (const s of e.seen.entries()) {
    const a = s[1];
    if (t === s[0]) {
      r(s);
      continue;
    }
    if (e.external) {
      const u = e.external.registry.get(s[0])?.id;
      if (t !== s[0] && u) {
        r(s);
        continue;
      }
    }
    if (e.metadataRegistry.get(s[0])?.id) {
      r(s);
      continue;
    }
    if (a.cycle) {
      r(s);
      continue;
    }
    a.count > 1 && e.reused === "ref" && r(s);
  }
  e.external && (e.sharedDefsExtractedFor = e.external);
}
function _o(e) {
  const t = e.anyOf;
  if (!Array.isArray(t) || t.length === 0 || e.type !== void 0)
    return;
  const n = [];
  for (const i of t) {
    if (!i || typeof i != "object")
      return;
    _o(i);
    const o = Object.keys(i);
    if (o.length !== 1 || o[0] !== "type")
      return;
    const r = i.type;
    for (const s of Array.isArray(r) ? r : [r]) {
      if (typeof s != "string")
        return;
      n.includes(s) || n.push(s);
    }
  }
  delete e.anyOf, e.type = n.length === 1 ? n[0] : n;
}
const go = /* @__PURE__ */ new Set(["type", "properties", "required", "additionalProperties"]), ai = ["oneOf", "anyOf"];
function ci(e) {
  const t = e.additionalProperties;
  return t === void 0 || t === !1 || typeof t != "object" || t === null ? null : Object.keys(t).length ? t : null;
}
function Xt(e) {
  const t = [];
  for (const r of e) {
    if (typeof r != "object" || r.type !== "object")
      return null;
    for (const s in r)
      if (!go.has(s))
        return null;
    t.push(r);
  }
  const n = {}, i = /* @__PURE__ */ new Set();
  for (const r of t) {
    for (const s in r.properties) {
      if (Object.prototype.hasOwnProperty.call(n, s))
        continue;
      const a = [];
      for (const u of t) {
        const l = u.properties?.[s] ?? ci(u);
        l != null && (a.some((d) => JSON.stringify(d) === JSON.stringify(l)) || a.push(l));
      }
      const c = a.length === 1 ? a[0] : Xt(a) ?? { allOf: a };
      re(n, s, c);
    }
    for (const s of r.required ?? [])
      i.add(s);
  }
  const o = { type: "object", properties: n };
  if (i.size && (o.required = [...i]), t.every((r) => r.additionalProperties === !1))
    o.additionalProperties = !1;
  else {
    const r = [];
    for (const s of t) {
      const a = ci(s);
      a && !r.some((c) => JSON.stringify(c) === JSON.stringify(a)) && r.push(a);
    }
    r.length === 1 ? o.additionalProperties = r[0] : r.length > 1 && (o.additionalProperties = { allOf: r });
  }
  return o;
}
function iu(e) {
  const t = e.allOf;
  if (!Array.isArray(t) || t.length < 2)
    return;
  for (const o of go)
    if (o in e)
      return;
  const n = t.filter((o) => ai.some((r) => Array.isArray(o[r])));
  let i = null;
  if (!n.length)
    i = Xt(t);
  else {
    const o = n[0], r = ai.find((c) => Array.isArray(o[c]));
    if (Object.keys(o).length !== 1)
      return;
    const s = t.filter((c) => c !== o), a = o[r].map((c) => Xt([...s, c]));
    if (a.some((c) => !c))
      return;
    i = { [r]: a };
  }
  i && (delete e.allOf, Ue(e, i));
}
function bo(e, t) {
  const n = e.seen.get(t);
  if (!n)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const i = (a) => {
    const c = e.seen.get(a);
    if (c.ref === null)
      return;
    const u = c.def ?? c.schema, l = { ...u }, d = c.ref;
    if (c.ref = null, d) {
      i(d);
      const f = e.seen.get(d), _ = f.schema;
      if (_.$ref && (e.target === "draft-07" || e.target === "draft-04" || e.target === "openapi-3.0") ? (u.allOf = u.allOf ?? [], u.allOf.push(_)) : Ue(u, _), Ue(u, l), a._zod.parent === d)
        for (const z in u)
          z === "$ref" || z === "allOf" || z in l || delete u[z];
      if (_.$ref && f.def)
        for (const z in u)
          z === "$ref" || z === "allOf" || z in f.def && JSON.stringify(u[z]) === JSON.stringify(f.def[z]) && delete u[z];
    }
    const m = a._zod.parent;
    if (m && m !== d) {
      i(m);
      const f = e.seen.get(m);
      if (f?.schema.$ref && (u.$ref = f.schema.$ref, f.def))
        for (const _ in u)
          _ === "$ref" || _ === "allOf" || _ in f.def && JSON.stringify(u[_]) === JSON.stringify(f.def[_]) && delete u[_];
    }
    e.override({
      zodSchema: a,
      jsonSchema: u,
      path: c.path ?? []
    });
  };
  if (!e.external || e.sharedEmitDoneFor !== e.external) {
    for (const a of [...e.seen.entries()].reverse())
      i(a[0]);
    if (e.target !== "openapi-3.0")
      for (const a of e.seen.entries())
        _o(a[1].def ?? a[1].schema);
    for (const a of e.deferred)
      a();
    if (e.intersections.length) {
      const a = /* @__PURE__ */ new Map();
      for (const c of e.seen.values())
        for (const u of [c.schema, c.def]) {
          const l = u?.allOf;
          if (!Array.isArray(l))
            continue;
          const d = a.get(l);
          d ? d.push(u) : a.set(l, [u]);
        }
      for (const c of e.intersections)
        for (const u of a.get(c) ?? [])
          iu(u);
    }
  }
  const o = {};
  if (e.target === "draft-2020-12" ? o.$schema = "https://json-schema.org/draft/2020-12/schema" : e.target === "draft-07" ? o.$schema = "http://json-schema.org/draft-07/schema#" : e.target === "draft-04" ? o.$schema = "http://json-schema.org/draft-04/schema#" : e.target, e.external?.uri) {
    const a = e.external.registry.get(t)?.id;
    if (!a)
      throw new Error("Schema is missing an `id` property");
    o.$id = e.external.uri(a);
  }
  Ue(o, n.defId ? n.schema : n.def ?? n.schema);
  const r = e.metadataRegistry.get(t)?.id;
  r !== void 0 && o.id === r && delete o.id;
  const s = e.external?.defs ?? {};
  if (!e.external || e.sharedEmitDoneFor !== e.external)
    for (const a of e.seen.entries()) {
      const c = a[1];
      c.def && c.defId && (c.def.id === c.defId && delete c.def.id, re(s, c.defId, c.def));
    }
  e.external && (e.sharedEmitDoneFor = e.external), e.external || Object.keys(s).length > 0 && (e.target === "draft-2020-12" ? o.$defs = s : o.definitions = s);
  try {
    const a = JSON.parse(JSON.stringify(o));
    return Object.defineProperty(a, "~standard", {
      value: {
        ...t["~standard"],
        jsonSchema: {
          input: mt(t, "input", e.processors),
          output: mt(t, "output", e.processors)
        }
      },
      enumerable: !1,
      writable: !1
    }), a;
  } catch {
    throw new Error("Error converting schema to JSON.");
  }
}
function C(e, t) {
  const n = t ?? { seen: /* @__PURE__ */ new Set() };
  if (n.seen.has(e))
    return !1;
  n.seen.add(e);
  const i = e._zod.def;
  if (i.type === "transform")
    return !0;
  if (i.type === "array")
    return C(i.element, n);
  if (i.type === "set")
    return C(i.valueType, n);
  if (i.type === "lazy")
    return C(i.getter(), n);
  if (i.type === "promise" || i.type === "optional" || i.type === "nonoptional" || i.type === "nullable" || i.type === "readonly" || i.type === "default" || i.type === "prefault" || i.type === "catch")
    return C(i.innerType, n);
  if (i.type === "intersection")
    return C(i.left, n) || C(i.right, n);
  if (i.type === "record" || i.type === "map")
    return C(i.keyType, n) || C(i.valueType, n);
  if (i.type === "pipe")
    return e._zod.traits.has("$ZodCodec") ? !0 : C(i.in, n) || C(i.out, n);
  if (i.type === "object") {
    for (const o in i.shape)
      if (C(i.shape[o], n))
        return !0;
    return !1;
  }
  if (i.type === "union") {
    for (const o of i.options)
      if (C(o, n))
        return !0;
    return !1;
  }
  if (i.type === "tuple") {
    for (const o of i.items)
      if (C(o, n))
        return !0;
    return !!(i.rest && C(i.rest, n));
  }
  return !1;
}
const ou = (e, t = {}) => (n) => {
  const i = mo({ ...n, processors: t });
  return j(e, i), ho(i, e), bo(i, e);
}, mt = (e, t, n = {}) => (i) => {
  const { libraryOptions: o, target: r } = i ?? {}, s = mo({ ...o ?? {}, target: r, io: t, processors: n });
  return j(e, s), ho(s, e), bo(s, e);
}, Se = (e, t, n) => {
  (e[t] === void 0 || n > e[t]) && (e[t] = n);
}, Oe = (e, t, n) => {
  (e[t] === void 0 || n < e[t]) && (e[t] = n);
}, ui = (e, t) => {
  Se(e, "minimum", t), Oe(e, "maximum", t);
}, yo = (e, t) => {
  e.multipleOf ?? (e.multipleOf = []), e.multipleOf.includes(t) || e.multipleOf.push(t);
}, vo = (e, t) => {
  e.patterns ?? (e.patterns = /* @__PURE__ */ new Set()), e.patterns.add(t);
}, wo = (e, t) => {
  e.mime = e.mime ? e.mime.filter((n) => t.includes(n)) : [...t];
}, ko = (e, t) => {
  e.format = t, t.includes("int") && (e.isInt = !0);
}, li = (e, t) => Se(e, "minimum", t.minimum), di = (e, t) => Oe(e, "maximum", t.maximum), pi = (e) => (t, n) => {
  ko(t, n.format);
  const [i, o] = e[n.format];
  Se(t, "minimum", i), Oe(t, "maximum", o);
}, ru = {
  greater_than: (e, t) => Se(e, t.inclusive ? "minimum" : "exclusiveMinimum", t.value),
  less_than: (e, t) => Oe(e, t.inclusive ? "maximum" : "exclusiveMaximum", t.value),
  multiple_of: (e, t) => yo(e, t.value),
  number_format: pi(Di),
  bigint_format: pi(vr),
  min_length: li,
  max_length: di,
  length_equals: (e, t) => ui(e, t.length),
  min_size: li,
  max_size: di,
  size_equals: (e, t) => ui(e, t.size),
  string_format: (e, t) => {
    ko(e, t.format), t.pattern && vo(e, t.pattern), (t.format === "base64" || t.format === "base64url") && (e.contentEncoding = t.format), (t.local || t.precision === -1) && (e.laxFormat = !0);
  },
  mime_type: (e, t) => wo(e, t.mime)
};
function q(e) {
  const t = {}, n = e._zod.def, i = e._zod.traits.has("$ZodCheck") ? [e, ...n.checks ?? []] : n.checks ?? [];
  for (const r of i)
    ru[r._zod.def.check]?.(t, r._zod.def);
  const o = e._zod.bag;
  o.minimum !== void 0 && Se(t, "minimum", o.minimum), o.exclusiveMinimum !== void 0 && Se(t, "exclusiveMinimum", o.exclusiveMinimum), o.maximum !== void 0 && Oe(t, "maximum", o.maximum), o.exclusiveMaximum !== void 0 && Oe(t, "exclusiveMaximum", o.exclusiveMaximum), o.multipleOf !== void 0 && yo(t, o.multipleOf), o.format !== void 0 && (t.format ?? (t.format = o.format), o.format.includes("int") && (t.isInt = !0)), o.mime && wo(t, o.mime);
  for (const r of o.patterns ?? [])
    vo(t, r);
  return t;
}
const su = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
  // do not set
}, au = /* @__PURE__ */ new Map([
  [Qi, ws],
  [gn, ks]
]), zo = (e) => au.get(e) ?? e, cu = (e, t, n, i) => {
  const o = n;
  o.type = "string";
  const { minimum: r, maximum: s, format: a, patterns: c, contentEncoding: u, laxFormat: l } = q(e);
  if (typeof r == "number" && (o.minLength = r), typeof s == "number" && (o.maxLength = s), a && (o.format = su[a] ?? a, o.format === "" && delete o.format, (a === "time" || l) && delete o.format), u && (o.contentEncoding = u), c && c.size > 0) {
    const d = [...c].map(zo);
    d.length === 1 ? o.pattern = d[0].source : d.length > 1 && (o.allOf = [
      ...d.map((m) => ({
        ...t.target === "draft-07" || t.target === "draft-04" || t.target === "openapi-3.0" ? { type: "string" } : {},
        pattern: m.source
      }))
    ]);
  }
}, uu = (e, t, n, i) => {
  const o = n, { minimum: r, maximum: s, multipleOf: a, exclusiveMaximum: c, exclusiveMinimum: u, isInt: l } = q(e);
  o.type = l ? "integer" : "number";
  const d = typeof u == "number" && u >= (r ?? Number.NEGATIVE_INFINITY), m = typeof c == "number" && c <= (s ?? Number.POSITIVE_INFINITY), f = t.target === "draft-04" || t.target === "openapi-3.0";
  if (d ? f ? (o.minimum = u, o.exclusiveMinimum = !0) : o.exclusiveMinimum = u : typeof r == "number" && (o.minimum = r), m ? f ? (o.maximum = c, o.exclusiveMaximum = !0) : o.exclusiveMaximum = c : typeof s == "number" && (o.maximum = s), a) {
    const _ = /* @__PURE__ */ new Set();
    for (const O of a)
      Number.isFinite(O) && O !== 0 ? _.add(Math.abs(O)) : me(e, t, o, i, `A multipleOf divisor of ${O} cannot be represented in JSON Schema`);
    const [v, ...z] = _;
    v !== void 0 && (o.multipleOf = v), z.length && (o.allOf = [...o.allOf ?? [], ...z.map((O) => ({ multipleOf: O }))]);
  }
}, lu = (e, t, n, i) => {
  n.type = "boolean";
}, du = (e, t, n, i) => {
  t.target === "openapi-3.0" ? (n.type = "string", n.nullable = !0, n.enum = [null]) : n.type = "null";
}, pu = (e, t, n, i) => {
  n.not = {};
}, fu = (e, t, n, i) => {
}, mu = (e, t, n, i) => {
  const o = e._zod.def, r = Jt(o.entries);
  if (r.length === 0) {
    n.not = {};
    return;
  }
  r.every((s) => typeof s == "number") && (n.type = "number"), r.every((s) => typeof s == "string") && (n.type = "string"), n.enum = r;
}, hu = (e, t, n, i) => {
  const o = e._zod.def;
  if (o.values.length === 0) {
    n.not = {};
    return;
  }
  const r = [];
  for (const s of o.values)
    if (s === void 0) {
      if (me(e, t, n, i, "Literal `undefined` cannot be represented in JSON Schema"))
        return;
    } else if (typeof s == "bigint") {
      if (me(e, t, n, i, "BigInt literals cannot be represented in JSON Schema"))
        return;
      r.push(Number(s));
    } else
      r.push(s);
  if (r.length !== 0) if (r.length === 1) {
    const s = r[0];
    n.type = s === null ? "null" : typeof s, t.target === "draft-04" || t.target === "openapi-3.0" ? n.enum = [s] : n.const = s;
  } else
    r.every((s) => typeof s == "number") && (n.type = "number"), r.every((s) => typeof s == "string") && (n.type = "string"), r.every((s) => typeof s == "boolean") && (n.type = "boolean"), r.every((s) => s === null) && (n.type = "null"), n.enum = r;
}, _u = (e, t, n, i) => {
  me(e, t, n, i, "Custom types cannot be represented in JSON Schema");
}, gu = (e, t, n, i) => {
  me(e, t, n, i, "Transforms cannot be represented in JSON Schema");
}, bu = (e, t, n, i) => {
  const o = n, r = e._zod.def, { minimum: s, maximum: a } = q(e);
  typeof s == "number" && (o.minItems = s), typeof a == "number" && (o.maxItems = a), o.type = "array", o.items = j(r.element, t, {
    ...i,
    path: [...i.path, "items"]
  });
};
function Be(e) {
  const t = e._zod.def;
  return t.type === "pipe" && t.in._zod.traits.has("$ZodTransform") ? Be(t.out) : t.type === "catch" ? Be(t.innerType) : e._zod.optin;
}
const yu = (e, t, n, i) => {
  const o = n, r = e._zod.def, s = r.shape;
  if (Object.getOwnPropertySymbols(s).length && me(e, t, o, i, "Symbol keys cannot be represented in JSON Schema"))
    return;
  o.type = "object", o.properties = {};
  for (const u in s)
    re(o.properties, u, j(s[u], t, {
      ...i,
      path: [...i.path, "properties", u]
    }));
  const c = [];
  for (const u of Object.keys(s)) {
    const l = r.shape[u];
    (t.io === "input" ? Be(l) === void 0 : l._zod.optout === void 0) && c.push(u);
  }
  c.length > 0 && (o.required = c), r.catchall?._zod.def.type === "never" ? o.additionalProperties = !1 : r.catchall ? r.catchall && (o.additionalProperties = j(r.catchall, t, {
    ...i,
    path: [...i.path, "additionalProperties"]
  })) : t.io === "output" && (o.additionalProperties = !1);
}, vu = (e, t, n, i) => {
  const o = e._zod.def, r = o.inclusive === !1, s = o.options.map((a, c) => j(a, t, {
    ...i,
    path: [...i.path, r ? "oneOf" : "anyOf", c]
  }));
  r ? n.oneOf = s : n.anyOf = s;
}, wu = (e, t, n, i) => {
  const o = e._zod.def, r = j(o.left, t, {
    ...i,
    path: [...i.path, "allOf", 0]
  }), s = j(o.right, t, {
    ...i,
    path: [...i.path, "allOf", 1]
  }), a = (u) => "allOf" in u && Object.keys(u).length === 1, c = [
    ...a(r) ? r.allOf : [r],
    ...a(s) ? s.allOf : [s]
  ];
  n.allOf = c, t.intersections.push(c);
}, ku = (e, t, n, i) => {
  const o = n, r = e._zod.def;
  o.type = "array";
  const s = t.target === "draft-2020-12" ? "prefixItems" : "items", a = t.target === "draft-2020-12" || t.target === "openapi-3.0" ? "items" : "additionalItems", c = r.items.map((v, z) => j(v, t, {
    ...i,
    path: [...i.path, s, z]
  })), u = r.rest ? j(r.rest, t, {
    ...i,
    path: [...i.path, a, ...t.target === "openapi-3.0" ? [r.items.length] : []]
  }) : null;
  let l = r.items.length;
  for (; l > 0; ) {
    const v = r.items[l - 1];
    if (!(t.io === "input" ? Be(v) !== void 0 : v._zod.optout === "optional"))
      break;
    l--;
  }
  const d = r.items.length, m = !r.rest;
  t.target === "draft-2020-12" ? (o.prefixItems = c, m ? o.items = !1 : u && (o.items = u), l > 0 && (o.minItems = l), m && (o.maxItems = d)) : t.target === "openapi-3.0" ? (o.items = {
    anyOf: c
  }, u && o.items.anyOf.push(u), l > 0 && (o.minItems = l), m && (o.maxItems = d)) : (o.items = c, m ? o.additionalItems = !1 : u && (o.additionalItems = u), l > 0 && (o.minItems = l), m && (o.maxItems = d));
  const { minimum: f, maximum: _ } = q(e);
  typeof f == "number" && (o.minItems = f), typeof _ == "number" && (o.maxItems = _);
};
function Yt(e, t, n) {
  if (t.$ref) {
    if (n.has(t))
      return t;
    n.add(t);
    const _ = e.get(t)?.def;
    if (!_)
      return t;
    const v = Yt(e, _, n);
    return v === _ ? t : v;
  }
  for (const _ of ["anyOf", "oneOf"]) {
    const v = t[_];
    if (!Array.isArray(v))
      continue;
    const z = v.map((O) => Yt(e, O, n));
    z.some((O, D) => O !== v[D]) && (t = { ...t, [_]: z });
  }
  const i = Array.isArray(t.type) ? t.type : [t.type], o = !i.includes("string") && i.some((_) => _ === "number" || _ === "integer"), r = t.enum ?? (t.const !== void 0 ? [t.const] : void 0);
  if (!o && !r?.some((_) => typeof _ == "number"))
    return t;
  const { minimum: s, maximum: a, exclusiveMinimum: c, exclusiveMaximum: u, multipleOf: l, format: d, id: m, ...f } = t;
  return f.enum ? f.enum = f.enum.map((_) => typeof _ == "number" ? String(_) : _) : typeof f.const == "number" && (f.const = String(f.const)), o && (f.type = "string", r || (f.pattern = (i.includes("number") ? mn : Ts).source)), f;
}
const Qt = /* @__PURE__ */ new WeakMap();
function zu(e) {
  const t = /* @__PURE__ */ new Map();
  for (const i of e.seen.values())
    i.def && !t.has(i.schema) && t.set(i.schema, i);
  const n = /* @__PURE__ */ new Map();
  for (const i of Qt.get(e) ?? []) {
    const o = e.seen.get(i), r = (o?.def ?? o?.schema)?.propertyNames;
    if (!r || r === !0 || n.has(r))
      continue;
    const s = Yt(t, r, /* @__PURE__ */ new Set());
    s !== r && n.set(r, s);
  }
  if (n.size)
    for (const i of e.seen.values())
      for (const o of [i.schema, i.def]) {
        const r = o && n.get(o.propertyNames);
        r && (o.propertyNames = r);
      }
}
const xu = (e, t, n, i) => {
  const o = n, r = e._zod.def;
  o.type = "object";
  const s = r.keyType, a = q(s).patterns;
  if (r.mode === "loose" && a && a.size > 0) {
    const l = j(r.valueType, t, {
      ...i,
      path: [...i.path, "patternProperties", "*"]
    });
    o.patternProperties = {};
    for (const d of a)
      re(o.patternProperties, zo(d).source, l);
  } else {
    if (t.target === "draft-07" || t.target === "draft-2020-12") {
      o.propertyNames = j(r.keyType, t, {
        ...i,
        path: [...i.path, "propertyNames"]
      });
      let l = Qt.get(t);
      l || (l = [], Qt.set(t, l), t.deferred.push(() => zu(t))), l.push(e);
    }
    o.additionalProperties = j(r.valueType, t, {
      ...i,
      path: [...i.path, "additionalProperties"]
    });
  }
  const c = s._zod.values, u = t.io === "input" && Be(r.valueType) !== void 0;
  if (c && !r.partial && !u) {
    const l = [...c].filter((d) => typeof d == "string" || typeof d == "number");
    l.length > 0 && (o.required = l.map(String));
  }
}, Iu = (e, t, n, i) => {
  const o = e._zod.def, r = j(o.innerType, t, i), s = t.seen.get(e);
  t.target === "openapi-3.0" ? (s.ref = o.innerType, n.nullable = !0) : n.anyOf = [r, { type: "null" }];
}, Su = (e, t, n, i) => {
  const o = e._zod.def;
  j(o.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = o.innerType;
}, bn = /* @__PURE__ */ Symbol();
function xo(e, t, n, i, o) {
  let r = !1;
  const s = JSON.stringify(e, (a, c) => typeof c != "bigint" ? c : (r = !0, null));
  return r ? (me(t, n, i, o, "BigInt defaults cannot be represented in JSON Schema"), bn) : JSON.parse(s);
}
const Ou = (e, t, n, i) => {
  const o = e._zod.def;
  j(o.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = o.innerType;
  const s = xo(o.defaultValue, e, t, n, i);
  s !== bn && (n.default = s);
}, $u = (e, t, n, i) => {
  const o = e._zod.def;
  j(o.innerType, t, i);
  const r = t.seen.get(e);
  if (r.ref = o.innerType, t.io !== "input")
    return;
  const s = xo(o.defaultValue, e, t, n, i);
  s !== bn && (n._prefault = s);
}, Eu = (e, t, n, i) => {
  const o = e._zod.def;
  j(o.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = o.innerType;
  let s;
  try {
    s = o.catchValue(void 0);
  } catch {
    me(e, t, n, i, "Dynamic catch values are not supported in JSON Schema");
    return;
  }
  n.default = s;
}, Tu = (e, t, n, i) => {
  const o = e._zod.def, r = o.in._zod.traits.has("$ZodTransform"), s = t.io === "input" ? r ? o.out : o.in : o.out;
  j(s, t, i);
  const a = t.seen.get(e);
  a.ref = s;
}, Pu = (e, t, n, i) => {
  const o = e._zod.def;
  j(o.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = o.innerType, n.readOnly = !0;
}, Io = (e, t, n, i) => {
  const o = e._zod.def;
  j(o.innerType, t, i);
  const r = t.seen.get(e);
  r.ref = o.innerType;
}, fi = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function tt(e, t, n) {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    get() {
      const i = n(this);
      return Object.defineProperty(this, t, { value: i, configurable: !0, writable: !0 }), i;
    },
    set(i) {
      Object.defineProperty(this, t, { value: i, configurable: !0, writable: !0 });
    }
  });
}
const Zu = (e, t) => {
  Lr.init(e, t), e.name = "ZodError";
  const n = Object.getPrototypeOf(e);
  fi.has(n) || (fi.add(n), tt(n, "format", (i) => (o) => Jr(i, o)), tt(n, "flatten", (i) => (o) => Br(i, o)), tt(n, "addIssue", (i) => (o) => {
    i.issues.push(o), i.message = JSON.stringify(i.issues, Ht, 2);
  }), tt(n, "addIssues", (i) => (o) => {
    i.issues.push(...o), i.message = JSON.stringify(i.issues, Ht, 2);
  }), Object.defineProperty(n, "isEmpty", {
    configurable: !0,
    enumerable: !1,
    get() {
      return this.issues.length === 0;
    }
  }));
}, H = /* @__PURE__ */ p("ZodError", Zu, void 0, {
  Parent: Error
}), Au = /* @__PURE__ */ ln(H), Nu = /* @__PURE__ */ dn(H), ju = /* @__PURE__ */ pn(H), Ru = /* @__PURE__ */ fn(H), Cu = /* @__PURE__ */ Xr(H), Du = /* @__PURE__ */ Yr(H), Mu = /* @__PURE__ */ Qr(H), Fu = /* @__PURE__ */ es(H), Uu = /* @__PURE__ */ ts(H), Lu = /* @__PURE__ */ ns(H), qu = /* @__PURE__ */ is(H), Bu = /* @__PURE__ */ os(H);
function Ju() {
  J.localeError || X(uc());
}
function Ke() {
  J.memoizer || X({ memoizer: sc() });
}
const Z = /* @__PURE__ */ p("ZodType", (e, t) => (Ju(), E.init(e, t), e.def = t, e.type = t.type, e), {
  check(...e) {
    const t = this.def;
    return this.clone(U(t, {
      checks: [
        ...t.checks ?? [],
        ...e.map((n) => typeof n == "function" ? { _zod: { check: n, def: { check: "custom" }, onattach: [] } } : n)
      ]
    }), { parent: !0 });
  },
  with(...e) {
    return this.check(...e);
  },
  clone(e, t) {
    return he(this, e, t);
  },
  brand() {
    return this;
  },
  register(e, t) {
    return e.add(this, t), this;
  },
  refine(e, t) {
    return this.check(Fl(e, t));
  },
  superRefine(e, t) {
    return this.check(Ul(e, t));
  },
  overwrite(e) {
    return this.check(/* @__PURE__ */ Ee(e));
  },
  optional() {
    return gi(this);
  },
  exactOptional() {
    return Ol(this);
  },
  nullable() {
    return bi(this);
  },
  nullish() {
    return gi(bi(this));
  },
  nonoptional(e) {
    return Al(this, e);
  },
  array() {
    return x(this);
  },
  or(e) {
    return se([this, e]);
  },
  and(e) {
    return kl(this, e);
  },
  transform(e) {
    return yi(this, Sl(e));
  },
  default(e) {
    return Tl(this, e);
  },
  prefault(e) {
    return Zl(this, e);
  },
  catch(e) {
    return jl(this, e);
  },
  pipe(e) {
    return yi(this, e);
  },
  readonly() {
    return Dl(this);
  },
  describe(e) {
    const t = this.clone();
    return De.add(t, { description: e }), t;
  },
  meta(...e) {
    if (e.length === 0)
      return De.get(this);
    const t = this.clone();
    return De.add(t, e[0]), t;
  },
  isOptional() {
    return this.safeParse(void 0).success;
  },
  isNullable() {
    return this.safeParse(null).success;
  },
  apply(e, ...t) {
    return t.length === 0 ? e(this) : e(this, ...t);
  },
  // Overrides core's `~standard` to add `jsonSchema`. Must stay a prototype entry: redefining it per instance demotes instances to dictionary mode.
  get "~standard"() {
    return Fi(this, "~standard", {
      ...Vi(this),
      jsonSchema: {
        input: mt(this, "input"),
        output: mt(this, "output")
      }
    });
  },
  set "~standard"(e) {
    fe(this, "~standard", e);
  },
  parse: function e(t, n) {
    return Au(this, t, n, { callee: e });
  },
  parseAsync: async function e(t, n) {
    return await Nu(this, t, n, { callee: e });
  },
  safeParse(e, t) {
    return ju(this, e, t);
  },
  async safeParseAsync(e, t) {
    return Ru(this, e, t);
  },
  // `spa` is an alias: same function object as `safeParseAsync`, as before.
  get spa() {
    return this?.safeParseAsync;
  },
  set spa(e) {
    fe(this, "spa", e);
  },
  validate(e, t) {
    return Vr(this, e, t);
  },
  validateAsync(e, t) {
    return Wr(this, e, t);
  },
  encode: function e(t, n) {
    return Cu(this, t, n, { callee: e });
  },
  decode: function e(t, n) {
    return Du(this, t, n, { callee: e });
  },
  encodeAsync: async function e(t, n) {
    return await Mu(this, t, n, { callee: e });
  },
  decodeAsync: async function e(t, n) {
    return await Fu(this, t, n, { callee: e });
  },
  safeEncode(e, t) {
    return Uu(this, e, t);
  },
  safeDecode(e, t) {
    return Lu(this, e, t);
  },
  async safeEncodeAsync(e, t) {
    return qu(this, e, t);
  },
  async safeDecodeAsync(e, t) {
    return Bu(this, e, t);
  },
  toJSONSchema(e) {
    return ou(this, {})(e);
  },
  // Reads through to the registry on every access, so it must not cache.
  get description() {
    return De.get(this)?.description;
  },
  // No setter: `schema._def = x` throws, as it did when `_def` was a non-writable own property.
  get _def() {
    return this._zod.def;
  }
}), So = /* @__PURE__ */ p(
  "_ZodString",
  (e, t) => {
    _n.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => cu(e, n, i);
  },
  /* @__PURE__ */ Ui({
    format: (e) => q(e).format ?? null,
    minLength: (e) => q(e).minimum ?? null,
    maxLength: (e) => q(e).maximum ?? null
  }, {
    regex(...e) {
      return this.check(/* @__PURE__ */ Lc(...e));
    },
    includes(...e) {
      return this.check(/* @__PURE__ */ Jc(...e));
    },
    startsWith(...e) {
      return this.check(/* @__PURE__ */ Hc(...e));
    },
    endsWith(...e) {
      return this.check(/* @__PURE__ */ Kc(...e));
    },
    min(...e) {
      return this.check(/* @__PURE__ */ ft(...e));
    },
    max(...e) {
      return this.check(/* @__PURE__ */ po(...e));
    },
    length(...e) {
      return this.check(/* @__PURE__ */ fo(...e));
    },
    nonempty(...e) {
      return this.check(/* @__PURE__ */ ft(1, ...e));
    },
    lowercase(e) {
      return this.check(/* @__PURE__ */ qc(e));
    },
    uppercase(e) {
      return this.check(/* @__PURE__ */ Bc(e));
    },
    trim() {
      return this.check(/* @__PURE__ */ Gc());
    },
    normalize(...e) {
      return this.check(/* @__PURE__ */ Vc(...e));
    },
    toLowerCase() {
      return this.check(/* @__PURE__ */ Wc());
    },
    toUpperCase() {
      return this.check(/* @__PURE__ */ Xc());
    },
    slugify() {
      return this.check(/* @__PURE__ */ Yc());
    }
  })
), Hu = /* @__PURE__ */ p("ZodString", (e, t) => {
  _n.init(e, t), So.init(e, t);
}, {
  email(e) {
    return this.check(/* @__PURE__ */ fc(Wu, e));
  },
  url(e) {
    return this.check(/* @__PURE__ */ uo($o, e));
  },
  jwt(e) {
    return this.check(/* @__PURE__ */ Zc(pl, e));
  },
  emoji(e) {
    return this.check(/* @__PURE__ */ bc(Yu, e));
  },
  guid(e) {
    return this.check(/* @__PURE__ */ mc(Xu, e));
  },
  uuid(e) {
    return this.check(/* @__PURE__ */ co(Me, e));
  },
  uuidv4(e) {
    return this.check(/* @__PURE__ */ hc(Me, e));
  },
  uuidv6(e) {
    return this.check(/* @__PURE__ */ _c(Me, e));
  },
  uuidv7(e) {
    return this.check(/* @__PURE__ */ gc(Me, e));
  },
  nanoid(e) {
    return this.check(/* @__PURE__ */ yc(Qu, e));
  },
  cuid(e) {
    return this.check(/* @__PURE__ */ vc(el, e));
  },
  cuid2(e) {
    return this.check(/* @__PURE__ */ wc(tl, e));
  },
  ulid(e) {
    return this.check(/* @__PURE__ */ kc(nl, e));
  },
  base64(e) {
    return this.check(/* @__PURE__ */ Ec(ul, e));
  },
  base64url(e) {
    return this.check(/* @__PURE__ */ Tc(ll, e));
  },
  xid(e) {
    return this.check(/* @__PURE__ */ zc(il, e));
  },
  ksuid(e) {
    return this.check(/* @__PURE__ */ xc(ol, e));
  },
  ipv4(e) {
    return this.check(/* @__PURE__ */ Ic(rl, e));
  },
  ipv6(e) {
    return this.check(/* @__PURE__ */ Sc(sl, e));
  },
  cidrv4(e) {
    return this.check(/* @__PURE__ */ Oc(al, e));
  },
  cidrv6(e) {
    return this.check(/* @__PURE__ */ $c(cl, e));
  },
  e164(e) {
    return this.check(/* @__PURE__ */ Pc(dl, e));
  },
  datetime(e) {
    return this.check(/* @__PURE__ */ Ac(Ku, e));
  },
  date(e) {
    return this.check(/* @__PURE__ */ lo(Oo, e));
  },
  time(e) {
    return this.check(/* @__PURE__ */ Nc(Vu, e));
  },
  duration(e) {
    return this.check(/* @__PURE__ */ jc(Gu, e));
  }
});
function b(e) {
  return /* @__PURE__ */ pc(Hu, e);
}
const N = /* @__PURE__ */ p("ZodStringFormat", (e, t) => {
  A.init(e, t), So.init(e, t);
}), Ku = /* @__PURE__ */ p("ZodISODateTime", (e, t) => {
  pa.init(e, t), N.init(e, t);
}), Oo = /* @__PURE__ */ p("ZodISODate", (e, t) => {
  fa.init(e, t), N.init(e, t);
}), Vu = /* @__PURE__ */ p("ZodISOTime", (e, t) => {
  ma.init(e, t), N.init(e, t);
}), Gu = /* @__PURE__ */ p("ZodISODuration", (e, t) => {
  ha.init(e, t), N.init(e, t);
}), Wu = /* @__PURE__ */ p("ZodEmail", (e, t) => {
  Ys.init(e, t), N.init(e, t);
}), Xu = /* @__PURE__ */ p("ZodGUID", (e, t) => {
  Ws.init(e, t), N.init(e, t);
}), Me = /* @__PURE__ */ p("ZodUUID", (e, t) => {
  Xs.init(e, t), N.init(e, t);
});
function ve(e) {
  return /* @__PURE__ */ co(Me, e);
}
const $o = /* @__PURE__ */ p("ZodURL", (e, t) => {
  oa.init(e, t), N.init(e, t);
});
function be(e) {
  return /* @__PURE__ */ uo($o, e);
}
const Yu = /* @__PURE__ */ p("ZodEmoji", (e, t) => {
  ra.init(e, t), N.init(e, t);
}), Qu = /* @__PURE__ */ p("ZodNanoID", (e, t) => {
  sa.init(e, t), N.init(e, t);
}), el = /* @__PURE__ */ p("ZodCUID", (e, t) => {
  aa.init(e, t), N.init(e, t);
}), tl = /* @__PURE__ */ p("ZodCUID2", (e, t) => {
  ca.init(e, t), N.init(e, t);
}), nl = /* @__PURE__ */ p("ZodULID", (e, t) => {
  ua.init(e, t), N.init(e, t);
}), il = /* @__PURE__ */ p("ZodXID", (e, t) => {
  la.init(e, t), N.init(e, t);
}), ol = /* @__PURE__ */ p("ZodKSUID", (e, t) => {
  da.init(e, t), N.init(e, t);
}), rl = /* @__PURE__ */ p("ZodIPv4", (e, t) => {
  _a.init(e, t), N.init(e, t);
}), sl = /* @__PURE__ */ p("ZodIPv6", (e, t) => {
  ba.init(e, t), N.init(e, t);
}), al = /* @__PURE__ */ p("ZodCIDRv4", (e, t) => {
  ya.init(e, t), N.init(e, t);
}), cl = /* @__PURE__ */ p("ZodCIDRv6", (e, t) => {
  wa.init(e, t), N.init(e, t);
}), ul = /* @__PURE__ */ p("ZodBase64", (e, t) => {
  ka.init(e, t), N.init(e, t);
}), ll = /* @__PURE__ */ p("ZodBase64URL", (e, t) => {
  xa.init(e, t), N.init(e, t);
}), dl = /* @__PURE__ */ p("ZodE164", (e, t) => {
  Ia.init(e, t), N.init(e, t);
}), pl = /* @__PURE__ */ p("ZodJWT", (e, t) => {
  Oa.init(e, t), N.init(e, t);
}), Eo = /* @__PURE__ */ p(
  "ZodNumber",
  (e, t) => {
    eo.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => uu(e, n, i, o), e.isFinite = !0;
  },
  /* @__PURE__ */ Ui({
    minValue: (e) => {
      const { minimum: t, exclusiveMinimum: n } = q(e);
      return Math.max(t ?? Number.NEGATIVE_INFINITY, n ?? Number.NEGATIVE_INFINITY);
    },
    maxValue: (e) => {
      const { maximum: t, exclusiveMaximum: n } = q(e);
      return Math.min(t ?? Number.POSITIVE_INFINITY, n ?? Number.POSITIVE_INFINITY);
    },
    isInt: (e) => {
      const { isInt: t, multipleOf: n } = q(e);
      return !!t || !!n?.some(Number.isSafeInteger);
    },
    format: (e) => q(e).format ?? null
  }, {
    gt(e, t) {
      return this.check(/* @__PURE__ */ oi(e, t));
    },
    gte(e, t) {
      return this.check(/* @__PURE__ */ jt(e, t));
    },
    min(e, t) {
      return this.check(/* @__PURE__ */ jt(e, t));
    },
    lt(e, t) {
      return this.check(/* @__PURE__ */ ii(e, t));
    },
    lte(e, t) {
      return this.check(/* @__PURE__ */ Nt(e, t));
    },
    max(e, t) {
      return this.check(/* @__PURE__ */ Nt(e, t));
    },
    int(e) {
      return this.check(mi(e));
    },
    safe(e) {
      return this.check(mi(e));
    },
    positive(e) {
      return this.check(/* @__PURE__ */ oi(0, e));
    },
    nonnegative(e) {
      return this.check(/* @__PURE__ */ jt(0, e));
    },
    negative(e) {
      return this.check(/* @__PURE__ */ ii(0, e));
    },
    nonpositive(e) {
      return this.check(/* @__PURE__ */ Nt(0, e));
    },
    multipleOf(e, t) {
      return this.check(/* @__PURE__ */ ri(e, t));
    },
    step(e, t) {
      return this.check(/* @__PURE__ */ ri(e, t));
    },
    finite() {
      return this;
    }
  })
);
function S(e) {
  return /* @__PURE__ */ Rc(Eo, e);
}
const fl = /* @__PURE__ */ p("ZodNumberFormat", (e, t) => {
  $a.init(e, t), Eo.init(e, t);
});
function mi(e) {
  return /* @__PURE__ */ Cc(fl, e);
}
const ml = /* @__PURE__ */ p("ZodBoolean", (e, t) => {
  Ea.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => lu(e, n, i);
});
function ie(e) {
  return /* @__PURE__ */ Dc(ml, e);
}
const hl = /* @__PURE__ */ p("ZodNull", (e, t) => {
  Ta.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => du(e, n, i);
});
function en(e) {
  return /* @__PURE__ */ Mc(hl, e);
}
const _l = /* @__PURE__ */ p("ZodUnknown", (e, t) => {
  Pa.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => fu();
});
function hi() {
  return /* @__PURE__ */ Fc(_l);
}
const gl = /* @__PURE__ */ p("ZodNever", (e, t) => {
  Za.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => pu(e, n, i);
});
function To(e) {
  return /* @__PURE__ */ Uc(gl, e);
}
const bl = /* @__PURE__ */ p("ZodArray", (e, t) => {
  Ke(), ja.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => bu(e, n, i, o), e.element = t.element;
}, {
  min(e, t) {
    return this.check(/* @__PURE__ */ ft(e, t));
  },
  nonempty(e) {
    return this.check(/* @__PURE__ */ ft(1, e));
  },
  max(e, t) {
    return this.check(/* @__PURE__ */ po(e, t));
  },
  length(e, t) {
    return this.check(/* @__PURE__ */ fo(e, t));
  },
  unwrap() {
    return this.element;
  }
});
function x(e, t) {
  return /* @__PURE__ */ Qc(bl, e, t);
}
const yl = /* @__PURE__ */ p("ZodObject", (e, t) => {
  Ke(), Da.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => yu(e, n, i, o), Nr(e, "shape", (n) => n._zod.def.shape, !1);
}, {
  keyof() {
    return h(Object.keys(this._zod.def.shape));
  },
  catchall(e) {
    return this.clone(U(this._zod.def, { catchall: e }));
  },
  passthrough() {
    return this.clone(U(this._zod.def, { catchall: hi() }));
  },
  loose() {
    return this.clone(U(this._zod.def, { catchall: hi() }));
  },
  strict() {
    return this.clone(U(this._zod.def, { catchall: To() }));
  },
  strip() {
    return this.clone(U(this._zod.def, { catchall: void 0 }));
  },
  extend(e) {
    return zr(this, e);
  },
  safeExtend(e) {
    return xr(this, e);
  },
  merge(e) {
    return Ir(this, e);
  },
  pick(e) {
    return wr(this, e);
  },
  omit(e) {
    return kr(this, e);
  },
  partial(...e) {
    return Rn(yn, this, e[0]);
  },
  exactPartial(...e) {
    return Rn(Zo, this, e[0], "exactPartial");
  },
  required(...e) {
    return Sr(Ao, this, e[0]);
  }
});
function g(e, t) {
  return new yl({
    type: "object",
    shape: e,
    catchall: To(),
    ...w(t)
  });
}
const Po = /* @__PURE__ */ p("ZodUnion", (e, t) => {
  io.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => vu(e, n, i, o), e.options = t.options;
});
function se(e, t) {
  return new Po({
    type: "union",
    options: e,
    ...w(t)
  });
}
const vl = /* @__PURE__ */ p("ZodDiscriminatedUnion", (e, t) => {
  Po.init(e, t), Fa.init(e, t);
});
function Te(e, t, n) {
  return new vl({
    type: "union",
    options: t,
    discriminator: e,
    ...w(n)
  });
}
const wl = /* @__PURE__ */ p("ZodIntersection", (e, t) => {
  Ua.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => wu(e, n, i, o);
});
function kl(e, t) {
  return new wl({
    type: "intersection",
    left: e,
    right: t
  });
}
const zl = /* @__PURE__ */ p("ZodTuple", (e, t) => {
  Ke(), La.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => ku(e, n, i, o);
}, {
  rest(e) {
    return this.clone({
      ...this._zod.def,
      rest: e
    });
  },
  partial() {
    const e = this._zod.def;
    if (e.checks?.length)
      throw new Error(".partial() cannot be used on tuple schemas containing refinements");
    return this.clone({
      ...e,
      items: e.items.map((t) => new yn({ type: "optional", innerType: t }))
    });
  }
});
function _i(e, t, n) {
  const i = t instanceof E, o = i ? n : t, r = i ? t : null;
  return new zl({
    type: "tuple",
    items: e,
    rest: r,
    ...w(o)
  });
}
const tn = /* @__PURE__ */ p("ZodRecord", (e, t) => {
  Ke(), qa.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => xu(e, n, i, o), e.keyType = t.keyType, e.valueType = t.valueType;
});
function ee(e, t, n) {
  return !t || !t._zod ? new tn({
    type: "record",
    keyType: b(),
    valueType: e,
    ...w(t)
  }) : new tn({
    type: "record",
    keyType: e,
    valueType: t,
    ...w(n)
  });
}
function le(e, t, n) {
  return new tn({
    type: "record",
    keyType: e,
    valueType: t,
    ...w(n),
    partial: !0
  });
}
const nn = /* @__PURE__ */ p("ZodEnum", (e, t) => {
  Ba.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (i, o, r) => mu(e, i, o), e.enum = t.entries, e.options = [...e._zod.values];
  const n = new Set(Object.keys(t.entries));
  e.extract = (i, o) => {
    const r = {};
    for (const s of i)
      if (n.has(s))
        r[s] = t.entries[s];
      else
        throw new Error(`Key ${s} not found in enum`);
    return new nn({
      ...t,
      checks: [],
      ...w(o),
      entries: r
    });
  }, e.exclude = (i, o) => {
    const r = { ...t.entries };
    for (const s of i)
      if (n.has(s))
        delete r[s];
      else
        throw new Error(`Key ${s} not found in enum`);
    return new nn({
      ...t,
      checks: [],
      ...w(o),
      entries: r
    });
  };
});
function h(e, t) {
  const n = Array.isArray(e) ? Object.fromEntries(e.map((i) => [i, i])) : e;
  return new nn({
    type: "enum",
    entries: n,
    ...w(t)
  });
}
const xl = /* @__PURE__ */ p("ZodLiteral", (e, t) => {
  Ja.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => hu(e, n, i, o), e.values = new Set(t.values), Object.defineProperty(e, "value", {
    get() {
      if (t.values.length > 1)
        throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
      return t.values[0];
    }
  });
});
function y(e, t) {
  return new xl({
    type: "literal",
    values: Array.isArray(e) ? e : [e],
    ...w(t)
  });
}
const Il = /* @__PURE__ */ p("ZodTransform", (e, t) => {
  Ke(), Ha.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => gu(e, n, i, o), e._zod.parse = (n, i) => {
    if (i.direction === "backward")
      throw new Li(e.constructor.name);
    n.addIssue = (r) => {
      if (typeof r == "string")
        n.issues.push(qe(r, n.value, t));
      else {
        const s = r;
        s.fatal && (s.continue = !1), s.code ?? (s.code = "custom"), "input" in s || (s.input = n.value), s.inst ?? (s.inst = e), n.issues.push(qe(s));
      }
    };
    const o = t.transform(n.value, n);
    return o instanceof Promise ? o.then((r) => (n.value = r, n)) : (n.value = o, n);
  };
});
function Sl(e) {
  return new Il({
    type: "transform",
    transform: e
  });
}
const yn = /* @__PURE__ */ p("ZodOptional", (e, t) => {
  oo.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Io(e, n, i, o), e.unwrap = () => e._zod.def.innerType;
});
function gi(e) {
  return new yn({
    type: "optional",
    innerType: e
  });
}
const Zo = /* @__PURE__ */ p("ZodExactOptional", (e, t) => {
  Ka.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Io(e, n, i, o), e.unwrap = () => e._zod.def.innerType;
});
function Ol(e) {
  return new Zo({
    type: "optional",
    innerType: e
  });
}
const $l = /* @__PURE__ */ p("ZodNullable", (e, t) => {
  Va.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Iu(e, n, i, o), e.unwrap = () => e._zod.def.innerType;
});
function bi(e) {
  return new $l({
    type: "nullable",
    innerType: e
  });
}
const El = /* @__PURE__ */ p("ZodDefault", (e, t) => {
  Ga.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Ou(e, n, i, o), e.unwrap = () => e._zod.def.innerType, e.removeDefault = e.unwrap;
});
function Tl(e, t) {
  return new El({
    type: "default",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Ri(t);
    }
  });
}
const Pl = /* @__PURE__ */ p("ZodPrefault", (e, t) => {
  Wa.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => $u(e, n, i, o), e.unwrap = () => e._zod.def.innerType;
});
function Zl(e, t) {
  return new Pl({
    type: "prefault",
    innerType: e,
    get defaultValue() {
      return typeof t == "function" ? t() : Ri(t);
    }
  });
}
const Ao = /* @__PURE__ */ p("ZodNonOptional", (e, t) => {
  Xa.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Su(e, n, i, o), e.unwrap = () => e._zod.def.innerType;
});
function Al(e, t) {
  return new Ao({
    type: "nonoptional",
    innerType: e,
    ...w(t)
  });
}
const Nl = /* @__PURE__ */ p("ZodCatch", (e, t) => {
  Ya.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Eu(e, n, i, o), e.unwrap = () => e._zod.def.innerType, e.removeCatch = e.unwrap;
});
function jl(e, t) {
  return new Nl({
    type: "catch",
    innerType: e,
    catchValue: typeof t == "function" ? t : Rr(t)
  });
}
const Rl = /* @__PURE__ */ p("ZodPipe", (e, t) => {
  Qa.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Tu(e, n, i, o), e.in = t.in, e.out = t.out;
});
function yi(e, t) {
  return new Rl({
    type: "pipe",
    in: e,
    out: t
    // ...util.normalizeParams(params),
  });
}
const Cl = /* @__PURE__ */ p("ZodReadonly", (e, t) => {
  ec.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => Pu(e, n, i, o), e.unwrap = () => e._zod.def.innerType;
});
function Dl(e) {
  return new Cl({
    type: "readonly",
    innerType: e
  });
}
const Ml = /* @__PURE__ */ p("ZodCustom", (e, t) => {
  tc.init(e, t), Z.init(e, t), e._zod.processJSONSchema = (n, i, o) => _u(e, n, i, o);
});
function Fl(e, t = {}) {
  return /* @__PURE__ */ eu(Ml, e, t);
}
function Ul(e, t) {
  return /* @__PURE__ */ tu(e, t);
}
function wt(e) {
  return /* @__PURE__ */ lo(Oo, e);
}
X({ jitless: !0 });
const I = b().regex(/^(0|[1-9][0-9]{0,18})$/).refine(
  (e) => /^(0|[1-9][0-9]{0,18})$/.test(e) && BigInt(e) <= 9223372036854775807n,
  "Counter overflow"
), kt = b().regex(/^(0|[1-9][0-9]*)(\.[0-9]{1,18})?$/).refine((e) => e.replace(".", "").length <= 38, "Decimal overflow"), G = b().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/).refine(
  (e) => !Number.isNaN(Date.parse(e)) && new Date(e).toISOString() === e,
  "Invalid calendar instant"
), k = b().regex(/^[0-9a-f]{64}$/), P = b().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/), vn = b().max(96).regex(/^-?(0|[1-9][0-9]*)(\.[0-9]+)?(e[+-]?[0-9]{1,3})?$/).refine((e) => Number.isFinite(Number(e)), "Nonfinite quantity").refine(
  (e) => Number(e) !== 0 || /^-?0(\.0+)?(e[+-]?[0-9]{1,3})?$/.test(e),
  "Quantity underflow"
), te = vn.refine(
  (e) => Number(e) >= 0 && !Object.is(Number(e), -0),
  "Negative quantity"
), ht = h(["original", "ecologits"]), zt = h([
  "build_default",
  "original",
  "ecologits"
]), on = S().int().min(1).max(2147483647), ze = b().regex(/^[a-z][a-z0-9_-]{0,63}$/), No = b().regex(/^[A-Za-z0-9][A-Za-z0-9._:/@+\-]{0,191}$/), Ve = g({
  provider: ze,
  model_name: No,
  workload: h(["text", "video"])
}), wn = g({
  strategy: y("original_engine")
}), kn = g({
  strategy: y("unavailable")
}), jo = g({
  strategy: y("upstream_provider_flagship"),
  profile: Ve
}), Ll = Te("strategy", [
  jo,
  wn,
  kn
]), ql = h([
  "nearest_record",
  "family_benchmark",
  "model_not_named",
  "model_not_in_library",
  // The highest version of the same family in the catalog, for a version not listed yet.
  "model_family_stand_in",
  // The highest version of the same variant (GPT Pro, Gemini Pro Image) for a variant not listed.
  "model_variant_stand_in",
  // The highest model of the same kind and vendor when the catalog has no record of the variant.
  "model_kind_stand_in"
]), Bl = Te("strategy", [
  g({
    strategy: y("upstream_profile"),
    profile: Ve,
    basis: ql
  }),
  wn,
  kn
]), Ro = g({
  policy_version: P,
  review_date: wt(),
  provider_defaults: ee(ze, Ll),
  model_overrides: ee(P, Bl),
  /** A site without an identified provider may name one explicit benchmark profile. */
  unknown_provider: Te("strategy", [
    jo,
    wn,
    kn
  ])
}).superRefine((e, t) => {
  (Object.keys(e.provider_defaults).length > 64 || Object.keys(e.model_overrides).length > 4096) && t.addIssue({
    code: "custom",
    message: "Policy exceeds its entry limit"
  });
  for (const [n, i] of Object.entries(
    e.provider_defaults
  ))
    i.strategy === "upstream_provider_flagship" && i.profile.provider !== n && t.addIssue({
      code: "custom",
      message: "A provider flagship must belong to that provider",
      path: ["provider_defaults", n]
    });
}), Jl = g({
  schema_version: y("1.0.0"),
  review_date: wt(),
  mapping_basis: y("consumer_to_api_assumption"),
  source: be(),
  bindings: ee(P, Ve).refine(
    (e) => Object.keys(e).length <= 4096,
    "Too many mappings"
  )
}), nt = h([
  "chatgpt",
  "claude",
  "gemini",
  "perplexity",
  "notebooklm"
]), ne = b().regex(/^(0|[1-9][0-9]{0,6})(\.[0-9]{1,9})?$/).refine((e) => Number(e) > 0, "Coefficient must be positive"), vi = se([
  ne,
  g({ min: ne, max: ne }).refine(
    (e) => Number(e.min) <= Number(e.max),
    "Range minimum exceeds its maximum"
  )
]), Hl = g({
  factor: ne,
  tokenizer_profile_id: y("o200k-base-4.0.0-reference"),
  measured_on: wt(),
  source: be()
}), wi = g({
  width: S().int().min(1).max(65536),
  height: S().int().min(1).max(65536),
  duration_seconds: ne,
  with_audio: ie()
}), Kl = g({
  schema_version: y("1.0.0"),
  review_date: wt(),
  image: g({
    method_id: P,
    it_energy_wh_per_image: ne,
    source: be(),
    model_providers: ee(P, ze),
    site_providers: le(nt, ze)
  }),
  speech: g({
    method_id: P,
    profile: Ve,
    tokens_per_second: ee(ze, ne),
    characters_per_second: ne,
    site_providers: le(nt, ze),
    source: be()
  }),
  video: g({
    method_id: P,
    // The registry model that stands in when the page shows a video but names no model.
    site_models: le(nt, P),
    site_defaults: le(nt, wi),
    model_defaults: ee(No, wi),
    source: be()
  }),
  overview: g({
    method_id: P,
    seconds_per_illustration: ne
  }),
  // A model served away from its catalog provider's data centres takes the grid and, when
  // given, the PUE and WUE of where it runs. Factors replace the provider's for that model only.
  environment_overrides: ee(
    P,
    g({
      electricity_mix_zone: b().regex(/^[A-Z]{3}$/),
      datacenter_pue: vi.optional(),
      datacenter_wue: vi.optional()
    }).refine(
      (e) => e.datacenter_pue === void 0 || Number(
        typeof e.datacenter_pue == "string" ? e.datacenter_pue : e.datacenter_pue.min
      ) >= 1,
      "PUE cannot be below 1"
    )
  ),
  // Optional, so method definitions saved before 15 October 2026 stay readable: a method
  // without it estimates Claude text from the tokenizer's count unchanged.
  claude_token_factor: Hl.optional()
}), Vl = g({
  catalog_schema: P,
  catalog_sha256: k,
  converter_version: P,
  core_sha256: k,
  core_version: P,
  requested_git_commit: b().regex(/^[a-f0-9]{40}$/),
  source_artifact_sha256: k,
  upstream_version: P
});
g({
  schema_version: y("1.0.0"),
  engine_id: y("ecologits"),
  core: Vl,
  mappings: Jl,
  fallback: Ro,
  media: Kl,
  product_policy: y("operational-only-output-1"),
  latency_policy: y("observed-live-then-history-then-modeled-1"),
  environment_policy: y("upstream-provider-default-assumed"),
  water_total_policy: y("upstream-wcf-1"),
  original_fallback: g({
    method_id: P,
    method_hash: k
  })
});
g({
  schema_version: y("1.0.0"),
  default_engine: ht,
  // Keep historical research configurations readable after retiring the Original engine.
  available_engines: se([
    _i([y("ecologits")]),
    _i([y("original"), y("ecologits")])
  ]),
  ecologits_fallback: Ro
});
g({
  schema_version: y("1.0.0"),
  preference: zt,
  selection_revision: on,
  updated_at: G
});
const Je = g({
  engine_id: ht,
  implementation_version: P,
  method_id: P,
  method_hash: k,
  source_version: P.nullable(),
  source_commit: b().regex(/^[a-f0-9]{40}$/).nullable(),
  catalog_hash: k.nullable(),
  profile_policy_hash: k,
  environment_policy_hash: k,
  product_scope: y("operational-only")
}), Gl = g({
  observed_request_id: ve(),
  canonical_request_id: ve(),
  relation_hash: k
}), Wl = g({
  message_key: k,
  observation_hash: k
}), Xl = Te("family", [
  g({
    family: y("live"),
    request_id: ve(),
    request_revision: on,
    request_hash: k,
    attempt_id: ve(),
    attempt_revision: on,
    attempt_hash: k,
    canonical_request_binding: Gl.optional(),
    history_binding: Wl.optional()
  }),
  g({
    family: y("history"),
    message_key: k,
    observation_hash: k
  })
]), L = b().regex(/^[0-9]+(\.[0-9]+)?$/).refine((e) => Number(e) > 0 && Number(e) < 1e9), it = b().regex(/^(0|[1-9][0-9]*)(\.[0-9]+)?$/).refine((e) => Number(e) < 1e9).nullable(), zn = g({
  publisher: b(),
  title: b(),
  url: be(),
  section: b(),
  source_revision: b(),
  license: b(),
  access_date: b(),
  activity_period: b().nullable(),
  factor_data_period: b().nullable(),
  publication_date: b().nullable(),
  software_snapshot: b(),
  review_date: b(),
  unknown_period_reason: b(),
  population: b(),
  statistic: h(["scenario_example", "measured_configuration"])
}), Co = g({
  id: b(),
  pue: it,
  carbon: it,
  carbon_gas: h(["CO2", "CO2e"]),
  carbon_boundary: h(["generation", "lifecycle", "unknown"]),
  carbon_accounting: h(["location", "market"]),
  gases: x(b()),
  gwp: b().nullable(),
  direct_water: it,
  direct_denominator: h(["it", "facility"]),
  upstream_water: it,
  water_kind: y("consumption"),
  direct_water_source: h(["freshwater", "all_source", "unknown"]),
  upstream_water_source: h(["freshwater", "all_source", "unknown"]),
  common_water_scope: h(["freshwater_consumption", "all_source_consumption"]).nullable(),
  upstream_exclusions: x(b()),
  provenance: zn
}).refine((e) => e.pue === null || Number(e.pue) >= 1, "PUE below 1");
g({
  schema_version: y("1.0.0"),
  method_id: b().regex(/^[a-z0-9.-]+$/),
  equation_id: h(["ecologits-output-v1", "test-linear-v1"]),
  runtime_selection_allowed: y(!0),
  validation_state: y("unvalidated_reference"),
  reviewer: b().min(1),
  review_date: b(),
  release_validation: y("pending"),
  coefficients: g({
    energyAlpha: L,
    energyBeta: b().regex(/^-[0-9]+\.[0-9]+$/),
    energyGamma: L,
    latencyAlpha: L,
    latencyBeta: L,
    latencyGamma: L
  }),
  settings: g({
    gpuMemoryGb: L,
    precisionBits: y("16"),
    batchSize: L,
    memoryMultiplier: L,
    hostPowerKw: L,
    serverGpuCount: L
  }),
  profiles: x(
    g({
      id: b(),
      model: b(),
      activeBillions: L,
      totalBillions: L,
      architecture_source: be()
    })
  ).min(1).max(1e3),
  scenario: Co,
  provenance: zn,
  missing_components: x(b())
});
const Do = [
  "capture_hook_missing",
  "protocol_unsupported",
  "composer_anchor_missing",
  "capture_limit_exceeded",
  "model_unverified",
  "tokenizer_unavailable",
  "storage_write_failed",
  "ledger_integrity_failed",
  "auth_reconnect_required",
  "enrollment_revoked",
  "sync_delayed",
  "payload_rejected",
  "revision_conflict",
  "request_identity_ambiguous",
  "dependency_missing",
  "clock_skew",
  "estimate_pending",
  "estimate_unavailable",
  "method_update_invalid",
  "aggregate_inconsistent",
  "ip_unresolved",
  "ip_history_expired",
  "retention_expired",
  "deletion_in_progress",
  "policy_unavailable",
  "guidance_budget_unavailable",
  "host_interference_detected",
  "conversation_identity_local_only",
  "cross_device_dedup_unverified",
  "hidden_reasoning_unobserved",
  "context_unobserved",
  "cache_semantics_unknown",
  "tool_work_unobserved",
  "media_processing_unobserved",
  "media_metadata_limit_exceeded",
  "image_dimensions_unknown",
  "image_settings_unknown",
  "image_execution_incomplete",
  "tokenizer_mapping_unverified",
  "observed_text_only",
  "not_applicable",
  "provider_usage_unavailable",
  "malformed_frame",
  "unsupported_operation",
  "conflicting_duplicate_identity",
  "capture_body_missing",
  "buffer_overflow",
  "stale_tokenizer_response",
  "tokenizer_timeout",
  "unknown_model",
  "profile_absent",
  "no_comparable_profile",
  "input_length_not_modelled",
  "unvalidated_reference",
  "factor_unavailable",
  "factor_incompatible",
  "method_unsupported",
  "partial_capture",
  "history_only",
  "historical_timing_conflict",
  "unknown_terminal_state",
  "media_direction_unknown",
  "provider_selection_unverified",
  "reasoning_overlap_unknown",
  "record_erased",
  // Tracking accuracy rules of 30 Sep to 4 Oct 2026. Each names what Details explains.
  "reasoning_summary_only",
  "research_work_unobserved",
  "side_calls_unobserved",
  "unknown_event_observed",
  "model_not_in_library",
  "model_not_named",
  "model_stand_in",
  "component_unavailable",
  "media_default_assumed",
  "speech_length_estimated",
  "file_size_estimated",
  "content_not_opened",
  "environment_override",
  // A saved row no live capture can produce (NotebookLM Studio); never an unresolved match.
  "no_live_request"
], Pe = h(Do), Yl = (e) => e / 2 ** 32 | 0, Ql = (e) => e >>> 0;
function ed(e, t, n, i) {
  const o = Yl(n), r = Ql(n);
  e.setUint32(t, i ? r : o, i), e.setUint32(t + 4, i ? o : r, i);
}
function ki(e) {
  return e instanceof Uint8Array || ArrayBuffer.isView(e) && e.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in e && e.BYTES_PER_ELEMENT === 1;
}
const td = (e) => e ? `"${e}" ` : "";
function xn(e, t, n = "") {
  if (ki(e) && t === void 0)
    return e;
  const i = ki(e), o = "", r = i ? `length=${e.length}` : `type=${typeof e}`, s = td(n) + "expected Uint8Array" + o + ", got " + r;
  throw i ? new RangeError(s) : new TypeError(s);
}
const nd = (e, t) => {
  if (e === null || typeof e != "object" || Array.isArray(e))
    throw new TypeError((t === "object" ? "" : `"${t}" `) + "expected object, got type=" + typeof e);
}, zi = (e, t) => {
  nd(e, t);
  const n = Object.getPrototypeOf(e);
  if (n !== Object.prototype && n !== null)
    throw new TypeError(`"${t}" expected plain object`);
  if (Object.hasOwn(e, "__proto__"))
    throw new TypeError(`"${t}.__proto__" is not allowed`);
};
function xi(e, t = !0) {
  if (e.destroyed)
    throw new Error("hash was destroyed");
  if (t && e.finished)
    throw new Error("digest() was already called");
}
function id(e, t) {
  xn(e, void 0, "output");
  const n = t.outputLen;
  if (!(e.length >= n))
    throw new RangeError('"output" expected length >= ' + n);
}
function Ii(...e) {
  for (let t = 0; t < e.length; t++)
    e[t].fill(0);
}
function Rt(e) {
  return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function Q(e, t) {
  return e << 32 - t | e >>> t;
}
const od = /* @ts-ignore */ typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function", rd = /* @__PURE__ */ Array.from({ length: 256 }, (e, t) => t.toString(16).padStart(2, "0"));
function sd(e) {
  if (xn(e), od)
    return e.toHex();
  let t = "";
  for (let n = 0; n < e.length; n++)
    t += rd[e[n]];
  return t;
}
function ad(e, t, n = "opts") {
  return zi(e, "defaults"), t !== void 0 && zi(t, n), Object.assign(/* @__PURE__ */ Object.create(null), e, t);
}
function cd(e, t = {}) {
  if (typeof e != "function")
    throw new TypeError('"hashCons" expected function, got type=' + typeof e);
  t = ad({}, t, "info");
  const n = (o, r) => e(r).update(o).digest(), i = e(void 0);
  return n.outputLen = i.outputLen, n.blockLen = i.blockLen, n.canXOF = i.canXOF, n.create = (o) => e(o), Object.assign(n, t), Object.freeze(n);
}
const ud = (e) => ({
  // Current NIST hashAlgs suffixes used here fit in one DER subidentifier octet.
  // Larger suffix values would need base-128 OID encoding and a different length byte.
  oid: Uint8Array.from([6, 9, 96, 134, 72, 1, 101, 3, 4, 2, e])
});
function ld(e, t, n) {
  return e & t ^ ~e & n;
}
function dd(e, t, n) {
  return e & t ^ e & n ^ t & n;
}
class pd {
  blockLen;
  outputLen;
  canXOF = !1;
  padOffset;
  isLE;
  // For partial updates less than block size
  buffer;
  view;
  finished = !1;
  length = 0;
  pos = 0;
  destroyed = !1;
  constructor(t, n, i, o) {
    this.blockLen = t, this.outputLen = n, this.padOffset = i, this.isLE = o, this.buffer = new Uint8Array(t), this.view = Rt(this.buffer);
  }
  update(t) {
    xi(this), xn(t);
    const { view: n, buffer: i, blockLen: o } = this, r = t.length;
    let s = !1;
    for (let a = 0; a < r; ) {
      const c = Math.min(o - this.pos, r - a);
      if (c === o) {
        const u = Rt(t);
        for (; o <= r - a; a += o)
          this.process(u, a);
        s = !0;
        continue;
      }
      i.set(a === 0 && c === r ? t : t.subarray(a, a + c), this.pos), this.pos += c, a += c, this.pos === o && (this.process(n, 0), this.pos = 0, s = !0);
    }
    return this.length += t.length, s && this.roundClean(), this;
  }
  digestInto(t) {
    xi(this), id(t, this), this.finished = !0;
    const { buffer: n, view: i, blockLen: o, isLE: r } = this;
    let { pos: s } = this;
    n[s++] = 128, n.fill(0, s), this.padOffset > o - s && (this.process(i, 0), n.fill(0)), ed(i, o - 8, this.length * 8, r), this.process(i, 0), this.roundClean();
    const a = t === n ? i : Rt(t), c = this.outputLen, u = c / 4, l = this.get();
    if (c % 4 || u > l.length)
      throw new Error("invalid outputLen");
    for (let d = 0; d < u; d++)
      a.setUint32(4 * d, l[d], r);
  }
  digest() {
    const { buffer: t, outputLen: n } = this;
    this.digestInto(t);
    const i = t.slice(0, n);
    return this.destroy(), i;
  }
  _cloneIntoMeta(t) {
    const { buffer: n, length: i, finished: o, destroyed: r, pos: s } = this;
    return t.destroyed = r, t.finished = o, t.length = i, t.pos = s, s && t.buffer.set(n), t;
  }
  clone() {
    return this._cloneInto();
  }
}
const fd = /* @__PURE__ */ Uint32Array.from([
  1779033703,
  3144134277,
  1013904242,
  2773480762,
  1359893119,
  2600822924,
  528734635,
  1541459225
]), md = /* @__PURE__ */ Uint32Array.from([
  1116352408,
  1899447441,
  3049323471,
  3921009573,
  961987163,
  1508970993,
  2453635748,
  2870763221,
  3624381080,
  310598401,
  607225278,
  1426881987,
  1925078388,
  2162078206,
  2614888103,
  3248222580,
  3835390401,
  4022224774,
  264347078,
  604807628,
  770255983,
  1249150122,
  1555081692,
  1996064986,
  2554220882,
  2821834349,
  2952996808,
  3210313671,
  3336571891,
  3584528711,
  113926993,
  338241895,
  666307205,
  773529912,
  1294757372,
  1396182291,
  1695183700,
  1986661051,
  2177026350,
  2456956037,
  2730485921,
  2820302411,
  3259730800,
  3345764771,
  3516065817,
  3600352804,
  4094571909,
  275423344,
  430227734,
  506948616,
  659060556,
  883997877,
  958139571,
  1322822218,
  1537002063,
  1747873779,
  1955562222,
  2024104815,
  2227730452,
  2361852424,
  2428436474,
  2756734187,
  3204031479,
  3329325298
]), ae = /* @__PURE__ */ new Uint32Array(64);
class hd extends pd {
  // We cannot use array here since array allows indexing by variable
  // which means optimizer/compiler cannot use registers.
  // Numeric initializers matter: starting the fields as `undefined` changes
  // V8's field representation and makes sha256 3x slower (measured).
  A = 0;
  B = 0;
  C = 0;
  D = 0;
  E = 0;
  F = 0;
  G = 0;
  H = 0;
  constructor(t, n) {
    super(64, t, 8, !1), this.A = n[0] | 0, this.B = n[1] | 0, this.C = n[2] | 0, this.D = n[3] | 0, this.E = n[4] | 0, this.F = n[5] | 0, this.G = n[6] | 0, this.H = n[7] | 0;
  }
  get() {
    const { A: t, B: n, C: i, D: o, E: r, F: s, G: a, H: c } = this;
    return [t, n, i, o, r, s, a, c];
  }
  // prettier-ignore
  set(t, n, i, o, r, s, a, c) {
    this.A = t | 0, this.B = n | 0, this.C = i | 0, this.D = o | 0, this.E = r | 0, this.F = s | 0, this.G = a | 0, this.H = c | 0;
  }
  _cloneInto(t) {
    return (t ||= new this.constructor()).set(...this.get()), this._cloneIntoMeta(t);
  }
  process(t, n) {
    for (let d = 0; d < 16; d++, n += 4)
      ae[d] = t.getUint32(n, !1);
    for (let d = 16; d < 64; d++) {
      const m = ae[d - 15], f = ae[d - 2], _ = Q(m, 7) ^ Q(m, 18) ^ m >>> 3, v = Q(f, 17) ^ Q(f, 19) ^ f >>> 10;
      ae[d] = v + ae[d - 7] + _ + ae[d - 16] | 0;
    }
    let { A: i, B: o, C: r, D: s, E: a, F: c, G: u, H: l } = this;
    for (let d = 0; d < 64; d++) {
      const m = Q(a, 6) ^ Q(a, 11) ^ Q(a, 25), f = l + m + ld(a, c, u) + md[d] + ae[d] | 0, v = (Q(i, 2) ^ Q(i, 13) ^ Q(i, 22)) + dd(i, o, r) | 0;
      l = u, u = c, c = a, a = s + f | 0, s = r, r = o, o = i, i = f + v | 0;
    }
    i = i + this.A | 0, o = o + this.B | 0, r = r + this.C | 0, s = s + this.D | 0, a = a + this.E | 0, c = c + this.F | 0, u = u + this.G | 0, l = l + this.H | 0, this.set(i, o, r, s, a, c, u, l);
  }
  roundClean() {
    Ii(ae);
  }
  destroy() {
    this.destroyed = !0, this.set(0, 0, 0, 0, 0, 0, 0, 0), Ii(this.buffer);
  }
}
class _d extends hd {
  constructor() {
    super(32, fd);
  }
}
const gd = /* @__PURE__ */ cd(
  () => new _d(),
  /* @__PURE__ */ ud(1)
);
function we(e, t = 0) {
  if (t > 16) throw new Error("payload_rejected");
  if (e === null || typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isSafeInteger(e))
    return JSON.stringify(e);
  if (Array.isArray(e))
    return "[" + e.map((n) => we(n, t + 1)).join(",") + "]";
  if (typeof e == "object" && Object.getPrototypeOf(e) === Object.prototype)
    return "{" + Object.keys(e).sort().map(
      (n) => JSON.stringify(n) + ":" + we(e[n], t + 1)
    ).join(",") + "}";
  throw new Error("payload_rejected");
}
function $e(e) {
  return sd(gd(new TextEncoder().encode(we(e))));
}
const Mo = se([
  Pe,
  h([
    "provider_unknown",
    "model_override",
    "provider_policy",
    "unknown_provider_policy",
    "model_provider_conflict",
    "unsupported_workload",
    "numeric_domain_unsupported",
    "model_proxy",
    "original_engine_fallback",
    "provider_environment_assumed",
    "source_error",
    "source_warning",
    "cancelled",
    "stale_estimation_result",
    "original_method_missing"
  ])
]), xt = x(Mo).max(96);
function Fo(e, t, n) {
  return n === "original_fallback" ? e === "ecologits" && t === "original" : n === "legacy_reference" ? e === "original" && t === "original" : ["direct_mapping", "model_override", "provider_flagship"].includes(
    n
  ) ? e === "ecologits" && t === "ecologits" : n === "unavailable" && e === t;
}
const bd = se([
  te,
  g({
    min: te,
    max: te
  }).refine(
    (e) => Number(e.min) <= Number(e.max),
    "Reversed impact interval"
  )
]);
function Ge(e, t, n) {
  return g({
    type: y(e),
    name: y(t),
    unit: y(n),
    value: bd
  });
}
const Si = Ge("energy", "Energy", "kWh"), Ct = Ge("GWP", "Global Warming Potential", "kgCO2eq"), Dt = Ge("ADPe", "Abiotic Depletion Potential (elements)", "kgSbeq"), Mt = Ge("PE", "Primary Energy", "MJ"), Oi = Ge("WCF", "Water Consumption Footprint", "L"), $i = g({
  code: b().regex(/^[a-z][a-z0-9_-]{0,127}$/),
  message: b().max(1024)
}), Uo = g({
  energy: Si.nullable(),
  gwp: Ct.nullable(),
  adpe: Dt.nullable(),
  pe: Mt.nullable(),
  wcf: Oi.nullable(),
  usage: g({
    type: y("usage"),
    name: y("Usage"),
    energy: Si,
    gwp: Ct,
    adpe: Dt,
    pe: Mt,
    wcf: Oi
  }).nullable(),
  embodied: g({
    type: y("embodied"),
    name: y("Embodied"),
    gwp: Ct,
    adpe: Dt,
    pe: Mt
  }).nullable(),
  warnings: x($i).min(1).max(64).nullable(),
  errors: x($i).min(1).max(64).nullable()
}).superRefine((e, t) => {
  const n = [
    e.energy,
    e.gwp,
    e.adpe,
    e.pe,
    e.wcf,
    e.usage,
    e.embodied
  ];
  (e.errors === null ? n.some((i) => i === null) : n.some((i) => i !== null)) && t.addIssue({
    code: "custom",
    message: "Inconsistent upstream outcome"
  });
}), je = g({
  value: kt.nullable(),
  unit: h(["kWh", "gCO2e", "gCO2", "L"]),
  status: h(["partial_estimate", "unavailable"]),
  scope: b(),
  scenario_low: en(),
  scenario_high: en(),
  reasons: x(b())
}), Lo = g({
  profile_selection: h(["reference_only", "unavailable"]),
  reference_only: y(!0),
  selected_profile_id: b().nullable(),
  cohort_id: b(),
  cohort_hash: k,
  eligible_candidate_count: S().int().nonnegative(),
  result_scope: y("gpu_associated_reference"),
  starting_energy_boundary: y("gpu"),
  gpu_kwh: kt.nullable(),
  generated_image_count: I.nullable(),
  known_settings: g({
    width: S().nullable().optional(),
    height: S().nullable().optional(),
    steps: S().nullable().optional(),
    precision: b().optional(),
    kind: b().optional()
  }),
  reasons: x(b())
}), yd = g({
  schema_version: y("1.0.0"),
  attempt_id: ve(),
  observation_revision: S().int().min(1),
  observation_hash: k,
  method_id: P,
  method_hash: k,
  view: h(["original", "recalculated"]),
  original_method_hash: k.nullable(),
  observed_model_key: b().nullable(),
  model_evidence: b(),
  profile_selection: h([
    "matched_profile",
    "highest_comparable",
    "reference_only",
    "unavailable"
  ]),
  selected_profile_id: b().nullable(),
  cohort_id: b(),
  cohort_hash: k,
  eligible_candidate_count: S().int().nonnegative(),
  eligibility_signature: k,
  environment_scenario_id: b(),
  factor_provenance_status: b(),
  starting_energy_boundary: y("it"),
  result_scope: y("modeled_text_component"),
  reference_only: ie(),
  validation_state: y("unvalidated_reference"),
  known_settings: ee(b(), b()),
  assumed_settings: ee(b(), b()),
  selection_reason: b(),
  included_components: x(b()),
  missing_components: x(b()),
  reasons: x(b()),
  metrics: g({
    energy: je,
    carbon: je,
    water_direct: je,
    water_upstream: je,
    water_total: je
  }),
  image_references: x(Lo),
  provenance: zn,
  environment_provenance: Co
}), qo = g({
  quantity: h([
    "energy",
    "carbon",
    "water_direct",
    "water_upstream",
    "water_total"
  ]),
  value: kt.nullable(),
  unit: b(),
  scope: y("historical_visible_response"),
  method_id: P,
  method_hash: k,
  status: h(["partial_estimate", "unavailable"]),
  validation_state: y("unvalidated_reference"),
  profile_selection: h(["highest_comparable", "unavailable"]),
  selected_profile_id: b().nullable(),
  reasons: x(b()),
  missing_components: x(b()),
  known_message_count: I,
  unknown_message_count: I
}), vd = x(qo).max(5).refine(
  (e) => (e.length === 0 || e.length === 5) && new Set(e.map((t) => t.quantity)).size === e.length,
  "Incomplete historical result"
), Re = g({
  value: te.nullable(),
  unit: h(["kWh", "gCO2e", "gCO2", "L"]),
  status: h(["partial_estimate", "unavailable"]),
  scope: h([
    "modeled_text_component",
    "historical_visible_response",
    "modeled_video_component",
    "modeled_image_component",
    "modeled_speech_component"
  ]),
  phase: y("usage"),
  scenario_low: te.nullable(),
  scenario_high: te.nullable(),
  interval_kind: h(["upstream_approximation", "scenario"]).nullable(),
  value_kind: h(["scalar", "midpoint", "unavailable"]),
  reasons: xt
}).superRefine((e, t) => {
  const n = e.value === null, i = e.scenario_low !== null && e.scenario_high !== null;
  (n !== (e.status === "unavailable") || n !== (e.value_kind === "unavailable")) && t.addIssue({
    code: "custom",
    message: "Metric availability contradicts value"
  }), (i !== (e.value_kind === "midpoint") || i !== (e.interval_kind !== null) || e.scenario_low === null != (e.scenario_high === null)) && t.addIssue({
    code: "custom",
    message: "Incomplete interval metadata"
  }), i && (Number(e.scenario_low) > Number(e.value) || Number(e.value) > Number(e.scenario_high)) && t.addIssue({
    code: "custom",
    message: "Display value outside interval"
  });
});
h(["minimum", "midpoint", "maximum"]);
const Bo = g({
  energy: Re,
  carbon: Re,
  water_direct: Re,
  water_upstream: Re,
  water_total: Re
}).superRefine((e, t) => {
  (e.energy.unit !== "kWh" || !["gCO2e", "gCO2"].includes(e.carbon.unit) || [e.water_direct, e.water_upstream, e.water_total].some(
    (n) => n.unit !== "L"
  )) && t.addIssue({
    code: "custom",
    message: "Metric has incompatible units"
  });
}), Jo = "3.0.0", wd = [
  "exact_record",
  "nearest_record",
  "family_benchmark",
  "model_not_named",
  "model_not_in_library",
  "model_family_stand_in",
  "model_variant_stand_in",
  "model_kind_stand_in"
], kd = h(wd), Ho = g({
  kind: h([
    "legacy_reference",
    "direct_mapping",
    "model_override",
    "provider_flagship",
    "original_fallback",
    "unavailable"
  ]),
  observed_model_id: P.nullable(),
  profile: Ve.nullable(),
  reason: Mo.nullable(),
  basis: kd.nullable()
}), Ft = te.nullable(), zd = g({
  output_tokens: I.nullable(),
  latency_seconds: Ft,
  latency_basis: h(["measured", "history", "research_task", "modeled"]).nullable(),
  environment_provider: b().regex(/^[a-z][a-z0-9_-]{0,63}$/).nullable(),
  electricity_mix_zone: b().regex(/^[A-Z]{3}$/).nullable(),
  units: I.nullable(),
  width: S().int().min(1).max(65536).nullable(),
  height: S().int().min(1).max(65536).nullable(),
  duration_seconds: Ft,
  with_audio: ie().nullable(),
  audio_seconds: Ft,
  defaults_applied: x(h(["resolution", "duration", "audio", "length", "model"])).max(5)
}), xd = g({
  component_id: b().regex(/^[a-z][a-z_]{0,31}_[0-9]{1,3}$/),
  kind: h(["text", "image", "video", "speech"]),
  role: h([
    "main",
    "side_calls",
    "research",
    "storyboard",
    "generated_image",
    "generated_video",
    "generated_speech",
    "overview_illustrations",
    "overview_narration"
  ]),
  method_id: P,
  selection: Ho.nullable(),
  inputs: zd,
  raw: Uo.nullable(),
  status: h(["estimated", "unavailable"]),
  metrics: Bo,
  reasons: xt
}).superRefine((e, t) => {
  Object.values(e.metrics).some(
    (i) => i.value !== null
  ) !== (e.status === "estimated") && t.addIssue({
    code: "custom",
    message: "Component status contradicts its metrics"
  }), e.selection !== null && ["direct_mapping", "model_override", "provider_flagship"].includes(
    e.selection.kind
  ) !== (e.selection.profile !== null) && t.addIssue({
    code: "custom",
    message: "Component selection profile mismatch"
  }), e.raw?.errors && e.status === "estimated" && t.addIssue({
    code: "custom",
    message: "Component estimate carries upstream errors"
  });
}), Id = g({
  schema_version: y(Jo),
  source: Xl,
  input_hash: k,
  auxiliary_method_hashes: g({
    image_reference: k
  }),
  requested_method: Je,
  effective_method: Je,
  execution_origin: h(["local", "organization"]),
  view: h(["original", "recalculated"]),
  original_method_hash: k.nullable(),
  selection: Ho,
  components: x(xd).max(96),
  raw: Te("engine_id", [
    g({
      engine_id: y("original"),
      result: se([
        yd,
        vd
      ])
    }),
    g({
      engine_id: y("ecologits"),
      result: Uo
    })
  ]).nullable(),
  status: h(["estimated", "unavailable"]),
  metrics: Bo,
  image_references: x(Lo).max(100),
  reasons: xt,
  missing_components: x(b().regex(/^[a-z][a-z0-9_]{0,127}$/)).max(64),
  validation_state: y("unvalidated_reference"),
  comparability: g({
    energy_boundary: y("facility"),
    carbon_boundary: h(["generation", "lifecycle", "unknown"]),
    carbon_accounting: h(["location", "market"]),
    water_kind: y("consumption"),
    direct_water_source: h(["freshwater", "all_source", "unknown"]),
    upstream_water_source: h(["freshwater", "all_source", "unknown"]),
    common_water_scope: h(["freshwater_consumption", "all_source_consumption"]).nullable(),
    tokenizer_profile_id: P.nullable()
  })
}).superRefine((e, t) => {
  e.requested_method.engine_id === e.effective_method.engine_id && $e(e.requested_method) !== $e(e.effective_method) && t.addIssue({
    code: "custom",
    message: "The same engine must retain its complete method identity"
  }), e.input_hash !== Od(e) && t.addIssue({
    code: "custom",
    message: "Calculation input hash mismatch"
  }), e.image_references.some(
    (r) => r.cohort_hash !== e.auxiliary_method_hashes.image_reference
  ) && t.addIssue({
    code: "custom",
    message: "Independent image method mismatch"
  }), Fo(
    e.requested_method.engine_id,
    e.effective_method.engine_id,
    e.selection.kind
  ) || t.addIssue({
    code: "custom",
    message: "Selection misattributes its engine"
  }), ["direct_mapping", "model_override", "provider_flagship"].includes(
    e.selection.kind
  ) !== (e.selection.profile !== null) && t.addIssue({
    code: "custom",
    message: "Selection profile mismatch"
  }), e.raw !== null && e.raw.engine_id !== e.effective_method.engine_id && t.addIssue({
    code: "custom",
    message: "Raw output engine mismatch"
  });
  const n = e.reasons.includes("original_method_missing");
  n && (e.view !== "recalculated" || e.source.family !== "live" || e.original_method_hash !== null) && t.addIssue({
    code: "custom",
    message: "Missing original lineage is only valid for an explicitly unrecorded live calculation"
  }), e.view === "recalculated" && e.original_method_hash === null && !n && t.addIssue({
    code: "custom",
    message: "Recalculation requires original lineage"
  }), e.status === "unavailable" && Object.values(e.metrics).some((r) => r.value !== null) && t.addIssue({
    code: "custom",
    message: "Unavailable result has a successful metric"
  });
  const i = e.components.some(
    (r) => r.status === "estimated"
  );
  e.status === "estimated" && (e.raw === null && !i || Object.values(e.metrics).every(
    (r) => r.value === null
  ) || e.raw?.engine_id === "ecologits" && e.raw.result.errors !== null && !i) && t.addIssue({
    code: "custom",
    message: "Estimated result lacks numerical evidence"
  }), (i || e.effective_method.engine_id === "ecologits") && !Sd(e.metrics, e.components) && t.addIssue({
    code: "custom",
    message: "Top-level metrics must equal the sum of the estimated components"
  }), e.effective_method.engine_id === "original" && e.components.length > 0 && t.addIssue({
    code: "custom",
    message: "The original method has no components"
  }), new Set(e.components.map((r) => r.component_id)).size !== e.components.length && t.addIssue({
    code: "custom",
    message: "Duplicate component identity"
  });
  const o = e.components.filter(
    (r) => r.role === "main"
  );
  if (e.effective_method.engine_id === "ecologits" && (o.length > 1 || we(e.raw) !== we(
    o[0]?.raw ? { engine_id: "ecologits", result: o[0].raw } : null
  )) && t.addIssue({
    code: "custom",
    message: "Raw output must be the main component's raw output"
  }), e.requested_method.engine_id !== e.effective_method.engine_id && !(e.requested_method.engine_id === "ecologits" && e.effective_method.engine_id === "original" && e.selection.kind === "original_fallback") && t.addIssue({
    code: "custom",
    message: "Unsupported engine substitution"
  }), e.raw?.engine_id === "original") {
    const r = e.raw.result;
    Array.isArray(r) ? (e.source.family !== "history" || r.some(
      (s) => s.method_hash !== e.effective_method.method_hash || s.method_id !== e.effective_method.method_id
    ) || r.length === 0 && e.status === "estimated") && t.addIssue({
      code: "custom",
      message: "Original historical result binding mismatch"
    }) : (e.source.family !== "live" || r.observation_hash !== e.source.attempt_hash || r.observation_revision !== e.source.attempt_revision || r.attempt_id !== e.source.attempt_id || r.method_hash !== e.effective_method.method_hash || r.method_id !== e.effective_method.method_id || r.observed_model_key !== e.selection.observed_model_id) && t.addIssue({
      code: "custom",
      message: "Original live result binding mismatch"
    });
  }
});
function ot(e, t) {
  if (e === null) return !1;
  const n = Number(e);
  return Math.abs(n - t) <= 1e-9 * Math.max(Math.abs(n), Math.abs(t));
}
function Sd(e, t) {
  const n = t.filter(
    (i) => i.status === "estimated"
  );
  return Object.keys(e).every((i) => {
    const o = n.map((c) => c.metrics[i]).filter((c) => c.value !== null), r = e[i];
    if (!o.length) return r.value === null;
    if (r.value_kind === "scalar")
      return !o.some((c) => c.value_kind === "midpoint") && ot(
        r.value,
        o.reduce((c, u) => c + Number(u.value), 0)
      );
    const s = o.reduce(
      (c, u) => c + Number(u.scenario_low ?? u.value),
      0
    ), a = o.reduce(
      (c, u) => c + Number(u.scenario_high ?? u.value),
      0
    );
    return r.value_kind === "midpoint" && ot(r.scenario_low, s) && ot(r.scenario_high, a) && ot(r.value, (s + a) / 2);
  });
}
function Od(e) {
  return $e({
    schema_version: Jo,
    source: e.source,
    requested_method_hash: e.requested_method.method_hash,
    effective_method_hash: e.effective_method.method_hash,
    selection: e.selection,
    auxiliary_method_hashes: e.auxiliary_method_hashes
  });
}
const $d = g({
  ...qo.shape,
  value: te.nullable(),
  unit: h(["kWh", "gCO2e", "gCO2", "L"]),
  phase: y("usage"),
  scenario_low: te.nullable(),
  scenario_high: te.nullable(),
  interval_kind: h(["upstream_approximation", "scenario"]).nullable(),
  value_kind: h(["scalar", "midpoint", "midpoint_sum", "unavailable"]),
  profile_selection: h([
    "legacy_reference",
    "direct_mapping",
    "model_override",
    "provider_flagship",
    "original_fallback",
    "unavailable"
  ]),
  selected_profile_id: b().max(320).regex(/^[A-Za-z0-9][A-Za-z0-9._:/@+\-]*$/).nullable(),
  reasons: xt,
  requested_method: Je,
  effective_method: Je,
  comparability: Id.shape.comparability
}).superRefine((e, t) => {
  const n = (r) => t.addIssue({ code: "custom", message: r });
  e.requested_method.engine_id === e.effective_method.engine_id && $e(e.requested_method) !== $e(e.effective_method) && n(
    "The same historical engine must retain its complete method identity"
  ), Fo(
    e.requested_method.engine_id,
    e.effective_method.engine_id,
    e.profile_selection
  ) || n("Historical selection misattributes its engine"), (e.method_id !== e.requested_method.method_id || e.method_hash !== e.requested_method.method_hash) && n("Historical method binding mismatch"), (e.value === null != (e.status === "unavailable") || e.value === null != (e.value_kind === "unavailable")) && n("Historical availability mismatch"), (e.profile_selection === "unavailable" && e.selected_profile_id !== null || e.value !== null && e.selected_profile_id === null) && n("Historical profile mismatch");
  const i = e.scenario_low !== null && e.scenario_high !== null, o = e.value_kind === "midpoint" || e.value_kind === "midpoint_sum";
  (e.scenario_low === null != (e.scenario_high === null) || e.value_kind === "midpoint" && (!i || e.interval_kind === null) || e.value_kind === "midpoint_sum" && e.interval_kind !== null || !o && (i || e.interval_kind !== null)) && n("Historical interval metadata mismatch"), i && (Number(e.scenario_low) > Number(e.value) || Number(e.value) > Number(e.scenario_high)) && n("Historical value outside interval"), (e.quantity === "energy" ? e.unit !== "kWh" : e.quantity === "carbon" ? !["gCO2e", "gCO2"].includes(e.unit) : e.unit !== "L") && n("Historical quantity unit mismatch"), e.requested_method.engine_id !== e.effective_method.engine_id && !(e.requested_method.engine_id === "ecologits" && e.effective_method.engine_id === "original" && e.profile_selection === "original_fallback") && n("Historical engine substitution mismatch");
}), Ed = [
  "chatgpt-latest",
  "chatgpt-gpt-5-6-sol",
  "chatgpt-gpt-5-5",
  "chatgpt-gpt-5-6-luna",
  "chatgpt-gpt-5-6-sol-pro",
  "chatgpt-gpt-6-pro",
  "chatgpt-reasoning-effort",
  "chatgpt-pro-option",
  "chatgpt-think",
  "chatgpt-images-2-5",
  "chatgpt-images-thinking",
  "chatgpt-gpt-live-1",
  "chatgpt-gpt-live-1-mini",
  "chatgpt-voice-live",
  "chatgpt-voice-advanced",
  "chatgpt-voice-standard",
  "chatgpt-gpt-6-2-sol",
  "chatgpt-gpt-6-2-astra",
  "chatgpt-gpt-6-1-terra",
  "chatgpt-gpt-6-2-sol-pro",
  "chatgpt-gpt-6-2-astra-pro",
  "chatgpt-gpt-6-1-terra-pro",
  "chatgpt-gpt-6-1-sol",
  "chatgpt-gpt-6-sol",
  "chatgpt-gpt-6-luna",
  "chatgpt-gpt-6-astra",
  "chatgpt-gpt-6-1-sol-pro",
  "chatgpt-gpt-6-sol-pro",
  "chatgpt-gpt-6-luna-pro",
  "chatgpt-gpt-5-6-luna-pro",
  "chatgpt-gpt-5-6-terra-pro",
  "chatgpt-gpt-5-6-terra",
  "chatgpt-gpt-5-5-pro",
  "chatgpt-gpt-5-5-mini",
  "chatgpt-gpt-5-4",
  "chatgpt-gpt-5-4-pro",
  "chatgpt-gpt-5-4-mini",
  "chatgpt-gpt-5-3-mini",
  "chatgpt-gpt-5-2",
  "chatgpt-gpt-5-2-pro",
  "chatgpt-gpt-5-1",
  "chatgpt-gpt-5",
  "chatgpt-gpt-5-mini",
  "chatgpt-gpt-5-pro",
  "chatgpt-gpt-4-1",
  "chatgpt-gpt-4-1-mini",
  "chatgpt-gpt-4o",
  "chatgpt-gpt-4o-mini",
  "chatgpt-gpt-4",
  "chatgpt-gpt-3-5",
  "chatgpt-o4-mini",
  "chatgpt-o3",
  "chatgpt-o3-pro",
  "chatgpt-o3-mini",
  "chatgpt-o1",
  "chatgpt-voice-bidi",
  "chatgpt-deep-research",
  "chatgpt-agent",
  "chatgpt-unlisted",
  "chatgpt-gpt-sol-unlisted",
  "chatgpt-gpt-astra-unlisted",
  "chatgpt-gpt-luna-unlisted",
  "chatgpt-gpt-terra-unlisted",
  "chatgpt-gpt-pro-unlisted",
  "chatgpt-gpt-mini-unlisted",
  "chatgpt-gpt-nano-unlisted",
  "chatgpt-gpt-codex-unlisted",
  "chatgpt-gpt-sol-pro-unlisted",
  "chatgpt-gpt-astra-pro-unlisted",
  "chatgpt-gpt-luna-pro-unlisted",
  "chatgpt-gpt-terra-pro-unlisted",
  "claude-fable-5-2",
  "claude-fable-5-1",
  "claude-opus-5",
  "claude-sonnet-5",
  "claude-haiku-5-5",
  "claude-haiku-4-5",
  "claude-fable-5",
  "claude-opus-4-8",
  "claude-opus-4-7",
  "claude-opus-4-6",
  "claude-opus-3",
  "claude-sonnet-4-6",
  "claude-effort",
  "claude-thinking",
  "claude-opus-5-5",
  "claude-sonnet-5-5",
  "claude-opus-4-5",
  "claude-sonnet-4-5",
  "claude-opus-4-1",
  "claude-opus-4",
  "claude-sonnet-4",
  "claude-sonnet-3-7",
  "claude-sonnet-3-5",
  "claude-haiku-3-5",
  "claude-haiku-3",
  "claude-unlisted",
  "claude-haiku-unlisted",
  "claude-sonnet-unlisted",
  "claude-opus-unlisted",
  "claude-fable-unlisted",
  "claude-small-unlisted",
  "gemini-3-6-flash",
  "gemini-3-6-thinking",
  "gemini-3-1-pro",
  "gemini-public-flash-lite",
  "gemini-public-flash",
  "gemini-public-pro",
  "gemini-thinking-level",
  "gemini-deep-think",
  "gemini-deep-research",
  "gemini-nano-banana-2-lite",
  "gemini-nano-banana-2",
  "gemini-nano-banana-pro",
  "gemini-omni",
  "gemini-lyria",
  "gemini-4-hydrogen",
  "gemini-4-neon",
  "gemini-3-8-flash",
  "gemini-3-7-flash",
  "gemini-3-5-flash",
  "gemini-3-5-flash-lite",
  "gemini-3-flash",
  "gemini-3-pro",
  "gemini-2-5-flash",
  "gemini-2-5-flash-lite",
  "gemini-2-5-pro",
  "gemini-nano-banana",
  "gemini-omni-video",
  "gemini-unnamed",
  "gemini-unlisted",
  "gemini-flash-unlisted",
  "gemini-flash-lite-unlisted",
  "gemini-pro-unlisted",
  "gemini-pro-image-unlisted",
  "gemini-flash-image-unlisted",
  "gemini-image-unlisted",
  "perplexity-best",
  "perplexity-sonar-2",
  "perplexity-gpt-5-6-terra",
  "perplexity-gpt-5-6-sol",
  "perplexity-gemini-3-8-flash",
  "perplexity-claude-sonnet-5",
  "perplexity-claude-opus-5",
  "perplexity-kimi-k3",
  "perplexity-glm-5-3",
  "perplexity-grok-4-6",
  "perplexity-nemotron-3-ultra",
  "perplexity-gemini-3-7-flash",
  "perplexity-thinking",
  "perplexity-search",
  "perplexity-deep-research",
  "perplexity-learn",
  "perplexity-council",
  "perplexity-computer",
  "perplexity-comet",
  "perplexity-image-default",
  "perplexity-gpt-image-1",
  "perplexity-nano-banana",
  "perplexity-nano-banana-pro",
  "perplexity-seedream-4-5",
  "perplexity-veo-3-1",
  "perplexity-gpt-6-2-sol",
  "perplexity-gpt-6-2-astra",
  "perplexity-gpt-6-2-sol-pro",
  "perplexity-gpt-6-2-astra-pro",
  "perplexity-gemini-4-argon",
  "perplexity-gemini-4-carbon",
  "perplexity-gemini-4-hydrogen",
  "perplexity-gemini-4-neon",
  "perplexity-claude-fable-5-2",
  "perplexity-gpt-6-1-sol",
  "perplexity-gpt-6-sol",
  "perplexity-gpt-6-astra",
  "perplexity-gpt-6-1-sol-pro",
  "perplexity-gpt-6-sol-pro",
  "perplexity-gpt-6-astra-pro",
  "perplexity-gpt-5-6-sol-pro",
  "perplexity-gpt-5-6-terra-pro",
  "perplexity-gpt-5-5",
  "perplexity-gpt-5-4",
  "perplexity-gpt-5-2",
  "perplexity-gpt-5-2-pro",
  "perplexity-gpt-5-1",
  "perplexity-gpt-5",
  "perplexity-gpt-5-mini",
  "perplexity-gpt-5-nano",
  "perplexity-gpt-5-pro",
  "perplexity-gpt-4-1",
  "perplexity-gpt-4o",
  "perplexity-o4-mini",
  "perplexity-o3-pro",
  "perplexity-claude-fable-5-1",
  "perplexity-claude-opus-5-5",
  "perplexity-claude-sonnet-5-5",
  "perplexity-claude-opus-4-8",
  "perplexity-claude-opus-4-7",
  "perplexity-claude-opus-4-6",
  "perplexity-claude-opus-4-5",
  "perplexity-claude-opus-4-1",
  "perplexity-claude-opus-4",
  "perplexity-claude-sonnet-4-6",
  "perplexity-claude-sonnet-4-5",
  "perplexity-claude-sonnet-4",
  "perplexity-claude-haiku-4-5",
  "perplexity-gemini-3-5-flash",
  "perplexity-gemini-3-1-pro",
  "perplexity-gemini-3-flash",
  "perplexity-gemini-3-pro",
  "perplexity-gemini-2-5-pro",
  "perplexity-glm-5-2",
  "perplexity-deepseek",
  "perplexity-qwen",
  "perplexity-kimi",
  "perplexity-grok",
  "perplexity-nemotron",
  "perplexity-agentic-research",
  "perplexity-create-files",
  "perplexity-study",
  "perplexity-nano-banana-2",
  "perplexity-veo-3-1-fast",
  "perplexity-veo-3-0",
  "perplexity-veo-3-0-fast",
  "perplexity-sora-2-pro",
  "perplexity-video-unlisted",
  "perplexity-unlisted",
  "perplexity-unlisted-anthropic",
  "perplexity-unlisted-google",
  "perplexity-claude-haiku-unlisted",
  "perplexity-claude-sonnet-unlisted",
  "perplexity-claude-opus-unlisted",
  "perplexity-claude-fable-unlisted",
  "perplexity-gpt-sol-unlisted",
  "perplexity-gpt-astra-unlisted",
  "perplexity-gpt-luna-unlisted",
  "perplexity-gpt-terra-unlisted",
  "perplexity-gemini-flash-unlisted",
  "perplexity-gemini-flash-lite-unlisted",
  "perplexity-gemini-pro-unlisted",
  "perplexity-claude-small-unlisted",
  "perplexity-gpt-pro-unlisted",
  "perplexity-gpt-mini-unlisted",
  "perplexity-gpt-nano-unlisted",
  "perplexity-gpt-codex-unlisted",
  "perplexity-gpt-sol-pro-unlisted",
  "perplexity-gpt-astra-pro-unlisted",
  "perplexity-gpt-luna-pro-unlisted",
  "perplexity-gpt-terra-pro-unlisted",
  "perplexity-gemini-pro-image-unlisted",
  "perplexity-gemini-flash-image-unlisted",
  "perplexity-gemini-image-unlisted",
  "notebooklm-default",
  "notebooklm-image"
], Td = g({
  namespace: b().min(1).max(256),
  mode: h(["personal", "company"]),
  era: b().max(256).nullable()
});
g({
  preference: zt,
  expectedRevision: S().int().min(1).max(2147483647).nullable()
});
g({
  schema_version: y("1.0.0"),
  scope: Td,
  scopeToken: b().min(1).max(256),
  preference: zt.nullable(),
  selectionRevision: S().int().min(1).max(2147483647).nullable(),
  buildDefault: ht,
  effectiveEngine: ht.nullable(),
  method: Je.nullable(),
  local: g({
    status: h(["idle", "running", "complete", "pending", "failed"]),
    jobId: b().max(128).nullable(),
    processed: S().int().nonnegative(),
    unavailable: S().int().nonnegative(),
    pending: S().int().nonnegative()
  }),
  organization: g({
    status: h([
      "personal",
      "current",
      "pending",
      "unavailable",
      "invalidated"
    ]),
    reason: h([
      "sync_delayed",
      "method_unsupported",
      "deletion_changed",
      "auth_reconnect_required",
      "policy_unavailable"
    ]).nullable()
  }),
  reason: h([
    "invalid_preference",
    "engine_unavailable",
    "selection_conflict",
    "storage_write_failed",
    "estimate_unavailable",
    "policy_unavailable"
  ]).nullable()
});
const Pd = g({
  preference: zt,
  selection_revision: S().int().min(1).max(2147483647),
  method_id: P,
  method_hash: k,
  operation_id: ve()
});
g({
  selection: Pd.extend({
    selection_generation: S().int().min(1),
    job_id: k,
    updated_at: G
  }).nullable(),
  compatibility: g({
    status: h(["supported", "pending"]),
    reason: h([
      "method_unsupported",
      "method_hash_mismatch",
      "engine_mismatch",
      "engine_unavailable"
    ]).nullable()
  }).nullable(),
  recalculation: se([
    g({
      job_id: k,
      status: y("invalidated"),
      completed_at: en(),
      error_code: y("deletion_changed")
    }),
    g({
      job_id: k,
      method_id: P,
      calculation_view: y("recalculated"),
      status: h([
        "pending",
        "completed",
        "failed",
        "invalidated",
        "superseded"
      ]),
      processed_estimates: S().int().nonnegative(),
      created_at: G,
      completed_at: G.nullable(),
      error_code: b().regex(/^[a-z][a-z0-9_]{0,127}$/).nullable(),
      requires_advance: y(!1),
      selection_revision: S().int().min(1),
      selection_generation: S().int().min(1)
    })
  ]).nullable()
}).superRefine((e, t) => {
  (e.selection === null ? e.compatibility !== null || e.recalculation !== null : e.compatibility === null || e.recalculation === null) && t.addIssue({
    code: "custom",
    message: "Incomplete organization selection"
  }), e.selection && e.recalculation && (e.selection.job_id !== e.recalculation.job_id || "method_id" in e.recalculation && (e.recalculation.method_id !== e.selection.method_id || e.recalculation.selection_revision !== e.selection.selection_revision || e.recalculation.selection_generation !== e.selection.selection_generation)) && t.addIssue({
    code: "custom",
    message: "Organization selection binding mismatch"
  });
});
const In = k.nullable(), We = "3.0.0", It = x(Pe).max(32).refine((e) => new Set(e).size === e.length, "Duplicate reasons"), Ko = y("0.1.0"), Zd = [
  "chatgpt",
  "claude",
  "gemini",
  "perplexity",
  "notebooklm"
], Sn = h(Zd), ke = h(Ed).nullable(), St = h([
  "response_field",
  "request_field",
  "ui_selection",
  "unknown"
]), He = ve(), Vo = S().int().min(1).max(2147483647), Ad = [
  "o200k-base-4.0.0-reference",
  "cl100k-base-4.0.0-reference",
  "observed-text-v1",
  // Uploaded image tokens from each vendor's published rule (A7), not a text tokenizer.
  "vendor-image-rules-1"
], Xe = h(Ad).nullable(), Nd = [
  "browser_request",
  "chatgpt_history",
  "claude_history",
  "perplexity_history",
  "gemini_history",
  "cowork_history",
  "notebooklm_history"
], jd = Object.freeze({
  browser_request: ["request"],
  chatgpt_history: ["provider_message", "research_task"],
  claude_history: ["content_blocks", "research_task"],
  perplexity_history: ["workflow"],
  gemini_history: ["research_task"],
  cowork_history: ["provider_message"],
  notebooklm_history: ["provider_message"]
}), On = g({
  duration_seconds: vn.refine((e) => {
    const t = Number(e);
    if (!(t > 0 && t <= 86400)) return !1;
    const n = /^(0|[1-9][0-9]*)(?:\.([0-9]+))?(?:e([+-]?[0-9]{1,3}))?$/.exec(e);
    if (!n) return !1;
    const i = BigInt(n[1] + (n[2] ?? "")), o = Number(n[3] ?? 0) - (n[2]?.length ?? 0);
    return o >= 0 ? i * 10n ** BigInt(o) <= 86400n : i <= 86400n * 10n ** BigInt(-o);
  }, "Timing duration must be greater than zero and at most one day"),
  source: h(Nd),
  scope: h([
    "request",
    "provider_message",
    "content_blocks",
    "workflow",
    "research_task"
  ]),
  completeness: h(["complete_for_scope", "partial", "unknown"]),
  profile_version: y("timing-observation-1")
}).superRefine((e, t) => {
  jd[e.source].includes(e.scope) || t.addIssue({
    code: "custom",
    path: ["scope"],
    message: "Timing source and scope do not match"
  });
});
function Rd(e) {
  return e === "claude" ? ["claude_history", "cowork_history"] : [`${e}_history`];
}
const W = g({
  value: I.nullable(),
  evidence: h([
    "provider_reported",
    "official_tokenizer",
    "calibrated_estimate",
    "heuristic_estimate",
    "unknown",
    "not_applicable"
  ]),
  scope: h([
    "provider_request",
    "observed_text",
    "reconstructed_context",
    "provider_defined_subset"
  ]),
  completeness: h(["complete_for_scope", "partial", "unknown"]),
  profile_id: Xe,
  reason: Pe.nullable()
}).superRefine((e, t) => {
  (e.evidence === "unknown" || e.evidence === "not_applicable") && (e.value !== null || e.reason === null) && t.addIssue({
    code: "custom",
    message: "Unknown or inapplicable measurements require null and a reason"
  }), e.value === null && e.reason === null && t.addIssue({
    code: "custom",
    message: "Missing quantity requires a reason"
  }), e.value !== null && e.evidence === "calibrated_estimate" && t.addIssue({
    code: "custom",
    message: "No calibrated tokenizer profiles are approved"
  });
}), Cd = [
  "new_input_text",
  "logical_input_total",
  "input_uncached",
  "input_cache_read",
  "input_cache_write",
  "answer_output",
  "visible_thinking",
  "reported_reasoning",
  "output_total",
  "tool_input",
  "intermediate_output",
  "tool_output",
  "image_input_tokens",
  "image_output_tokens"
], $n = [
  "answer_output",
  "visible_thinking",
  "tool_input",
  "intermediate_output"
], Dd = [
  ...$n,
  "reported_reasoning",
  "tool_output",
  "image_input_tokens"
], Ei = [
  "visible_thinking",
  "tool_input",
  "intermediate_output",
  "tool_output"
], Md = g(
  Object.fromEntries(
    Cd.map((e) => [e, W])
  )
);
function Go(e = "provider_usage_unavailable") {
  return {
    value: null,
    evidence: "unknown",
    scope: "observed_text",
    completeness: "unknown",
    profile_id: null,
    reason: e
  };
}
function Fd(e) {
  const t = $n.map((a) => e[a]), n = t.filter((a) => a.value !== null), i = t.filter(
    (a) => a.value === null && a.evidence !== "not_applicable"
  );
  if (!n.length)
    return Go(
      i[0]?.reason ?? e.answer_output.reason ?? "estimate_unavailable"
    );
  const o = new Set(n.map((a) => a.profile_id)), r = new Set(n.map((a) => a.evidence)), s = i.length > 0 || n.some(
    (a) => a.completeness !== "complete_for_scope"
  ) || o.size > 1 || r.size > 1;
  return {
    value: n.reduce((a, c) => a + BigInt(c.value), 0n).toString(),
    evidence: r.size === 1 ? [...r][0] : "heuristic_estimate",
    scope: "observed_text",
    completeness: s ? "partial" : "complete_for_scope",
    profile_id: o.size === 1 ? [...o][0] : null,
    reason: s ? i[0]?.reason ?? n.find(
      (a) => a.completeness !== "complete_for_scope"
    )?.reason ?? "partial_capture" : n[0].reason ?? null
  };
}
const Wo = (e, t) => we(e) === we(Fd(t)), de = S().int().min(1).max(65536).nullable(), En = g({
  width: de,
  height: de,
  steps: S().int().min(1).max(1e4).nullable(),
  precision: h(["bfloat16", "float16", "float32", "unknown"]),
  architecture: h(["diffusion", "autoregressive", "unknown"])
}), Xo = {
  width: de,
  height: de,
  dimension_source: h([
    "original",
    "provider_resized",
    "thumbnail_only",
    "unknown"
  ])
}, Yo = h([
  "text_to_image",
  "image_edit",
  "inpaint",
  "upscale",
  "unknown"
]), Ud = h([
  "requested",
  "generating",
  "completed",
  "cancelled",
  "failed",
  "interrupted_unconfirmed"
]), Ld = g({
  count: I,
  origin: h(["new_upload", "retained_context", "unknown_origin"]),
  ...Xo,
  detail: h(["low", "high", "auto", "unknown"]),
  token_profile_id: Xe,
  tokens: W
}), qd = g({
  operation_key: k,
  kind: Yo,
  requested_count: I.nullable(),
  settings: En
}), Bd = g({
  operation_key: k,
  kind: Yo,
  requested_count: I.nullable(),
  returned_count: I.nullable(),
  state: Ud,
  execution_evidence: h([
    "none",
    "provider_started",
    "content_observed",
    "usage_reported"
  ]),
  settings: En,
  model_id: ke,
  model_evidence: St
}), Jd = g({
  operation_key: k,
  count: I,
  ...Xo,
  settings: En
}), Hd = g({
  input_images: x(Ld).max(100),
  requested_operations: x(qd).max(100),
  coverage_reasons: It
}).refine(
  (e) => e.input_images.length + e.requested_operations.length <= 100,
  "Media entry limit"
).refine(
  (e) => new Set(e.requested_operations.map((t) => t.operation_key)).size === e.requested_operations.length,
  "Duplicate operation"
), Kd = g({
  image_operations: x(Bd).max(100),
  generated_images: x(Jd).max(100),
  coverage_reasons: It
}).superRefine((e, t) => {
  e.image_operations.length + e.generated_images.length > 100 && t.addIssue({ code: "custom", message: "Media entry limit" }), new Set(e.image_operations.map((n) => n.operation_key)).size !== e.image_operations.length && t.addIssue({ code: "custom", message: "Duplicate operation" });
  for (const n of e.generated_images)
    e.image_operations.some((i) => i.operation_key === n.operation_key) || t.addIssue({
      code: "custom",
      message: "Generated image requires operation"
    });
  for (const n of e.image_operations) {
    const i = e.generated_images.filter(
      (o) => o.operation_key === n.operation_key
    );
    n.returned_count !== null && I.safeParse(n.returned_count).success && i.every((o) => I.safeParse(o.count).success) && i.reduce((r, s) => r + BigInt(s.count), 0n) > BigInt(n.returned_count) && t.addIssue({
      code: "custom",
      message: "Grouped outputs exceed returned count"
    });
  }
}), Ut = vn.refine((e) => {
  const t = Number(e);
  return t > 0 && t <= 86400;
}, "Media length must be greater than zero and at most one day"), Vd = g({
  role: h(["side_calls", "research", "storyboard"]),
  model_id: ke,
  model_evidence: St,
  tokens: W,
  timing: On.nullable()
}), Gd = Te("kind", [
  g({
    kind: y("image"),
    model_id: ke,
    count: I,
    width: de,
    height: de,
    // A stopped or failed job counts as one image only when generation visibly started.
    outcome: h(["returned", "started_not_returned"])
  }),
  g({
    kind: y("video"),
    model_id: ke,
    width: de,
    height: de,
    duration_seconds: Ut.nullable(),
    with_audio: ie().nullable()
  }),
  g({
    kind: y("speech"),
    length_basis: h(["audio_frames", "stored_length", "characters"]),
    seconds: Ut.nullable(),
    characters: I.nullable()
  }),
  g({
    kind: y("video_overview"),
    duration_seconds: Ut
  })
]), Qo = g({
  text_components: x(Vd).max(16),
  media: x(Gd).max(64)
}).superRefine((e, t) => {
  for (const [n, i] of e.media.entries())
    i.kind === "speech" && (i.length_basis === "characters" ? i.characters === null || i.characters === "0" || i.seconds !== null : i.seconds === null || i.characters !== null) && t.addIssue({
      code: "custom",
      path: ["media", n],
      message: "Speech length must match its basis"
    }), i.kind === "image" && (i.count === "0" || i.outcome === "started_not_returned" && i.count !== "1") && t.addIssue({
      code: "custom",
      path: ["media", n],
      message: "Image entries need a positive count; a started job is one image"
    });
}), Wd = [
  "local-file-text-utf8-pdfjs6.3.289-opc-v1",
  "observed-inline-file-text-v1"
], er = h(Wd), tr = [
  "provider_processing",
  "ocr",
  "image_encoding",
  "retrieval_selection",
  "layout_and_drawing_text",
  "rendered_visibility",
  "formula_recalculation",
  "external_font_mapping"
], nr = h(tr), Xd = g({
  ...W.shape,
  scope: y("extracted_file_text"),
  evidence: h(["heuristic_estimate", "unknown"])
}).superRefine((e, t) => {
  e.value === null && (e.reason === null || e.evidence !== "unknown" || e.completeness !== "unknown") && t.addIssue({
    code: "custom",
    message: "Missing file text requires unknown evidence and a reason"
  }), e.value !== null && (e.evidence !== "heuristic_estimate" || e.profile_id === null || e.completeness === "unknown" || e.reason === null) && t.addIssue({
    code: "custom",
    message: "Known file text requires an approved profile and scoped evidence"
  });
}), Tn = g({
  component_id: b().regex(
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/
  ),
  origin: h(["new_upload", "retained_context", "unknown_origin"]),
  extraction_profile_id: er,
  page_count: S().int().min(0).max(200).nullable(),
  tokens: Xd,
  missing: x(nr).min(1).max(tr.length).refine(
    (e) => new Set(e).size === e.length && e.includes("provider_processing"),
    "Local extraction does not establish provider processing"
  )
}), Yd = g({
  schema_version: y(We),
  kind: y("request"),
  request_id: He,
  revision: Vo,
  conversation_key: k,
  key_version: y("1"),
  provider_request_key: k.nullable(),
  site: Sn,
  adapter_version: Ko,
  // `read_aloud` is speech made from a reply already shown (ChatGPT, G1) and
  // `notebook_guide` a NotebookLM guide the page asks for itself (W9).
  // Neither has a prompt: they add energy, never a request (see countsAsRequest).
  action: h([
    "send",
    "regenerate",
    "continue",
    "edit_and_send",
    "read_aloud",
    "notebook_guide"
  ]),
  dispatched_at: G,
  ended_at: G.nullable(),
  state: h([
    "dispatched",
    "generating",
    "completed",
    "cancelled",
    "failed",
    "interrupted_unconfirmed"
  ]),
  model_id: ke,
  model_evidence: St,
  features: x(
    h([
      "text",
      "thinking",
      "search",
      "document",
      "image_input",
      "image_generation",
      "image_edit",
      "audio",
      "video",
      "other_tool"
    ])
  ).max(10).refine((e) => new Set(e).size === e.length),
  observed_search_operations: I.nullable(),
  documents: g({
    extracted_text: x(Tn).max(100).nullable(),
    upload_count: I.nullable(),
    types: x(
      h([
        "text_pdf",
        "scanned_pdf",
        "text",
        "office",
        "other",
        "unknown"
      ])
    ).max(6).refine((e) => new Set(e).size === e.length),
    processing: h([
      "observed_text",
      "opaque",
      "mixed",
      "none",
      "unknown"
    ])
  }),
  media: Hd,
  coverage_reasons: It,
  policy_version: b().regex(/^(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})\.(0|[1-9][0-9]{0,5})$/),
  company_dedup_key: In
}).superRefine((e, t) => {
  e.coverage_reasons.includes("historical_timing_conflict") && t.addIssue({
    code: "custom",
    message: "Historical timing conflicts require a historical response"
  }), e.coverage_reasons.includes("no_live_request") && t.addIssue({
    code: "custom",
    message: "Only saved history rows can lack a live request"
  }), e.company_dedup_key !== null && t.addIssue({
    code: "custom",
    path: ["company_dedup_key"],
    message: "The company key travels beside the record"
  }), e.ended_at !== null && e.ended_at < e.dispatched_at && t.addIssue({ code: "custom", message: "End precedes dispatch" }), e.action === "read_aloud" && (e.site !== "chatgpt" || e.features.length !== 1 || e.features[0] !== "audio" || e.documents.upload_count !== null && e.documents.upload_count !== "0" || e.documents.types.length > 0 || e.documents.extracted_text !== null || !["none", "unknown"].includes(e.documents.processing) || e.media.input_images.length > 0 || e.media.requested_operations.length > 0 || e.observed_search_operations !== null && e.observed_search_operations !== "0") && t.addIssue({
    code: "custom",
    message: "Read aloud is ChatGPT audio only"
  }), e.action === "notebook_guide" && (e.site !== "notebooklm" || e.features.length !== 1 || e.features[0] !== "text" || e.documents.upload_count !== null && e.documents.upload_count !== "0" || e.documents.types.length > 0 || e.documents.extracted_text !== null || !["none", "unknown"].includes(e.documents.processing) || e.media.input_images.length > 0 || e.media.requested_operations.length > 0 || e.observed_search_operations !== null && e.observed_search_operations !== "0") && t.addIssue({
    code: "custom",
    message: "A notebook guide is NotebookLM text only"
  });
  const n = e.documents.extracted_text ?? [];
  new Set(n.map((i) => i.component_id)).size !== n.length && t.addIssue({
    code: "custom",
    message: "Duplicate file component identity"
  }), e.documents.upload_count !== null && I.safeParse(e.documents.upload_count).success && BigInt(n.filter((i) => i.origin === "new_upload").length) > BigInt(e.documents.upload_count) && t.addIssue({
    code: "custom",
    message: "New file components exceed observed uploads"
  }), n.length + e.media.input_images.length + e.media.requested_operations.length > 100 && t.addIssue({
    code: "custom",
    message: "Combined media metadata limit exceeded"
  });
}), Qd = g({
  schema_version: y(We),
  kind: y("attempt"),
  attempt_id: He,
  request_id: He,
  revision: Vo,
  provider_attempt_key: k.nullable(),
  key_version: y("1"),
  started_at: G,
  ended_at: G.nullable(),
  state: h([
    "dispatch_only",
    "generating",
    "completed",
    "cancelled",
    "failed",
    "interrupted_unconfirmed"
  ]),
  execution_evidence: h([
    "none",
    "provider_started",
    "content_observed",
    "usage_reported"
  ]),
  model_id: ke,
  model_evidence: St,
  tokens: Md,
  timing: On.nullable(),
  media: Kd,
  generation: Qo,
  coverage_reasons: It,
  tokenizer_profile_id: Xe,
  tokenizer_asset_hash: k.nullable(),
  proposed_method_id: b().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/).nullable(),
  company_dedup_key: In
}).refine(
  (e) => !e.coverage_reasons.includes("historical_timing_conflict"),
  "Historical timing conflicts require a historical response"
).refine(
  (e) => !e.coverage_reasons.includes("no_live_request"),
  "Only saved history rows can lack a live request"
).refine(
  (e) => e.company_dedup_key === null,
  "The company key travels beside the record"
).refine(
  (e) => Wo(e.tokens.output_total, e.tokens) || e.tokens.output_total.evidence === "provider_reported" && e.tokens.output_total.scope === "provider_request" && e.tokens.output_total.value !== null,
  "Output total must equal its parts unless the provider reports it for the request"
).refine(
  (e) => e.ended_at === null || e.ended_at >= e.started_at,
  "End precedes start"
).refine(
  (e) => e.timing === null || e.timing.source === "browser_request",
  "Live attempts require browser timing"
).refine(
  (e) => e.timing?.completeness !== "complete_for_scope" || e.state === "completed",
  "Complete live timing requires a completed attempt"
), ep = se([
  Yd,
  Qd
]), tp = g({
  kind: h(["request", "attempt"]),
  record_id: He,
  company_dedup_key: k
});
g({
  schema_version: y(We),
  batch_id: He,
  sent_at: G,
  client_version: Ko,
  deletion_epoch: S().int().min(0).max(Number.MAX_SAFE_INTEGER),
  records: x(ep).min(1).max(100),
  // Left out when no record has a key, so a server without company keys accepts it.
  company_dedup_keys: x(tp).max(100).optional()
}).superRefine((e, t) => {
  if (!e.company_dedup_keys) return;
  const n = new Set(
    e.records.map(
      (o) => o.kind === "request" ? `request:${o.request_id}` : `attempt:${o.attempt_id}`
    )
  ), i = e.company_dedup_keys.map((o) => `${o.kind}:${o.record_id}`);
  (new Set(i).size !== i.length || i.some((o) => !n.has(o))) && t.addIssue({
    code: "custom",
    path: ["company_dedup_keys"],
    message: "Each company key names one record of the batch"
  });
});
const Ti = {
  historical_timing_conflict: [
    "Historical timing is uncertain. Valid message and token counts are retained.",
    "No action is required. Estimates use valid live timing when available, otherwise modeled timing."
  ],
  storage_write_failed: [
    "This activity could not be saved.",
    "Check browser storage and retry. Keep this tab open while recording recovers."
  ],
  ledger_integrity_failed: [
    "Some saved records need repair.",
    "Open tracking details. Affected totals remain unavailable until the records reconcile."
  ],
  tokenizer_unavailable: [
    "The request was recorded, but text counting failed.",
    "Reload the extension to restart its local counting worker."
  ],
  tokenizer_mapping_unverified: [
    "This text count uses an approximate model mapping.",
    "Read the counting scope in Details."
  ],
  sync_delayed: [
    "Saved activity is waiting to sync.",
    "Check the company connection; pending records will retry automatically."
  ],
  auth_reconnect_required: [
    "Your company connection needs renewal.",
    "Open Company and connect again with your work email."
  ],
  protocol_unsupported: [
    "This provider response is not supported by the current parser.",
    "Update the extension. Independently recorded activity remains available."
  ],
  estimate_unavailable: [
    "Resources are unavailable for part of this activity.",
    "Read the missing components in Details."
  ],
  method_update_invalid: [
    "The calculation update could not be verified.",
    "Keep the current valid method and contact the deployment operator."
  ],
  revision_conflict: [
    "Two versions of this record conflict.",
    "Keep the record in the reconciliation queue; do not create a replacement identity."
  ],
  capture_limit_exceeded: [
    "The measurement limit was reached. Your AI request continues.",
    "The recorded subtotal remains partial; review its coverage in Details."
  ],
  retention_expired: [
    "These company records are outside the retention period.",
    "Remove the expired local records after applying the server receipt."
  ],
  host_interference_detected: [
    "On-page measurement has stopped to preserve the AI tool.",
    "Reload the page and inspect the extension diagnostic."
  ],
  factor_incompatible: [
    "The available environmental factors cover different scopes.",
    "Show the supported components separately."
  ],
  payload_rejected: [
    "This numerical record does not match the accepted contract.",
    "Keep it quarantined and update the extension before retrying."
  ]
};
Object.freeze(
  Object.fromEntries(
    Do.map((e) => [
      e,
      Object.freeze({
        code: e,
        retryable: [
          "sync_delayed",
          "dependency_missing",
          "estimate_pending",
          "tokenizer_timeout",
          "storage_write_failed"
        ].includes(e),
        safe_message: Ti[e]?.[0] ?? "This component has limited or unavailable coverage.",
        safe_action: Ti[e]?.[1] ?? "Open Details for the affected scope and its recorded reason."
      })
    ])
  )
);
const ir = We, np = b().regex(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3,6}Z$/).refine((e) => {
  const t = e.replace(/(\.\d{3})\d*Z$/, "$1Z");
  return Number.isFinite(Date.parse(t)) && new Date(t).toISOString() === t;
}, "Invalid history date"), ip = g(
  Object.fromEntries(
    Dd.map((e) => [e, W])
  )
);
function op(e, t) {
  return e.evidence === "provider_reported" ? t === "response" && e.scope === "provider_request" && e.value !== null : e.scope === "observed_text" && (e.value === null ? e.evidence === "unknown" : e.evidence === "heuristic_estimate" && e.profile_id !== null);
}
function rp(e, t, n) {
  return n === "prompt" ? [...$n, "reported_reasoning", "tool_output"].every((i) => t[i].evidence === "not_applicable") : t.image_input_tokens.evidence !== "not_applicable" ? !1 : e.evidence === "provider_reported" ? !0 : Wo(e, t);
}
const sp = g({
  schema_version: y(ir),
  kind: y("history_message"),
  message_key: k,
  role: h(["prompt", "response"]),
  conversation_key: k,
  key_version: y("1"),
  site: Sn,
  parent_key: k.nullable(),
  prompt_key: k.nullable(),
  provider_request_key: k.nullable(),
  provider_attempt_key: k.nullable(),
  occurred_at: np.nullable(),
  date_basis: h([
    "message_created",
    "entry_created",
    "turn_created",
    "unknown"
  ]),
  observed_at: G,
  proposed_method_id: b().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/),
  proposed_method_hash: k,
  model_id: ke,
  tokens: W,
  parts: ip.nullable(),
  generation: Qo,
  inline_file_text: x(Tn.omit({ component_id: !0 })).max(16).nullable(),
  timing: On.nullable(),
  text_complete: ie(),
  coverage_reasons: x(Pe).max(33).refine(
    (e) => new Set(e).size === e.length && (e.length <= 32 || e.includes("historical_timing_conflict")),
    "Historical timing conflict reserves one additional reason slot"
  ),
  company_dedup_key: In
}).superRefine((e, t) => {
  e.company_dedup_key !== null && t.addIssue({
    code: "custom",
    path: ["company_dedup_key"],
    message: "The company key travels beside the message"
  }), e.coverage_reasons.includes("no_live_request") && e.site !== "notebooklm" && t.addIssue({
    code: "custom",
    path: ["coverage_reasons"],
    message: "Only NotebookLM Studio rows lack a live request"
  }), e.coverage_reasons.includes("historical_timing_conflict") && (e.role !== "response" || e.timing !== null) && t.addIssue({
    code: "custom",
    path: ["timing"],
    message: "Conflicting historical response timing must be unavailable"
  }), e.timing !== null && (e.role !== "response" || !Rd(e.site).includes(e.timing.source) || e.timing.completeness === "complete_for_scope" && !e.text_complete) && t.addIssue({
    code: "custom",
    path: ["timing"],
    message: "Historical timing must match the response provider"
  }), (e.occurred_at === null != (e.date_basis === "unknown") || !op(e.tokens, e.role) || e.role === "prompt" && e.provider_attempt_key !== null) && t.addIssue({
    code: "custom",
    message: "Invalid historical text evidence"
  }), (e.role === "response" && e.parts === null || e.parts !== null && !rp(e.tokens, e.parts, e.role)) && t.addIssue({
    code: "custom",
    path: ["parts"],
    message: "Historical parts do not match the recorded total"
  }), e.role === "prompt" && (e.generation.text_components.length || e.generation.media.length) && t.addIssue({
    code: "custom",
    path: ["generation"],
    message: "Prompts carry no generated output"
  });
});
g({
  schema_version: y(ir),
  site: Sn,
  conversation_key: k,
  observed_at: G,
  deletion_epoch: S().int().min(0).max(Number.MAX_SAFE_INTEGER),
  messages: x(sp).max(100),
  branch_scope: h(["selected_branch", "loaded_messages", "unknown"]),
  selected_leaf_key: k.nullable(),
  branch_message_keys: x(k).max(100).nullable(),
  root_message_key: k.nullable(),
  first_request_verified: ie(),
  has_earlier: ie().nullable(),
  has_later: ie().nullable(),
  // Company keys of the page's messages, beside them as in a usage batch (W11). Left out
  // when no message has one.
  company_dedup_keys: x(
    g({
      message_key: k,
      company_dedup_key: k
    })
  ).max(100).optional(),
  // Message keys of the member's saved Claude messages that this page's exact rows replace,
  // once, so the server stops counting their text estimate. Keyed hashes like message_key,
  // never ids or text. Left out when empty; a published browser never sends it.
  replaced_message_keys: x(k).max(200).optional(),
  // Claude's exact input for the turn of an exact reply of this page (owner decision of 23 Nov
  // 2026, package EC): new input, input written to the cache and input read from it, as
  // Claude reports them. The server counts that input once for the turn, as the browser
  // does: the reply's tool results and the prompt it answers add none of their own. Left
  // out when empty; the published 0.1.0 never sends it.
  exact_inputs: x(
    g({
      message_key: k,
      new: I,
      cache_write: I,
      cache_read: I
    })
  ).max(100).optional()
}).superRefine((e, t) => {
  if (e.exact_inputs) {
    const n = new Map(e.messages.map((o) => [o.message_key, o])), i = e.exact_inputs.map((o) => o.message_key);
    (e.site !== "claude" || new Set(i).size !== i.length || i.some((o) => {
      const r = n.get(o);
      return !r || r.role !== "response" || r.prompt_key === null || r.tokens.evidence !== "provider_reported";
    })) && t.addIssue({
      code: "custom",
      path: ["exact_inputs"],
      message: "Exact input names Claude replies of this page that carry Claude's own count, each once"
    });
  }
  if (e.replaced_message_keys) {
    const n = new Set(e.messages.map((o) => o.message_key)), i = e.replaced_message_keys;
    (e.site !== "claude" || new Set(i).size !== i.length || i.some((o) => n.has(o))) && t.addIssue({
      code: "custom",
      path: ["replaced_message_keys"],
      message: "Replaced keys name other saved Claude messages, each once"
    });
  }
  if ((new Set(e.messages.map((n) => n.message_key)).size !== e.messages.length || e.messages.some(
    (n) => n.site !== e.site || n.conversation_key !== e.conversation_key
  ) || e.first_request_verified && e.root_message_key === null || e.branch_message_keys !== null && new Set(e.branch_message_keys).size !== e.branch_message_keys.length) && t.addIssue({ code: "custom", message: "Inconsistent history page" }), e.company_dedup_keys) {
    const n = new Set(e.messages.map((o) => o.message_key)), i = e.company_dedup_keys.map((o) => o.message_key);
    (new Set(i).size !== i.length || i.some((o) => !n.has(o))) && t.addIssue({
      code: "custom",
      path: ["company_dedup_keys"],
      message: "Each company key names one message of the page"
    });
  }
});
const ap = 2097152, cp = 262144, Lt = S().int().min(0).max(ap);
g({
  units: Lt,
  fileUnits: x(S().int().min(0).max(cp)).max(16).nullable(),
  // Lengths and counts of the reply's other text parts and other-model text, so a
  // message whose reasoning or tool input changed is counted again.
  partUnits: le(h(Ei), Lt),
  partTokens: le(h(Ei), W),
  componentUnits: x(Lt.nullable()).max(16),
  componentTokens: x(W.nullable()).max(16),
  implementationId: b().min(1).max(128),
  profileId: b().min(1).max(128),
  assetHash: b().min(1).max(256),
  tokens: W,
  inlineFileComponents: x(Tn.omit({ component_id: !0 })).max(16).nullable(),
  // The tokens of each text or code file Perplexity Computer created in the reply, by a
  // keyed hash of the file's id, and whether they were counted from its content or its
  // size (14 Oct 2026). Kept so a reopened chat neither downloads nor counts it again.
  computerFiles: ee(
    b().regex(/^[0-9a-f]{64}$/),
    g({
      tokens: I,
      basis: h(["content", "size"])
    })
  ).refine((e) => Object.keys(e).length <= 64).optional()
});
const up = [
  "total",
  "tool_output",
  "image_input_tokens",
  "other_models"
], lp = g({
  quantity: y("extracted_file_text"),
  scope: y("extracted_file_text"),
  unit: y("tokens"),
  additive: y(!1),
  value: I.nullable(),
  measurement_group: g({
    origin: h(["new_upload", "retained_context", "unknown_origin"]),
    extraction_profile_id: er,
    evidence: h(["heuristic_estimate", "unknown"]),
    profile_id: Xe
  }),
  applicable_count: S().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  contributing_component_count: S().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  unknown_count: S().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  partial_count: S().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  unvalidated_count: S().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
  reason_counts: le(
    Pe,
    S().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
  ),
  missing_counts: le(
    nr,
    S().int().nonnegative().max(Number.MAX_SAFE_INTEGER)
  )
});
function dp(e, t) {
  if ([
    "observed_prompt_count",
    "observed_response_count",
    "prompt_count",
    "response_count",
    "dated_message_count",
    "undated_message_count",
    "calculated_message_count",
    "uncalculated_message_count",
    "matched_live_message_count",
    "unresolved_overlap_message_count",
    "conflicting_message_count"
  ].some((a) => !I.safeParse(e[a]).success))
    return;
  const i = (a) => BigInt(e[a]), o = i("observed_prompt_count") + i("observed_response_count"), r = i("calculated_message_count") + i("uncalculated_message_count"), s = i("prompt_count") + i("response_count") - r;
  (o !== i("dated_message_count") + i("undated_message_count") || o !== r + i("matched_live_message_count") + i("conflicting_message_count") || s < 0n || s > i("response_count") || // Rows no live capture can produce (no_live_request) contribute without waiting for a
  // live match, so only the other contributing rows are unresolved.
  i("unresolved_overlap_message_count") > r) && t.addIssue({
    code: "custom",
    message: "Inconsistent historical coverage"
  });
  for (const a of e.resources)
    (a.value === null != (a.status === "unavailable") || !("requested_method" in a) && a.profile_selection === "unavailable" != (a.selected_profile_id === null)) && t.addIssue({
      code: "custom",
      message: "Inconsistent historical assessment"
    });
}
const pp = x(
  se([
    g({
      quantity: h([
        "energy",
        "carbon",
        "water_direct",
        "water_upstream",
        "water_total"
      ]),
      value: kt.nullable(),
      unit: h(["kWh", "gCO2e", "gCO2", "L"]),
      scope: y("historical_visible_response"),
      method_id: b().regex(/^[a-z0-9][a-z0-9.-]{0,127}$/),
      method_hash: k,
      status: h(["partial_estimate", "unavailable"]),
      validation_state: y("unvalidated_reference"),
      profile_selection: h(["highest_comparable", "unavailable"]),
      selected_profile_id: b().regex(/^[a-z0-9][a-z0-9.-]{0,159}$/).nullable(),
      reasons: x(Pe).max(32),
      missing_components: x(b().regex(/^[a-z0-9_]{1,100}$/)).max(32),
      known_message_count: I,
      unknown_message_count: I
    }),
    $d
  ])
).max(160);
g({
  schema_version: y(We),
  scope: y("loaded_history"),
  status: h(["available", "empty", "unavailable"]),
  observed_prompt_count: I,
  observed_response_count: I,
  prompt_count: I,
  response_count: I,
  dated_message_count: I,
  undated_message_count: I,
  calculated_message_count: I,
  uncalculated_message_count: I,
  matched_live_message_count: I,
  unresolved_overlap_message_count: I,
  conflicting_message_count: I,
  first_request_verified: ie(),
  branch_scope: h(["selected_branch", "loaded_messages", "unknown"]),
  provider_history_complete: y(!1),
  tokens: x(
    g({
      role: h(["prompt", "response"]),
      part: h(up),
      profile_id: Xe,
      evidence: h(["heuristic_estimate", "provider_reported", "unknown"]),
      value: I.nullable(),
      known_message_count: I,
      unknown_message_count: I
    })
  ).max(128),
  file_text: x(lp).max(256),
  file_text_coverage: g({
    observed_message_count: I,
    unknown_message_count: I,
    scope: y("extracted_file_text"),
    additive: y(!1)
  }),
  resources: pp
}).superRefine(dp);
const fp = "gpt-tokenizer-4.0.0", or = "o200k-base-4.0.0-reference", B = Object.freeze({
  jobId: 128,
  modelId: 256,
  fieldTextUnits: 2097152,
  fieldTextBytes: 8 * 1024 * 1024,
  inlineFileTextUnits: 262144,
  // Six text fields, up to 16 inline files and up to 16 other-model components.
  fields: 38,
  pendingJobs: 16,
  timeoutMs: 2e4
}), mp = new TextEncoder();
function _t(e, t) {
  const n = Object.keys(e).sort(), i = [...t].sort();
  return n.length === i.length && n.every((o, r) => o === i[r]);
}
function Pn(e, t) {
  return typeof e == "string" && e.length > 0 && e.length <= B.jobId && !/[\u0000-\u001f\u007f]/.test(e) && Number.isSafeInteger(t) && Number(t) >= 1;
}
function hp(e) {
  return e === "input" || e === "answer" || e === "thinking" || e === "tool_input" || e === "intermediate" || e === "tool_output" || /^(?:file|component)_([0-9]|1[0-5])$/.test(e);
}
function Pi(e) {
  return typeof e == "string" && /^[a-z0-9][a-z0-9._-]{0,127}$/.test(e);
}
function rr(e) {
  if (!e || typeof e != "object" || Array.isArray(e))
    throw new Error("payload_rejected");
  const t = e;
  if (!_t(t, [
    "fields",
    "implementationId",
    "jobId",
    "modelId",
    "profileId",
    "revision"
  ]) || !Pn(t.jobId, t.revision) || t.modelId !== null && (typeof t.modelId != "string" || t.modelId.length > B.modelId) || !Pi(t.implementationId) || !Pi(t.profileId) || !t.fields || typeof t.fields != "object" || Array.isArray(t.fields))
    throw new Error("payload_rejected");
  const n = Object.entries(t.fields);
  if (n.length < 1 || n.length > B.fields)
    throw new Error("payload_rejected");
  let i = 0;
  for (const [o, r] of n) {
    if (!hp(o) || typeof r != "string")
      throw new Error("payload_rejected");
    i += r.length;
  }
  if (i > 5 * B.fieldTextUnits + B.inlineFileTextUnits)
    throw new Error("capture_limit_exceeded");
}
function _p(e) {
  if (!e || typeof e != "object" || Array.isArray(e))
    throw new Error("payload_rejected");
  const t = e;
  if (t.type === "count") {
    if (!_t(t, ["request", "type"]))
      throw new Error("payload_rejected");
    rr(t.request);
    return;
  }
  if (t.type !== "cancel" || !_t(t, ["jobId", "revision", "type"]) || !Pn(t.jobId, t.revision))
    throw new Error("payload_rejected");
}
function K(e, t, n = {}) {
  return {
    jobId: e.jobId,
    revision: e.revision,
    implementationId: n.implementationId ?? null,
    profileId: n.profileId ?? null,
    status: t === "cancelled" ? "cancelled" : "unavailable",
    reason: t,
    counts: {}
  };
}
function ct(e, t) {
  return {
    jobId: e.jobId,
    revision: e.revision,
    measurement: Go(t),
    assetHash: null,
    profileId: null,
    encoding: null,
    modelExactness: "unverified",
    status: "unavailable"
  };
}
function sr(e, t) {
  const n = e.profiles.filter(
    (i) => i.profileId === t
  );
  return n.length === 1 ? n[0] : null;
}
function gp(e, t, n) {
  if (!e || typeof e != "object" || Array.isArray(e)) return !1;
  const i = e;
  if (!_t(i, [
    "assetHash",
    "encoding",
    "jobId",
    "measurement",
    "modelExactness",
    "profileId",
    "revision",
    "status"
  ]) || i.jobId !== t.jobId || i.revision !== t.revision || i.modelExactness !== "unverified")
    return !1;
  const o = W.safeParse(i.measurement);
  return i.status === "counted" ? !o.success || o.data.value === null || !/^(0|[1-9][0-9]*)$/.test(o.data.value) || BigInt(o.data.value) > BigInt(mp.encode(t.text).byteLength) || t.text.length > 0 && BigInt(o.data.value) === 0n ? !1 : i.assetHash === n.assetHash && i.profileId === n.profileId && i.encoding === n.encoding && o.data.evidence === "heuristic_estimate" && o.data.scope === "observed_text" && o.data.completeness === "complete_for_scope" && o.data.profile_id === n.profileId && o.data.reason === "tokenizer_mapping_unverified" : i.status === "unavailable" && o.success && o.data.value === null && o.data.evidence === "unknown" && o.data.scope === "observed_text" && o.data.completeness === "unknown" && o.data.profile_id === null && (o.data.reason === "tokenizer_unavailable" || o.data.reason === "capture_limit_exceeded") && i.assetHash === null && i.profileId === null && i.encoding === null;
}
const bp = "4.0.0", yp = { o200k_base: { profile_id: "o200k-base-4.0.0-reference", asset_hash: "4cd35a52f4ece645422670151ccbdbd6afd2bcb47b83efd13e47e5d8942aecb4" }, cl100k_base: { profile_id: "cl100k-base-4.0.0-reference", asset_hash: "b56372fb0b95dbd370f9de6f44b6c15006a8a36980fbc6c0568a0108971aea45" } };
var Zn = {
  version: bp,
  profiles: yp
};
const rn = Object.freeze({
  "o200k-base-4.0.0-reference": "o200k_base",
  "cl100k-base-4.0.0-reference": "cl100k_base"
}), ar = Object.freeze({
  id: fp,
  profiles: Object.freeze(
    Object.entries(rn).map(
      ([e, t]) => Object.freeze({
        profileId: e,
        encoding: t,
        assetHash: Zn.profiles[t].asset_hash
      })
    )
  )
}), qt = (e) => typeof e == "string" && /^[a-z0-9][a-z0-9._-]{0,127}$/.test(e), Bt = (e, t) => Object.keys(e).sort().join(",") === t.sort().join(","), ut = () => {
  throw new Error("tokenizer_manifest_invalid");
};
function vp(e) {
  (!e || typeof e != "object" || Array.isArray(e) || !qt(e.id) || !Array.isArray(e.profiles) || e.profiles.length < 1 || e.profiles.length > 16 || !Bt(e, ["id", "profiles"]) && !Bt(e, ["id", "profiles", "count"]) || "count" in e && typeof e.count != "function") && ut();
  const t = e.profiles.map((n) => ((!n || typeof n != "object" || Array.isArray(n) || !Bt(n, ["profileId", "encoding", "assetHash"]) || !qt(n.profileId) || !qt(n.encoding) || typeof n.assetHash != "string" || !/^[a-f0-9]{64}$/.test(n.assetHash) || !W.safeParse({
    value: "0",
    evidence: "heuristic_estimate",
    scope: "observed_text",
    completeness: "complete_for_scope",
    profile_id: n.profileId,
    reason: "tokenizer_mapping_unverified"
  }).success) && ut(), Object.freeze({
    profileId: n.profileId,
    encoding: n.encoding,
    assetHash: n.assetHash
  })));
  return new Set(t.map((n) => n.profileId)).size !== t.length && ut(), Object.freeze({ id: e.id, profiles: Object.freeze(t) });
}
function wp(e, t) {
  const n = vp(e);
  return sr(n, t) || ut(), Object.freeze({
    selection: Object.freeze({ implementationId: n.id, profileId: t }),
    manifest: n
  });
}
wp(
  ar,
  or
);
const rt = { maxDimension: 65535, budget: null }, F = (e, t) => ({ kind: "openai_patches", ...e, multiplier: t }), _e = (e, t) => ({
  kind: "openai_tiles",
  base: e,
  tile: t
}), kp = Object.freeze({
  "gpt-6-astra": F(rt, 120),
  "gpt-5-6-sol": F(rt, 120),
  "gpt-5-6-terra": F(rt, 120),
  "gpt-5-6-luna": F(rt, 120),
  // Auto is original detail: up to 10,000 patches and 6,000 pixels.
  "gpt-5-5": F({ maxDimension: 6e3, budget: 1e4 }, 120),
  // Auto is high detail: up to 2,500 patches and 2,048 pixels.
  "gpt-5-4": F({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-4-mini": F({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-4-nano": F({ maxDimension: 2048, budget: 2500 }, 120),
  "gpt-5-2": F({ maxDimension: 2048, budget: 6144 }, 120),
  "gpt-4-1-mini": F({ maxDimension: 2048, budget: 6144 }, 162),
  // Retired patch models have a published multiplier but no sizing row; they use the
  // sizing of the other patch models of their generation.
  "gpt-5-mini": F({ maxDimension: 2048, budget: 6144 }, 120),
  "gpt-5-nano": F({ maxDimension: 2048, budget: 6144 }, 150),
  "o4-mini": F({ maxDimension: 2048, budget: 6144 }, 172),
  "gpt-5-1": _e(70, 140),
  "gpt-5": _e(70, 140),
  "gpt-4o": _e(85, 170),
  "gpt-4-1": _e(85, 170),
  "gpt-4o-mini": _e(2833, 5667),
  o1: _e(75, 150),
  o3: _e(75, 150)
});
kp["gpt-6-astra"];
const Zi = /* @__PURE__ */ new Map(), zp = new TextEncoder();
function xp(e, t) {
  if ($e(e) !== t)
    throw new Error("tokenizer_unavailable");
}
async function Ip(e) {
  let t = Zi.get(e);
  return t || (t = (async () => {
    const [n, i] = e === "o200k_base" ? await Promise.all([
      import("./o200k_base-CvUU9Zmb.js"),
      import("./o200k_base-BYTgCC8K.js")
    ]) : await Promise.all([
      import("./cl100k_base-BhiXU_Ff.js"),
      import("./cl100k_base-MCg9hpJE.js")
    ]);
    return xp(i.default, Zn.profiles[e].asset_hash), n.setMergeCacheSize(0), n;
  })(), Zi.set(e, t)), t;
}
async function Sp(e) {
  if (e.text.length > B.fieldTextBytes || zp.encode(e.text).byteLength > B.fieldTextBytes)
    return ct(e, "capture_limit_exceeded");
  const t = e.profileId ?? or;
  if (!(t in rn))
    return ct(e, "tokenizer_unavailable");
  const n = rn[t];
  try {
    const o = (await Ip(n)).countTokens(e.text, { disallowedSpecial: /* @__PURE__ */ new Set() });
    return {
      jobId: e.jobId,
      revision: e.revision,
      measurement: {
        value: String(o),
        evidence: "heuristic_estimate",
        scope: "observed_text",
        completeness: "complete_for_scope",
        profile_id: t,
        reason: "tokenizer_mapping_unverified"
      },
      assetHash: Zn.profiles[n].asset_hash,
      profileId: t,
      encoding: n,
      modelExactness: "unverified",
      status: "counted"
    };
  } catch {
    return ct(e, "tokenizer_unavailable");
  }
}
const Ot = Object.freeze({
  ...ar,
  count: Sp
}), Op = new TextEncoder();
async function $p(e, t = Ot) {
  if (!e || typeof e != "object" || typeof e.text != "string" || e.modelId !== null && typeof e.modelId != "string" || !Pn(e.jobId, e.revision) || e.profileId !== void 0 && typeof e.profileId != "string")
    throw new Error("payload_rejected");
  return t.count(e);
}
async function Ep(e, t = Ot, n) {
  try {
    rr(e);
  } catch (l) {
    const d = l instanceof Error && l.message === "capture_limit_exceeded" ? "capture_limit_exceeded" : "payload_rejected";
    return K(e, d);
  }
  const i = {
    implementationId: e.implementationId,
    profileId: e.profileId
  };
  if (n?.aborted)
    return K(e, "cancelled", i);
  const o = sr(t, e.profileId);
  if (e.implementationId !== t.id || !o)
    return K(
      e,
      "tokenizer_unavailable",
      i
    );
  const r = Object.entries(e.fields).filter(
    (l) => typeof l[1] == "string"
  ), s = r.reduce(
    (l, [d, m]) => l + (d.startsWith("file_") ? m.length : 0),
    0
  ), a = {};
  let c = null;
  for (const [l, d] of r) {
    if (n?.aborted)
      return K(e, "cancelled", i);
    const m = {
      text: d,
      modelId: e.modelId,
      profileId: e.profileId,
      jobId: `${e.jobId}:${l}`,
      revision: e.revision
    };
    let f;
    if (d.length > B.fieldTextUnits || Op.encode(d).byteLength > B.fieldTextBytes || l.startsWith("file_") && s > B.inlineFileTextUnits ? (f = ct(m, "capture_limit_exceeded"), c = "capture_limit_exceeded") : (f = await $p(m, t), f.status !== "counted" && (c ??= "tokenizer_unavailable")), n?.aborted)
      return K(e, "cancelled", i);
    if (!gp(f, m, o))
      return K(
        e,
        "tokenizer_unavailable",
        i
      );
    a[l] = f;
  }
  return Object.values(a).filter(
    (l) => l?.status === "counted"
  ).length === 0 ? K(
    e,
    c ?? "tokenizer_unavailable",
    i
  ) : {
    jobId: e.jobId,
    revision: e.revision,
    implementationId: e.implementationId,
    profileId: e.profileId,
    status: c ? "partial" : "counted",
    reason: c,
    counts: a
  };
}
const Tp = Ot;
class Pp {
  constructor(t, n = Ot) {
    this.post = t, this.implementation = n;
  }
  post;
  implementation;
  active = null;
  queue = [];
  seen = [];
  receive(t) {
    try {
      _p(t);
    } catch {
      return;
    }
    const n = t;
    if (n.type === "cancel") {
      this.cancel(n.jobId, n.revision);
      return;
    }
    const i = n.request, o = {
      implementationId: i.implementationId,
      profileId: i.profileId
    };
    if (this.seen.includes(i.jobId) || this.active?.request.jobId === i.jobId || this.queue.some((r) => r.jobId === i.jobId)) {
      this.post(K(i, "duplicate_job", o));
      return;
    }
    if (this.queue.length + (this.active ? 1 : 0) >= B.pendingJobs) {
      this.post(K(i, "busy", o));
      return;
    }
    this.seen.push(i.jobId), this.seen.length > B.pendingJobs * 8 && this.seen.shift(), this.queue.push(i), this.pump();
  }
  cancel(t, n) {
    if (this.active?.request.jobId === t && this.active.request.revision === n) {
      this.active.abort.abort();
      return;
    }
    const i = this.queue.findIndex(
      (r) => r.jobId === t && r.revision === n
    );
    if (i < 0) return;
    const [o] = this.queue.splice(i, 1);
    this.post(
      K(o, "cancelled", {
        implementationId: o.implementationId,
        profileId: o.profileId
      })
    );
  }
  async pump() {
    if (this.active) return;
    const t = this.queue.shift();
    if (!t) return;
    const n = new AbortController();
    this.active = { request: t, abort: n };
    let i;
    try {
      i = await Ep(t, this.implementation, n.signal);
    } catch {
      i = K(t, "tokenizer_unavailable", {
        implementationId: t.implementationId,
        profileId: t.profileId
      });
    }
    this.active?.request === t && (this.active = null, this.post(i)), this.pump();
  }
}
const cr = self, Zp = new Pp(
  (e) => cr.postMessage(e),
  Tp
);
cr.onmessage = (e) => Zp.receive(e.data);
