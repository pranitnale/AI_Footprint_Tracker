const Le = "all", Be = 1e5, l = "<|endoftext|>", k = "<|fim_prefix|>", E = "<|fim_middle|>", T = "<|fim_suffix|>", _ = "<|im_start|>", P = "<|im_end|>", S = "<|im_sep|>", w = "<|endofprompt|>", W = "<|startoftext|>", F = "<|start|>", O = "<|end|>", $ = "<|message|>", D = "<|channel|>", K = "<|return|>", H = "<|constrain|>", U = "<|call|>", X = (n) => n <= 127;
function I(n) {
  if (n.length === 0) return !1;
  const t = n.charCodeAt(n.length - 1);
  return t >= 55296 && t <= 56319;
}
function Y(n) {
  let t = 0;
  for (; t < n.length; ) {
    const e = n[t];
    let o = 0, r = 0;
    if (e <= 127)
      o = 1, r = e;
    else if ((e & 224) === 192) {
      if (o = 2, r = e & 31, e <= 193) return !1;
    } else if ((e & 240) === 224)
      o = 3, r = e & 15;
    else if ((e & 248) === 240) {
      if (o = 4, r = e & 7, e > 244) return !1;
    } else return !1;
    if (t + o > n.length) return !1;
    for (let i = 1; i < o; i++) {
      const s = n[t + i];
      if (s === void 0 || (s & 192) !== 128) return !1;
      r = r << 6 | s & 63;
    }
    if (o === 2 && r < 128 || o === 3 && r < 2048 || o === 4 && r < 65536 || r >= 55296 && r <= 57343 || r > 1114111) return !1;
    t += o;
  }
  return !0;
}
const Z = new TextDecoder("utf8", { fatal: !1 });
function J(n) {
  if (Y(n))
    return Z.decode(n);
}
function Q(n, t) {
  const e = Math.min(n.length, t.length);
  for (let o = 0; o < e; o++) if (n[o] !== t[o]) return n[o] - t[o];
  return n.length - t.length;
}
function ee(n) {
  let t = 0;
  return n.forEach((e) => {
    t = Math.max(t, e);
  }), t;
}
function j(n) {
  return n.replace(/[$()*+.?[\\\]^{|}]/g, "\\$&");
}
function M(n) {
  const t = [...n].map(j).join("|");
  return new RegExp(`(${t})`);
}
const b = /* @__PURE__ */ new Uint8Array(0), m = new TextDecoder("utf8");
var te = class {
  mergeableBytePairRankCount;
  /**
  * an array where the index is the BPE rank,
  * and the value is the string or the array of bytes that it decodes to
  * it may contain holes if token is unused
  */
  bytePairRankDecoder;
  bytePairNonUtfRankDecoder = /* @__PURE__ */ new Map();
  bytePairNonUtfSortedEncoder;
  /**
  * a reverse map of the bytePairRankDecoder,
  * where the key is the string and the value is the rank
  * values that cannot be represented as a string are present in `bytePairNonUtfSortedEncoder`
  */
  bytePairStringRankEncoder;
  tokenSplitRegex;
  specialTokensEncoder;
  specialTokensDecoder;
  specialTokenPatternRegex;
  textEncoder = new TextEncoder();
  mergeCache;
  mergeCacheSize;
  constructor({ bytePairRankDecoder: n, specialTokensEncoder: t, tokenSplitRegex: e, mergeCacheSize: o = 1e5 }) {
    this.bytePairRankDecoder = n, this.bytePairStringRankEncoder = /* @__PURE__ */ new Map(), this.mergeCacheSize = o, o > 0 && (this.mergeCache = /* @__PURE__ */ new Map()), this.mergeableBytePairRankCount = Object.keys(n).length;
    const r = [];
    n.forEach((s, c) => {
      if (typeof s == "string") {
        this.bytePairStringRankEncoder.set(s, c);
        return;
      }
      const a = new Uint8Array(s);
      r.push([a, c]), this.bytePairNonUtfRankDecoder.set(c, a);
    }), this.bytePairNonUtfSortedEncoder = r.sort((s, c) => Q(s[0], c[0])), this.specialTokensEncoder = t ?? /* @__PURE__ */ new Map(), this.specialTokensDecoder = t ? new Map([...t].map(([s, c]) => [c, s])) : /* @__PURE__ */ new Map(), this.tokenSplitRegex = e;
    const i = [...this.specialTokensEncoder.keys()].map(j).join("|");
    try {
      this.specialTokenPatternRegex = new RegExp(i, "y");
    } catch {
      throw new Error("Invalid regular expression pattern.");
    }
  }
  setMergeCacheSize(n) {
    this.mergeCacheSize === 0 && n > 0 && (this.mergeCache = /* @__PURE__ */ new Map()), this.mergeCacheSize = n, n === 0 && (this.mergeCache = void 0);
  }
  clearMergeCache() {
    this.mergeCache?.clear();
  }
  *encodeNativeGenerator(n, t) {
    let e = 0, o = 0;
    for (; ; ) {
      const r = this.findNextSpecialToken(n, t, e), i = r?.[0], s = i ?? n.length, c = e === 0 && s === n.length ? n : n.slice(e, s);
      for (const [a] of c.matchAll(this.tokenSplitRegex)) {
        const d = this.getBpeRankFromString(a);
        if (d !== void 0) {
          o = 1, yield [d];
          continue;
        }
        const p = this.bytePairEncode(a);
        o = p.length, yield p;
      }
      if (i !== void 0) {
        const a = r[1], d = this.specialTokensEncoder.get(a);
        if (d === void 0) throw new Error(`Special token "${a}" is not in the special token encoder.`);
        yield [d], e = i + a.length, o = 1;
      } else break;
    }
    return o;
  }
  encodeNative(n, t) {
    let e = 0;
    const o = [];
    for (; ; ) {
      const r = this.findNextSpecialToken(n, t, e), i = r?.[0], s = i ?? n.length, c = e === 0 && s === n.length ? n : n.slice(e, s);
      for (const [a] of c.matchAll(this.tokenSplitRegex)) {
        const d = this.getBpeRankFromString(a);
        if (d !== void 0) {
          o.push(d);
          continue;
        }
        const p = this.bytePairEncode(a);
        o.push(...p);
      }
      if (i !== void 0) {
        const a = r[1], d = this.specialTokensEncoder.get(a);
        if (d === void 0) throw new Error(`Special token "${a}" is not in the special token encoder.`);
        o.push(d), e = i + a.length;
      } else break;
    }
    return o;
  }
  countNative(n, t) {
    let e = 0, o = 0;
    for (; ; ) {
      const r = this.findNextSpecialToken(n, t, e), i = r?.[0], s = i ?? n.length, c = e === 0 && s === n.length ? n : n.slice(e, s);
      for (const [a] of c.matchAll(this.tokenSplitRegex)) {
        if (this.getBpeRankFromString(a) !== void 0) {
          o++;
          continue;
        }
        const d = this.bytePairEncode(a);
        o += d.length;
      }
      if (i !== void 0) {
        const a = r[1];
        if (this.specialTokensEncoder.get(a) === void 0) throw new Error(`Special token "${a}" is not in the special token encoder.`);
        o++, e = i + a.length;
      } else break;
    }
    return o;
  }
  *decodeNativeGenerator(n) {
    for (const t of n) {
      const e = this.tryDecodeToken(t);
      e && (yield e);
    }
  }
  decodeNative(n) {
    let t = "", e = b;
    for (const o of n) {
      const r = this.tryDecodeToken(o);
      if (r === void 0) throw new Error(`Token ${o} is not in the byte pair encoder.`);
      if (typeof r == "string")
        e !== b && (t += m.decode(e, { stream: !0 }), e = b), t += r;
      else {
        const i = new Uint8Array(e.length + r.length);
        i.set(e), i.set(r, e.length), e = i;
      }
    }
    return e !== b && (t += m.decode(e, { stream: !0 })), t;
  }
  async *decodeNativeAsyncIterable(n) {
    for await (const t of n) {
      const e = this.tryDecodeToken(t);
      e && (yield e);
    }
  }
  getBpeRankFromString(n) {
    return this.bytePairStringRankEncoder.get(n);
  }
  getBpeRankFromStringOrThrow(n) {
    const t = this.getBpeRankFromString(n);
    if (t === void 0) throw new Error(`The byte-pair encoding does not contain a value for: ${n}`);
    return t;
  }
  getBpeRankFromBytes(n) {
    const t = J(n);
    if (t !== void 0) return this.getBpeRankFromString(t);
    const e = this.binarySearch(n);
    if (e !== -1) return this.bytePairNonUtfSortedEncoder[e][1];
  }
  getBpeRankFromBytesOrThrow(n) {
    const t = this.getBpeRankFromBytes(n);
    if (t === void 0) throw new Error(`The byte-pair encoding does not contain a value for: ${n.toString()}`);
    return t;
  }
  binarySearch(n) {
    let t = 0, e = this.bytePairNonUtfSortedEncoder.length - 1;
    for (; t <= e; ) {
      const o = t + e >>> 1, r = this.bytePairNonUtfSortedEncoder[o][0];
      let i = 0;
      const s = Math.min(r.length, n.length);
      for (let c = 0; c < s && (i = r[c] - n[c], i === 0); c++)
        ;
      if (i === 0 && (i = r.length - n.length), i === 0) return o;
      i < 0 ? t = o + 1 : e = o - 1;
    }
    return -1;
  }
  findNextSpecialToken(n, t, e) {
    let o = e;
    for (; ; ) {
      this.specialTokenPatternRegex.lastIndex = o;
      const r = this.specialTokenPatternRegex.exec(n);
      if (!r) return;
      const i = r[0];
      if (t?.has(i)) return [r.index + o, i];
      o = r.index + o + 1;
    }
  }
  tryDecodeToken(n) {
    const t = this.bytePairRankDecoder[n];
    if (typeof t == "string") return t;
    if (typeof t == "object") {
      const e = this.bytePairNonUtfRankDecoder.get(n);
      if (e) return e;
    }
    return this.specialTokensDecoder.get(n);
  }
  addToMergeCache(n, t) {
    if (this.mergeCache) {
      if (this.mergeCache.size >= this.mergeCacheSize) {
        const e = this.mergeCache.keys().next().value;
        this.mergeCache.delete(e);
      }
      this.mergeCache.set(n, t);
    }
  }
  bytePairEncode(n) {
    if (n.length === 1 && X(n.codePointAt(0))) return [this.getBpeRankFromStringOrThrow(n)];
    if (this.mergeCache?.has(n)) {
      const o = this.mergeCache.get(n);
      return this.mergeCache.delete(n), this.mergeCache.set(n, o), o;
    }
    const t = this.textEncoder.encode(n), e = this.bytePairMerge(t);
    return this.addToMergeCache(n, e), e;
  }
  bytePairMerge(n) {
    const t = [], e = [], o = (i, s = t[i], c = t[i + 2]) => {
      if (c === void 0) return Number.POSITIVE_INFINITY;
      const a = n.subarray(s, c);
      return this.getBpeRankFromBytes(a) ?? Number.POSITIVE_INFINITY;
    };
    for (let i = 0; i <= n.length; i++)
      t.push(i), i < n.length - 1 ? e.push(o(i, i, i + 2)) : e.push(Number.POSITIVE_INFINITY);
    for (; t.length > 1; ) {
      let i = Number.POSITIVE_INFINITY, s = -1;
      for (let c = 0; c < e.length - 1; c++) {
        const a = e[c];
        a < i && (i = a, s = c);
      }
      if (i === Number.POSITIVE_INFINITY || s === -1) break;
      t.splice(s + 1, 1), e.splice(s, 1), e[s] = o(s), s > 0 && (e[s - 1] = o(s - 1));
    }
    const r = [];
    for (let i = 0; i < t.length - 1; i++) {
      const s = t[i], c = t[i + 1], a = this.getBpeRankFromBytesOrThrow(n.subarray(s, c));
      r.push(a);
    }
    return r;
  }
};
const A = `
`;
function ne(n, t) {
  let e = 0;
  if (n.role && (e += t(n.role)), n.content && (e += t(n.content)), n.name && (e += t(n.name) + 1), n.function_call) {
    const { name: o, arguments: r } = n.function_call;
    o && (e += t(o)), r && (e += t(r)), e += 3;
  }
  return e += 3, n.role === "function" && (e -= 2), e;
}
function z(n, t, e) {
  if (!n.properties) return "";
  const o = [], r = new Set(n.required ?? []), i = " ".repeat(t);
  for (const [s, c] of Object.entries(n.properties)) {
    c.description && t < 2 && o.push(`${i}// ${c.description}`);
    const a = r.has(s), d = e(c, t);
    o.push(`${i}${s}${a ? "" : "?"}: ${d},`);
  }
  return o.join(`
`);
}
function C(n, t) {
  switch (n.type) {
    case "string":
      return n.enum?.map((e) => JSON.stringify(e)).join(" | ") ?? "string";
    case "integer":
    case "number":
      return n.enum?.map((e) => `${e}`).join(" | ") ?? "number";
    case "boolean":
      return "boolean";
    case "null":
      return "null";
    case "array":
      return n.items ? `${C(n.items, t)}[]` : "any[]";
    case "object":
      return `{
${z(n, t + 2, C)}
${" ".repeat(t)}}`;
    default:
      return "any";
  }
}
function oe(n) {
  const t = ["namespace functions {", ""];
  for (const e of n) {
    e.description && t.push(`// ${e.description}`);
    const { parameters: o } = e, r = o?.properties;
    if (!o || !r || Object.keys(r).length === 0) t.push(`type ${e.name} = () => any;`);
    else {
      t.push(`type ${e.name} = (_: {`);
      const i = z(o, 0, C);
      i.length > 0 && t.push(i), t.push("}) => any;");
    }
    t.push("");
  }
  return t.push("} // namespace functions"), t.join(`
`);
}
function re(n, t) {
  let e = t(oe(n));
  return e += 9, e;
}
function ie(n, t, e) {
  return !t || e || n.role !== "system" || !n.content || n.content.endsWith(A) ? n : {
    ...n,
    content: `${n.content}${A}`
  };
}
function se(n, t) {
  const { messages: e, functions: o, function_call: r } = n, i = !!(o && o.length > 0);
  let s = !1, c = 0;
  for (const a of e) {
    const d = ie(a, i, s);
    (d !== a && a.role === "system" || a.role === "system" && i && !s) && (s = !0), c += ne(d, t);
  }
  return c += 3, i && o && (c += re(o, t), e.some((a) => a.role === "system") && (c -= 4)), r && r !== "auto" && (r === "none" ? c += 1 : typeof r == "object" && r.name && (c += t(r.name) + 4)), c;
}
const ae = [
  "chat-latest",
  "chatgpt-4o-latest",
  "codex-mini-latest",
  "computer-use-preview",
  "computer-use-preview-2025-03-11",
  "daybreak-blue-latest",
  "daybreak-red-latest",
  "gpt-3.5",
  "gpt-3.5-0301",
  "gpt-3.5-turbo",
  "gpt-3.5-turbo-0125",
  "gpt-3.5-turbo-0613",
  "gpt-3.5-turbo-1106",
  "gpt-3.5-turbo-16k-0613",
  "gpt-3.5-turbo-instruct",
  "gpt-4",
  "gpt-4-0125-preview",
  "gpt-4-0314",
  "gpt-4-0613",
  "gpt-4-1106-preview",
  "gpt-4-1106-vision-preview",
  "gpt-4-32k",
  "gpt-4-turbo",
  "gpt-4-turbo-2024-04-09",
  "gpt-4-turbo-preview",
  "gpt-4.1",
  "gpt-4.1-2025-04-14",
  "gpt-4.1-mini",
  "gpt-4.1-mini-2025-04-14",
  "gpt-4.1-nano",
  "gpt-4.1-nano-2025-04-14",
  "gpt-4.5-preview",
  "gpt-4.5-preview-2025-02-27",
  "gpt-4o",
  "gpt-4o-2024-05-13",
  "gpt-4o-2024-08-06",
  "gpt-4o-2024-11-20",
  "gpt-4o-audio-preview",
  "gpt-4o-audio-preview-2024-10-01",
  "gpt-4o-audio-preview-2024-12-17",
  "gpt-4o-audio-preview-2025-06-03",
  "gpt-4o-mini",
  "gpt-4o-mini-2024-07-18",
  "gpt-4o-mini-audio-preview",
  "gpt-4o-mini-audio-preview-2024-12-17",
  "gpt-4o-mini-search-preview",
  "gpt-4o-mini-search-preview-2025-03-11",
  "gpt-4o-search-preview",
  "gpt-4o-search-preview-2025-03-11",
  "gpt-5",
  "gpt-5-2025-08-07",
  "gpt-5-chat-latest",
  "gpt-5-codex",
  "gpt-5-mini",
  "gpt-5-mini-2025-08-07",
  "gpt-5-nano",
  "gpt-5-nano-2025-08-07",
  "gpt-5-pro",
  "gpt-5-pro-2025-10-06",
  "gpt-5.1",
  "gpt-5.1-2025-11-13",
  "gpt-5.1-chat-latest",
  "gpt-5.1-codex",
  "gpt-5.1-codex-max",
  "gpt-5.1-codex-mini",
  "gpt-5.2",
  "gpt-5.2-2025-12-11",
  "gpt-5.2-chat-latest",
  "gpt-5.2-codex",
  "gpt-5.2-pro",
  "gpt-5.2-pro-2025-12-11",
  "gpt-5.3-chat-latest",
  "gpt-5.3-codex",
  "gpt-5.4",
  "gpt-5.4-2026-03-05",
  "gpt-5.4-mini",
  "gpt-5.4-mini-2026-03-17",
  "gpt-5.4-nano",
  "gpt-5.4-nano-2026-03-17",
  "gpt-5.4-pro",
  "gpt-5.4-pro-2026-03-05",
  "gpt-5.5",
  "gpt-5.5-2026-04-23",
  "gpt-5.5-pro",
  "gpt-5.5-pro-2026-04-23",
  "gpt-5.6-cyber",
  "gpt-5.6-luna",
  "gpt-5.6-sol",
  "gpt-5.6-terra",
  "gpt-audio",
  "gpt-audio-1.5",
  "gpt-audio-2025-08-28",
  "gpt-audio-mini",
  "gpt-audio-mini-2025-10-06",
  "gpt-audio-mini-2025-12-15",
  "gpt-image-1",
  "gpt-oss-120b",
  "gpt-oss-20b",
  "o1",
  "o1-2024-12-17",
  "o1-mini",
  "o1-mini-2024-09-12",
  "o1-preview",
  "o1-preview-2024-09-12",
  "o1-pro",
  "o1-pro-2025-03-19",
  "o3",
  "o3-2025-04-16",
  "o3-deep-research",
  "o3-deep-research-2025-06-26",
  "o3-mini",
  "o3-mini-2025-01-31",
  "o3-pro",
  "o3-pro-2025-06-10",
  "o4-mini",
  "o4-mini-2025-04-16",
  "o4-mini-deep-research",
  "o4-mini-deep-research-2025-06-26"
];
var G = Object.defineProperty, ce = (n, t) => {
  let e = {};
  for (var o in n) G(e, o, {
    get: n[o],
    enumerable: !0
  });
  return G(e, Symbol.toStringTag, { value: "Module" }), e;
}, de = /* @__PURE__ */ ce({
  cl100k_base: () => ue,
  gpt2: () => he,
  o200k_base: () => fe,
  o200k_harmony: () => me,
  p50k_base: () => pe,
  p50k_edit: () => ge,
  r50k_base: () => le
});
const he = ["gpt2", "gpt-2"], pe = [
  "text-davinci-002",
  "text-davinci-003",
  "code-davinci-001",
  "code-davinci-002",
  "davinci-codex",
  "code-cushman-001",
  "code-cushman-002",
  "cushman-codex"
], le = [
  "text-ada-001",
  "text-babbage-001",
  "text-curie-001",
  "text-davinci-001",
  "ada",
  "babbage",
  "curie",
  "davinci",
  "code-search-ada-code-001",
  "code-search-ada-text-001",
  "text-similarity-ada-001",
  "text-search-ada-doc-001",
  "text-search-ada-query-001",
  "text-similarity-babbage-001",
  "text-search-babbage-doc-001",
  "text-search-babbage-query-001",
  "code-search-babbage-code-001",
  "code-search-babbage-text-001",
  "text-similarity-curie-001",
  "text-search-curie-doc-001",
  "text-search-curie-query-001",
  "text-similarity-davinci-001",
  "text-search-davinci-doc-001",
  "text-search-davinci-query-001"
], ge = ["code-davinci-edit-001", "text-davinci-edit-001"], ue = [
  "gpt-3.5",
  "gpt-3.5-0301",
  "gpt-3.5-turbo",
  "gpt-3.5-turbo-0125",
  "gpt-3.5-turbo-0613",
  "gpt-3.5-turbo-1106",
  "gpt-3.5-turbo-16k-0613",
  "gpt-3.5-turbo-instruct",
  "gpt-4",
  "gpt-4-0125-preview",
  "gpt-4-0314",
  "gpt-4-0613",
  "gpt-4-1106-preview",
  "gpt-4-1106-vision-preview",
  "gpt-4-32k",
  "gpt-4-turbo",
  "gpt-4-turbo-2024-04-09",
  "gpt-4-turbo-preview",
  "text-embedding-3-large",
  "text-embedding-3-small",
  "text-embedding-ada-002",
  "babbage-002",
  "davinci-002"
], fe = [], me = ["gpt-oss-20b", "gpt-oss-120b"], ye = Object.fromEntries(Object.entries(de).flatMap(([n, t]) => t.map((e) => [e, n]))), be = {
  messageSeparator: `
`,
  roleSeparator: `
`
}, ke = {
  messageSeparator: "",
  roleSeparator: S
}, Ee = Object.fromEntries(ae.flatMap((n) => n.startsWith("gpt-3.5") ? [[n, be]] : [[n, ke]])), R = new RegExp("'s|'t|'re|'ve|'m|'ll|'d| ?\\p{L}+| ?\\p{N}+| ?[^\\s\\p{L}\\p{N}]+|\\s+(?!\\S)|\\s+", "gu"), V = String.raw`'(?:[sS]|[dD]|[mM]|[tT]|[lL][lL]|[vV][eE]|[rR][eE])`, L = String.raw`(?:${V})?`, Te = String.raw`${V}|[^\r\n\p{L}\p{N}]?\p{L}+|\p{N}{1,3}| ?[^\s\p{L}\p{N}]+[\r\n]*|\s+$|\s*[\r\n]|\s+(?!\S)|\s`, Se = new RegExp(Te, "gu"), we = String.raw`[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]*[\p{Ll}\p{Lm}\p{Lo}\p{M}]+${L}|[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]+[\p{Ll}\p{Lm}\p{Lo}\p{M}]*${L}|\p{N}{1,3}| ?[^\s\p{L}\p{N}]+[\r\n/]*|\s*[\r\n]+|\s+(?!\S)|\s+`, q = new RegExp(we, "gu");
function ve(n) {
  return {
    tokenSplitRegex: Se,
    bytePairRankDecoder: n,
    specialTokensEncoder: /* @__PURE__ */ new Map([
      [l, 100257],
      [k, 100258],
      [E, 100259],
      [T, 100260],
      [_, 100264],
      [P, 100265],
      [S, 100266],
      [w, 100276]
    ])
  };
}
const Ce = [
  [l, 199999],
  [k, 2e5],
  [E, 200001],
  [T, 200002],
  [_, 200003],
  [P, 200004],
  [S, 200005],
  [w, 200006]
], xe = () => new Map(Ce);
function _e(n) {
  return {
    tokenSplitRegex: q,
    bytePairRankDecoder: n,
    specialTokensEncoder: xe()
  };
}
const Pe = 200013, Re = 201088, Ne = [
  [W, 199998],
  [l, 199999],
  ["<|reserved_200000|>", 2e5],
  ["<|reserved_200001|>", 200001],
  [K, 200002],
  [H, 200003],
  ["<|reserved_200004|>", 200004],
  [D, 200005],
  [F, 200006],
  [O, 200007],
  [$, 200008],
  ["<|reserved_200009|>", 200009],
  ["<|reserved_200010|>", 200010],
  ["<|reserved_200011|>", 200011],
  [U, 200012]
];
function Ie(n) {
  const t = new Map(Ne);
  for (let e = Pe; e < Re; e += 1) t.set(`<|reserved_${e}|>`, e);
  return t.set(w, 200018), {
    tokenSplitRegex: q,
    bytePairRankDecoder: n,
    specialTokensEncoder: t,
    chatFormatter: "harmony"
  };
}
function Me(n) {
  return {
    expectedVocabularySize: 50281,
    tokenSplitRegex: R,
    bytePairRankDecoder: n,
    specialTokensEncoder: /* @__PURE__ */ new Map([[l, 50256]])
  };
}
function Ae(n) {
  return {
    tokenSplitRegex: R,
    bytePairRankDecoder: n,
    specialTokensEncoder: /* @__PURE__ */ new Map([
      [l, 50256],
      [k, 50281],
      [E, 50282],
      [T, 50283]
    ])
  };
}
function Ge(n) {
  return {
    expectedVocabularySize: 50257,
    tokenSplitRegex: R,
    bytePairRankDecoder: n,
    specialTokensEncoder: /* @__PURE__ */ new Map([[l, 50256]])
  };
}
function B(n, t) {
  const e = t(n);
  switch (n.toLowerCase()) {
    case "gpt2":
    case "r50k_base":
      return Ge(e);
    case "p50k_base":
      return Me(e);
    case "p50k_edit":
      return Ae(e);
    case "cl100k_base":
      return ve(e);
    case "o200k_base":
      return _e(e);
    case "o200k_harmony":
      return Ie(e);
    default:
      throw new Error(`Unknown encoding name: ${n}`);
  }
}
var Fe = class x {
  static EndOfPrompt = w;
  static EndOfText = l;
  static FimMiddle = E;
  static FimPrefix = k;
  static FimSuffix = T;
  modelName;
  modelSpec;
  bytePairEncodingCoreProcessor;
  specialTokensEncoder;
  specialTokensSet;
  allSpecialTokenRegex;
  defaultSpecialTokenConfig;
  chatFormatter;
  countChatCompletionTokens;
  vocabularySize;
  constructor({ bytePairRankDecoder: t, specialTokensEncoder: e, expectedVocabularySize: o, modelName: r, modelSpec: i, chatFormatter: s, ...c }) {
    this.specialTokensEncoder = e, this.specialTokensSet = new Set(this.specialTokensEncoder.keys()), this.allSpecialTokenRegex = M(this.specialTokensSet), this.bytePairEncodingCoreProcessor = new te({
      bytePairRankDecoder: t,
      specialTokensEncoder: e,
      ...c
    }), this.defaultSpecialTokenConfig = this.processSpecialTokens();
    const a = Math.max(t.length - 1, ee(e));
    if (this.vocabularySize = this.bytePairEncodingCoreProcessor.mergeableBytePairRankCount + e.size, o !== void 0) {
      if (this.vocabularySize !== o) throw new Error("The number of mergeable tokens and special tokens must be equal to expectedVocabularySize.");
      if (a !== o - 1) throw new Error(`The model encodings are invalid. The maximum token value must be equal to expectedVocabularySize - 1. Currently ${a}, expected ${o - 1}`);
    }
    this.encode = this.encode.bind(this), this.decode = this.decode.bind(this), this.encodeGenerator = this.encodeGenerator.bind(this), this.decodeGenerator = this.decodeGenerator.bind(this), this.decodeAsyncGenerator = this.decodeAsyncGenerator.bind(this), this.decodeAsync = this.decodeAsync.bind(this), this.isWithinTokenLimit = this.isWithinTokenLimit.bind(this), this.encodeChat = this.encodeChat.bind(this), this.encodeChatGenerator = this.encodeChatGenerator.bind(this), this.countTokens = this.countTokens.bind(this), this.setMergeCacheSize = this.setMergeCacheSize.bind(this), this.clearMergeCache = this.clearMergeCache.bind(this), this.estimateCost = this.estimateCost.bind(this), i?.supported_features?.includes("function_calling") && (this.countChatCompletionTokens = this.countChatCompletionTokensInternal.bind(this)), this.modelName = r, this.modelSpec = i, this.chatFormatter = s ?? "chatml";
  }
  *encodeHarmonyChatGenerator(t, e) {
    const o = this.specialTokensEncoder.get(F), r = this.specialTokensEncoder.get($), i = this.specialTokensEncoder.get(O), s = this.specialTokensEncoder.get(K), c = this.specialTokensEncoder.get(U), a = this.specialTokensEncoder.get(D), d = this.specialTokensEncoder.get(H);
    if (o === void 0 || r === void 0 || i === void 0 || s === void 0 || c === void 0 || a === void 0 || d === void 0) throw new Error("Harmony chat format requires dedicated special tokens.");
    const p = (h) => h.length > 0 ? this.encode(h) : [], g = (h) => {
      switch (h) {
        case "<|return|>":
          return s;
        case "<|call|>":
          return c;
        default:
          return i;
      }
    };
    for (const h of t) {
      if (h.content === void 0) throw new Error("Content must be defined for all messages.");
      const v = h.name ?? h.role ?? "user";
      yield [o], yield p(v);
      const u = h.recipient && (h.recipientPlacement === "role" || !h.channel), y = h.recipient && !u;
      u && (yield p(` to=${h.recipient}`)), h.channel && (yield [a], yield p(h.channel), y && (yield p(` to=${h.recipient}`))), h.constraint && (yield [d], yield p(h.constraint)), yield [r], yield* this.encodeGenerator(h.content, e), yield [g(h.terminator)];
    }
    const f = e?.primeWithAssistantResponse ?? "assistant";
    f.length > 0 && (yield [o], yield p(f));
  }
  static getEncodingApi(t, e) {
    const o = B(t, e);
    return new x(o);
  }
  static getEncodingApiForModel(t, e, o) {
    const r = ye[t] ?? "o200k_base", i = B(r, e);
    return new x({
      ...i,
      modelName: t,
      modelSpec: o
    });
  }
  processSpecialTokens({ allowedSpecial: t, disallowedSpecial: e } = {}) {
    let o;
    if (t === "all" || t?.has("all")) {
      t = new Set(this.specialTokensSet);
      const r = t;
      if (e === "all") throw new Error('allowedSpecial and disallowedSpecial cannot both be set to "all".');
      typeof e == "object" ? e.forEach((i) => r.delete(i)) : e = /* @__PURE__ */ new Set();
    }
    if (!e || e === "all" || e.has("all")) {
      e = new Set(this.specialTokensSet);
      const r = e;
      t?.size ? (t.forEach((i) => r.delete(i)), e.forEach((i) => t.delete(i)), e.size > 0 && (o = M(e))) : o = this.allSpecialTokenRegex;
    }
    return {
      allowedSpecial: t,
      regexPattern: o
    };
  }
  encodeGenerator(t, e) {
    const o = e ? this.processSpecialTokens(e) : this.defaultSpecialTokenConfig;
    if (o.regexPattern) {
      const r = t.match(o.regexPattern);
      if (r !== null) throw new Error(`Disallowed special token found: ${r[0]}`);
    }
    return this.bytePairEncodingCoreProcessor.encodeNativeGenerator(t, o.allowedSpecial);
  }
  encode(t, e) {
    const o = e ? this.processSpecialTokens(e) : this.defaultSpecialTokenConfig;
    if (o.regexPattern) {
      const r = t.match(o.regexPattern);
      if (r !== null) throw new Error(`Disallowed special token found: ${r[0]}`);
    }
    return this.bytePairEncodingCoreProcessor.encodeNative(t, o.allowedSpecial);
  }
  /**
  * Progressively tokenizes an OpenAI chat.
  * Warning: gpt-3.5-turbo and gpt-4 chat format may change over time.
  * Returns tokens assuming the 'gpt-3.5-turbo-0301' / 'gpt-4-0314' format.
  * Based on OpenAI's guidelines: https://github.com/openai/openai-python/blob/main/chatml.md
  * Also mentioned in section 6 of this document: https://github.com/openai/openai-cookbook/blob/main/examples/How_to_count_tokens_with_tiktoken.ipynb
  * @param encodeOptions Options controlling how special tokens are handled.
  */
  *encodeChatGenerator(t, e = this.modelName, o) {
    if (!e) throw new Error("Model name must be provided either during initialization or passed in to the method.");
    const r = Ee[e];
    if (!r) throw new Error(`Model '${e}' does not support chat.`);
    if (this.chatFormatter === "harmony") {
      yield* this.encodeHarmonyChatGenerator(t, o);
      return;
    }
    const i = this.specialTokensEncoder.get(_), s = this.specialTokensEncoder.get(P);
    if (i === void 0 || s === void 0) throw new Error(`Model '${e}' does not support chat.`);
    const c = /* @__PURE__ */ new Set([S]), { messageSeparator: a, roleSeparator: d } = r, p = a.length > 0 ? this.encode(a) : [], g = d.length > 0 ? this.encode(d, { allowedSpecial: c }) : [], f = /* @__PURE__ */ new Map();
    for (const { role: v = "system", name: u = v, content: y } of t) {
      if (y === void 0) throw new Error("Content must be defined for all messages.");
      yield [i];
      const N = f.get(u) ?? this.encode(u);
      f.set(u, N), yield N, g.length > 0 && (yield g), yield* this.encodeGenerator(y, o), yield [s], yield p;
    }
    const h = o?.primeWithAssistantResponse ?? "assistant";
    h.length > 0 && (yield [i], yield* this.encodeGenerator(h, o)), g.length > 0 && (yield g);
  }
  /**
  * Encodes a chat into a single array of tokens.
  * Warning: gpt-3.5-turbo and gpt-4 chat format may change over time.
  * Returns tokens assuming the 'gpt-3.5-turbo-0301' / 'gpt-4-0314' format.
  * Based on OpenAI's guidelines: https://github.com/openai/openai-python/blob/main/chatml.md
  * Also mentioned in section 6 of this document: https://github.com/openai/openai-cookbook/blob/main/examples/How_to_count_tokens_with_tiktoken.ipynb
  * @param encodeOptions Options controlling how special tokens are handled.
  */
  encodeChat(t, e = this.modelName, o) {
    return [...this.encodeChatGenerator(t, e, o)].flat();
  }
  /**
  * Checks whether the provided input stays within the provided token limit.
  * @param input The string or chat messages to evaluate.
  * @param tokenLimit The maximum allowed number of tokens.
  * @param encodeOptions Options controlling how special tokens are handled.
  * @returns {false | number} false if token limit is exceeded, otherwise the number of tokens
  */
  isWithinTokenLimit(t, e, o) {
    const r = typeof t == "string" ? this.encodeGenerator(t, o) : this.encodeChatGenerator(t, void 0, o);
    let i = 0;
    for (const s of r)
      if (i += s.length, i > e) return !1;
    return i;
  }
  /**
  * Counts the number of tokens in the input.
  * @param input The string or chat messages to evaluate.
  * @param encodeOptions Options controlling how special tokens are handled.
  * @returns {number} The number of tokens.
  */
  countTokens(t, e) {
    if (typeof t == "string") {
      const i = e ? this.processSpecialTokens(e) : this.defaultSpecialTokenConfig;
      if (i.regexPattern) {
        const s = t.match(i.regexPattern);
        if (s !== null) throw new Error(`Disallowed special token found: ${s[0]}`);
      }
      return this.bytePairEncodingCoreProcessor.countNative(t, i.allowedSpecial);
    }
    const o = this.encodeChatGenerator(t, void 0, e);
    let r = 0;
    for (const i of o) r += i.length;
    return r;
  }
  countStringTokens(t) {
    return t ? this.bytePairEncodingCoreProcessor.countNative(t) : 0;
  }
  countChatCompletionTokensInternal(t) {
    return se(t, (e) => this.countStringTokens(e));
  }
  setMergeCacheSize(t) {
    this.bytePairEncodingCoreProcessor.setMergeCacheSize(t);
  }
  clearMergeCache() {
    this.bytePairEncodingCoreProcessor.clearMergeCache();
  }
  decode(t) {
    return this.bytePairEncodingCoreProcessor.decodeNative(t);
  }
  *decodeGenerator(t) {
    const e = this.bytePairEncodingCoreProcessor.decodeNativeGenerator(t);
    let o = "";
    for (const r of e)
      o += typeof r == "string" ? r : m.decode(r, { stream: !0 }), !(o.length === 0 || I(o)) && (yield o, o = "");
    o.length > 0 && (yield o);
  }
  async *decodeAsyncGenerator(t) {
    const e = this.bytePairEncodingCoreProcessor.decodeNativeAsyncIterable(t);
    let o = "";
    for await (const r of e)
      o += typeof r == "string" ? r : m.decode(r, { stream: !0 }), !(o.length === 0 || I(o)) && (yield o, o = "");
    o.length > 0 && (yield o);
  }
  async decodeAsync(t) {
    const e = this.bytePairEncodingCoreProcessor.decodeNativeAsyncIterable(t);
    let o = "";
    for await (const r of e) o += typeof r == "string" ? r : m.decode(r, { stream: !0 });
    return o;
  }
  /**
  * Estimates the cost of processing a given token count using the model's pricing.
  *
  * @param tokenCount - The number of tokens to estimate cost for
  * @returns Cost estimate object with applicable price components (input, output, batchInput, batchOutput)
  */
  estimateCost(t, e = this.modelSpec) {
    if (!e) throw new Error("Model spec must be provided either during initialization or passed in to the method.");
    if (!e.price_data) throw new Error(`No cost information available for model: ${e.name}`);
    const o = e.price_data, r = {}, i = t / 1e6;
    return o.main && (r.main = {
      input: o.main.input && o.main.input * i,
      output: o.main.output && o.main.output * i,
      cached_input: o.main.cached_input && o.main.cached_input * i,
      cached_output: o.main.cached_output && o.main.cached_output * i
    }), o.batch && (r.batch = {
      input: o.batch.input && o.batch.input * i,
      output: o.batch.output && o.batch.output * i,
      cached_input: o.batch.cached_input && o.batch.cached_input * i,
      cached_output: o.batch.cached_output && o.batch.cached_output * i
    }), r;
  }
};
export {
  Le as A,
  Be as D,
  w as E,
  E as F,
  Fe as G,
  U as H,
  P as I,
  l as a,
  k as b,
  T as c,
  D as d,
  H as e,
  O as f,
  $ as g,
  K as h,
  F as i,
  W as j,
  S as k,
  _ as l
};
